package com.blackcode.core;

import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Iterator;

import javax.imageio.ImageIO;
import javax.imageio.ImageReadParam;
import javax.imageio.ImageReader;
import javax.imageio.stream.ImageInputStream;


final public class FileConvertor {
	
	public static byte[] convertFileToByteArray(String fileName){
		FileInputStream fileInputStream=null;
		 
        File file = new File(fileName);
 
        byte[] bFile = new byte[(int) file.length()];
 
        try {
            //convert file into array of bytes
		    fileInputStream = new FileInputStream(file);
		    fileInputStream.read(bFile);
		    fileInputStream.close();
	 
		    /*for (int i = 0; i < bFile.length; i++) {
		       	System.out.print((char)bFile[i]);
	         }*/
		    
		    return bFile;
        }catch(Exception e){
        	e.printStackTrace();
        	return null;
        }
	}
	
	public static File convertByteArrayToFile(byte[] bFile, String newFileName){
        try {
        	File imageFile = new File(newFileName);
        	FileOutputStream fileOuputStream = 	new FileOutputStream(imageFile); 
		    fileOuputStream.write(bFile);
		    fileOuputStream.close();
		    
		    return imageFile;
        }catch(Exception e){
            e.printStackTrace();
            return null;
        }
	}
	
	public static Image convertByteArrayToImage(byte[] bytes){
		ByteArrayInputStream bis = new ByteArrayInputStream(bytes);
        Iterator<?> readers = ImageIO.getImageReadersByFormatName("png");
        
        try{
	        ImageReader reader = (ImageReader) readers.next();
	        Object source = bis; 
	        ImageInputStream iis = ImageIO.createImageInputStream(source); 
	        reader.setInput(iis, true);
	        ImageReadParam param = reader.getDefaultReadParam();
	 
	        Image image = reader.read(0, param);
	        //got an image file
	 
	        BufferedImage bufferedImage = new BufferedImage(image.getWidth(null), image.getHeight(null), BufferedImage.TYPE_INT_RGB);
	        //bufferedImage is the RenderedImage to be written
	 
	        Graphics2D g2 = bufferedImage.createGraphics();
	        g2.drawImage(image, null, null);
	 
	        File imageFile = new File("C:\\ProgramData\\BlackCodeCRM\tmp.png");
	        ImageIO.write(bufferedImage, "png", imageFile);
	        
	        return image;
        }catch(Exception e){
        	e.printStackTrace();
        	return null;
        }
	}
	
	public static File convertInputStreamToFile(InputStream is, String filename){
		try{
			File file = new File("C:\\ProgramData\\BlackCodeCRM\\"+filename);
			FileOutputStream fileOuputStream = 	new FileOutputStream(file); 
			byte[] buffer = new byte[1024];
	        int bytesRead;
	        while((bytesRead = is.read(buffer)) !=-1){
	        	fileOuputStream.write(buffer, 0, bytesRead);
	        }
	        is.close();
	        fileOuputStream.flush();
		    fileOuputStream.close();
		    
		    return file;
		}catch(Exception e){
        	e.printStackTrace();
        	return null;
        }
		
	}
	
	public static void copyFile(String source, String dest, String name){
		InputStream inStream = null;
		OutputStream outStream = null;
	 
	    try{	    	
	    	File sourcefile = new File(source);
	    	if(name == null)
	    		name = sourcefile.getName();
	    	File destfile = new File(dest+"\\"+name);
	 
	    	inStream = new FileInputStream(sourcefile);
	    	outStream = new FileOutputStream(destfile);
	 
	    	byte[] buffer = new byte[1024];
	 
	    	int length;
	    	while ((length = inStream.read(buffer)) > 0){	 
	    		outStream.write(buffer, 0, length);	 
	    	}
	 
	    	inStream.close();
	    	outStream.close();
	    }catch(IOException e){
	        e.printStackTrace();
	    }
	}
	
	public static int[] getImageDimension(String filename){
		File imageFile = new File(filename);
		//double bytes = imageFile.length();
		//System.out.println("File Size: " + String.format("%.2f", bytes/1024) + "kb");

		try{
		    BufferedImage image = ImageIO.read(imageFile);		    
		    return new int[]{image.getWidth(), image.getHeight()};
		} catch (Exception ex){
		    ex.printStackTrace();
		    return new int[]{0, 0};
		}
	}
	
}
