package com.blackcode.core;

import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

final public class CalendarUtil {
	
	public static int calculateAgaingInYear(int year, int month, int date){
		Calendar cal = new GregorianCalendar(year, month, date);
	    Calendar now = new GregorianCalendar();
	    int res = now.get(Calendar.YEAR) - cal.get(Calendar.YEAR);
	    if ((cal.get(Calendar.MONTH) > now.get(Calendar.MONTH))|| (cal.get(Calendar.MONTH) == now.get(Calendar.MONTH) 
	    		&& cal.get(Calendar.DAY_OF_MONTH) > now.get(Calendar.DAY_OF_MONTH))) {
	    	res--;
	    }
	    
	    return res;
	}
	
	public static int calculateDiffInDay(Date newerDate, Date olderDate){
		int diffInDays = (int)( (newerDate.getTime() - olderDate.getTime()) / (1000 * 60 * 60 * 24) );
		
		return diffInDays;
	}
}
