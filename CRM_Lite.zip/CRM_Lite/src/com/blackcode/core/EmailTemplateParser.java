package com.blackcode.core;

import java.io.File;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;

public class EmailTemplateParser {
	public static String getLayout(File file){
		try{
			DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
			Document doc = docBuilder.parse(file);
			
			Node template = doc.getElementsByTagName("template").item(0);
			NamedNodeMap attr = template.getAttributes();		
			return attr.getNamedItem("layout").getTextContent();
		}catch(Exception e){
			return null;
		}
	}
	
	
	
	
}
