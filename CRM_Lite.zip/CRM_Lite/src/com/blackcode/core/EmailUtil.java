package com.blackcode.core;

import java.io.File;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.BodyPart;
import javax.mail.Folder;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.NoSuchProviderException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Store;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.jface.operation.IRunnableWithProgress;

import com.blackcode.model.EmailController;
import com.sun.mail.imap.protocol.FLAGS;

public class EmailUtil implements IRunnableWithProgress{
	private static final int TOTAL_TIME = 10000;
	private int INCREMENT = 500;
	private boolean indeterminate;
	private int action;
	private EmailController controller;
	private List<String> recipientList = new ArrayList<String>();
	
	public class ACTIONS{
		public final static int SEND = 0;
		public final static int RECEIVE = 1;
		public final static int LOAD = 2;
	}
	public EmailUtil (int action, EmailController controller){
		this.action = action;
		this.controller = controller;
	}
	
	public void run(IProgressMonitor monitor) throws InvocationTargetException, InterruptedException {
		switch(action){
		case 0:
			String taskname = "";
			if(controller.getRecipients() != null){
				for(int i=0; i<controller.getRecipients().size(); i++)
					recipientList.add(controller.getRecipients().get(i).getEmails());
				taskname = "Sending email to group ..";
			}else if(controller.getToRecipient() != null){
				recipientList.add(controller.getToRecipient());
				taskname = "Sending email ..";
			}
			
			INCREMENT = TOTAL_TIME / (recipientList.size()+1);
			monitor.beginTask(taskname, TOTAL_TIME);
			sending(monitor);
			monitor.done();
			
			if (monitor.isCanceled())
			      throw new InterruptedException("Email Sending Failed.");
			break;
		
		case 1:
			monitor.beginTask("Receiving emails", TOTAL_TIME);
			receiving(monitor);
			monitor.done();
			
			if (monitor.isCanceled())
			      throw new InterruptedException("Email Sending Failed.");
			break;
			
		default:
			monitor.beginTask("Running long running operation", indeterminate ? IProgressMonitor.UNKNOWN  : TOTAL_TIME);
			for (int total = 0; total < TOTAL_TIME && !monitor.isCanceled(); total += INCREMENT) {
			      Thread.sleep(INCREMENT);
			      monitor.worked(INCREMENT);
			      if (total == TOTAL_TIME / 2)
			        monitor.subTask("Doing second half");
			}
			monitor.done();
			
			if (monitor.isCanceled())
			      throw new InterruptedException("Operation Cancallation");
		}
	}
	
	private void sending(IProgressMonitor monitor){
		try {
			Thread.sleep(INCREMENT);	  
			monitor.subTask("Email Authentication");
			Properties props = new Properties();
		    props.put("mail.smtp.auth", true);
		    props.put("mail.smtp.starttls.enable", true);
		    props.put("mail.smtp.host", controller.getEmailAccount().getOutgoingMailServer());
	    
		    Session session = Session.getInstance(props,
		    		new javax.mail.Authenticator() {
		                protected PasswordAuthentication getPasswordAuthentication() {
		                    return new PasswordAuthentication(controller.getEmailAccount().getEmailId(), controller.getEmailAccount().getEmailPassword());
		                }
		            });
		    monitor.worked(INCREMENT);
	   
		    Folder savefolder = null;
	    	for(int z=0; z<recipientList.size(); z++){
	    		Thread.sleep(INCREMENT);
			      
	    		MimeMessage message = new MimeMessage(session);
		        message.setFrom(new InternetAddress(controller.getEmailAccount().getEmailId()));
		        message.addRecipients(Message.RecipientType.TO, InternetAddress.parse(recipientList.get(z)));
		        if(controller.getCCRecipient() != null && controller.getCCRecipient().length() > 0)
		        message.addRecipients(Message.RecipientType.CC, InternetAddress.parse(controller.getCCRecipient()));
		        message.setSubject(controller.getEmailSubject());
		                
		        Multipart multipart = new MimeMultipart();	       
		         
		        // Fill the message
		        BodyPart messageBodyPart = new MimeBodyPart();	 
		        messageBodyPart.setContent(controller.getEmailContent(),"text/html");
		        multipart.addBodyPart(messageBodyPart);

		        BodyPart messagefooterPart = new MimeBodyPart();
	        	messagefooterPart.setContent("</br></br><font size='1'><p align='center'>Neither the information, nor any opinion contained in this site, constitutes a solicitation</br>"
	        		+ "or offer by us to buy or to sell any securities, futures, options or other financial instruments</br>"
	        		+ "or to provide any investment advice or service. We do not provide advice concerning the suitability</br>"
	        		+ "or value of any particular investment in securities, futures or options</br>"
	        		+ "or regarding any investment strategy."
	        		+ "</p></font>", "text/html");
	        	multipart.addBodyPart(messagefooterPart);
		        
		         // Attachment
	        	if(controller.getEmailAttachments() != null){
	        		for(int i=0; i<controller.getEmailAttachments().size(); i++){		    			    		
			    		File file = controller.getEmailAttachments().get(i);
			    		BodyPart attachmentPart = new MimeBodyPart();
				        DataSource source = new FileDataSource(file);
				        attachmentPart.setDataHandler(new DataHandler(source));
				        attachmentPart.setFileName(file.getName());
				        multipart.addBodyPart(attachmentPart);
			    	}
	        	}		    	
	        	
	        	monitor.subTask("Sending to "+recipientList.get(z));
		        
		    	// Picture in content
		    	 /*if(original==null && house.getLogoFile() != null){
	        	BodyPart messageheaderPart = new MimeBodyPart();
	        	messageheaderPart.setContent("</br></br><img src='cid:icon'/>", "text/html");
	        	multipart.addBodyPart(messageheaderPart);
	        	
	        	MimeBodyPart iconBodyPart = new MimeBodyPart();
	        	DataSource iconDataSource = new FileDataSource(new File(house.getLogoFile()));
	        	iconBodyPart.setDataHandler(new DataHandler(iconDataSource));
	        	iconBodyPart.setDisposition(Part.INLINE);
	        	iconBodyPart.setContentID("<icon>");
	        	iconBodyPart.addHeader("Content-Type", "image/png");
	        	multipart.addBodyPart(iconBodyPart);
	        }*/
		    	
		        /*if(originalContent != null && type.equalsIgnoreCase("Forward"))
		        	multipart.addBodyPart(originalContent);*/
		        
		         // Send the complete message parts
		        message.setContent(multipart);
		        Transport.send(message);
		        
		        //Save sent email
		        if(savefolder == null){
		        	Store store = (Store) session.getStore("imaps");
					store.connect(controller.getEmailAccount().getIncomingMailServer(), controller.getEmailAccount().getEmailId(), controller.getEmailAccount().getEmailPassword());

			        savefolder = (Folder) store.getFolder("INBOX").getFolder("Sent");
			        if (!savefolder.exists()) {
			            savefolder.create(Folder.HOLDS_MESSAGES);
			        }
			        savefolder.open(Folder.READ_WRITE);
		        }		        
		        savefolder.appendMessages(new Message[]{message});
		        message.setFlag(FLAGS.Flag.RECENT, true);
		        
		        monitor.worked(INCREMENT);
	    	}
	        
	    } catch (MessagingException e) {
	    	monitor.setCanceled(true);
	        e.printStackTrace();
	    } catch (Exception e) {
	    	monitor.setCanceled(true);
	        e.printStackTrace();
	    }
	}
	
	private void receiving(IProgressMonitor monitor) {
		try {
			Thread.sleep(INCREMENT);
			monitor.subTask("Email Authentication");
			
			Properties properties = new Properties();
			properties.put("mail.store.protocol",  "imaps");
			Session session = Session.getDefaultInstance(properties);

			Store store = (Store) session.getStore("imaps");
			store.connect(controller.getEmailAccount().getIncomingMailServer(), controller.getEmailAccount().getEmailId(), controller.getEmailAccount().getEmailPassword());			
			monitor.worked(INCREMENT);
			
			Thread.sleep(INCREMENT);
			monitor.subTask("Refreshing folders ..");
			
			Folder rootFolder = store.getFolder("INBOX");
			rootFolder.open(Folder.READ_WRITE);
			
			monitor.worked(INCREMENT);
			
			Folder[] folders = rootFolder.list();
			INCREMENT = (TOTAL_TIME - INCREMENT - INCREMENT) / folders.length;
			for(int i=0; i<folders.length; i++){
				Thread.sleep(INCREMENT);
				Folder folder = folders[i];
				monitor.subTask("Refreshing "+folder.getName()+" ..");
				folder.open(Folder.READ_WRITE);		
				monitor.worked(INCREMENT);
			}			
			
			controller.setFolder(rootFolder);
			controller.setFolderList(folders);
			
		} catch (NoSuchProviderException e) {
			monitor.subTask(e.getMessage());
			monitor.setCanceled(true);
			e.printStackTrace();
		} catch (MessagingException e) {
			monitor.subTask(e.getMessage());
			monitor.setCanceled(true);
			e.printStackTrace();
		}catch (Exception e) {
			monitor.subTask(e.getMessage());
			monitor.setCanceled(true);
			e.printStackTrace();
		}		
	}
		
	public EmailController getController(){
		return this.controller;
	}
}
