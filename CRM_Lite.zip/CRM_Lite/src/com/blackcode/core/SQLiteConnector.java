package com.blackcode.core;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.blackcode.model.Account;
import com.blackcode.model.Contact;
import com.blackcode.model.EmailCampaign;
import com.blackcode.model.EmailCampaignRecipient;
import com.blackcode.model.FollowUpTask;
import com.blackcode.model.History;
import com.blackcode.model.Sales;

public class SQLiteConnector {
	private Connection connection;
	
	public SQLiteConnector(){		
	}
	
	public Connection getConnection(){
		try{
			Class.forName("org.sqlite.JDBC");
			connection = DriverManager.getConnection("jdbc:sqlite:C:\\ProgramData\\BlackCodeCRM\\bccrm_db");
			
			return connection;
		}catch(Exception e){
			e.printStackTrace();
			return null;
		}
	}
	
	public static String DateFormat(Date date){
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		return sdf.format(date);
	}
	
	public static Connection getMySqlConnection(String driver, String ip, String databaseName, String user, String password) throws Exception {
		try{
			Class.forName(driver);
			Connection conn = DriverManager.getConnection(ip+"/"+databaseName, user, password);
			return conn;
		}catch(Exception e){
			e.printStackTrace();
			return null;
		}
		
	}
	
	// ACCOUNT
	public List<Account> readAccount(String selectClause, String whereClause){
		Statement statement = null;
		ResultSet resultSet = null;
		List<Account> accounts = null;
		
		try{
			connection = getConnection();
			
			String sql = "FROM account";
			if(selectClause == null)
				sql = "SELECT * FROM account";
			else
				sql = "SELECT "+selectClause+" "+sql;
			if(whereClause != null)
				sql += " WHERE "+whereClause;
			
			statement = connection.createStatement();			
			resultSet = statement.executeQuery(sql);	
			accounts = new ArrayList<Account>();
			while(resultSet.next()){
				Account account = new Account(resultSet.getString(1), resultSet.getString(2), resultSet.getString(3), resultSet.getString(4),
						resultSet.getString(5), resultSet.getString(6), resultSet.getString(7), resultSet.getBytes(8), resultSet.getString(9),
						resultSet.getString(10));
				accounts.add(account);
			}
			
			return accounts;
		}catch(Exception e){
			e.printStackTrace();
			
			return accounts;			
		}finally{
			try {
				if(statement != null)
					statement.close();
				if(connection != null)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	public Object createAccount(Account account){
		Connection connection = null;
		Statement statement = null;
		PreparedStatement ps = null;
		
		try{
			connection = getConnection();
			ps = connection.prepareStatement("INSERT INTO account VALUES (?,?,?,?,?,?,?,?,?,?)");
			ps.setString(1, account.getCode());
			ps.setString(2, account.getName());
			ps.setString(3, account.getEmailId());
			ps.setString(4, account.getEmailPassword());
			ps.setString(5, account.getIncomingMailServer());
			ps.setString(6, account.getOutgoingMailServer());
			ps.setString(7, account.getEmailSignature());
			ps.setBytes(8, account.getImage());
			ps.setString(9, account.getEmailSignatureStyle());
			ps.setString(10, account.getSlogo());			
			ps.executeUpdate();	
			
			return account;
		}catch(Exception e){
			e.printStackTrace();
			return e.getMessage();
		}finally{
			try {
				if(ps != null)
					ps.close();
				if(statement != null)
					statement.close();
				if(connection != null)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	public Object updateAccount(Account account, String whereClause){
		Connection connection = null;
		Statement statement = null;
		PreparedStatement ps = null;
		
		try{
			connection = getConnection();
			String stmt = "UPDATE account SET name=?, emailId=?, emailPassword=?, incomingMailServer=?, outgoingMailServer=?, emailSignature=?, "
					+ "image=?, emailSignatureStyle=?, slogo=?";
			if(whereClause != null)
				stmt += " WHERE "+whereClause;
			else
				stmt += " WHERE code=?";
			ps = connection.prepareStatement(stmt);
			ps.setString(1, account.getName());
			ps.setString(2, account.getEmailId());
			ps.setString(3, account.getEmailPassword());
			ps.setString(4, account.getIncomingMailServer());
			ps.setString(5, account.getOutgoingMailServer());
			ps.setString(6, account.getEmailSignature());
			ps.setBytes(7, account.getImage());
			ps.setString(8, account.getEmailSignatureStyle());
			ps.setString(9, account.getSlogo());
			ps.setString(10, account.getCode());
			ps.executeUpdate();
			
			return account;
		}catch(Exception e){
			e.printStackTrace();
			return e.getMessage();
		}finally{
			try {
				if(ps != null)
					ps.close();
				if(statement != null)
					statement.close();
				if(connection != null)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	public Object deleteAccount(Account account, String whereClause){
		Connection connection = null;
		Statement statement = null;
		PreparedStatement ps = null;
		
		try{
			connection = getConnection();
			String stmt = "";
			if(whereClause != null)
				stmt = "DELETE FROM account WHERE "+whereClause;
			else
				stmt = "DELETE FROM account WHERE code='"+account.getCode()+"'";
			ps = connection.prepareStatement(stmt);
			ps.executeUpdate();
			
			return account;
		}catch(Exception e){
			e.printStackTrace();
			return e.getMessage();
		}finally{
			try {
				if(ps != null)
					ps.close();
				if(statement != null)
					statement.close();
				if(connection != null)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	//CONTACT
	public List<Contact> readContact(String selectClause, String whereClause, String orderClause){
		Statement statement = null;
		ResultSet resultSet = null;
		List<Contact> contacts = null;
		
		try{
			connection = getConnection();
			
			String sql = "FROM contact";
			if(selectClause == null)
				sql = "SELECT * FROM contact";
			else
				sql = "SELECT "+selectClause+" "+sql;
			if(whereClause != null)
				sql += " WHERE "+whereClause;
			if(orderClause != null)
				sql += " ORDER BY "+orderClause;
			
			statement = connection.createStatement();			
			resultSet = statement.executeQuery(sql);	
			contacts = new ArrayList<Contact>();
			while(resultSet.next()){
				Contact contact = new Contact(resultSet.getString(1), resultSet.getString(2), resultSet.getString(3), resultSet.getString(4),
						resultSet.getString(5), resultSet.getString(6), resultSet.getString(7), resultSet.getString(8), resultSet.getString(9),
						resultSet.getString(10), resultSet.getString(11), resultSet.getString(12), resultSet.getString(13), resultSet.getString(14),
						resultSet.getString(15),resultSet.getString(16),resultSet.getString(17), resultSet.getString(18),resultSet.getString(19),
						resultSet.getString(20),resultSet.getString(21),resultSet.getString(22),resultSet.getString(23), resultSet.getString(24),
						resultSet.getString(25), resultSet.getString(26), resultSet.getString(27), resultSet.getDate(28), resultSet.getBoolean(29),
						resultSet.getBytes(30), resultSet.getString(31), resultSet.getTimestamp(32), resultSet.getTimestamp(33),resultSet.getString(34));
				contacts.add(contact);
			}
									
			return contacts;
		}catch(Exception e){
			e.printStackTrace();
			
			return contacts;			
		}finally{
			try {
				if(statement != null)
					statement.close();
				if(connection != null)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	public Object createContact(Contact contact){
		Connection connection = null;
		Statement statement = null;
		PreparedStatement ps = null;
			
		try{
			connection = getConnection();
			ps = connection.prepareStatement("INSERT INTO contact VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
			ps.setString(1, contact.getContactId());
			ps.setString(2, contact.getAccountId());			
			ps.setString(3, contact.getJobTitle());
			ps.setString(4, contact.getCompany());
			ps.setString(5, contact.getTitle());
			ps.setString(6, contact.getFirstName());
			ps.setString(7, contact.getMiddleName());
			ps.setString(8, contact.getLastName());
			ps.setString(9, contact.getNickName());
			ps.setString(10, contact.getHomePhone());		
			ps.setString(11, contact.getMobile());
			ps.setString(12, contact.getWorkPhone());
			ps.setString(13, contact.getAltPhone());
			ps.setString(14, contact.getHomeFax());
			ps.setString(15, contact.getWorkFax());
			ps.setString(16, contact.getPersonalEmail());
			ps.setString(17, contact.getWorkEmail());
			ps.setString(18, contact.getOtherEmail());
			ps.setString(19, contact.getHomeAddress());
			ps.setString(20, contact.getWorkAddress());
			ps.setString(21, contact.getMailingAddress());
			ps.setString(22, contact.getGender());
			ps.setString(23, contact.getGroups());
			ps.setString(24, contact.getNotes());
			ps.setString(25, contact.getSocialNetworks());
			ps.setString(26, contact.getCustomFields());
			ps.setString(27, contact.getDateFields());
			if(contact.getDob() != null)
				ps.setDate(28,  new java.sql.Date(contact.getDob().getTime()));
			else
				ps.setDate(28,  null);
			ps.setBoolean(29, contact.isFlag());
			ps.setBytes(30, contact.getPhoto());
			ps.setString(31, contact.getCreatedBy());
			ps.setTimestamp(32, contact.getCreatedOn());
			ps.setTimestamp(33, contact.getUpdatedOn());
			ps.setString(34, contact.getLastUpdate());
			ps.executeUpdate();	
			
			return contact;
		}catch(Exception e){
			e.printStackTrace();
			return e.getMessage();
		}finally{
			try {
				if(ps != null)
					ps.close();
				if(statement != null)
					statement.close();
				if(connection != null)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	public Object updateContact(Contact contact, String whereClause){
		Connection connection = null;
		Statement statement = null;
		PreparedStatement ps = null;
					
		try{
			connection = getConnection();
			String stmt = "UPDATE contact SET accountId=?, jobTitle=?, company=?, title=?, firstName=?, middleName=?, lastName=?, nickName=?, homePhone=?, "
					+ "mobile=?, workPhone=?, altPhone=?, homeFax=?, workFax=?, personalEmail=?, workEmail=?, otherEmail=?, homeAddress=?, workAddress=?, "
					+ "mailingAddress=?, gender=?, groups=?, notes=?, socialNetworks=?, customFields=?, dateFields=?, dob=?, flag=?, photo=?, updatedOn=?, "
					+ "lastUpdate=?";
			if(whereClause != null)
				stmt += " WHERE "+whereClause;
			else
				stmt += " WHERE contactId=?";
			ps = connection.prepareStatement(stmt);
			ps.setString(1, contact.getAccountId());
			ps.setString(2, contact.getJobTitle());
			ps.setString(3, contact.getCompany());
			ps.setString(4, contact.getTitle());
			ps.setString(5, contact.getFirstName());
			ps.setString(6, contact.getMiddleName());
			ps.setString(7, contact.getLastName());
			ps.setString(8, contact.getNickName());
			ps.setString(9, contact.getHomePhone());
			ps.setString(10, contact.getMobile());
			ps.setString(11, contact.getWorkPhone());
			ps.setString(12, contact.getAltPhone());
			ps.setString(13, contact.getHomeFax());
			ps.setString(14, contact.getWorkFax());
			ps.setString(15, contact.getPersonalEmail());
			ps.setString(16, contact.getWorkEmail());
			ps.setString(17, contact.getOtherEmail());
			ps.setString(18, contact.getHomeAddress());
			ps.setString(19, contact.getWorkAddress());
			ps.setString(20, contact.getMailingAddress());
			ps.setString(21, contact.getGender());
			ps.setString(22, contact.getGroups());
			ps.setString(23, contact.getNotes());
			ps.setString(24, contact.getSocialNetworks());
			ps.setString(25, contact.getCustomFields());
			ps.setString(26, contact.getDateFields());			
			if(contact.getDob() != null)
				ps.setDate(27,  new java.sql.Date(contact.getDob().getTime()));
			else
				ps.setDate(27,  null);
			ps.setBoolean(28, contact.isFlag());
			ps.setBytes(29, contact.getPhoto());
			ps.setTimestamp(30, contact.getUpdatedOn());
			ps.setString(31, contact.getLastUpdate());
			ps.setString(32, contact.getContactId());
			ps.executeUpdate();
						
			return contact;
		}catch(Exception e){
			e.printStackTrace();
			return e.getMessage();
		}finally{
			try {
				if(ps != null)
					ps.close();
				if(statement != null)
					statement.close();
				if(connection != null)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	public Object updateContactFlag(Contact contact, String whereClause){
		Connection connection = null;
		Statement statement = null;
		PreparedStatement ps = null;
					
		try{
			connection = getConnection();
			String stmt = "UPDATE contact SET flag=?";
			if(whereClause != null)
				stmt += " WHERE "+whereClause;
			else
				stmt += " WHERE contactId=?";
			ps = connection.prepareStatement(stmt);
			ps.setBoolean(1, contact.isFlag());
			ps.setString(2, contact.getContactId());
			ps.executeUpdate();
			
			return contact;
		}catch(Exception e){
			e.printStackTrace();
			return e.getMessage();
		}finally{
			try {
				if(ps != null)
					ps.close();
				if(statement != null)
					statement.close();
				if(connection != null)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	public Object deleteContact(Contact contact, String whereClause){
		Connection connection = null;
		Statement statement = null;
		PreparedStatement ps = null;
		
		try{
			connection = getConnection();
			String stmt = "DELETE FROM contact WHERE contactId='"+contact.getContactId()+"'";
			if(whereClause != null)
				stmt = "DELETE FROM contact WHERE "+whereClause;
			ps = connection.prepareStatement(stmt);
			ps.executeUpdate();
			
			History history = new History(0, contact.getCreatedOn(), "Contact", contact.getContactId(), contact.getFullName(), "Delete New Contact", contact.getCreatedBy(), null);
			createHistory(history);
			
			return contact;
		}catch(Exception e){
			e.printStackTrace();
			return e.getMessage();
		}finally{
			try {
				if(ps != null)
					ps.close();
				if(statement != null)
					statement.close();
				if(connection != null)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	//Followup Task
	public List<FollowUpTask> readTask(String selectClause, String whereClause, String orderClause){
		Statement statement = null;
		ResultSet resultSet = null;
		List<FollowUpTask> tasks = null;
		
		try{
			connection = getConnection();
			
			String sql = "FROM FollowUpTask";
			if(selectClause == null)
				sql = "SELECT * FROM FollowUpTask";
			else
				sql = "SELECT "+selectClause+" "+sql;
			if(whereClause != null)
				sql += " WHERE "+whereClause;
			if(orderClause != null)
				sql += " ORDER BY "+orderClause;
			
			statement = connection.createStatement();			
			resultSet = statement.executeQuery(sql);	
			tasks = new ArrayList<FollowUpTask>();
			while(resultSet.next()){
				FollowUpTask task = new FollowUpTask(resultSet.getLong(1), resultSet.getString(2), resultSet.getString(3), resultSet.getDate(4),
						resultSet.getString(5), resultSet.getString(6), resultSet.getString(7), resultSet.getString(8), resultSet.getBoolean(9),
						resultSet.getBoolean(10), resultSet.getInt(11), resultSet.getString(12), resultSet.getString(13), resultSet.getTimestamp(14));
				tasks.add(task);
			}
									
			return tasks;
		}catch(Exception e){
			e.printStackTrace();
			
			return tasks;			
		}finally{
			try {
				if(statement != null)
					statement.close();
				if(connection != null)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	public Object createTask(FollowUpTask task){
		Connection connection = null;
		Statement statement = null;
		PreparedStatement ps = null;
		
		try{
			connection = getConnection();
			ps = connection.prepareStatement("INSERT INTO FollowUpTask (contactId, contactName, date, time, type, subject, notes, "
					+ "privateTag, highImportanceTag, reminder, shareWith, createdBy, createdOn) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)");
			ps.setString(1, task.getContactId());
			ps.setString(2, task.getContactName());
			if(task.getDate() != null)
				ps.setDate(3, new java.sql.Date(task.getDate().getTime()));
			else
				ps.setString(3, null);
			ps.setString(4, task.getTime());
			ps.setString(5, task.getType());
			ps.setString(6, task.getSubject());
			ps.setString(7, task.getNotes());
			ps.setBoolean(8, task.isPrivateTag());
			ps.setBoolean(9, task.isHighImportanceTag());
			ps.setInt(10, task.getReminder());		
			ps.setString(11, task.getShareWith());
			ps.setString(12, task.getCreatedBy());
			ps.setTimestamp(13, task.getCreatedOn());
			ps.executeUpdate();	
			
			ResultSet rs = ps.getGeneratedKeys();
		    rs.next();
		    task.setId(rs.getInt(1));
			
			return task;
		}catch(Exception e){
			e.printStackTrace();
			return e.getMessage();
		}finally{
			try {
				if(ps != null)
					ps.close();
				if(statement != null)
					statement.close();
				if(connection != null)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	public Object updateTask(FollowUpTask task, String whereClause){
		Connection connection = null;
		Statement statement = null;
		PreparedStatement ps = null;					
		
		try{
			connection = getConnection();
			String stmt = "UPDATE FollowUpTask SET contactId=?, contactName=?, date=?, time=?, type=?, subject=?, notes=?, privateTag=?, highImportanceTag=?, "
					+ "reminder=?, shareWith=?, createdBy=?, createdOn=?";
			if(whereClause != null)
				stmt += " WHERE "+whereClause;
			else
				stmt += " WHERE id=?";
			ps = connection.prepareStatement(stmt);
			ps.setString(1, task.getContactId());
			ps.setString(2, task.getContactName());
			if(task.getDate() != null)
				ps.setDate(3, new java.sql.Date(task.getDate().getTime()));
			else
				ps.setDate(3, null);
			ps.setString(4, task.getTime());
			ps.setString(5, task.getType());
			ps.setString(6, task.getSubject());
			ps.setString(7, task.getNotes());
			ps.setBoolean(8, task.isPrivateTag());
			ps.setBoolean(9, task.isHighImportanceTag());
			ps.setInt(10, task.getReminder());
			ps.setString(11, task.getShareWith());
			ps.setString(12, task.getCreatedBy());
			ps.setTimestamp(13, task.getCreatedOn());
			ps.setLong(14, task.getId());
			ps.executeUpdate();
			
			return task;
		}catch(Exception e){
			e.printStackTrace();
			return e.getMessage();
		}finally{
			try {
				if(ps != null)
					ps.close();
				if(statement != null)
					statement.close();
				if(connection != null)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
		
	public Object deleteTask(FollowUpTask task, String whereClause){
		Connection connection = null;
		Statement statement = null;
		PreparedStatement ps = null;
		
		try{
			connection = getConnection();
			String stmt = "";
			if(whereClause != null)
				stmt = "DELETE FROM FollowUpTask WHERE "+whereClause;
			else
				stmt = "DELETE FROM followuptask WHERE id="+task.getId();
			ps = connection.prepareStatement(stmt);
			ps.executeUpdate();
			
			return task;
		}catch(Exception e){
			e.printStackTrace();
			return e.getMessage();
		}finally{
			try {
				if(ps != null)
					ps.close();
				if(statement != null)
					statement.close();
				if(connection != null)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	//Email Campaign
	public List<EmailCampaign> readEmailCampaign(String selectClause, String whereClause, String orderClause){
		Statement statement = null;
		ResultSet resultSet = null;
		List<EmailCampaign> campaigns = null;
		
		try{
			connection = getConnection();
			
			String sql = "FROM emailcampaign";
			if(selectClause == null)
				sql = "SELECT * FROM emailcampaign";
			else
				sql = "SELECT "+selectClause+" "+sql;
			if(whereClause != null)
				sql += " WHERE "+whereClause;
			if(orderClause != null)
				sql += " ORDER BY "+orderClause;
			
			statement = connection.createStatement();			
			resultSet = statement.executeQuery(sql);	
			campaigns = new ArrayList<EmailCampaign>();
						
			while(resultSet.next()){
				EmailCampaign campaign = new EmailCampaign(resultSet.getLong(1), resultSet.getString(2), resultSet.getString(3), resultSet.getString(4),resultSet.getString(5),
						resultSet.getString(6), resultSet.getTimestamp(7), resultSet.getTimestamp(8), resultSet.getTimestamp(9), resultSet.getString(10),resultSet.getString(11),
						resultSet.getString(12), resultSet.getBoolean(13), resultSet.getString(14), resultSet.getTimestamp(15));
				campaign.setRecipients(readEmailRecipient(null, "campaignId="+campaign.getId(), null));
				campaigns.add(campaign);
				
			}
									
			return campaigns;
		}catch(Exception e){
			e.printStackTrace();
			
			return campaigns;			
		}finally{
			try {
				if(statement != null)
					statement.close();
				if(connection != null)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	public Object createEmailCampaign(EmailCampaign campaign){
		Connection connection = null;
		Statement statement = null;
		PreparedStatement ps = null;
		
		try{
			connection = getConnection();
			ps = connection.prepareStatement("INSERT INTO emailcampaign (name, emailAccount, sendByName, emailSubject, sendByEmailId, dateTime1, dateTime2, dateTime3,"
					+ "template1, template2, template3, active, createdBy, createdOn) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
			ps.setString(1, campaign.getName());
			ps.setString(2, campaign.getEmailAccount());
			ps.setString(3, campaign.getSendByName());
			ps.setString(4, campaign.getEmailSubject());
			ps.setString(5, campaign.getSendByEmailId());
			ps.setTimestamp(6, campaign.getDateTime1());
			ps.setTimestamp(7, campaign.getDateTime2());
			ps.setTimestamp(8, campaign.getDateTime3());
			ps.setString(9, campaign.getTemplate1());
			ps.setString(10, campaign.getTemplate2());
			ps.setString(11, campaign.getTemplate3());
			ps.setBoolean(12, campaign.isActive());
			ps.setString(13, campaign.getCreatedBy());		
			ps.setTimestamp(14, campaign.getCreatedOn());
			ps.executeUpdate();	
			
			ResultSet rs = ps.getGeneratedKeys();
		    rs.next();
		    campaign.setId(rs.getInt(1));
		    
			return campaign;
		}catch(Exception e){
			e.printStackTrace();
			return e.getMessage();
		}finally{
			try {
				if(ps != null)
					ps.close();
				if(statement != null)
					statement.close();
				if(connection != null)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	public Object updateEmailCampaign(EmailCampaign campaign, String whereClause){
		Connection connection = null;
		Statement statement = null;
		PreparedStatement ps = null;					
		
		try{
			connection = getConnection();
			String stmt = "UPDATE emailcampaign SET name=?, emailsubject=?, emailAccount=?, sendByName=?, sendByEmailId=?, dateTime1=?, dateTime2=?, dateTime3=?,"
					+ "template1=?, template2=?, template2=?, active=?";
			if(whereClause != null)
				stmt += " WHERE "+whereClause;
			else
				stmt += " WHERE id=?";
			ps = connection.prepareStatement(stmt);
			ps.setString(1, campaign.getName());
			ps.setString(2, campaign.getEmailSubject());
			ps.setString(3, campaign.getEmailAccount());
			ps.setString(4, campaign.getSendByName());
			ps.setString(5, campaign.getSendByEmailId());
			ps.setTimestamp(6, campaign.getDateTime1());
			ps.setTimestamp(7, campaign.getDateTime2());
			ps.setTimestamp(8, campaign.getDateTime3());
			ps.setString(9, campaign.getTemplate1());
			ps.setString(10, campaign.getTemplate2());
			ps.setString(11, campaign.getTemplate3());
			ps.setBoolean(12, campaign.isActive());
			ps.setLong(13, campaign.getId());
			ps.executeUpdate();
			
			return campaign;
		}catch(Exception e){
			e.printStackTrace();
			return e.getMessage();
		}finally{
			try {
				if(ps != null)
					ps.close();
				if(statement != null)
					statement.close();
				if(connection != null)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
		
	public Object deleteEmailCampaign(EmailCampaign campaign, String whereClause){
		Connection connection = null;
		Statement statement = null;
		PreparedStatement ps = null;
		
		try{
			deleteEmailRecipient(null, "campaignId="+campaign.getId());
			connection = getConnection();
			String stmt = "";
			if(whereClause != null)
				stmt = "DELETE FROM emailcampaign WHERE "+whereClause;
			else
				stmt = "DELETE FROM emailcampaign WHERE id="+campaign.getId();
			ps = connection.prepareStatement(stmt);
			ps.executeUpdate();
			
			return campaign;
		}catch(Exception e){
			e.printStackTrace();
			return e.getMessage();
		}finally{
			try {
				if(ps != null)
					ps.close();
				if(statement != null)
					statement.close();
				if(connection != null)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	//Recipient
	public List<EmailCampaignRecipient> findEmailRecipient(String selectClause, String whereClause, String orderClause, long campaign){
		Statement statement = null;
		ResultSet resultSet = null;
		List<EmailCampaignRecipient> recipients = null;
		
		try{
			connection = getConnection();
			
			String sql = "FROM contact";
			if(selectClause == null)
				sql = "SELECT contactId, firstName, lastName, personalEmail, workEmail, otherEmail FROM contact";
			else
				sql = "SELECT "+selectClause+" "+sql;
			sql = sql+" WHERE contactId NOT IN (SELECT contactId from emailcampaignrecipient WHERE campaignId="+campaign+")";
			if(whereClause != null)
				sql += " AND ("+whereClause+")";
			if(orderClause != null)
				sql += " ORDER BY "+orderClause;
			
			statement = connection.createStatement();			
			resultSet = statement.executeQuery(sql);	
			recipients = new ArrayList<EmailCampaignRecipient>();
			while(resultSet.next()){
				String name = "";
				if(resultSet.getString(2) != null)
					name += resultSet.getString(2);
				if(resultSet.getString(3) != null)
					name += " "+resultSet.getString(3);
				
				String emails = "";
				if(resultSet.getString(4) != null)
					emails = resultSet.getString(4)+",";
				if(resultSet.getString(5) != null)
					emails += resultSet.getString(5)+",";
				if(resultSet.getString(6) != null)
					emails += resultSet.getString(6)+",";
				if(emails.endsWith(","))
					emails = emails.substring(0, emails.length()-1);
				
				EmailCampaignRecipient recipient = new EmailCampaignRecipient();
				recipient.setCampaignId(campaign);
				recipient.setContactId(resultSet.getString(1));
				recipient.setContactName(name);
				recipient.setEmailId(emails);
				recipient.setStatus("Pending");
				
				Object obj = createEmailRecipient(recipient);
				if(obj instanceof EmailCampaignRecipient)
					recipients.add((EmailCampaignRecipient)obj);
			}
									
			return recipients;
		}catch(Exception e){
			e.printStackTrace();
			
			return recipients;			
		}finally{
			try {
				if(statement != null)
					statement.close();
				if(connection != null)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	public List<EmailCampaignRecipient> readEmailRecipient(String selectClause, String whereClause, String orderClause){
		Statement statement = null;
		ResultSet resultSet = null;
		List<EmailCampaignRecipient> recipients = null;
		
		try{
			connection = getConnection();
			
			String sql = "FROM emailcampaignrecipient";
			if(selectClause == null)
				sql = "SELECT * FROM emailcampaignrecipient";
			else
				sql = "SELECT "+selectClause+" "+sql;
			if(whereClause != null)
				sql += " WHERE "+whereClause;
			if(orderClause != null)
				sql += " ORDER BY "+orderClause;
			
			statement = connection.createStatement();			
			resultSet = statement.executeQuery(sql);	
			recipients = new ArrayList<EmailCampaignRecipient>();
			while(resultSet.next()){
				EmailCampaignRecipient recipient = new EmailCampaignRecipient(resultSet.getLong(1), resultSet.getLong(2), resultSet.getString(3), resultSet.getString(4),
						resultSet.getString(5), resultSet.getTimestamp(6), resultSet.getTimestamp(7), resultSet.getString(8));
				recipients.add(recipient);
			}
									
			return recipients;
		}catch(Exception e){
			e.printStackTrace();
			
			return recipients;			
		}finally{
			try {
				if(statement != null)
					statement.close();
				if(connection != null)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	public Object createEmailRecipient(EmailCampaignRecipient recipient){
		Connection connection = null;
		Statement statement = null;
		PreparedStatement ps = null;
		
		try{
			List<EmailCampaignRecipient> col = readEmailRecipient(null, "campaignId="+recipient.getCampainId()+" AND contactId='"+recipient.getContactId()+"'", null);
			if(col.size()>0){
				return "Already in recipient list";
			}
			
			connection = getConnection();
			ps = connection.prepareStatement("INSERT INTO emailcampaignrecipient (campaignId, emailId, contactId, contactName, sentDateTime, replyDateTime, status) "
					+ "VALUES (?,?,?,?,?,?,?)");
			ps.setLong(1, recipient.getCampainId());
			ps.setString(2, recipient.getEmailId());
			ps.setString(3, recipient.getContactId());
			ps.setString(4, recipient.getContactName());
			ps.setTimestamp(5, recipient.getSentDateTime());
			ps.setTimestamp(6, recipient.getReplyDateTime());
			ps.setString(7, recipient.getStatus());
			ps.executeUpdate();	
			
			ResultSet rs = ps.getGeneratedKeys();
		    rs.next();
		    recipient.setId(rs.getInt(1));
		    
			return recipient;
		}catch(Exception e){
			e.printStackTrace();
			return e.getMessage();
		}finally{
			try {
				if(ps != null)
					ps.close();
				if(statement != null)
					statement.close();
				if(connection != null)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	public Object updateEmailRecipient(EmailCampaignRecipient recipient, String whereClause){
		Connection connection = null;
		Statement statement = null;
		PreparedStatement ps = null;					
				
		try{
			connection = getConnection();
			String stmt = "UPDATE emailcampaignrecipient SET campaignId=?, emailId=?, contactId=?, contactName=?, sentDateTime=?, replyDateTime=?, status=?";
			if(whereClause != null)
				stmt += " WHERE "+whereClause;
			else
				stmt += " WHERE id=?";
			ps = connection.prepareStatement(stmt);
			ps.setLong(1, recipient.getCampainId());
			ps.setString(2, recipient.getEmailId());
			ps.setString(3, recipient.getContactId());
			ps.setString(4, recipient.getContactName());
			ps.setTimestamp(5, recipient.getSentDateTime());
			ps.setTimestamp(6, recipient.getReplyDateTime());
			ps.setString(7, recipient.getStatus());
			ps.setLong(8, recipient.getId());
			ps.executeUpdate();
			
			return recipient;
		}catch(Exception e){
			e.printStackTrace();
			return e.getMessage();
		}finally{
			try {
				if(ps != null)
					ps.close();
				if(statement != null)
					statement.close();
				if(connection != null)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
		
	public Object deleteEmailRecipient(EmailCampaignRecipient recipient, String whereClause){
		Connection connection = null;
		Statement statement = null;
		PreparedStatement ps = null;
		
		try{
			connection = getConnection();
			String stmt = "";
			if(whereClause != null)
				stmt = "DELETE FROM emailcampaignrecipient WHERE "+whereClause;
			else
				stmt = "DELETE FROM emailcampaignrecipient WHERE id="+recipient.getId();
			ps = connection.prepareStatement(stmt);
			ps.executeUpdate();
			
			return recipient;
		}catch(Exception e){
			e.printStackTrace();
			return e.getMessage();
		}finally{
			try {
				if(ps != null)
					ps.close();
				if(statement != null)
					statement.close();
				if(connection != null)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	//History
	public List<History> readHistory(String selectClause, String whereClause, String orderClause){
		Statement statement = null;
		ResultSet resultSet = null;
		List<History> histories = null;
		
		try{
			connection = getConnection();
			
			String sql = "FROM history";
			if(selectClause == null)
				sql = "SELECT * FROM history";
			else
				sql = "SELECT "+selectClause+" "+sql;
			if(whereClause != null)
				sql += " WHERE "+whereClause;
			if(orderClause != null)
				sql += " ORDER BY "+orderClause;
			
			statement = connection.createStatement();			
			resultSet = statement.executeQuery(sql);	
			histories = new ArrayList<History>();			
			while(resultSet.next()){
				History history = new History(resultSet.getLong(1), resultSet.getTimestamp(2), resultSet.getString(3), resultSet.getString(4),
						resultSet.getString(5), resultSet.getString(6), resultSet.getString(7), resultSet.getString(8));
				histories.add(history);
			}
									
			return histories;
		}catch(Exception e){
			e.printStackTrace();
			
			return histories;			
		}finally{
			try {
				if(statement != null)
					statement.close();
				if(connection != null)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	public Object createHistory(History history){
		Connection connection = null;
		Statement statement = null;
		PreparedStatement ps = null;
		
		try{
			connection = getConnection();			
			ps = connection.prepareStatement("INSERT INTO history (logDateTime, type, contactId, contactName, subject, createdBy, notes) "
					+ "VALUES (?,?,?,?,?,?,?)");
			ps.setTimestamp(1, history.getLogDateTime());
			ps.setString(2, history.getType());
			ps.setString(3, history.getContactId());
			ps.setString(4, history.getContactName());
			ps.setString(5, history.getSubject());
			ps.setString(6, history.getCreatedBy());
			ps.setString(7, history.getNotes());
			ps.executeUpdate();	
			
			ResultSet rs = ps.getGeneratedKeys();
		    rs.next();
		    history.setId(rs.getInt(1));
		    
			return history;
		}catch(Exception e){
			e.printStackTrace();
			return e.getMessage();
		}finally{
			try {
				if(ps != null)
					ps.close();
				if(statement != null)
					statement.close();
				if(connection != null)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	public Object updateHistory(History history, String whereClause){
		Connection connection = null;
		Statement statement = null;
		PreparedStatement ps = null;					
						
		try{
			connection = getConnection();
			String stmt = "UPDATE history SET logDateTime=?, type=?, contactId=?, contactName=?, subject=?, createdBy=?, notes=?";
			if(whereClause != null)
				stmt += " WHERE "+whereClause;
			else
				stmt += " WHERE id=?";
			ps = connection.prepareStatement(stmt);
			ps.setTimestamp(1, history.getLogDateTime());
			ps.setString(2, history.getType());
			ps.setString(3, history.getContactId());
			ps.setString(4, history.getContactName());
			ps.setString(5, history.getSubject());
			ps.setString(6, history.getCreatedBy());
			ps.setString(7, history.getNotes());
			ps.setLong(8,  history.getId());
			ps.executeUpdate();
			
			return history;
		}catch(Exception e){
			e.printStackTrace();
			return e.getMessage();
		}finally{
			try {
				if(ps != null)
					ps.close();
				if(statement != null)
					statement.close();
				if(connection != null)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
		
	public Object deleteHistory(History history, String whereClause){
		Connection connection = null;
		Statement statement = null;
		PreparedStatement ps = null;
		
		try{
			connection = getConnection();
			String stmt = "";
			if(whereClause != null)
				stmt = "DELETE FROM history WHERE "+whereClause;
			else
				stmt = "DELETE FROM history WHERE id="+history.getId();
			ps = connection.prepareStatement(stmt);
			ps.executeUpdate();
			
			return history;
		}catch(Exception e){
			e.printStackTrace();
			return e.getMessage();
		}finally{
			try {
				if(ps != null)
					ps.close();
				if(statement != null)
					statement.close();
				if(connection != null)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	//sales
	public List<Sales> readSales(String selectClause, String whereClause, String orderClause){
		Statement statement = null;
		ResultSet resultSet = null;
		List<Sales> sales = null;
		
		try{
			connection = getConnection();
			
			String sql = "FROM sales";
			if(selectClause == null)
				sql = "SELECT * FROM sales";
			else
				sql = "SELECT "+selectClause+" "+sql;
			if(whereClause != null)
				sql += " WHERE "+whereClause;
			if(orderClause != null)
				sql += " ORDER BY "+orderClause;
			
			statement = connection.createStatement();			
			resultSet = statement.executeQuery(sql);	
			sales = new ArrayList<Sales>();			
			while(resultSet.next()){
				Sales sale = new Sales(resultSet.getLong(1), resultSet.getString(2), resultSet.getString(3), resultSet.getDate(4),resultSet.getString(5), resultSet.getString(6), 
						new BigDecimal(resultSet.getDouble(7)), new BigDecimal(resultSet.getDouble(8)), new BigDecimal(resultSet.getDouble(9)), new BigDecimal(resultSet.getDouble(10)), 
						new BigDecimal(resultSet.getDouble(11)),new BigDecimal(resultSet.getDouble(12)),
						resultSet.getString(13), resultSet.getDate(14), resultSet.getString(15), resultSet.getString(16), resultSet.getString(17));
				sales.add(sale);
			}
									
			return sales;
		}catch(Exception e){
			e.printStackTrace();
			
			return sales;			
		}finally{
			try {
				if(statement != null)
					statement.close();
				if(connection != null)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	public Object createSales(Sales sales){
		Connection connection = null;
		Statement statement = null;
		PreparedStatement ps = null;
		
		try{
			connection = getConnection();			
			ps = connection.prepareStatement("INSERT INTO sales (RefNo, Type, Date, Item, UOM, Volume, Price, Charge1, Charge2, Amount, Cleared, Status, StatusDate, Salesman, Customer, Remark) "
					+ "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
			ps.setString(1, sales.getRefNo());
			ps.setString(2, sales.getType());
			if(sales.getDate() != null)
				ps.setDate(3,  new java.sql.Date(sales.getDate().getTime()));
			else
				ps.setDate(3,  null);
			ps.setString(4, sales.getItem());
			ps.setString(5, sales.getUom());
			ps.setDouble(6, sales.getVolume()==null?0:sales.getVolume().doubleValue());
			ps.setDouble(7, sales.getPrice()==null?0:sales.getPrice().doubleValue());
			ps.setDouble(8, sales.getCharge1()==null?0:sales.getCharge1().doubleValue());
			ps.setDouble(9, sales.getCharge2()==null?0:sales.getCharge2().doubleValue());
			ps.setDouble(10, sales.getAmount()==null?0:sales.getAmount().doubleValue());
			ps.setDouble(11, sales.getCleared()==null?0:sales.getCleared().doubleValue());
			ps.setString(12, sales.getStatus());
			if(sales.getStatusDate() != null)
				ps.setDate(13, new java.sql.Date(sales.getStatusDate().getTime()));
			else
				ps.setDate(13, null);
			ps.setString(14, sales.getSaleman());
			ps.setString(15, sales.getCustomer());
			ps.setString(16, sales.getRemark());
			ps.executeUpdate();	
			
			ResultSet rs = ps.getGeneratedKeys();
		    rs.next();
		    sales.setId(rs.getInt(1));
			return sales;
		}catch(Exception e){
			e.printStackTrace();
			return e.getMessage();
		}finally{
			try {
				if(ps != null)
					ps.close();
				if(statement != null)
					statement.close();
				if(connection != null)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	public Object updateSales(Sales sales, String whereClause){
		Connection connection = null;
		Statement statement = null;
		PreparedStatement ps = null;		
						
		try{
			connection = getConnection();
			String stmt = "UPDATE sales SET RefNo=?, Type=?, Date=?, Item=?, UOM=?, Volume=?, Price=?, Charge1=?, Charge2=?, Amount=?, Status=?, StatusDate=?, Salesman=?, Customer=?, Remark=?, Cleared=?";
			if(whereClause != null)
				stmt += " WHERE "+whereClause;
			else
				stmt += " WHERE id=?";
			ps = connection.prepareStatement(stmt);
			ps.setString(1, sales.getRefNo());
			ps.setString(2, sales.getType());
			if(sales.getDate() != null)
				ps.setDate(3,  new java.sql.Date(sales.getDate().getTime()));
			else
				ps.setDate(3,  null);
			ps.setString(4, sales.getItem());
			ps.setString(5, sales.getUom());
			ps.setDouble(6, sales.getVolume()==null?0:sales.getVolume().doubleValue());
			ps.setDouble(7, sales.getPrice()==null?0:sales.getPrice().doubleValue());
			ps.setDouble(8, sales.getCharge1()==null?0:sales.getCharge1().doubleValue());
			ps.setDouble(9, sales.getCharge2()==null?0:sales.getCharge2().doubleValue());
			ps.setDouble(10, sales.getAmount()==null?0:sales.getAmount().doubleValue());
			ps.setString(11, sales.getStatus());
			if(sales.getStatusDate() != null)
				ps.setDate(12, new java.sql.Date(sales.getStatusDate().getTime()));
			else
				ps.setDate(12, null);
			ps.setString(13, sales.getSaleman());
			ps.setString(14, sales.getCustomer());
			ps.setString(15, sales.getRemark());
			ps.setDouble(16, sales.getCleared()==null?0:sales.getCleared().doubleValue());
			ps.setLong(17,  sales.getId());
			ps.executeUpdate();
			
			return sales;
		}catch(Exception e){
			e.printStackTrace();
			return e.getMessage();
		}finally{
			try {
				if(ps != null)
					ps.close();
				if(statement != null)
					statement.close();
				if(connection != null)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
		
	public Object deleteSales(Sales sales, String whereClause){
		Connection connection = null;
		Statement statement = null;
		PreparedStatement ps = null;
		
		try{
			connection = getConnection();
			String stmt = "";
			if(whereClause != null)
				stmt = "DELETE FROM sales WHERE "+whereClause;
			else
				stmt = "DELETE FROM sales WHERE id="+sales.getId();
			ps = connection.prepareStatement(stmt);
			ps.executeUpdate();
			
			return sales;
		}catch(Exception e){
			e.printStackTrace();
			return e.getMessage();
		}finally{
			try {
				if(ps != null)
					ps.close();
				if(statement != null)
					statement.close();
				if(connection != null)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	//Group Sales Data
	public List<Object[]> GroupSalesData(List<Contact> contacts, String saleCondition, List<Date[]> periods){
		Statement statement = null;
		ResultSet resultSet = null;
		
		try{
			connection = getConnection();
			
			List<Object[]> dataCol = new ArrayList<Object[]>();
			for(int i=0; i<contacts.size(); i++){
				Contact contact = contacts.get(i);
				String sql = "SELECT * FROM sales WHERE Customer='"+contact.getContactId()+"'";
				
				if(saleCondition != null && saleCondition.length() > 0)
					sql += " AND "+saleCondition;
				sql += " ORDER BY date desc";
				
				statement = connection.createStatement();			
				resultSet = statement.executeQuery(sql);	
				List<Sales> salesCol = new ArrayList<Sales>();
				String lastSaleDate = null; BigDecimal totalAmt = new BigDecimal(0); int totalSales=0;
				BigDecimal[] cellAmtValues = new BigDecimal[periods.size()];
				int[] cellTotalValues = new int[periods.size()];
				while(resultSet.next()){				
					Sales sale = new Sales(resultSet.getLong(1), resultSet.getString(2), resultSet.getString(3), resultSet.getDate(4),resultSet.getString(5), resultSet.getString(6), 
							new BigDecimal(resultSet.getDouble(7)), new BigDecimal(resultSet.getDouble(8)), new BigDecimal(resultSet.getDouble(9)), new BigDecimal(resultSet.getDouble(10)), 
							new BigDecimal(resultSet.getDouble(11)), new BigDecimal(resultSet.getDouble(12)),
							resultSet.getString(13), resultSet.getDate(14), resultSet.getString(15), resultSet.getString(16), resultSet.getString(17));
					salesCol.add(sale);
					
					for(int z=0; z<periods.size(); z++){
						if(sale.getDate() != null && sale.getDate().compareTo(periods.get(z)[0]) >=0 && sale.getDate().compareTo(periods.get(z)[1])<=0){
							if(sale.getAmount() != null){
								BigDecimal amt = cellAmtValues[z]==null?new BigDecimal(0):cellAmtValues[z];
								cellAmtValues[z] = amt.add(sale.getAmount());
							}
							int total = cellTotalValues[z];
							cellTotalValues[z] = total+1;
							break;
						}
					}
					
					if(lastSaleDate == null && sale.getDate() != null)
						lastSaleDate = DateFormat(sale.getDate());
					if(sale.getAmount() != null)
					totalAmt = totalAmt.add(sale.getAmount());
					totalSales++;
				}
				
				if(salesCol.size() >0)
					dataCol.add(new Object[]{contact, lastSaleDate, totalAmt, totalSales, cellAmtValues, cellTotalValues, salesCol});
			}		
			
			return dataCol;
		}catch(Exception e){
			e.printStackTrace();
			return null;
		}finally{
			try {
				if(statement != null)
					statement.close();
				if(connection != null)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	//Inactive contacts
	public List<Contact> readInactiveContact(int day, String sql){
		Statement statement = null;
		
		try{
			List<Contact> dataCol = new ArrayList<Contact>();
			List<Contact> contacts = readContact(null, sql, "contactId");		
			List<History> logs = readHistory(null, "DATEDIFF(CURDATE(), DATE(logDateTime)) < "+day+" GROUP BY contactId", null);
			
			a:
			for(int i=0; i<contacts.size(); i++){
				for(int j=0; j<logs.size(); j++){
					if(logs.get(j).getContactId().equalsIgnoreCase(contacts.get(i).getContactId()))
						continue a;
				}
				
				dataCol.add(contacts.get(i));
			}
			
			return dataCol;
		}catch(Exception e){
			e.printStackTrace();
			return null;
		}finally{
			try {
				if(statement != null)
					statement.close();
				if(connection != null)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	public List<Object[]> InactiveSalesData(List<Contact> contacts, int day, List<Date[]> periods){
		Statement statement = null;
		ResultSet resultSet = null;
		
		try{
			connection = getConnection();
			
			List<Object[]> dataCol = new ArrayList<Object[]>();
			a:
			for(int i=0; i<contacts.size(); i++){
				Contact contact = contacts.get(i);
				String sql = "SELECT * FROM sales WHERE Customer='"+contact.getContactId()+"' ORDER BY date desc";
				
				statement = connection.createStatement();			
				resultSet = statement.executeQuery(sql);	
				List<Sales> salesCol = new ArrayList<Sales>();
				String lastSaleDate = null; BigDecimal totalAmt = new BigDecimal(0); int totalSales=0;
				BigDecimal[] cellAmtValues = new BigDecimal[periods.size()];
				int[] cellTotalValues = new int[periods.size()];
				while(resultSet.next()){				
					Sales sale = new Sales(resultSet.getLong(1), resultSet.getString(2), resultSet.getString(3), resultSet.getDate(4),resultSet.getString(5), resultSet.getString(6), 
							new BigDecimal(resultSet.getDouble(7)), new BigDecimal(resultSet.getDouble(8)), new BigDecimal(resultSet.getDouble(9)), new BigDecimal(resultSet.getDouble(10)), 
							new BigDecimal(resultSet.getDouble(11)), new BigDecimal(resultSet.getDouble(12)),
							resultSet.getString(13), resultSet.getDate(14), resultSet.getString(15), resultSet.getString(16), resultSet.getString(17));
					salesCol.add(sale);
					
					//Check last sales gap
					if(totalSales==0){
						int gap = CalendarUtil.calculateDiffInDay(new Date(), sale.getDate());
						if(gap < day)
							continue a;
					}
					
					for(int z=0; z<periods.size(); z++){
						if(sale.getDate() != null && sale.getDate().compareTo(periods.get(z)[0]) >=0 && sale.getDate().compareTo(periods.get(z)[1])<=0){
							if(sale.getAmount() != null){
								BigDecimal amt = cellAmtValues[z]==null?new BigDecimal(0):cellAmtValues[z];
								cellAmtValues[z] = amt.add(sale.getAmount());
							}
							int total = cellTotalValues[z];
							cellTotalValues[z] = total+1;
							break;
						}
					}
					
					if(lastSaleDate == null && sale.getDate() != null)
						lastSaleDate = DateFormat(sale.getDate());
					if(sale.getAmount() != null)
					totalAmt = totalAmt.add(sale.getAmount());
					totalSales++;
				}
				
				if(salesCol.size() >0)
					dataCol.add(new Object[]{contact, lastSaleDate, totalAmt, totalSales, cellAmtValues, cellTotalValues, salesCol});
			}		
			
			return dataCol;
		}catch(Exception e){
			e.printStackTrace();
			return null;
		}finally{
			try {
				if(statement != null)
					statement.close();
				if(connection != null)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	public int MinYearOfSales(){
		Statement statement = null;
		ResultSet resultSet = null;
		
		try{
			connection = getConnection();
			
			statement = connection.createStatement();	
			resultSet = statement.executeQuery("SELECT min(strftime('%Y', date(Date / 1000, 'unixepoch', 'localtime'))) FROM sales");	
			int year=-1;
			while(resultSet.next()){
				year = resultSet.getInt(1);
			}
			
			return year;
		}catch(Exception e){
			e.printStackTrace();
			return -1;
		}finally{
			try {
				if(statement != null)
					statement.close();
				if(connection != null)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	public List<Object[]> CallPlanHelper(int planDay, int salesDay, String event, String eventMonth){
		Statement statement = null;
		ResultSet resultSet = null;
		
		try{
			connection = getConnection();
			
			String notIncludeContact = "";
			
			//Call History
			if(planDay > 0){
				Statement stmt1 = connection.createStatement();			
				resultSet = stmt1.executeQuery("SELECT contactId FROM followuptask "
						+ "WHERE type='Call' AND contactId IS NOT NULL AND julianday(date('now'))-julianday(date(Date / 1000, 'unixepoch', 'localtime')) <"+planDay+" "
						+ "GROUP BY contactId ORDER BY date");
				while(resultSet.next())
					notIncludeContact += "'"+resultSet.getString(1)+"',";
			}
			
			//Sales History
			if(salesDay > 0){
				Statement stmt2 = connection.createStatement();
				resultSet = stmt2.executeQuery("SELECT Customer FROM sales "
						+ "WHERE Customer IS NOT NULL AND julianday(date('now'))-julianday(date(Date / 1000, 'unixepoch', 'localtime')) <"+salesDay+" "
						+ "GROUP BY Customer ORDER BY date");
				while(resultSet.next())
					notIncludeContact += "'"+resultSet.getString(1)+"',";
			}
			
			//Find matching contacts
			if(notIncludeContact.endsWith(","))
				notIncludeContact = notIncludeContact.substring(0, notIncludeContact.length()-1);
			String sql = "";
			if(notIncludeContact.length() > 0 )
				sql = "contactId NOT IN ("+notIncludeContact+")";
			if(event != null && event.equalsIgnoreCase("dob") && eventMonth!=null){
				if(sql.length() > 0)
					sql += "AND ";
				
				sql += "strftime('%m', date(dob / 1000, 'unixepoch', 'localtime'))='"+eventMonth+"'";
			}
			if(sql.length()==0)
				sql = null;
			
			connection = getConnection();
			statement = connection.createStatement();
			
			List<Object[]> dataCol = new ArrayList<Object[]>();
			List<Contact> contacts = readContact(null, sql, null);
			for(int i=0; i<contacts.size(); i++){
				Object[] data = new Object[3];				
				Contact contact = contacts.get(i);
				data[0] = contact;
				
				boolean skip = false;
				if(event != null && event.equalsIgnoreCase("all") && eventMonth!=null){
					skip = true;
					if(contact.getDateFields() != null){
						String[] dates = contact.getDateFields().split("&#44");
						for(int z=0; z<dates.length; z++){
							String[] tmp = dates[z].split("&#47");
							if(tmp[1].substring(3,5).equals(eventMonth)){
								skip = false;
								break;
							}
						}			
					}
				}
				
				if(skip)
					continue;
				
				ResultSet rs1 = statement.executeQuery("SELECT MAX(date) FROM followuptask WHERE type='Call' AND contactId='"+contact.getContactId()+"'");
				while(rs1.next())
					data[1] = rs1.getDate(1)!=null?new SimpleDateFormat("EEEE, dd-MMM-yyyy").format(rs1.getDate(1)):null;
				
				ResultSet rs2 = statement.executeQuery("SELECT MAX(Date) FROM sales WHERE customer='"+contact.getContactId()+"'");
				while(rs2.next())
					data[2] = rs2.getDate(1)!=null?new SimpleDateFormat("EEEE, dd-MMM-yyyy").format(rs2.getDate(1)):null;		
				
				dataCol.add(data);
			}
			
			return dataCol;
		}catch(Exception e){
			e.printStackTrace();
			return null;
		}finally{
			try {
				if(statement != null)
					statement.close();
				if(connection != null)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
}
