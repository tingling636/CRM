package com.blackcode.model;

import java.io.Serializable;
import java.sql.Timestamp;

public class History implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private long id;
	private Timestamp logDateTime;
	private String type;
	private String contactId;
	private String contactName;
	private String subject;
	private String createdBy;
	private String notes;
	
	public History(){		
	}
	
	public History(long id, Timestamp logDateTime, String type, String contactId, String contactName, String subject, String createdBy, String notes){
		this.id = id;
		this.logDateTime = logDateTime;
		this.type = type;
		this.contactId = contactId;
		this.contactName = contactName;
		this.subject = subject;
		this.createdBy = createdBy;
		this.notes = notes;
	}
	
	public History(Timestamp logDateTime, String type, String contactId, String contactName, String subject, String followUpBy){
		this.logDateTime = logDateTime;
		this.type = type;
		this.contactId = contactId;
		this.contactName = contactName;
		this.subject = subject;
		this.createdBy = followUpBy;
	}
	
	public long getId(){
		return this.id;
	}
	public void setId(long id){
		this.id = id;
	}
	
	public Timestamp getLogDateTime(){
		return this.logDateTime;
	}
	public void setLogDateTime(Timestamp logDateTime){
		this.logDateTime = logDateTime;
	}
	
	public String getType(){
		return this.type;
	}
	public void setType(String type){
		this.type = type;
	}
	
	public String getContactId(){
		return this.contactId;
	}
	public void setContactId(String contactId){
		this.contactId = contactId;
	}
	
	public String getContactName(){
		return this.contactName;
	}
	public void setContactName(String contactName){
		this.contactName = contactName;
	}
	
	public String getSubject(){
		return this.subject;
	}
	public void setSubject(String subject){
		this.subject = subject;
	}
	
	public String getCreatedBy(){
		return this.createdBy;
	}
	public void setCreatedBy(String createdBy){
		this.createdBy = createdBy;
	}
	
	public String getNotes(){
		return this.notes;
	}
	public void setNotes(String notes){
		this.notes = notes;
	}
	
}
