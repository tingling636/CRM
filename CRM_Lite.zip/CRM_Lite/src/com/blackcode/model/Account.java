package com.blackcode.model;

import java.io.Serializable;

public class Account implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String code;
	private String name;
	private String emailId;
	private String emailPassword;
	private String incomingMailServer;
	private String outgoingMailServer;
	private String emailSignature;
	private byte[] image;
	private String emailSignatureStyle;
	private String slogo;
	
	public class SORT_BY{
		final static String ACCOUNT = "ACCOUNT";
		final static String NAME = "NAME";
		final static String CONTACT_ID = "CONTACT_ID";
	}
	
	public class VIEW_AS{
		final static String NAME = "NAME";
		final static String CONTACT_ID = "CONTACT_ID";
		final static String TABLE_LIST = "TABLE_LIST";
	}
	
	public Account(){
		
	}
	public Account(String code, String name, String emailId, String emailPassword, String incomingMailServer, String outgoingMailServer, String emailSignature,
			byte[] image, String emailSignatureStyle, String slogo){
		this.code = code;
		this.name = name;
		this.emailId = emailId;
		this.emailPassword= emailPassword;
		this.incomingMailServer = incomingMailServer;
		this.outgoingMailServer = outgoingMailServer;
		this.emailSignature = emailSignature;
		this.image = image;
		this.emailSignatureStyle = emailSignatureStyle;
		this.slogo = slogo;
	}
	
	public String getCode(){
		return this.code;
	}
	public void setCode(String code){
		this.code = code;
	}
	
	public String getName(){
		return this.name;
	}
	public void setName(String name){
		this.name = name;
	}
	
	public String getEmailId(){
		return this.emailId;
	}
	public void setEmailId(String emailId){
		this.emailId = emailId;
	}
	
	public String getEmailPassword(){
		return this.emailPassword;
	}
	public void setEmailPassword(String emailPassword){
		this.emailPassword = emailPassword;
	}
	
	public String getIncomingMailServer(){
		return this.incomingMailServer;
	}
	public void setIncomingMailServer(String incomingMailServer){
		this.incomingMailServer = incomingMailServer;
	}
	
	public String getOutgoingMailServer(){
		return this.outgoingMailServer;
	}
	public void setOutgoingMailServer(String outgoingMailServer){
		this.outgoingMailServer = outgoingMailServer;
	}
	
	public String getEmailSignature(){
		return this.emailSignature;
	}
	public void setEmailSignature(String emailSignature){
		this.emailSignature = emailSignature;
	}
	
	public byte[]  getImage(){
		return this.image;
	}
	public void setImage(byte[]  image){
		this.image = image;
	}
	
	public String getEmailSignatureStyle(){
		return this.emailSignatureStyle;
	}
	public void setEmailSignatureStyle(String emailSignatureStyle){
		this.emailSignatureStyle = emailSignatureStyle;
	}
	
	public String getSlogo(){
		return this.slogo;
	}
	public void setSlogo(String slogo){
		this.slogo = slogo;
	}
	
}
