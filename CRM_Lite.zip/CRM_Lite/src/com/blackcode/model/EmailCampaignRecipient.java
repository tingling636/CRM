package com.blackcode.model;

import java.io.Serializable;
import java.sql.Timestamp;

public class EmailCampaignRecipient implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private long id;
	private long campaignId;
	private String emailId;
	private String contactId;
	private String contactName;
	private Timestamp sentDateTime;
	private Timestamp replyDateTime;
	private String status;
	
	public EmailCampaignRecipient(){		
	}
	public EmailCampaignRecipient(long id, long campaignId, String emailId, String contactId, String contactName, Timestamp sentDateTime, Timestamp replyDateTime, String status){
		this.id = id;
		this.campaignId = campaignId;
		this.emailId = emailId;
		this.contactId = contactId;
		this.contactName = contactName;
		this.sentDateTime = sentDateTime;
		this.replyDateTime = replyDateTime;
		this.status = status;
	}
	
	public long getId(){
		return this.id;
	}
	public void setId(long id){
		this.id = id;
	}
	
	public long getCampainId(){
		return this.campaignId;
	}
	public void setCampaignId(long campaignId){
		this.campaignId = campaignId;
	}
	
	public String getEmailId(){
		return this.emailId;
	}
	public void setEmailId(String emailId){
		this.emailId = emailId;
	}
	
	public String getContactId(){
		return this.contactId;
	}
	public void setContactId(String contactId){
		this.contactId = contactId;
	}
	
	public String getContactName(){
		return this.contactName;
	}
	public void setContactName(String name){
		this.contactName = name;
	}
	
	public Timestamp getSentDateTime(){
		return this.sentDateTime;
	}
	public void setSentDateTime(Timestamp sentDateTime){
		this.sentDateTime = sentDateTime;
	}
	
	public Timestamp getReplyDateTime(){
		return this.replyDateTime;
	}
	public void setReplyDateTime(Timestamp replyDateTime){
		this.replyDateTime = replyDateTime;
	}
	
	public String getStatus(){
		return this.status;
	}
	public void setStatus(String status){
		this.status = status;
	}
}
