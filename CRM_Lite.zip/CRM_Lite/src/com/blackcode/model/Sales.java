package com.blackcode.model;

import java.math.BigDecimal;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class Sales {
	private long id;
	private String refNo;
	private String type;
	private Date date;
	private String item;
	private String uom;
	private BigDecimal volume;
	private BigDecimal price;
	private BigDecimal charge1;
	private BigDecimal charge2;
	private BigDecimal amount;
	private BigDecimal cleared;
	private String status;
	private Date statusDate;
	private String salesman;
	private String customer;
	private String remark;	
	
	public final static String CurrencyFormat(BigDecimal number){
		if(number == null)
			return "-";
		return NumberFormat.getCurrencyInstance(Locale.US).format(number);
		
	}
	
	public final static String DateFormat(Date date){
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		if(date == null)
			return "";
		else
			return sdf.format(date);
	}
	
	
	public Sales(){
	}
	public Sales(long id, String refNo, String type, Date date, String item, String uom, BigDecimal volume, BigDecimal price, BigDecimal charge1,
			BigDecimal charge2, BigDecimal amount, BigDecimal cleared, String status, Date statusDate, String salesman, String customer, String remark){
		this.id = id;
		this.refNo = refNo;
		this.type = type;
		this.date = date;
		this.item = item;
		this.uom = uom;
		this.volume = volume;
		this.price = price;
		this.charge1 = charge1;
		this.charge2 = charge2;
		this.amount = amount;
		this.cleared = cleared;
		this.status = status;
		this.statusDate = statusDate;
		this.salesman = salesman;
		this.customer = customer;
		this.remark = remark;
	}
	
	public long getId(){
		return this.id;
	}
	public void setId(long id){
		this.id = id;
	}
	
	public String getRefNo(){
		return this.refNo;
	}
	public void setRefNo(String refNo){
		this.refNo = refNo;
	}
	
	public String getType(){
		return this.type;
	}
	public void setType(String type){
		this.type = type;
	}
	
	public Date getDate(){
		return this.date;
	}
	public void setDate(Date date){
		this.date = date;
	}
	
	public String getItem(){
		return this.item;
	}
	public void setItem(String item){
		this.item = item;
	}
	
	public String getUom(){
		return this.uom;
	}
	public void setUom(String uom){
		this.uom = uom;
	}
	
	public BigDecimal getVolume(){
		return this.volume;
	}
	public void setVolume(BigDecimal volume){
		this.volume = volume;
	}
	
	public BigDecimal getPrice(){
		return this.price;
	}
	public void setPrice(BigDecimal price){
		this.price = price;
	}
	
	public BigDecimal getCharge1(){
		return this.charge1;
	}
	public void setCharge1(BigDecimal charge1){
		this.charge1 = charge1;
	}
	
	public BigDecimal getCharge2(){
		return this.charge2;
	}
	public void setCharge2(BigDecimal charge2){
		this.charge2 = charge2;
	}
	
	public BigDecimal getAmount(){
		return this.amount;
	}
	public void setAmount(BigDecimal amount){
		this.amount = amount;
	}
	
	public BigDecimal getCleared(){
		return this.cleared;
	}
	public void setCleared(BigDecimal cleared){
		this.cleared = cleared;
	}
	
	public String getStatus(){
		return this.status;
	}
	public void setStatus(String status){
		this.status = status;
	}
	
	public Date getStatusDate(){
		return this.statusDate;
	}
	public void setStatusDate(Date statusDate){
		this.statusDate = statusDate;
	}
	
	public String getSaleman(){
		return this.salesman;
	}
	public void setSaleman(String saleman){
		this.salesman = saleman;
	}
	
	public String getCustomer(){
		return this.customer;
	}
	public void setCustomer(String customer){
		this.customer = customer;
	}
	
	public String getRemark(){
		return this.remark;
	}
	public void setRemark(String remark){
		this.remark = remark;
	}
}
