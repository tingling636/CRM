package com.blackcode.model;

import java.io.Serializable;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Contact implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String accountId;
	private String contactId;
	private String jobTitle;
	private String company;
	private String title;
	private String firstName;
	private String middleName;
	private String lastName;
	private String nickName;
	private String homePhone;
	private String mobile;
	private String workPhone;
	private String altPhone;
	private String homeFax;
	private String workFax;
	private String personalEmail;
	private String workEmail;
	private String otherEmail;
	private String homeAddress;
	private String workAddress;
	private String mailingAddress;
	private String gender;
	private String groups;
	private String notes;
	private String socialNetworks;
	private String customFields;
	private String dateFields;
	private Date dob;
	private boolean flag;
	private byte[] photo;
	private String createdBy;
	private Timestamp createdOn;
	private Timestamp updatedOn;
	private String lastUpdate;
	
	public Contact(){		
	}
	
	public Contact(String contactId, String account, String jobTitle, String company, String title, String firstName, String middleName, String lastName,
			String nickName, String homePhone, String mobile, String workPhone, String altPhone, String homeFax, String workFax, String personalEmail, String workEmail,
			String otherEmail, String homeAddress, String workAddress, String mailingAddress, String gender, String groups, String notes, String socialNetworks, 
			String customFields, String dateFields, Date dob, boolean flag,byte[] photo, String createdBy, Timestamp createdOn, Timestamp updatedOn, String lastUpdate){
		this.accountId = account;
		this.contactId = contactId;
		this.jobTitle = jobTitle;
		this.company = company;
		this.title = title;
		this.firstName = firstName;
		this.middleName = middleName;
		this.lastName = lastName;
		this.nickName = nickName;
		this.homePhone = homePhone;
		this.mobile = mobile;
		this.workPhone = workPhone;
		this.altPhone = altPhone;
		this.homeFax = homeFax;
		this.workFax = workFax;
		this.personalEmail = personalEmail;
		this.workEmail = workEmail;
		this.otherEmail = otherEmail;
		this.homeAddress = homeAddress;
		this.workAddress = workAddress;
		this.mailingAddress = mailingAddress;
		this.gender = gender;
		this.groups = groups;
		this.notes = notes;
		this.socialNetworks = socialNetworks;
		this.customFields = customFields;
		this.dateFields = dateFields;
		this.dob = dob;
		this.flag = flag;
		this.photo = photo;
		this.createdBy = createdBy;
		this.createdOn = createdOn;
		this.updatedOn = updatedOn;
		this.lastUpdate = lastUpdate;
	}
	
	public Contact(String account, String serialno, String jobtitle, String company, String firstname, String middlename, String lastname, String nickname, String workphone, String workemail,
			String personEmail, String otherEmail, String mobile, String alt, String workaddress, String social, boolean flag){
		this.accountId = account;
		this.contactId = serialno;
		this.jobTitle = jobtitle;
		this.company = company;
		this.firstName = firstname;
		this.middleName = middlename;
		this.lastName = lastname;
		this.nickName = nickname;
		this.workPhone = workphone;
		this.workEmail = workemail;
		this.personalEmail = personEmail;
		this.otherEmail = otherEmail;
		this.mobile = mobile;
		this.altPhone = alt;
		this.workAddress = workaddress;
		this.socialNetworks = social;
		this.flag = flag;
	}
	
	public String getAccountId(){
		return accountId;
	}
	public void setAccountId(String account){
		this.accountId = account;
	}
	
	public String getContactId(){
		return this.contactId;
	}
	public void setContactId(String contactId){
		this.contactId = contactId;
	}
	
	public String getJobTitle(){
		return this.jobTitle;
	}
	public void setJobTitle(String jobTitle){
		this.jobTitle = jobTitle;
	}
	
	public String getCompany(){
		return this.company;
	}
	public void setCompany(String company){
		this.company = company;
	}
	
	public String getTitle(){
		return this.title;
	}
	public void setTitle(String title){
		this.title = title;
	}
	
	public String getFirstName(){
		return this.firstName;
	}
	public void setFirstName(String firstName){
		this.firstName = firstName;
	}
	
	public String getMiddleName(){
		return this.middleName;
	}
	public void setMiddleName(String middleName){
		this.middleName = middleName;
	}
	
	public String getLastName(){
		return this.lastName;
	}
	public void setLastName(String lastName){
		this.lastName = lastName;
	}
	
	public String getNickName(){
		return this.nickName;
	}
	public void setNickName(String nickName){
		this.nickName = nickName;
	}
	
	public String getHomePhone(){
		return this.homePhone;
	}
	public void setHomePhone(String homePhone){
		this.homePhone = homePhone;
	}
	
	public String getMobile(){
		return this.mobile;
	}
	public void setMobile(String mobile){
		this.mobile = mobile;
	}
	
	public String getWorkPhone(){
		return this.workPhone;
	}
	public void setWorkPhone(String workPhone){
		this.workPhone = workPhone;
	}
	
	public String getAltPhone(){
		return this.altPhone;
	}
	public void setAltPhone(String altPhone){
		this.altPhone = altPhone;
	}
	
	public String getHomeFax(){
		return this.homeFax;
	}
	public void setHomeFax(String homeFax){
		this.homeFax = homeFax;
	}
	
	public String getWorkFax(){
		return this.workFax;
	}
	public void setWorkFax(String workFax){
		this.workFax = workFax;
	}
	
	public String getPersonalEmail(){
		return this.personalEmail;
	}
	public void setPersonalEmail(String personalEmail){
		this.personalEmail = personalEmail;
	}
	
	public String getWorkEmail(){
		return this.workEmail;
	}
	public void setWorkEmail(String workEmail){
		this.workEmail = workEmail;
	}
	
	public String getOtherEmail(){
		return this.otherEmail;
	}
	public void setOtherEmail(String otherEmail){
		this.otherEmail = otherEmail;
	}
	
	public String getHomeAddress(){
		return this.homeAddress;
	}
	public void setHomeAddress(String homeAddress){
		this.homeAddress = homeAddress;
	}
	
	public String getWorkAddress(){
		return this.workAddress;
	}
	public void setWorkAddress(String workAddress){
		this.workAddress = workAddress;
	}
	
	public String getMailingAddress(){
		return this.mailingAddress;
	}
	public void setMailingAddress(String mailingAddress){
		this.mailingAddress = mailingAddress;
	}
	
	public String getGender(){
		return gender;
	}
	public void setGender(String gender){
		this.gender = gender;
	}
	
	public String getGroups(){
		return this.groups;
	}
	public void setGroups(String groups){
		this.groups = groups;
	}
	public String getGroupsText(){
		if(this.groups==null)
			return "";
		
		String str = this.groups.replace("&#44", ",");
		if(str.endsWith(","))
			str = str.substring(0, str.length()-1);
		return str;
	}
	
	public String getNotes(){
		return this.notes;
	}
	public void setNotes(String notes){
		this.notes = notes;
	}
	
	public String getSocialNetworks(){
		return this.socialNetworks;
	}
	public void setSocialNetworks(String socialNetwork){
		this.socialNetworks = socialNetwork;
	}
	
	public String getCustomFields(){
		return this.customFields;
	}
	public void setCustomFields(String customFields){
		this.customFields = customFields;
	}
	
	public String getDateFields(){
		return this.dateFields;
	}
	public void setDateFields(String dateFields){
		this.dateFields = dateFields;
	}
	
	public Date getDob(){
		return this.dob;
	}
	public void setDob(Date dob){
		this.dob = dob;
	}
	
	public byte[] getPhoto(){
		return this.photo;
	}
	public void setPhoto(byte[] photo){
		this.photo = photo;
	}
	
	public boolean isFlag(){
		return this.flag;
	}
	public void isFlag(boolean flag){
		this.flag = flag;
	}
	
	public String getCreatedBy(){
		return this.createdBy;
	}
	public void setCreatedBy(String createdBy){
		this.createdBy = createdBy;
	}
	
	public Timestamp getCreatedOn(){
		return this.createdOn;
	}
	public void setCreatedOn(Timestamp createdOn){
		this.createdOn = createdOn;
	}
	
	public Timestamp getUpdatedOn(){
		return this.updatedOn;
	}
	public void setUpdatedOn(Timestamp updatedOn){
		this.updatedOn = updatedOn;
	}
	
	public String getLastUpdate(){
		return this.lastUpdate;
	}
	public void setLastUpdate(String lastUpdate){
		this.lastUpdate = lastUpdate;
	}
	
	// Methods
	public String getFullNameWithNick(){
		String name="";
		if(this.firstName != null)
			name += this.firstName+" ";
		if(this.middleName != null)
			name += this.middleName+" ";
		if(this.lastName != null)
			name += this.lastName+" ";
		if(this.nickName != null)
			name += "("+this.nickName+")";
		
		return name.trim();
	}
	
	public String getFullName(){
		String name="";
		if(this.firstName != null)
			name += this.firstName+" ";
		if(this.middleName != null)
			name += this.middleName+" ";
		if(this.lastName != null)
			name += this.lastName;
		
		return name.trim();
	}
	
	public String getMaillingAddress(){
		if(this.mailingAddress == null)
			return null;
		
		if(this.mailingAddress.equalsIgnoreCase("WORK"))
			return this.workAddress;
		else if(this.mailingAddress.equalsIgnoreCase("HOME"))
			return this.homeAddress;
		
		return null;
	}
	
	public List<String[]> phonesDisplayDetail(){
		List<String[]> phones = new ArrayList<String[]>();
		
		if(this.workPhone != null)
			phones.add(new String[]{"Work", this.workPhone});
		if(this.mobile != null)
			phones.add(new String[]{"Mobile", this.mobile});
		if(this.homePhone != null)
			phones.add(new String[]{"Home", this.homePhone});
		if(this.altPhone != null)
			phones.add(new String[]{"Alternative", this.altPhone});
		if(this.workFax != null)
			phones.add(new String[]{"Work Fax", this.workFax});
		if(this.homeFax != null)
			phones.add(new String[]{"Home Fax", this.homeFax});
		
		return phones;
	}
	
	public List<String[]> emailsDisplayDetail(){
		List<String[]> emails = new ArrayList<String[]>();
		
		if(this.workEmail != null)
			emails.add(new String[]{"Work", this.workEmail});
		if(this.personalEmail != null)
			emails.add(new String[]{"Personal", this.personalEmail});
		if(this.otherEmail != null)
			emails.add(new String[]{"Other", this.otherEmail});
			
		return emails;
	}
	
	public List<String[]> dataDisplayDetail(){
		List<String[]> data = new ArrayList<String[]>();
		
		if(this.gender != null){
			data.add(new String[]{"Gender", this.gender});
		}
		if(this.groups != null){
			String grp = this.groups.replace("&#44", ",");
			if(grp.endsWith(","))
				grp = grp.substring(0, grp.length()-1);
			data.add(new String[]{"Groups", grp});
		}
		if(this.customFields != null){
			String[] pairs = customFields.split("&#44");
			for(int i=0; i<pairs.length; i++){
				String[] field = pairs[i].split("&#47");
				data.add(new String[]{field[0], field[1]});
			}
		}	
		if(this.dateFields != null){
			String[] pairs = dateFields.split("&#44");
			for(int i=0; i<pairs.length; i++){
				String[] field = pairs[i].split("&#47");
				data.add(new String[]{field[0], field[1]});
			}
		}
		
		return data;
	}
	
	public String getEmails(){
		if(isEmptyEmail())
			return null;
		
		String emails = "";
		if(this.personalEmail != null)
			emails += this.personalEmail+",";
		if(this.workEmail != null)
			emails += this.workEmail+",";
		if(this.otherEmail != null)
			emails += this.otherEmail+",";
		if(emails.endsWith(","))
			emails = emails.substring(0, emails.length()-1);
		
		return emails;
	}
	
	public boolean isEmptyName(){
		if(this.title==null && this.firstName==null && this.middleName==null && this.lastName==null && this.nickName==null)
			return true;
		return false;
	}
	
	public boolean isEmptyPhone(){
		if(this.homePhone==null && this.mobile==null && this.workPhone==null && this.altPhone==null && this.homeFax==null && this.workFax==null)
			return true;
		return false;
	}
	
	public boolean isEmptyEmail(){
		if(this.personalEmail==null && this.workEmail==null && this.otherEmail==null)
			return true;
		return false;
	}
	
	public boolean isEmptyAddress(){
		if(this.homeAddress==null && this.workAddress==null)
			return true;
		return false;
	}
}
