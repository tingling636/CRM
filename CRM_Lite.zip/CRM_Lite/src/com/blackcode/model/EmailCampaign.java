package com.blackcode.model;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.List;

public class EmailCampaign implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private long id;
	private String name;
	private String emailAccount;
	private String sendByName;
	private String sendByEmailId;
	private String emailSubject;
	private Timestamp dateTime1;
	private Timestamp dateTime2;
	private Timestamp dateTime3;
	private String template1;
	private String template2;
	private String template3;
	private boolean active;
	private String createdBy;
	private Timestamp createdOn;
	private List<EmailCampaignRecipient> recipients;
	
	public EmailCampaign(){
		
	}
	public EmailCampaign(long id, String name, String emailAccount, String sendByName, String sendByEmail, String emailSubject, Timestamp dateTime1,
			Timestamp dateTime2, Timestamp dateTime3, String template1, String template2, String template3, boolean active, String createdBy, Timestamp createdOn){
		this.id = id;
		this.name = name;
		this.emailAccount = emailAccount;
		this.sendByName = sendByName;
		this.sendByEmailId = sendByEmail;
		this.emailSubject = emailSubject;
		this.dateTime1 = dateTime1;
		this.dateTime2 = dateTime2;
		this.dateTime3 = dateTime3;
		this.template1 = template1;
		this.template2 = template2;
		this.template3 = template3;
		this.active = active;
		this.createdBy = createdBy;
		this.createdOn = createdOn;
	}
	
	public long getId(){
		return this.id;
	}
	public void setId(long id){
		this.id = id;
	}
	
	public String getName(){
		return this.name;
	}
	public void setName(String name){
		this.name = name;
	}
	
	public String getEmailAccount(){
		return this.emailAccount;
	}
	public void setEmailAccount(String emailAccount){
		this.emailAccount = emailAccount;
	}
	
	public String getSendByName(){
		return this.sendByName;
	}
	public void setSendByName(String sendByName){
		this.sendByName = sendByName;
	}
	
	public String getEmailSubject(){
		return this.emailSubject;
	}
	public void setEmailSubject(String emailSubject){
		this.emailSubject = emailSubject;
	}
	
	public String getSendByEmailId(){
		return this.sendByEmailId;
	}
	public void setSendByEmailId(String sendByEmailId){
		this.sendByEmailId = sendByEmailId;
	}
	
	public Timestamp getDateTime1(){
		return this.dateTime1;
	}
	public void setDateTime1(Timestamp dateTime1){
		this.dateTime1 = dateTime1;
	}
	
	public Timestamp getDateTime2(){
		return this.dateTime2;
	}
	public void setDateTime2(Timestamp dateTime2){
		this.dateTime2 = dateTime2;
	}
	
	public Timestamp getDateTime3(){
		return this.dateTime3;
	}
	public void setDateTime3(Timestamp dateTime3){
		this.dateTime3 = dateTime3;
	}
	
	public String getTemplate1(){
		return this.template1;
	}
	public void setTemplate1(String template1){
		this.template1 = template1;
	}
	
	public String getTemplate2(){
		return this.template2;
	}
	public void setTemplate2(String template2){
		this.template2 = template2;
	}
	
	public String getTemplate3(){
		return this.template3;
	}
	public void setTemplate3(String template3){
		this.template3 = template3;
	}

	public boolean isActive(){
		return this.active;
	}
	public void isActive(boolean active){
		this.active = active;
	}
	
	public String getCreatedBy(){
		return this.createdBy;
	}
	public void setCreatedBy(String createdBy){
		this.createdBy = createdBy;
	}
	
	public Timestamp getCreatedOn(){
		return this.createdOn;
	}
	public void setCreatedOn(Timestamp createdOn){
		this.createdOn = createdOn;
	}
	
	public List<EmailCampaignRecipient> getRecipients(){
		return this.recipients;
	}
	public void setRecipients(List<EmailCampaignRecipient> recipients){
		this.recipients = recipients;
	}
	
	public void clearTemplates(){
		this.dateTime1 = null;
		this.dateTime2 = null;
		this.dateTime3 = null;
		this.template1 = null;
		this.template2 = null;
		this.template3 = null;
	}
}
