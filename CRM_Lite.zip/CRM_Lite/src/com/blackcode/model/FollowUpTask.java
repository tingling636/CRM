package com.blackcode.model;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;

public class FollowUpTask implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private long id;
	private String contactId;
	private String contactName;
	private Date date;
	private String time;
	private String type;
	private String subject;
	private String notes;
	private boolean privateTag;
	private boolean highImportanceTag;
	private int reminder;
	private String shareWith;
	private String createdBy;
	private Timestamp createdOn;
	
	public FollowUpTask(){
		
	}
	
	public FollowUpTask(long id, String contactId, String contactName, Date date, String time, String type, String subject, String notes,
			boolean privateTag, boolean highImportanceTag, int reminder, String shareWith, String createdBy, Timestamp createdOn){
		this.id = id;
		this.contactId = contactId;
		this.contactName = contactName;
		this.date = date;
		this.time = time;
		this.type = type;
		this.subject = subject;
		this.notes = notes;
		this.privateTag = privateTag;
		this.highImportanceTag = highImportanceTag;
		this.reminder = reminder;
		this.shareWith = shareWith;
		this.createdBy = createdBy;
		this.createdOn = createdOn;
	}
	
	public FollowUpTask(String person, String personName, Date date, String time, String type, String task){
		this.contactId = person;
		this.contactName = personName;
		this.date = date;
		this.time = time;
		this.type = type;
		this.notes = task;
	}
	
	public long getId(){
		return this.id;
	}
	public void setId(long id){
		this.id = id;
	}
	
	public String getContactId(){
		return this.contactId;
	}
	public void setContactId(String contactId){
		this.contactId = contactId;
	}
	
	public String getContactName(){
		return this.contactName;
	}
	public void setContactName(String contactName){
		this.contactName = contactName;
	}
	
	public Date getDate(){
		return this.date;
	}
	public void setDate(Date date){
		this.date = date;
	}
	
	public String getTime(){
		return this.time;
	}
	public void setTime(String time){
		this.time = time;
	}
	
	public String getType(){
		return this.type;
	}
	public void setType(String type){
		this.type = type;
	}
	
	public String getSubject(){
		return this.subject;
	}
	public void setSubject(String subject){
		this.subject = subject;
	}
	
	public String getNotes(){
		return this.notes;
	}
	public void setNotes(String notes){
		this.notes = notes;
	}
	
	public boolean isPrivateTag(){
		return this.privateTag;
	}
	public void isPrivateTag(boolean privateTag){
		this.privateTag = privateTag;
	}
	
	public boolean isHighImportanceTag(){
		return this.highImportanceTag;
	}
	public void isHighImportantTag(boolean highImportanceTag){
		this.highImportanceTag = highImportanceTag;
	}
	
	public int getReminder(){
		return this.reminder;
	}
	public void setReminder(int reminder){
		this.reminder = reminder;
	}
	
	public String getShareWith(){
		return this.shareWith;
	}
	public void setShareWith(String shareWith){
		this.shareWith = shareWith;
	}
	
	public String getCreatedBy(){
		return this.createdBy;
	}
	public void setCreatedBy(String createdBy){
		this.createdBy = createdBy;
	}
	
	public Timestamp getCreatedOn(){
		return this.createdOn;
	}
	public void setCreatedOn(Timestamp createdOn){
		this.createdOn = createdOn;
	}
}
