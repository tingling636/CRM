package com.blackcode.model;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import javax.mail.Folder;

public class EmailController {
	private Account emailAccount;
	private List<Contact> recipients;
	private Contact recipientContact;
	private String toRecipient;
	private String ccRecipient;
	private String emailSubject;
	private String emailContent;
	private List<File> emailAttachments;
	private List<File> contentImage;
	private Folder folder;
	private Folder[] folderList;
	
	public Account getEmailAccount(){
		return this.emailAccount;
	}
	public void setEmailAccount(Account emailAccount){
		this.emailAccount = emailAccount;
	}
	
	public List<Contact> getRecipients(){
		return this.recipients;
	}
	public void setRecipients(List<Contact> recipients){
		this.recipients = recipients;
	}
	
	public Contact getRecipientContact(){
		return this.recipientContact;
	}
	public void setRecipientContact(Contact recipientContact){
		this.recipientContact = recipientContact;
	}
	
	public String getToRecipient(){
		return this.toRecipient;
	}
	public void setToRecipient(String toRecipient){
		this.toRecipient = toRecipient;
	}
	
	public String getCCRecipient(){
		return this.ccRecipient;
	}
	public void setCCRecipient(String ccRecipient){
		this.ccRecipient= ccRecipient;
	}
	
	public String getEmailSubject(){
		return this.emailSubject;
	}
	public void setEmailSubject(String emailSubject){
		this.emailSubject = emailSubject;
	}
	
	public String getEmailContent(){
		return this.emailContent;
	}
	public void setEmailContent(String emailContent){
		this.emailContent = emailContent;
	}
	
	public List<File> getEmailAttachments(){
		return this.emailAttachments;
	}
	public void setEmailAttachments(List<File> emailAttachments){
		this.emailAttachments = emailAttachments;
	}
	public void addEmailAttachments(File attachment){
		if(this.emailAttachments == null)
			this.emailAttachments = new ArrayList<File>();
		this.emailAttachments.add(attachment);
	}
	
	public List<File> getContentImages(){
		return this.contentImage;
	}
	public void setContentImages(List<File> contentImages){
		this.contentImage = contentImages;
	}
	
	public Folder getFolder(){
		return this.folder;
	}
	public void setFolder(Folder folder){
		this.folder = folder;
	}
	
	public Folder[] getFolderList(){
		return this.folderList;
	}
	public void setFolderList(Folder[] folderList){
		this.folderList = folderList;
	}
	
}
