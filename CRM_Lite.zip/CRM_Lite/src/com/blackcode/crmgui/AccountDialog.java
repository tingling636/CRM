package com.blackcode.crmgui;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.swt.events.MenuDetectEvent;
import org.eclipse.swt.events.MenuDetectListener;
import org.eclipse.swt.events.MouseAdapter;
import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.events.MouseTrackAdapter;
import org.eclipse.swt.events.VerifyEvent;
import org.eclipse.swt.events.VerifyListener;
import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.graphics.GlyphMetrics;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.widgets.Dialog;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.FileDialog;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.Menu;
import org.eclipse.swt.widgets.MenuItem;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.SWT;
import org.eclipse.wb.swt.SWTResourceManager;
import org.eclipse.swt.custom.CLabel;
import org.eclipse.swt.custom.PaintObjectEvent;
import org.eclipse.swt.custom.PaintObjectListener;
import org.eclipse.swt.custom.StyleRange;
import org.eclipse.swt.custom.StyledText;

import com.blackcode.core.FileConvertor;
import com.blackcode.core.SQLiteConnector;
import com.blackcode.model.Account;

public class AccountDialog extends Dialog {

	protected Object result;
	protected Shell shell;
	private Composite frameTitle;
	private Label lblCloseAction;
	private CLabel lblAddAccountAction;
	private Label lblCode;
	private Text txtName;
	private Text txtEmailId;
	private Text txtEmailPassword;
	private Text txtIncomingMail;
	private Text txtOutgoingMail;
	private StyledText sytxtImage;
	private Menu picMenu;
	private Composite frameSignature;
	
	private SQLiteConnector dbConnector = new SQLiteConnector();
	private Account account = null;
	private Image[] images = new Image[] { };
	private int[] offsets = new int[images.length];	 
	private TextEditorFrame textEditor;
	private Text txtCode;
	
	/**
	 * Create the dialog.
	 * @param parent
	 * @param style
	 */
	public AccountDialog(Shell parent, int style) {
		super(parent, style);
		setText("SWT Dialog");
	}
	
	public AccountDialog(Shell parent, int style, Account account) {
		super(parent, style);
		this.account = account;
	}

	/**
	 * Open the dialog.
	 * @return the result
	 */
	public Object open() {
		createContents();
		shell.open();
		shell.layout();
		Display display = getParent().getDisplay();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
		return result;
	}

	/**
	 * Create contents of the dialog.
	 */
	private void createContents() {
		shell = new Shell(getParent(), getStyle());
		shell.setSize(600, 460);
		shell.setText(getText());
		shell.setLocation((getParent().getBounds().width/2)-(shell.getBounds().width/2), 30);
		
		Composite composite = new Composite(shell, SWT.NONE);
		composite.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		composite.setBounds(0, 0, 600, 458);

		frameTitle = new Composite(composite, SWT.NONE);
		frameTitle.setBackground(SWTResourceManager.getColor(50, 50, 50));
		frameTitle.setBounds(0, 0, 600, 26);
		
		Label lblTitle = new Label(frameTitle, SWT.NONE);
		lblTitle.setForeground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblTitle.setFont(SWTResourceManager.getFont("Georgia", 8, SWT.BOLD));
		lblTitle.setBounds(5, 6, 133, 15);
		lblTitle.setBackground(SWTResourceManager.getColor(50, 50, 50));
		lblTitle.setText("Account Setting");
		
		lblCloseAction = new Label(frameTitle, SWT.CENTER);
		lblCloseAction.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				shell.close();
			}
		});
		lblCloseAction.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				lblCloseAction.setBackground(SWTResourceManager.getColor(100, 100, 100));
			}
			@Override
			public void mouseExit(MouseEvent e) {
				lblCloseAction.setBackground(SWTResourceManager.getColor(50, 50, 50));
			}
		});
		lblCloseAction.setBounds(570, 3, 20, 20);
		lblCloseAction.setBackground(SWTResourceManager.getColor(50, 50, 50));
		lblCloseAction.setImage(new Image(shell.getDisplay(), AccountDialog.class.getResourceAsStream("/images/close.png")));
		lblCloseAction.setToolTipText("Close Window");
		
		lblCode = new Label(composite, SWT.RIGHT);
		lblCode.setFont(SWTResourceManager.getFont("Segoe UI", 9, SWT.NORMAL));
		lblCode.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblCode.setBounds(5, 41, 38, 15);
		lblCode.setText("Code");
		
		txtCode = new Text(composite, SWT.BORDER);
	    txtCode.setBounds(49, 38, 203, 21);
	    
		Label lblName = new Label(composite, SWT.RIGHT);
		lblName.setFont(SWTResourceManager.getFont("Segoe UI", 9, SWT.NORMAL));
		lblName.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblName.setBounds(10, 72, 33, 15);
		lblName.setText("Name");
		
		txtName = new Text(composite, SWT.BORDER);
		txtName.setBounds(49, 69, 203, 21);
		
		Label lblEmailId = new Label(composite, SWT.RIGHT);
		lblEmailId.setFont(SWTResourceManager.getFont("Segoe UI", 9, SWT.NORMAL));
		lblEmailId.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblEmailId.setBounds(318, 41, 55, 15);
		lblEmailId.setText("Email Id");
		
		txtEmailId = new Text(composite, SWT.BORDER);
		txtEmailId.setBounds(379, 38, 203, 21);
		
		Label lblEmailPassword = new Label(composite, SWT.RIGHT);
		lblEmailPassword.setFont(SWTResourceManager.getFont("Segoe UI", 9, SWT.NORMAL));
		lblEmailPassword.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblEmailPassword.setBounds(278, 75, 95, 15);
		lblEmailPassword.setText("Email Password");
		
		txtEmailPassword = new Text(composite, SWT.BORDER | SWT.PASSWORD);
		txtEmailPassword.setBounds(379, 69, 203, 21);
		
		Label lblIncoming = new Label(composite, SWT.RIGHT);
		lblIncoming.setFont(SWTResourceManager.getFont("Segoe UI", 9, SWT.NORMAL));
		lblIncoming.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblIncoming.setBounds(258, 105, 117, 15);
		lblIncoming.setText("Incoming Mail Server");
		
		txtIncomingMail = new Text(composite, SWT.BORDER);
		txtIncomingMail.setBounds(379, 102, 203, 21);
		
		Label lblOutgoingMail = new Label(composite, SWT.RIGHT);
		lblOutgoingMail.setFont(SWTResourceManager.getFont("Segoe UI", 9, SWT.NORMAL));
		lblOutgoingMail.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblOutgoingMail.setBounds(258, 139, 117, 15);
		lblOutgoingMail.setText("Outgoing Mail Server");
		
		txtOutgoingMail = new Text(composite, SWT.BORDER);
		txtOutgoingMail.setBounds(379, 136, 203, 21);
		
		Label lblEmailFooter = new Label(composite, SWT.NONE);
		lblEmailFooter.setFont(SWTResourceManager.getFont("Segoe UI", 9, SWT.BOLD));
		lblEmailFooter.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblEmailFooter.setBounds(10, 191, 95, 15);
		lblEmailFooter.setText("Email Signature");
		
		frameSignature = new Composite(composite, SWT.NONE);
	    frameSignature.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
	    frameSignature.setBounds(49, 212, 530, 200);
	    textEditor = new TextEditorFrame(frameSignature, SWT.NONE);
	    textEditor.setBounds(0, 0, 530, 200);
		
		Label lblImage = new Label(composite, SWT.RIGHT);
		lblImage.setFont(SWTResourceManager.getFont("Segoe UI", 9, SWT.NORMAL));
		lblImage.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblImage.setBounds(10, 100, 33, 15);
		lblImage.setText("Logo");
		
		sytxtImage = new StyledText(composite, SWT.BORDER);
		sytxtImage.addMenuDetectListener(new MenuDetectListener() {
			public void menuDetected(MenuDetectEvent e) {
				picMenu.setVisible(true);
			}
		});
		sytxtImage.setBounds(49, 100, 203, 85);
		sytxtImage.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDoubleClick(MouseEvent e) {
				
			}			
		});
		sytxtImage.addPaintObjectListener(new PaintObjectListener() {
		      public void paintObject(PaintObjectEvent event) {
		          GC gc = event.gc;
		          StyleRange style = event.style;
		          int start = style.start;
		          for (int i = 0; i < offsets.length; i++) {
		            int offset = offsets[i];
		            if (start == offset) {
		              Image image = images[i];
		              int x = event.x;
		              int y = event.y + event.ascent - style.metrics.ascent;
		              gc.drawImage(image, x, y);
		            }
		          }
		        }
		      });
		sytxtImage.addVerifyListener(new VerifyListener() {
		      public void verifyText(VerifyEvent e) {
		          int start = e.start;
		          int replaceCharCount = e.end - e.start;
		          int newCharCount = e.text.length();
		          for (int i = 0; i < offsets.length; i++) {
		            int offset = offsets[i];
		            if (start <= offset && offset < start + replaceCharCount) {
		              // this image is being deleted from the text
		              if (images[i] != null && !images[i].isDisposed()) {
		                images[i].dispose();
		                images[i] = null;
		              }
		              offset = -1;
		            }
		            if (offset != -1 && offset >= start)
		              offset += newCharCount - replaceCharCount;
		            offsets[i] = offset;
		          }
		        }
		      });
		
		
		lblAddAccountAction = new CLabel(composite, SWT.CENTER);
		lblAddAccountAction.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				if(account==null)
					createAccount();
				else
					modifyAccount();
			}
		});
		lblAddAccountAction.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				lblAddAccountAction.setBackground(SWTResourceManager.getColor(86, 86, 86));
			}
			@Override
			public void mouseExit(MouseEvent e) {
				lblAddAccountAction.setBackground(SWTResourceManager.getColor(45, 45, 45));
			}
		});
		lblAddAccountAction.setBounds(207, 418, 74, 30);
		lblAddAccountAction.setBackground(SWTResourceManager.getColor(45, 45, 45));
		lblAddAccountAction.setForeground(SWTResourceManager.getColor(245, 245, 245));
		lblAddAccountAction.setFont(SWTResourceManager.getFont("Georgia", 9, SWT.BOLD));		
		lblAddAccountAction.setText("Save");
		lblAddAccountAction.setToolTipText("Update Account");
		
		final CLabel lblCancel = new CLabel(composite, SWT.CENTER);
		lblCancel.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				account = null;
				shell.close();
			}
		});
		lblCancel.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				lblCancel.setBackground(SWTResourceManager.getColor(86, 86, 86));
			}
			@Override
			public void mouseExit(MouseEvent e) {
				lblCancel.setBackground(SWTResourceManager.getColor(45, 45, 45));
			}
		});
		lblCancel.setBounds(299, 418, 74, 30);
		lblCancel.setBackground(SWTResourceManager.getColor(45, 45, 45));
		lblCancel.setForeground(SWTResourceManager.getColor(245, 245, 245));
		lblCancel.setFont(SWTResourceManager.getFont("Georgia", 9, SWT.BOLD));		
		lblCancel.setText("Cancel");
	    
	    picMenu = new Menu(sytxtImage);	  
		MenuItem addPic = new MenuItem(picMenu, SWT.NONE);
		addPic .setText("Insert Picture");
		addPic.setImage(new Image(shell.getDisplay(), AccountDialog.class.getResourceAsStream("/images/add.gif")));
		addPic .addListener(SWT.Selection, new Listener() {
			public void handleEvent(Event e) {
					FileDialog dialog = new FileDialog(shell);
			        String filename = dialog.open();
			        if (filename == null) 
			        	return;
			        
			        sytxtImage.setData(filename);
			        images = new Image[] { };
					offsets = new int[images.length];
			        insertPicture(filename);
		    	}
		 	});
	    MenuItem removePic = new MenuItem(picMenu, SWT.NONE);
	    removePic .setText("Remove Picture");
	    removePic.setImage(new Image(shell.getDisplay(), AccountDialog.class.getResourceAsStream("/images/remove.png")));
	    removePic .addListener(SWT.Selection, new Listener() {
	        public void handleEvent(Event e) {
		        	images = new Image[] { };
		    		offsets = new int[images.length];
		    		sytxtImage.setText("");
		    		sytxtImage.setData(null);
	          }
	        });
	    
	    showAccount();
	}
	
	private void showAccount(){
		if(account == null)
			return;
		
		try{
			txtCode.setText(account.getCode());
			txtName.setText(displayText(account.getName()));
			txtEmailId.setText(displayText(account.getEmailId()));
			txtEmailPassword.setText(displayText(account.getEmailPassword()));
			txtIncomingMail.setText(displayText(account.getIncomingMailServer()));
			txtOutgoingMail.setText(displayText(account.getOutgoingMailServer()));
			List<byte[]> pictures = new ArrayList<byte[]>();
			pictures.add(account.getImage());
			textEditor.clear();
			textEditor.displayContent(account.getEmailSignature(), account.getEmailSignatureStyle(), pictures);			
			
			images = new Image[] { };
			offsets = new int[images.length];
			sytxtImage.setText("");
			if(account.getImage()!=null){
				String filepath = FileConvertor.convertByteArrayToFile(account.getImage(), "C:\\ProgramData\\BlackCodeCRM\\tmp.png").getPath();
				insertPicture(filepath);
				sytxtImage.setData(filepath);
			}
		}catch(Exception e){
			e.printStackTrace();
			MessageDialog dlg = new MessageDialog(shell, SWT.NONE, "Erro 401 : System Problems (AD477)");
			dlg.open();
		}
	}
	
	private void createAccount(){
		//Insert new Account into database
		account = new Account();
		account.setCode(txtCode.getText());
		account.setName(captureText(txtName.getText()));
		account.setEmailId(captureText(txtEmailId.getText()));
		account.setEmailPassword(captureText(txtEmailPassword.getText()));
		account.setIncomingMailServer(captureText(txtIncomingMail.getText()));
		account.setOutgoingMailServer(captureText(txtOutgoingMail.getText()));
		account.setImage(null);
		if(sytxtImage.getData() != null){
			account.setImage(FileConvertor.convertFileToByteArray((String)sytxtImage.getData()));
		}
		account.setEmailSignature(captureText(textEditor.getContent()));
		account.setEmailSignatureStyle(captureText(textEditor.getContentStyled()));
		
		Object obj = dbConnector.createAccount(account);
		if(obj instanceof String){
			MessageDialog dlg = new MessageDialog(shell, SWT.NONE, "Erro 400 : Database Problems (AD416)");
			dlg.open();
			return;
		}
		
		shell.close();
	}
		
	private void modifyAccount(){
		try{
			if(account==null)
				return;
			
			account.setName(captureText(txtName.getText()));
			account.setEmailId(captureText(txtEmailId.getText()));
			account.setEmailPassword(captureText(txtEmailPassword.getText()));
			account.setIncomingMailServer(captureText(txtIncomingMail.getText()));
			account.setOutgoingMailServer(captureText(txtOutgoingMail.getText()));
			account.setImage(null);
			if(sytxtImage.getData() != null){
				account.setImage(FileConvertor.convertFileToByteArray((String)sytxtImage.getData()));
			}
			account.setEmailSignature(captureText(textEditor.getContent()));
			account.setEmailSignatureStyle(captureText(textEditor.getContentStyled()));
			
			Object obj = dbConnector.updateAccount(account, null);
			if(obj instanceof String){
				MessageDialog dlg = new MessageDialog(shell, SWT.NONE, "Erro 400 : Database Problems (AD500");
				dlg.open();
				return;
			}
		}catch(Exception e){
			MessageDialog dlg = new MessageDialog(shell, SWT.NONE, "Erro 401 : System Problems (AD518)");
			dlg.open();
		}
		
		shell.close();
	}
	
	private String displayText(Object obj){
		if(obj==null)
			return "";
		else
			return obj.toString();
	}
	
	private String captureText(String text){
		if(text.length() == 0)
			return null;
		else
			return text;
	}
	
	private void insertPicture(String filename){
        try {
            Image image = new Image(shell.getDisplay(), filename);
            int offset = sytxtImage.getCaretOffset();
            sytxtImage.replaceTextRange(offset, 0, "\uFFFC");
            int index = 0;
            while (index < offsets.length) {
            	if (offsets[index] == -1 && images[index] == null)
            		break;
            	index++;
            }
            
            if (index == offsets.length) {
            	int[] tmpOffsets = new int[index + 1];
            	System.arraycopy(offsets, 0, tmpOffsets, 0, offsets.length);
            	offsets = tmpOffsets;
            	Image[] tmpImages = new Image[index + 1];
            	System.arraycopy(images, 0, tmpImages, 0, images.length);
            	images = tmpImages;
            }
            
            offsets[index] = offset;
            images[index] = image;
            addImage(image, offset);
         } catch (Exception e) {
        	  MessageDialog dlg = new MessageDialog(shell, SWT.NONE, "Erro 401 : System Problems (AD564)");
        	  dlg.open();
         }
	}
	
	private void addImage(Image image, int offset) {
	    StyleRange style = new StyleRange();
	    style.start = offset;
	    style.length = 1;
	    Rectangle rect = image.getBounds();
	    style.metrics = new GlyphMetrics(rect.height, 0, rect.width);
	    sytxtImage.setStyleRange(style);
	}
	
	public Account getAccount(){
		return this.account;
	}
}
