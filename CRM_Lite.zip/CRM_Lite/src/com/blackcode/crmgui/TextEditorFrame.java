package com.blackcode.crmgui;

import java.util.List;

import org.eclipse.swt.custom.CCombo;
import org.eclipse.swt.custom.CLabel;
import org.eclipse.swt.custom.ExtendedModifyEvent;
import org.eclipse.swt.custom.ExtendedModifyListener;
import org.eclipse.swt.custom.PaintObjectEvent;
import org.eclipse.swt.custom.PaintObjectListener;
import org.eclipse.swt.custom.StyleRange;
import org.eclipse.swt.custom.StyledText;
import org.eclipse.swt.events.MouseAdapter;
import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.events.MouseTrackAdapter;
import org.eclipse.swt.events.VerifyEvent;
import org.eclipse.swt.events.VerifyListener;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.Font;
import org.eclipse.swt.graphics.FontData;
import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.graphics.GlyphMetrics;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.graphics.RGB;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.widgets.ColorDialog;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.FileDialog;
import org.eclipse.swt.widgets.Label;
import org.eclipse.wb.swt.SWTResourceManager;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;

public class TextEditorFrame extends Composite {
	private Composite parent;
	private CCombo cmbFont;
	private CCombo cmbSize;
	private Label lblBoldAction;
	private Label lblItalicAction;
	private Label lblUnderlineAction;
	private Label lblPictureAction;
	private Label lblColorAction;
	private Label label_2;
	private StyledText sytxtContent;
	private Composite composite;

	private String[] fonts = new String[]{"Sans Serif","Serif","Wide","Narrow","Comic Sans MS", "Courier New", "Georgia","Tahoma","Trebuchet MS","Verdana"};
	private String[] sizeName = new String[]{"8", "9", "10", "11", "12", "14", "16", "18", "20", "22", "24", "26", "28", "36", "48"};
	private int[] size = new int[]{8, 9, 10, 11, 12, 14, 16, 18, 20, 22, 24, 26, 28, 36, 48};
	private boolean isBold = false, isItalic = false, isUnderline = false;
	private Image[] images;
	private int[] offsets ;
	
	/**
	 * Create the composite.
	 * @param parent
	 * @param style
	 */
	public TextEditorFrame(Composite frame, int style) {
		super(frame, style);
		parent = frame;
		setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		
		composite = new Composite(this, SWT.NONE);
		composite.setBackground(SWTResourceManager.getColor(247, 239, 211));
		composite.setBounds(0, 0, parent.getBounds().width, parent.getBounds().height);

		Composite frameFormatting = new Composite(composite, SWT.BORDER);
		frameFormatting.setBackground(SWTResourceManager.getColor(245, 245, 245));
		frameFormatting.setBounds(5, 5, 320, 30);
		
		cmbFont = new CCombo(frameFormatting, SWT.BORDER);
		cmbFont.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				setFontStyle();
			}
		});
		cmbFont.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				
			}
			@Override
			public void mouseExit(MouseEvent e) {
			}
		});
		cmbFont.setBackground(SWTResourceManager.getColor(255, 255, 255));
		cmbFont.setToolTipText("Select Text Font");
		cmbFont.setBounds(2, 3, 108, 21);
		cmbFont.setItems(fonts);
		cmbFont.select(1);
				
		cmbSize = new CCombo(frameFormatting, SWT.BORDER);
		cmbSize.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				setFontStyle();
			}
		});
		cmbSize.setBackground(SWTResourceManager.getColor(245, 245, 245));
		cmbSize.setToolTipText("Set Text Size");
		cmbSize.setBounds(110, 3, 41, 21);
		cmbSize.setItems(sizeName);
		cmbSize.select(3);
		
		lblBoldAction = new Label(frameFormatting, SWT.NONE);
		lblBoldAction.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				isBold = !isBold;
				if(isBold)
					lblBoldAction.setImage(new Image(parent.getDisplay(), this.getClass().getResourceAsStream("/images/fontBold_selected.png")));
				else
					lblBoldAction.setImage(new Image(parent.getDisplay(), this.getClass().getResourceAsStream("/images/fontBold.png")));
				setFontStyle();
			}
		});
		lblBoldAction.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				lblBoldAction.setBackground(SWTResourceManager.getColor(225, 225, 225));
				
			}
			@Override
			public void mouseExit(MouseEvent e) {
				lblBoldAction.setBackground(SWTResourceManager.getColor(245, 245, 245));
			}
		});
		lblBoldAction.setImage(new Image(parent.getDisplay(), this.getClass().getResourceAsStream("/images/fontBold.png")));
		lblBoldAction.setToolTipText("Bold");
		lblBoldAction.setBounds(166, 3, 21, 21);
		
		lblItalicAction = new Label(frameFormatting, SWT.NONE);
		lblItalicAction.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				isItalic = !isItalic;
				if(isItalic)
					lblItalicAction.setImage(new Image(parent.getDisplay(), this.getClass().getResourceAsStream("/images/fontItalic_selected.png")));
				else
					lblItalicAction.setImage(new Image(parent.getDisplay(), this.getClass().getResourceAsStream("/images/fontItalic.png")));
				setFontStyle();
			}
		});
		lblItalicAction.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				//lblItalicAction.setImage(new Image(shell.getDisplay(), "images/fontItalic_selected.png"));
				
			}
			@Override
			public void mouseExit(MouseEvent e) {
				//lblItalicAction.setImage(new Image(shell.getDisplay(), "images/fontItalic.png"));
			}
		});
		lblItalicAction.setBackground(SWTResourceManager.getColor(245, 245, 245));
		lblItalicAction.setImage(new Image(parent.getDisplay(), this.getClass().getResourceAsStream("/images/fontItalic.png")));
		lblItalicAction.setToolTipText("Italic");
		lblItalicAction.setBounds(189, 3, 21, 21);
		
		lblUnderlineAction = new Label(frameFormatting, SWT.NONE);
		lblUnderlineAction.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				isUnderline = !isUnderline;
				if(isBold)
					lblUnderlineAction.setImage(new Image(parent.getDisplay(), this.getClass().getResourceAsStream("/images/fontUnderline_selected.png")));
				else
					lblUnderlineAction.setImage(new Image(parent.getDisplay(), this.getClass().getResourceAsStream("/images/fontUnderline.png")));
				setFontStyle();
			}
		});
		lblUnderlineAction.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				//lblUnderlineAction.setImage(new Image(shell.getDisplay(), "images/fontUnderline_selected.png"));
				
			}
			@Override
			public void mouseExit(MouseEvent e) {
				//lblUnderlineAction.setImage(new Image(shell.getDisplay(), "images/fontUnderline.png"));
				
			}
		});
		lblUnderlineAction.setBackground(SWTResourceManager.getColor(245, 245, 245));
		lblUnderlineAction.setImage(new Image(parent.getDisplay(), this.getClass().getResourceAsStream("/images/fontUnderline.png")));
		lblUnderlineAction.setToolTipText("Underline");
		lblUnderlineAction.setBounds(212, 3, 21, 21);
		
		lblColorAction = new Label(frameFormatting, SWT.NONE);
		lblColorAction.setBackground(SWTResourceManager.getColor(0, 0, 0));
		lblColorAction.setBounds(235, 3, 21, 21);
		
		CLabel lblColor = new CLabel(frameFormatting, SWT.BORDER | SWT.SHADOW_OUT | SWT.CENTER);
		lblColor.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				ColorDialog cd = new ColorDialog(parent.getShell());
		        cd.setText("ColorDialog Demo");
		        cd.setRGB(new RGB(255, 255, 255));
		        RGB newColor = cd.open();
		        if (newColor == null) 
		          return;
		        
		        lblColorAction.setBackground(SWTResourceManager.getColor(newColor.red, newColor.green, newColor.blue));
		        setForegroundColor(SWTResourceManager.getColor(newColor.red, newColor.green, newColor.blue));
			}
		});
		lblColor.setBackground(SWTResourceManager.getColor(245, 245, 245));
		lblColor.setImage(new Image(parent.getDisplay(), this.getClass().getResourceAsStream("/images/next_small.png")));
		lblColor.setBounds(254, 3, 17, 21);
		
		Label label = new Label(frameFormatting, SWT.SEPARATOR | SWT.VERTICAL);
		label.setBounds(158, 3, 2, 21);
		
		lblPictureAction = new Label(frameFormatting, SWT.NONE);
		lblPictureAction.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				FileDialog dialog = new FileDialog(parent.getShell());
		        String filename = dialog.open();		        
		        if (filename == null) 
		        	return;
		        		        
				insertPicture(filename);
			}
		});
		lblPictureAction.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				lblPictureAction.setImage(new Image(parent.getDisplay(), this.getClass().getResourceAsStream("/images/btnPicture_selected.png")));
				
			}
			@Override
			public void mouseExit(MouseEvent e) {
				lblPictureAction.setImage(new Image(parent.getDisplay(), this.getClass().getResourceAsStream("/images/btnPicture.png")));
			}
		});
		lblPictureAction.setImage(new Image(parent.getDisplay(), this.getClass().getResourceAsStream("/images/btnPicture.png")));
		lblPictureAction.setBackground(SWTResourceManager.getColor(245, 245, 245));
		lblPictureAction.setToolTipText("Insert Picture");
		lblPictureAction.setBounds(283, 3, 21, 21);
		
		label_2 = new Label(frameFormatting, SWT.SEPARATOR | SWT.VERTICAL);
		label_2.setBounds(277, 3, 2, 21);
		
		sytxtContent = new StyledText(composite, SWT.BORDER|SWT.WRAP);
		sytxtContent.addExtendedModifyListener(new ExtendedModifyListener() {
			public void modifyText(ExtendedModifyEvent event) {
				if(sytxtContent.getText().length() <=0)
					return;
				
				StyleRange style = new StyleRange(sytxtContent.getText().length()-1, 1, lblColorAction.getBackground(), null, SWT.NORMAL);				
				if (isBold) {
			        style.fontStyle |= SWT.BOLD;
			    } 
				if (isItalic) {
			        style.fontStyle |= SWT.ITALIC;
			    } 
				if (isUnderline) {
			        style.underline |= !style.underline;
			    } 
				style.font = SWTResourceManager.getFont(cmbFont.getText(), size[cmbSize.getSelectionIndex()], style.fontStyle) ;
			    sytxtContent.setStyleRange(style);
			}
		});
		sytxtContent.addPaintObjectListener(new PaintObjectListener() {
		      public void paintObject(PaintObjectEvent event) {
		          GC gc = event.gc;
		          StyleRange style = event.style;
		          int start = style.start;
		          for (int i = 0; i < offsets.length; i++) {
		            int offset = offsets[i];
		            if (start == offset) {
		              Image image = images[i];
		              int x = event.x;
		              int y = event.y + event.ascent - style.metrics.ascent;
		              gc.drawImage(image, x, y);
		            }
		          }
		        }
		      });
		sytxtContent.addVerifyListener(new VerifyListener() {
		      public void verifyText(VerifyEvent e) {
		          int start = e.start;
		          int replaceCharCount = e.end - e.start;
		          int newCharCount = e.text.length();
		          for (int i = 0; i < offsets.length; i++) {
		            int offset = offsets[i];
		            if (start <= offset && offset < start + replaceCharCount) {
		              // this image is being deleted from the text
		              if (images[i] != null && !images[i].isDisposed()) {
		                images[i].dispose();
		                images[i] = null;
		              }
		              offset = -1;
		            }
		            if (offset != -1 && offset >= start)
		              offset += newCharCount - replaceCharCount;
		            offsets[i] = offset;
		          }
		        }
		      });
		sytxtContent.setTopMargin(3);
		sytxtContent.setLeftMargin(3);
		sytxtContent.setBounds(5, 37, parent.getBounds().width-10, parent.getBounds().height-42);
		
		 images = new Image[] {};
		 offsets = new int[images.length];
	}
	
	public void resize(int width, int height){
		composite.getParent().setSize(width, height);
		composite.setBounds(0, 0, width, height);
		sytxtContent.setBounds(5, 37, width-10, height-42);
		composite.redraw();
	}
	
	private void setForegroundColor(Color fg) {
		Point sel = sytxtContent.getSelectionRange();
	    if ((sel == null) || (sel.y == 0))
	    	return;
	    
	    StyleRange style, range;
	    for (int i = sel.x; i < sel.x + sel.y; i++) {
	    	range = sytxtContent.getStyleRangeAtOffset(i);
	    	if (range != null) {
	    		style = (StyleRange) range.clone();
	    		style.start = i;
	    		style.length = 1;
	    		style.foreground = fg;
	    	} else {
	    		style = new StyleRange(i, 1, fg, null, SWT.NORMAL);
	    	}
	    	sytxtContent.setStyleRange(style);
	    }
	    //sytxtContent.setSelectionRange(sel.x + sel.y, 0);
	}
	
	private void setFontStyle() {
		Point sel = sytxtContent.getSelectionRange();
	    if ((sel == null) || (sel.y == 0))
	    	return;
	    
	    StyleRange style, range;
	    for (int i = sel.x; i < sel.x + sel.y; i++) {
	    	range = sytxtContent.getStyleRangeAtOffset(i);
	    	if (range != null) {
	    		style = (StyleRange) range.clone();
	    		style.start = i;
	    		style.length = 1;
	    		style.fontStyle = SWT.NORMAL;
	    		if (isBold) 
			        style.fontStyle |= SWT.BOLD;
				if (isItalic) 
			        style.fontStyle |= SWT.ITALIC;
				if (isUnderline) 
			        style.underline |= !style.underline;
				style.font = SWTResourceManager.getFont(cmbFont.getText(), size[cmbSize.getSelectionIndex()], style.fontStyle) ;
	    	} else {
	    		style = new StyleRange(i, 1, null, null, isBold?SWT.BOLD:SWT.NORMAL);
	    	}
	    	sytxtContent.setStyleRange(style);
	    }
	    //sytxtContent.setSelectionRange(sel.x + sel.y, 0);
	}
		
	private  StyleRange showPicture(Image image, int offset){		        
        try {            
            sytxtContent.replaceTextRange(offset, 0, "\uFFFC");
            int index = 0;
            while (index < offsets.length) {
            	if (offsets[index] == -1 && images[index] == null)
            		break;
            	index++;
            }
            
            if (index == offsets.length) {
            	int[] tmpOffsets = new int[index + 1];
            	System.arraycopy(offsets, 0, tmpOffsets, 0, offsets.length);
            	offsets = tmpOffsets;
            	Image[] tmpImages = new Image[index + 1];
            	System.arraycopy(images, 0, tmpImages, 0, images.length);
            	images = tmpImages;
            }
            
            offsets[index] = offset;
            images[index] = image;
            
            StyleRange style = new StyleRange();
    	    if(sytxtContent.getStyleRangeAtOffset(offset) != null)
    	    	style = (StyleRange) sytxtContent.getStyleRangeAtOffset(offset).clone();
    	    style.start = offset;
    	    style.length = 1;
    	    Rectangle rect = image.getBounds();
    	    style.metrics = new GlyphMetrics(rect.height, 0, rect.width);
    	    
    	    return style;
          } catch (Exception e) {
        	  e.printStackTrace();
        	  return null;
          }
	}
	
	private void insertPicture(String filename){		        
        try {            
        	Image image = new Image(parent.getDisplay(), filename);
            int offset = sytxtContent.getCaretOffset();
            
            sytxtContent.replaceTextRange(offset, 0, "\uFFFC");
            int index = 0;
            while (index < offsets.length) {
            	if (offsets[index] == -1 && images[index] == null)
            		break;
            	index++;
            }
            
            if (index == offsets.length) {
            	int[] tmpOffsets = new int[index + 1];
            	System.arraycopy(offsets, 0, tmpOffsets, 0, offsets.length);
            	offsets = tmpOffsets;
            	Image[] tmpImages = new Image[index + 1];
            	System.arraycopy(images, 0, tmpImages, 0, images.length);
            	images = tmpImages;
            }
            
            offsets[index] = offset;
            images[index] = image;
            addImage(image, offset);
          } catch (Exception e) {
        	  e.printStackTrace();
          }
	}
	
	private void addImage(Image image, int offset) {
	    StyleRange style = new StyleRange();
	    if(sytxtContent.getStyleRangeAtOffset(offset) != null)
	    	style = (StyleRange) sytxtContent.getStyleRangeAtOffset(offset).clone();
	    style.start = offset;
	    style.length = 1;
	    Rectangle rect = image.getBounds();
	    style.metrics = new GlyphMetrics(rect.height, 0, rect.width);
	    sytxtContent.setStyleRange(style);
	}
	
	public String getContentStyled(){
		String styleranges = "";
		StyleRange[] ranges = sytxtContent.getStyleRanges();
		
		for(int i=0; i<ranges.length; i++){
			StyleRange range = ranges[i]; 
			
			String style= range.borderStyle+":"+range.fontStyle+":"+range.length+":"+range.start+":"+range.strikeout+":"+range.underline+":"+range.underlineStyle
					+":"+(range.foreground==null?"null":range.foreground.toString())+":"+(range.metrics==null?"null":range.metrics.toString())+":";
			String fontstr = "null";
			if(range.font != null){
				FontData data = range.font.getFontData()[0];
				fontstr = "{"+data.getHeight()+","+data.getName()+","+data.getStyle()+"}";
			}
			style += fontstr;
			styleranges += style+";";	
		}
		
		return styleranges;
	}
	
	public String getContent(){
		return sytxtContent.getText();
	}
	
	public StyleRange[] getContentStyleRange(){
		return sytxtContent.getStyleRanges();
	}
	
	public void clear(){
		images = new Image[] { };
		offsets = new int[images.length];
		sytxtContent.setText("");
		
		cmbFont.select(0);
		cmbSize.select(0);
		isBold = false;
		isItalic = false;
		isUnderline = false;
		
		lblBoldAction.setImage(new Image(parent.getDisplay(), this.getClass().getResourceAsStream("/images/fontBold.png")));
		lblItalicAction.setImage(new Image(parent.getDisplay(), this.getClass().getResourceAsStream("/images/fontItalic.png")));
		lblUnderlineAction.setImage(new Image(parent.getDisplay(), this.getClass().getResourceAsStream("/images/fontUnderline.png")));
	}
	
	public void displayContent(String content, String style, List<byte[]> pictures){	
		sytxtContent.setText(content==null?"":content);
				
		int picIndex = 0;
		if(style != null && style.length() > 0){
			String[] ranges = style.split(";");
			
			StyleRange[] col = new StyleRange[ranges.length];
			for(int i=0; i<ranges.length; i++){
				String[] styles = ranges[i].split(":");
				
				StyleRange range = new StyleRange();
				range.borderStyle = Integer.parseInt(styles[0]);
				range.fontStyle = Integer.parseInt(styles[1]);
				range.length = Integer.parseInt(styles[2]);
				range.start = Integer.parseInt(styles[3]);
				range.strikeout = styles[4].equals("false")?false:true;
				range.underline = styles[5].equals("false")?false:true;
				range.underlineStyle = Integer.parseInt(styles[6]);
				
				if(styles[7].equals("null"))
					styles[7] = "Color {0, 0, 0}";
				String[] color = styles[7].substring(7, styles[7].length()-1).split(",");
				range.foreground = new Color(Display.getCurrent (), Integer.parseInt(color[0].trim()), Integer.parseInt(color[1].trim()), Integer.parseInt(color[2].trim()));
				
				if(!styles[8].equals("null")){
					/*String filepath = FileConvertor.convertByteArrayToFile(pictures.get(picIndex)).getPath();
					Image image = new Image(parent.getDisplay(), filepath);
					range = showPicture(image, range.start);
					picIndex++;*/
					//String[] metric = styles[8].substring(14, styles[8].length()-1).split(",");
					//range.metrics = new GlyphMetrics(Integer.parseInt(metric[0].trim()), Integer.parseInt(metric[1].trim()), Integer.parseInt(metric[2].trim()));
				}
				
				if(styles[9].equals("null"))
					styles[9] = "{9,Serif,0}";
				String[] font = styles[9].substring(1, styles[9].length()-1).split(",");
				range.font = new Font(Display.getCurrent (), font[1], Integer.parseInt(font[0]), Integer.parseInt(font[2]));				
				
				col[i] = range;
			}
			sytxtContent.setStyleRanges(col);
		}
	}
	
	
	@Override
	protected void checkSubclass() {
		// Disable the check that prevents subclassing of SWT components
	}
}
