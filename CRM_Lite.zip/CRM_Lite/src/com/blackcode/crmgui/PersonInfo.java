package com.blackcode.crmgui;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.custom.PaintObjectEvent;
import org.eclipse.swt.custom.PaintObjectListener;
import org.eclipse.swt.custom.ScrolledComposite;
import org.eclipse.swt.custom.StyleRange;
import org.eclipse.swt.custom.StyledText;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.FileDialog;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.Menu;
import org.eclipse.swt.widgets.MenuItem;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Widget;
import org.eclipse.wb.swt.SWTResourceManager;
import org.eclipse.swt.custom.CLabel;
import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.graphics.GlyphMetrics;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.events.MouseAdapter;
import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.events.MouseTrackAdapter;
import org.eclipse.swt.events.KeyAdapter;
import org.eclipse.swt.events.KeyEvent;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.VerifyEvent;
import org.eclipse.swt.events.VerifyListener;

import com.blackcode.core.FileConvertor;
import com.blackcode.core.SQLiteConnector;
import com.blackcode.model.Account;
import com.blackcode.model.Contact;

import org.eclipse.swt.widgets.DateTime;
import org.eclipse.swt.events.MenuDetectListener;
import org.eclipse.swt.events.MenuDetectEvent;

public class PersonInfo extends Composite {
	private Shell shell;
	private ScrolledComposite scrolledPersonInfo;
	private Composite framePersonInfo;
	private Combo cmbAccount;
	private Text txtSerialNo;
	private Text txtCompany;
	private Text txtPosition;
	private StyledText lblPicture;
	private Composite frameName;
	private Combo cmbNameTitle;
	private Text txtNameValue;
	private Button btnAddName;
	private Composite framePhone;
	private Combo cmbPhoneTitle;
	private Text txtPhoneValue;
	private Button btnAddPhone;
	private Composite frameEmail;
	private Combo cmbEmailTitle;
	private Text txtEmailValue;	
	private Button btnAddEmail;
	private Composite frameAddress;
	private Combo cmbAddressTitle;
	private Button btnIsMailing;
	private Text txtAddressValue;
	private Button btnAddAddress;
	private Composite frameSocialNetwork;
	private Combo cmbSocialNetwork;
	private Text txtSocialNetwork;
	private Button btnAddSocial;
	private Composite frameDate;
	private Combo cmbDateTitle;
	private DateTime dateTime;
	private Button btnAddDate;
	private Composite frameOther;
	private Combo cmbOther;
	private Text txtOther;
	private Button btnAddOther;
	private Label LblNameRemove;
	private Label lblPhoneRemove;
	private Label lblEmailRemove;
	private Label lblAddressRemove;
	private Label lblSocialRemove;
	private Label lblDateRemove;
	private Label lblOtherRemove;
	private Menu picMenu;

	private int showName=1,showPhone=1,showEmail=1,showAddress=0, showSocial=0, showOther=0, showDate=0;
	private String[] nameTitles = new String[]{"Title","First Name","Middle Name","Last Name","Nice Name"};
	private String[] phoneTitles = new String[]{"Home","Mobile","Work","Alternative","Home Fax","Work Fax"};
	private String[] emailTitles = new String[]{"Personal","Work","Other"};
	private String[] addressTitles = new String[]{"Home","Work"};
	private String[] socialTitles = new String[]{"Facebook","Twitter","LinkedIn"};
	private String[] otherTitles = new String[]{"Gender","Group","Custom"};
	private String[] dateTitles = new String[]{"DOB","Custom"};
	private Contact person;
	private Image[] images = new Image[] { };
	private int[] offsets = new int[images.length];	 
	private SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
	
	/**
	 * Create the composite.
	 * @param parent
	 * @param style
	 */
	public PersonInfo(Composite parent, int style, Contact person) {
		super(parent, style);		
		shell = parent.getShell();
		this.person = person;
		
		scrolledPersonInfo = new ScrolledComposite(this, SWT.BORDER | SWT.H_SCROLL | SWT.V_SCROLL);
		scrolledPersonInfo.setBounds(0, 0, parent.getBounds().width-5, parent.getBounds().height-28);
		scrolledPersonInfo.setExpandHorizontal(true);
		scrolledPersonInfo.setExpandVertical(true);
		
		framePersonInfo = new Composite(scrolledPersonInfo, SWT.NONE);
		framePersonInfo.setBackground(SWTResourceManager.getColor(255, 255, 255));
		scrolledPersonInfo.setContent(framePersonInfo);
		scrolledPersonInfo.setMinSize(framePersonInfo.computeSize(SWT.DEFAULT, SWT.DEFAULT));
		
		CLabel lblTitle = new CLabel(framePersonInfo, SWT.NONE);
		lblTitle.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblTitle.setForeground(SWTResourceManager.getColor(52, 64, 88));
		lblTitle.setFont(SWTResourceManager.getFont("Georgia", 14, SWT.BOLD));
		lblTitle.setBounds(10, 10, 276, 21);
		lblTitle.setText("Add New Contact");
		
		cmbAccount = new Combo(framePersonInfo, SWT.NONE);
		cmbAccount.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				
			}
		});
		cmbAccount.setBounds(10, 47, 181, 23);
		cmbAccount.setText("Account");
		
		txtSerialNo = new Text(framePersonInfo, SWT.BORDER);
		txtSerialNo.setText("Contact Id");
		txtSerialNo.setToolTipText("Serial No");
		txtSerialNo.setBounds(10, 76, 181, 24);
		
		txtCompany = new Text(framePersonInfo, SWT.BORDER);
		txtCompany.setText("Company Name");
		txtCompany.setBounds(10, 106, 276, 24);
		
		txtPosition = new Text(framePersonInfo, SWT.BORDER);
		txtPosition.setText("JobTitle");
		txtPosition.setBounds(10, 136, 276, 24);
		scrolledPersonInfo.setContent(framePersonInfo);
		scrolledPersonInfo.setMinSize(framePersonInfo.computeSize(SWT.DEFAULT, SWT.DEFAULT));
		
		lblPicture = new StyledText(framePersonInfo, SWT.BORDER);
		lblPicture.addMenuDetectListener(new MenuDetectListener() {
			public void menuDetected(MenuDetectEvent e) {
				picMenu.setVisible(true);
			}
		});
		lblPicture.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDoubleClick(MouseEvent e) {
				FileDialog dialog = new FileDialog(shell);
		        String filename = dialog.open();
		        if (filename == null) 
		        	return;
		        
		        lblPicture.setData(filename);
		        images = new Image[] { };
				offsets = new int[images.length];
		        insertPicture(filename);
			}			
		});
		lblPicture.addPaintObjectListener(new PaintObjectListener() {
		      public void paintObject(PaintObjectEvent event) {
		          GC gc = event.gc;
		          StyleRange style = event.style;
		          int start = style.start;
		          for (int i = 0; i < offsets.length; i++) {
		            int offset = offsets[i];
		            if (start == offset) {
		              Image image = images[i];
		              int x = event.x;
		              int y = event.y + event.ascent - style.metrics.ascent;
		              gc.drawImage(image, x, y);
		            }
		          }
		        }
		      });
		lblPicture.addVerifyListener(new VerifyListener() {
		      public void verifyText(VerifyEvent e) {
		          int start = e.start;
		          int replaceCharCount = e.end - e.start;
		          int newCharCount = e.text.length();
		          for (int i = 0; i < offsets.length; i++) {
		            int offset = offsets[i];
		            if (start <= offset && offset < start + replaceCharCount) {
		              // this image is being deleted from the text
		              if (images[i] != null && !images[i].isDisposed()) {
		                images[i].dispose();
		                images[i] = null;
		              }
		              offset = -1;
		            }
		            if (offset != -1 && offset >= start)
		              offset += newCharCount - replaceCharCount;
		            offsets[i] = offset;
		          }
		        }
		      });
		lblPicture.setBounds(292, 10, 150, 150);
		lblPicture.setEditable(false);
		
		frameName = new Composite(framePersonInfo, SWT.NONE);
		frameName.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		frameName.setBounds(10, 171, 431, 95);
		
		CLabel lblName = new CLabel(frameName, SWT.SHADOW_OUT);
		lblName.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				if(showName==1)
					showName=0;
				else
					showName=1;
				computeFrames(1);
			}
		});
		lblName.setFont(SWTResourceManager.getFont("Georgia", 10, SWT.BOLD));
		lblName.setBounds(0, 0, 431, 25);
		lblName.setImage(new Image(shell.getDisplay(), PersonFrame.class.getResourceAsStream("/images/arrowdownleft21.png")));
		lblName.setText("Name");
		
		cmbNameTitle = new Combo(frameName, SWT.NONE);
		cmbNameTitle.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				if(!selectTitle(frameName, ((Combo)e.widget).getText()))
					((Combo)e.widget).setText("");
			}
		});
		cmbNameTitle.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				cmbNameTitle.setText("");
			}
			@Override
			public void keyReleased(KeyEvent e) {
				cmbNameTitle.setText("");
			}
		});
		cmbNameTitle.setBounds(0, 31, 125, 23);
		cmbNameTitle.setItems(nameTitles);
		cmbNameTitle.setData("id", 0);
		
		txtNameValue = new Text(frameName, SWT.BORDER);
		txtNameValue.setBounds(131, 31, 265, 24);
		txtNameValue.setData("id", 0);
		
		LblNameRemove = new Label(frameName, SWT.NONE);
		LblNameRemove.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {				
				removeField(frameName, ((Label)e.widget).getData("id"));
			}
		});
		LblNameRemove.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				((Label)e.widget).setBackground(SWTResourceManager.getColor(235, 243, 247));
			}
			@Override
			public void mouseExit(MouseEvent e) {
				((Label)e.widget).setBackground(SWTResourceManager.getColor(255, 255, 255));
			}
		});
		LblNameRemove.setBounds(402, 31, 24, 24);
		LblNameRemove.setBackground(SWTResourceManager.getColor(255, 255, 255));
		LblNameRemove.setImage(new Image(shell.getDisplay(), PersonFrame.class.getResourceAsStream("/images/remove24.png")));
		LblNameRemove.setData("id", 0);
		
		btnAddName = new Button(frameName, SWT.NONE);
		btnAddName.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				addNameField(null, null);
			}
		});
		btnAddName.setBounds(177, 63, 75, 25);
		btnAddName.setText("Add Field");
				
		framePhone = new Composite(framePersonInfo, SWT.NONE);
		framePhone.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		framePhone.setBounds(11, 277, 431, 95);
		
		CLabel lblPhone = new CLabel(framePhone, SWT.SHADOW_OUT);
		lblPhone.setFont(SWTResourceManager.getFont("Georgia", 10, SWT.BOLD));
		lblPhone.setBounds(0, 0, 431, 25);
		lblPhone.setImage(new Image(shell.getDisplay(), PersonFrame.class.getResourceAsStream("/images/arrowdownleft21.png")));
		lblPhone.setText("Phone");
		lblPhone.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				if(showPhone==1)
					showPhone=0;
				else
					showPhone=1;
				computeFrames(2);
			}
		});
		
		cmbPhoneTitle = new Combo(framePhone, SWT.NONE);
		cmbPhoneTitle.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				if(!selectTitle(framePhone, ((Combo)e.widget).getText()))
					((Combo)e.widget).setText("");
			}
		});
		cmbPhoneTitle.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				cmbPhoneTitle.setText("");
			}
			@Override
			public void keyReleased(KeyEvent e) {
				cmbPhoneTitle.setText("");
			}
		});
		cmbPhoneTitle.setBounds(0, 31, 125, 23);
		cmbPhoneTitle.setItems(phoneTitles);
		cmbPhoneTitle.setData("id",0);
		
		txtPhoneValue = new Text(framePhone, SWT.BORDER);
		txtPhoneValue.setBounds(131, 31, 265, 24);
		txtPhoneValue.setData("id", 0);
		
		lblPhoneRemove = new Label(framePhone, SWT.NONE);
		lblPhoneRemove.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {				
				removeField(framePhone, ((Label)e.widget).getData("id"));
			}
		});
		lblPhoneRemove.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				((Label)e.widget).setBackground(SWTResourceManager.getColor(235, 243, 247));
			}
			@Override
			public void mouseExit(MouseEvent e) {
				((Label)e.widget).setBackground(SWTResourceManager.getColor(255, 255, 255));
			}
		});
		lblPhoneRemove.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblPhoneRemove.setBounds(402, 31, 24, 24);
		lblPhoneRemove.setImage(new Image(shell.getDisplay(), PersonFrame.class.getResourceAsStream("/images/remove24.png")));
		lblPhoneRemove.setData("id", 0);
		
		btnAddPhone = new Button(framePhone, SWT.NONE);
		btnAddPhone.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				addPhoneField(null,null);
			}
		});
		btnAddPhone.setBounds(177, 63, 75, 25);
		btnAddPhone.setText("Add Field");
		btnAddPhone.setData("id", 0);
				
		frameEmail = new Composite(framePersonInfo, SWT.NONE);
		frameEmail.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		frameEmail.setBounds(10, 383, 431, 95);
		
		CLabel lblEmail = new CLabel(frameEmail, SWT.SHADOW_OUT);
		lblEmail.setFont(SWTResourceManager.getFont("Georgia", 10, SWT.BOLD));
		lblEmail.setBounds(0, 0, 431, 25);
		lblEmail.setImage(new Image(shell.getDisplay(), PersonFrame.class.getResourceAsStream("/images/arrowdownleft21.png")));
		lblEmail.setText("Email");
		lblEmail.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				if(showEmail==1)
					showEmail=0;
				else
					showEmail=1;
				computeFrames(3);
			}
		});
		
		cmbEmailTitle = new Combo(frameEmail, SWT.NONE);
		cmbEmailTitle.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				if(!selectTitle(frameEmail, ((Combo)e.widget).getText()))
					((Combo)e.widget).setText("");
			}
		});
		cmbEmailTitle.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				cmbEmailTitle.setText("");
			}
			@Override
			public void keyReleased(KeyEvent e) {
				cmbEmailTitle.setText("");
			}
		});
		cmbEmailTitle.setBounds(0, 31, 125, 23);
		cmbEmailTitle.setItems(emailTitles);
		cmbEmailTitle.setData("id", 0);
		
		txtEmailValue = new Text(frameEmail, SWT.BORDER);
		txtEmailValue.setBounds(131, 31, 265, 24);
		txtEmailValue.setData("id", 0);
		
		lblEmailRemove = new Label(frameEmail, SWT.NONE);
		lblEmailRemove.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {				
				removeField(frameEmail, ((Label)e.widget).getData("id"));
			}
		});
		lblEmailRemove.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				((Label)e.widget).setBackground(SWTResourceManager.getColor(235, 243, 247));
			}
			@Override
			public void mouseExit(MouseEvent e) {
				((Label)e.widget).setBackground(SWTResourceManager.getColor(255, 255, 255));
			}
		});
		lblEmailRemove.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblEmailRemove.setBounds(402, 31, 24, 24);
		lblEmailRemove.setImage(new Image(shell.getDisplay(), PersonFrame.class.getResourceAsStream("/images/remove24.png")));
		lblEmailRemove.setData("id", 0);
		
		btnAddEmail = new Button(frameEmail, SWT.NONE);
		btnAddEmail.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				addEmailField(null,null);
			}
		});
		btnAddEmail.setBounds(179, 63, 75, 25);
		btnAddEmail.setText("Add Field");
		
		frameDate = new Composite(framePersonInfo, SWT.READ_ONLY);
		frameDate.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		frameDate.setBounds(10, 489, 431, 95);
		
		CLabel lblDate = new CLabel(frameDate, SWT.SHADOW_OUT);
		lblDate.setFont(SWTResourceManager.getFont("Georgia", 10, SWT.BOLD));
		lblDate.setBounds(0, 0, 431, 25);
		lblDate.setImage(new Image(shell.getDisplay(), PersonFrame.class.getResourceAsStream("/images/arrowdownleft21.png")));
		lblDate.setText("Importance Dates");
		lblDate.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				if(showDate==1)
					showDate=0;
				else
					showDate=1;
				computeFrames(4);
			}
		});
		
		cmbDateTitle = new Combo(frameDate, SWT.NONE);
		cmbDateTitle.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				if(!selectTitle(frameDate, ((Combo)e.widget).getText()))
					((Combo)e.widget).setText("");
			}
		});
		cmbDateTitle.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				if(((Combo)e.widget).getText().equals("Custom"))
					cmbDateTitle.setText("");
			}
		});
		cmbDateTitle.setBounds(0, 31, 125, 23);
		cmbDateTitle.setItems(dateTitles);
		cmbDateTitle.setData("id",0);
		
		dateTime = new DateTime(frameDate, SWT.BORDER | SWT.DROP_DOWN);
		dateTime.setBounds(131, 31, 80, 24);
		dateTime.setData("id",0);
		
		lblDateRemove = new Label(frameDate, SWT.NONE);
		lblDateRemove.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {				
				removeField(frameDate, ((Label)e.widget).getData("id"));
			}
		});
		lblDateRemove.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				((Label)e.widget).setBackground(SWTResourceManager.getColor(235, 243, 247));
			}
			@Override
			public void mouseExit(MouseEvent e) {
				((Label)e.widget).setBackground(SWTResourceManager.getColor(255, 255, 255));
			}
		});
		lblDateRemove.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblDateRemove.setBounds(402, 31, 25, 25);
		lblDateRemove.setImage(new Image(shell.getDisplay(), PersonFrame.class.getResourceAsStream("/images/remove24.png")));
		lblDateRemove.setData("id",0);
		
		btnAddDate= new Button(frameDate, SWT.NONE);
		btnAddDate.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				addDateField(null,null);
			}
		});
		btnAddDate.setLocation(177, 63);
		btnAddDate.setSize(75, 25);
		btnAddDate.setText("Add Date");
		
		frameOther = new Composite(framePersonInfo, SWT.NONE);
		frameOther.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		frameOther.setBounds(10, 617, 431, 95);
		
		CLabel lblOther = new CLabel(frameOther, SWT.SHADOW_OUT);
		lblOther.setFont(SWTResourceManager.getFont("Georgia", 10, SWT.BOLD));
		lblOther.setBounds(0, 0, 431, 25);
		lblOther.setImage(new Image(shell.getDisplay(), PersonFrame.class.getResourceAsStream("/images/arrowdownleft21.png")));
		lblOther.setText("Other");
		lblOther.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				if(showOther==1)
					showOther=0;
				else
					showOther=1;
				computeFrames(5);
			}
		});
		
		cmbOther = new Combo(frameOther, SWT.NONE);
		cmbOther.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				if(!selectTitle(frameOther, ((Combo)e.widget).getText()))
					((Combo)e.widget).setText("");
			}
		});
		cmbOther.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				if(((Combo)e.widget).getText().equals("Custom"))
					cmbOther.setText("");
			}
		});
		cmbOther.setBounds(0, 31, 125, 23);
		cmbOther.setItems(otherTitles);
		cmbOther.setData("id",0);
		
		txtOther = new Text(frameOther, SWT.BORDER);
		txtOther.setBounds(131, 31, 265, 24);
		txtOther.setData("id",0);
		
		lblOtherRemove = new Label(frameOther, SWT.NONE);
		lblOtherRemove.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {				
				removeField(frameOther, ((Label)e.widget).getData("id"));
			}
		});
		lblOtherRemove.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				((Label)e.widget).setBackground(SWTResourceManager.getColor(235, 243, 247));
			}
			@Override
			public void mouseExit(MouseEvent e) {
				((Label)e.widget).setBackground(SWTResourceManager.getColor(255, 255, 255));
			}
		});
		lblOtherRemove.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblOtherRemove.setBounds(402, 31, 25, 25);
		lblOtherRemove.setImage(new Image(shell.getDisplay(), PersonFrame.class.getResourceAsStream("/images/remove24.png")));
		lblOtherRemove.setData("id",0);
		
		btnAddOther= new Button(frameOther, SWT.NONE);
		btnAddOther.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				addOtherField(null,null);
			}
		});
		btnAddOther.setLocation(177, 63);
		btnAddOther.setSize(75, 25);
		btnAddOther.setText("Add Filed");
		
		frameSocialNetwork = new Composite(framePersonInfo, SWT.READ_ONLY);
		frameSocialNetwork.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		frameSocialNetwork.setBounds(10, 745, 431, 95);
		
		CLabel lblSocialNetwork = new CLabel(frameSocialNetwork, SWT.SHADOW_OUT);
		lblSocialNetwork.setFont(SWTResourceManager.getFont("Georgia", 10, SWT.BOLD));
		lblSocialNetwork.setBounds(0, 0, 431, 25);
		lblSocialNetwork.setImage(new Image(shell.getDisplay(), PersonFrame.class.getResourceAsStream("/images/arrowdownleft21.png")));
		lblSocialNetwork.setText("Social Network");
		lblSocialNetwork.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				if(showSocial==1)
					showSocial=0;
				else
					showSocial=1;
				computeFrames(6);
			}
		});
		
		cmbSocialNetwork = new Combo(frameSocialNetwork, SWT.NONE);
		cmbSocialNetwork.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				if(!selectTitle(frameSocialNetwork, ((Combo)e.widget).getText()))
					((Combo)e.widget).setText("");
			}
		});
		cmbSocialNetwork.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				cmbSocialNetwork.setText("");
			}
			@Override
			public void keyReleased(KeyEvent e) {
				cmbSocialNetwork.setText("");
			}
		});
		cmbSocialNetwork.setBounds(0, 31, 125, 23);
		cmbSocialNetwork.setItems(socialTitles);
		cmbSocialNetwork.setData("id",0);
		
		txtSocialNetwork = new Text(frameSocialNetwork, SWT.BORDER);
		txtSocialNetwork.setBounds(131, 31, 265, 24);
		txtSocialNetwork.setData("id",0);
		
		lblSocialRemove = new Label(frameSocialNetwork, SWT.NONE);
		lblSocialRemove.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {				
				removeField(frameSocialNetwork, ((Label)e.widget).getData("id"));
			}
		});
		lblSocialRemove.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				((Label)e.widget).setBackground(SWTResourceManager.getColor(235, 243, 247));
			}
			@Override
			public void mouseExit(MouseEvent e) {
				((Label)e.widget).setBackground(SWTResourceManager.getColor(255, 255, 255));
			}
		});
		lblSocialRemove.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblSocialRemove.setBounds(402, 31, 25, 25);
		lblSocialRemove.setImage(new Image(shell.getDisplay(), PersonFrame.class.getResourceAsStream("/images/remove24.png")));
		lblSocialRemove.setData("id",0);
		
		btnAddSocial= new Button(frameSocialNetwork, SWT.NONE);
		btnAddSocial.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				addSocialField(null,null);
			}
		});
		btnAddSocial.setLocation(177, 63);
		btnAddSocial.setSize(75, 25);
		btnAddSocial.setText("Add Social");
		
		frameAddress = new Composite(framePersonInfo, SWT.NONE);
		frameAddress.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		frameAddress.setBounds(10, 851, 431, 117);
		
		CLabel lblAddress = new CLabel(frameAddress, SWT.SHADOW_OUT);
		lblAddress.setFont(SWTResourceManager.getFont("Georgia", 10, SWT.BOLD));
		lblAddress.setBounds(0, 0, 431, 25);
		lblAddress.setImage(new Image(shell.getDisplay(), PersonFrame.class.getResourceAsStream("/images/arrowdownleft21.png")));
		lblAddress.setText("Address");
		lblAddress.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				if(showAddress==1)
					showAddress=0;
				else
					showAddress=1;
				computeFrames(7);
			}
		});
		
		cmbAddressTitle = new Combo(frameAddress, SWT.NONE);
		cmbAddressTitle.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				if(!selectTitle(frameAddress, ((Combo)e.widget).getText()))
					((Combo)e.widget).setText("");
			}
		});
		cmbAddressTitle.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				cmbAddressTitle.setText("");
			}
			@Override
			public void keyReleased(KeyEvent e) {
				cmbAddressTitle.setText("");
			}
		});
		cmbAddressTitle.setBounds(0, 31, 125, 23);
		cmbAddressTitle.setItems(addressTitles);
		cmbAddressTitle.setData("id", 0);
		
		txtAddressValue = new Text(frameAddress, SWT.BORDER | SWT.MULTI);
		txtAddressValue.setBounds(131, 31, 265, 48);
		txtAddressValue.setData("id", 0);
		
		btnIsMailing = new Button(frameAddress, SWT.CHECK);
		btnIsMailing.setBounds(53, 60, 72, 16);
		btnIsMailing.setBackground(SWTResourceManager.getColor(255, 255, 255));
		btnIsMailing.setText("Is Mailing");
		btnIsMailing.setData("id", 0);
		
		lblAddressRemove = new Label(frameAddress, SWT.NONE);
		lblAddressRemove.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {				
				removeField(frameAddress, ((Label)e.widget).getData("id"));
			}
		});
		lblAddressRemove.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				((Label)e.widget).setBackground(SWTResourceManager.getColor(235, 243, 247));
			}
			@Override
			public void mouseExit(MouseEvent e) {
				((Label)e.widget).setBackground(SWTResourceManager.getColor(255, 255, 255));
			}
		});
		lblAddressRemove.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblAddressRemove.setBounds(402, 31, 24, 24);
		lblAddressRemove.setImage(new Image(shell.getDisplay(), PersonFrame.class.getResourceAsStream("/images/remove24.png")));
		lblAddressRemove.setData("id",0);
		
		btnAddAddress = new Button(frameAddress, SWT.NONE);
		btnAddAddress.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				addAddressField(null,null);
			}
		});
		btnAddAddress.setBounds(177, 85, 75, 25);
		btnAddAddress.setText("Add Field");
				
		scrolledPersonInfo.setContent(framePersonInfo);
		scrolledPersonInfo.setMinSize(framePersonInfo.computeSize(SWT.DEFAULT, SWT.DEFAULT));
		
		picMenu = new Menu(lblPicture);
		 MenuItem addItem = new MenuItem(picMenu, SWT.NONE);
		 addItem .setText("Insert Picture");
		 addItem.setImage(new Image(shell.getDisplay(), AccountDialog.class.getResourceAsStream("/images/add.gif")));
		 addItem .addListener(SWT.Selection, new Listener() {
			public void handleEvent(Event e) {
					FileDialog dialog = new FileDialog(shell);
			        String filename = dialog.open();
			        if (filename == null) 
			        	return;
			        
			        lblPicture.setData(filename);
			        images = new Image[] { };
					offsets = new int[images.length];
			        insertPicture(filename);
		    	}
		 	});
	    MenuItem removeItem = new MenuItem(picMenu, SWT.NONE);
	    removeItem .setText("Remove Picture");
	    removeItem.setImage(new Image(shell.getDisplay(), AccountDialog.class.getResourceAsStream("/images/remove.png")));
	    removeItem .addListener(SWT.Selection, new Listener() {
	        public void handleEvent(Event e) {
		        	images = new Image[] { };
		    		offsets = new int[images.length];
		    		lblPicture.setText("");
		    		lblPicture.setData(null);
	          }
	        });
	    
		setInitial();
	}

	private void setInitial(){		
		List<Account> accessAccounts = new SQLiteConnector().readAccount(null, null);
		for(int i=0; i<accessAccounts.size(); i++){
			Account account = (Account)accessAccounts.get(i);
			cmbAccount.add(account.getCode());
		}
		if(cmbAccount.getItemCount() > 0){
			cmbAccount.select(0);
		}
		
		computeFrames(0);
	}
	
	private void computeFrames(int index){
		try{
			int y = 171;
			
			if(showName == 0){
				frameName.setBounds(10, y, 431, 25);
			}else{
				frameName.setBounds(10, y, 431, calculateHeight(frameName, 1));
			}
			frameName.redraw();
			y += frameName.getBounds().height + 11;
			
			if(showPhone == 0){
				framePhone.setBounds(10, y, 431, 25);
			}else{
				framePhone.setBounds(10, y, 431, calculateHeight(framePhone, 2));
			}
			framePhone.redraw();
			y += framePhone.getBounds().height + 11;
			
			if(showEmail == 0){
				frameEmail.setBounds(10, y, 431, 25);
			}else{
				frameEmail.setBounds(10, y, 431, calculateHeight(frameEmail, 3));
			}
			frameEmail.redraw();
			y += frameEmail.getBounds().height + 11;
					
			if(showDate == 0){
				frameDate.setBounds(10, y, 431, 25);
			}else{
				frameDate.setBounds(10, y, 431, calculateHeight(frameDate,4));
			}
			frameDate.redraw();
			y += frameDate.getBounds().height + 11;
			
			if(showOther == 0){
				frameOther.setBounds(10, y, 431, 25);
			}else{
				frameOther.setBounds(10, y, 431, calculateHeight(frameOther, 5));
			}
			frameOther.redraw();
			y += frameOther.getBounds().height + 11;
			
			if(showSocial == 0){
				frameSocialNetwork.setBounds(10, y, 431, 25);
			}else{
				frameSocialNetwork.setBounds(10, y, 431, calculateHeight(frameSocialNetwork,4));
			}
			frameSocialNetwork.redraw();
			y += frameSocialNetwork.getBounds().height + 11;
			
			if(showAddress == 0){
				frameAddress.setBounds(10, y, 431, 25);
			}else{
				frameAddress.setBounds(10, y, 431, calculateHeight(frameAddress, 6));
			}
			frameAddress.redraw();
			y += frameAddress.getBounds().height + 11;
			
			scrolledPersonInfo.setContent(framePersonInfo);
			scrolledPersonInfo.setMinSize(framePersonInfo.computeSize(SWT.DEFAULT, SWT.DEFAULT));
			
		}catch (Exception e){
			MessageDialog dlg = new MessageDialog(shell, SWT.NONE,"Error 401 : Syetem Problems (PI891)");
			dlg.open();
		}
	}
	
	private int calculateHeight(Composite frame, int id){
		int height = 25;
		int lines = 0;
		Control[] items = frame.getChildren();
		for(int i=0; i<items.length; i++){
			if(items[i] instanceof Combo)
				lines++;
		}
		
		if(id == 6)
			height += lines*53;
		else
			height += lines*30;
		height += 33;
		return height;
	}
	
	private void removeField(Composite frame, Object index){
		try{
			int y = 31;
			Control[] items = frame.getChildren();
			Button button = null;
			for(int i=0; i<items.length; i++){
				Widget item = items[i];
				if(item instanceof Button){
					button = (Button)item;
					continue;
				}
				//Remove widget
				if(item.getData("id") != null && item.getData("id").equals(index)){
					item.dispose();
					continue;
				}
				//Reset location
				if(item.getData("id") != null){
					if(item instanceof Combo){
						((Combo) item).setLocation(0, y);
					}else if(item instanceof Text){
						((Text) item).setLocation(131, y);
					}else if(item instanceof DateTime){
						((DateTime) item).setLocation(131, y);
					}else if(item instanceof Label){
						((Label) item).setLocation(402, y);
						 y += 30;
					}
				}
			}
			button.setLocation(177, y+3); 
			computeFrames(0);
		}catch (Exception e){
			MessageDialog dlg = new MessageDialog(shell, SWT.NONE,"Error 401 : Syetem Problems (PI946)");
			dlg.open();
		}		
	}
	
	private boolean selectTitle(Composite frame, String title){
		int count = 0;
		Control[] items = frame.getChildren();
		for(int i=0; i<items.length; i++){			
			if(items[i] instanceof Combo && ((Combo) items[i]).getText().equals(title)){
				count++;
			}
		}
		if(count > 1)
			return false;
		else
			return true;
	}
	
	private void addNameField(String title, String value){
		try{
			int y = 31;
			int lines = 0;
			Control[] items = frameName.getChildren();
			for(int i=0; i<items.length; i++){
				if(items[i] instanceof Combo)
					lines++;
			}
			
			if(lines >= nameTitles.length)
				return;
			
			y += lines*30;
			
			cmbNameTitle = new Combo(frameName, SWT.NONE);
			cmbNameTitle.addKeyListener(new KeyAdapter() {
				@Override
				public void keyPressed(KeyEvent e) {
					cmbNameTitle.setText("");
				}
				@Override
				public void keyReleased(KeyEvent e) {
					cmbNameTitle.setText("");
				}
			});
			cmbNameTitle.addSelectionListener(new SelectionAdapter() {
				@Override
				public void widgetSelected(SelectionEvent e) {
					if(!selectTitle(frameName, ((Combo)e.widget).getText()))
						((Combo)e.widget).setText("");
				}
			});
			cmbNameTitle.setBounds(0, y, 125, 23);
			cmbNameTitle.setItems(nameTitles);
			cmbNameTitle.setData("id", lines);
			if(title != null)
				cmbNameTitle.setText(title);
			
			txtNameValue = new Text(frameName, SWT.BORDER);
			txtNameValue.setBounds(131, y, 265, 24);
			txtNameValue.setData("id", lines);
			if(value != null)
				txtNameValue.setText(value);
			
			LblNameRemove = new Label(frameName, SWT.NONE);
			LblNameRemove.addMouseListener(new MouseAdapter() {
				@Override
				public void mouseDown(MouseEvent e) {
					
					removeField(frameName, ((Label)e.widget).getData("id"));
				}
			});
			LblNameRemove.addMouseTrackListener(new MouseTrackAdapter() {
				@Override
				public void mouseEnter(MouseEvent e) {
					((Label)e.widget).setBackground(SWTResourceManager.getColor(235, 243, 247));
				}
				@Override
				public void mouseExit(MouseEvent e) {
					((Label)e.widget).setBackground(SWTResourceManager.getColor(255, 255, 255));
				}
			});
			LblNameRemove.setBounds(402, y, 24, 24);
			LblNameRemove.setBackground(SWTResourceManager.getColor(255, 255, 255));
			LblNameRemove.setImage(new Image(shell.getDisplay(), PersonFrame.class.getResourceAsStream("/images/remove24.png")));
			LblNameRemove.setData("id", lines);
			
			btnAddName.setLocation(177, y+33);
			
			computeFrames(0);
		}catch (Exception e){
			MessageDialog dlg = new MessageDialog(shell, SWT.NONE,"Error 401 : Syetem Problems (PI1037)");
			dlg.open();
		}
	}
	
	private void addPhoneField(String title, String value){
		try{
			int y = 31;
			int lines = 0;
			Control[] items = framePhone.getChildren();
			for(int i=0; i<items.length; i++){
				if(items[i] instanceof Combo)
					lines++;
			}
			
			if(lines >= phoneTitles.length)
				return;
			
			y += lines*30;
			
			cmbPhoneTitle = new Combo(framePhone, SWT.NONE);		
			cmbPhoneTitle.addKeyListener(new KeyAdapter() {
				@Override
				public void keyPressed(KeyEvent e) {
					cmbPhoneTitle.setText("");
				}
				@Override
				public void keyReleased(KeyEvent e) {
					cmbPhoneTitle.setText("");
				}
			});
			cmbPhoneTitle.addSelectionListener(new SelectionAdapter() {
				@Override
				public void widgetSelected(SelectionEvent e) {
					if(!selectTitle(framePhone, ((Combo)e.widget).getText()))
						((Combo)e.widget).setText("");
				}
			});
			cmbPhoneTitle.setBounds(0, y, 125, 23);
			cmbPhoneTitle.setItems(phoneTitles);
			cmbPhoneTitle.setData("id", lines);
			if(title != null)
				cmbPhoneTitle.setText(title);
			
			txtPhoneValue = new Text(framePhone, SWT.BORDER);
			txtPhoneValue.setBounds(131, y, 265, 24);
			txtPhoneValue.setData("id", lines);
			if(value != null)
				txtPhoneValue.setText(value);
			
			lblPhoneRemove = new Label(framePhone, SWT.NONE);
			lblPhoneRemove.addMouseListener(new MouseAdapter() {
				@Override
				public void mouseDown(MouseEvent e) {				
					if(((Label)e.widget).getData("id") == new Integer(0))
						return;
					
					removeField(framePhone, ((Label)e.widget).getData("id"));
				}
			});
			lblPhoneRemove.addMouseTrackListener(new MouseTrackAdapter() {
				@Override
				public void mouseEnter(MouseEvent e) {
					((Label)e.widget).setBackground(SWTResourceManager.getColor(235, 243, 247));
				}
				@Override
				public void mouseExit(MouseEvent e) {
					((Label)e.widget).setBackground(SWTResourceManager.getColor(255, 255, 255));
				}
			});
			lblPhoneRemove.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
			lblPhoneRemove.setBounds(402, y, 24, 24);
			lblPhoneRemove.setImage(new Image(shell.getDisplay(), PersonFrame.class.getResourceAsStream("/images/remove24.png")));
			lblPhoneRemove.setData("id", lines);
			
			btnAddPhone.setLocation(177, y+33);
			
			computeFrames(0);
		}catch (Exception e){
			MessageDialog dlg = new MessageDialog(shell, SWT.NONE,"Error 401 : Syetem Problems (PI1116)");
			dlg.open();
		}
		
	}
	
	private void addEmailField(String title, String value){
		try{
			int y = 31;
			int lines = 0;
			Control[] items = frameEmail.getChildren();
			for(int i=0; i<items.length; i++){
				if(items[i] instanceof Combo)
					lines++;
			}
			
			if(lines >= emailTitles.length)
				return;
			
			y += lines*30;
			
			cmbEmailTitle = new Combo(frameEmail, SWT.NONE);
			cmbEmailTitle.addSelectionListener(new SelectionAdapter() {
				@Override
				public void widgetSelected(SelectionEvent e) {
					if(!selectTitle(frameEmail, ((Combo)e.widget).getText()))
						((Combo)e.widget).setText("");
				}
			});
			cmbEmailTitle.addKeyListener(new KeyAdapter() {
				@Override
				public void keyPressed(KeyEvent e) {
					cmbEmailTitle.setText("");
				}
				@Override
				public void keyReleased(KeyEvent e) {
					cmbEmailTitle.setText("");
				}
			});
			cmbEmailTitle.setBounds(0, y, 125, 23);
			cmbEmailTitle.setItems(emailTitles);
			cmbEmailTitle.setData("id", lines);
			if(title != null)
				cmbEmailTitle.setText(title);
			
			txtEmailValue = new Text(frameEmail, SWT.BORDER);
			txtEmailValue.setBounds(131, y, 265, 24);
			txtEmailValue.setData("id", lines);
			if(value != null)
				txtEmailValue.setText(value);
			
			lblEmailRemove = new Label(frameEmail, SWT.NONE);
			lblEmailRemove.addMouseListener(new MouseAdapter() {
				@Override
				public void mouseDown(MouseEvent e) {				
					removeField(frameEmail, ((Label)e.widget).getData("id"));
				}
			});
			lblEmailRemove.addMouseTrackListener(new MouseTrackAdapter() {
				@Override
				public void mouseEnter(MouseEvent e) {
					((Label)e.widget).setBackground(SWTResourceManager.getColor(235, 243, 247));
				}
				@Override
				public void mouseExit(MouseEvent e) {
					((Label)e.widget).setBackground(SWTResourceManager.getColor(255, 255, 255));
				}
			});
			lblEmailRemove.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
			lblEmailRemove.setBounds(402, y, 24, 24);
			lblEmailRemove.setImage(new Image(shell.getDisplay(), PersonFrame.class.getResourceAsStream("/images/remove24.png")));
			lblEmailRemove.setData("id", lines);
			
			btnAddEmail.setLocation(177, y+33);
			
			computeFrames(0);
		}catch (Exception e){
			MessageDialog dlg = new MessageDialog(shell, SWT.NONE,"Error 401 : Syetem Problems (PI1193)");
			dlg.open();
		}
	}
	
	private void addAddressField(String title, String value){
		try{
			int y = 31;
			int lines = 0;
			Control[] items = frameAddress.getChildren();
			for(int i=0; i<items.length; i++){
				if(items[i] instanceof Combo)
					lines++;
			}
			
			if(lines >= addressTitles.length)
				return;
			
			y += lines*53;
			
			cmbAddressTitle = new Combo(frameAddress, SWT.NONE);
			cmbAddressTitle.addSelectionListener(new SelectionAdapter() {
				@Override
				public void widgetSelected(SelectionEvent e) {
					if(!selectTitle(frameAddress, ((Combo)e.widget).getText()))
						((Combo)e.widget).setText("");
				}
			});
			cmbAddressTitle.addKeyListener(new KeyAdapter() {
				@Override
				public void keyPressed(KeyEvent e) {
					cmbAddressTitle.setText("");
				}
				@Override
				public void keyReleased(KeyEvent e) {
					cmbAddressTitle.setText("");
				}
			});
			cmbAddressTitle.setBounds(0, y, 125, 23);
			cmbAddressTitle.setItems(addressTitles);
			cmbAddressTitle.setData("id", lines);
			if(title != null)
				cmbAddressTitle.setText(title);
					
			txtAddressValue = new Text(frameAddress, SWT.BORDER | SWT.MULTI);
			txtAddressValue.setBounds(131, y, 265, 48);
			txtAddressValue.setData("id", lines);
			if(value != null)
				txtAddressValue.setText(value);
			
			btnIsMailing = new Button(frameAddress, SWT.CHECK);
			btnIsMailing.setBounds(53, y+30, 72, 16);
			btnIsMailing.setBackground(SWTResourceManager.getColor(255, 255, 255));
			btnIsMailing.setText("Is Mailing");
			btnIsMailing.setData("id", lines);
			
			lblAddressRemove = new Label(frameAddress, SWT.NONE);
			lblAddressRemove.addMouseListener(new MouseAdapter() {
				@Override
				public void mouseDown(MouseEvent e) {								
					removeField(frameAddress, ((Label)e.widget).getData("id"));
				}
			});
			lblAddressRemove.addMouseTrackListener(new MouseTrackAdapter() {
				@Override
				public void mouseEnter(MouseEvent e) {
					((Label)e.widget).setBackground(SWTResourceManager.getColor(235, 243, 247));
				}
				@Override
				public void mouseExit(MouseEvent e) {
					((Label)e.widget).setBackground(SWTResourceManager.getColor(255, 255, 255));
				}
			});
			lblAddressRemove.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
			lblAddressRemove.setBounds(402, y, 24, 24);
			lblAddressRemove.setImage(new Image(shell.getDisplay(), PersonFrame.class.getResourceAsStream("/images/remove24.png")));
			lblAddressRemove.setData("id",lines);
			
			btnAddAddress.setLocation(177, y+56);
			
			computeFrames(0);
		}catch (Exception e){
			MessageDialog dlg = new MessageDialog(shell, SWT.NONE,"Error 401 : Syetem Problems (PI1275)");
			dlg.open();
		}
	}
	
	private void addSocialField(String title, String value){
		try{
			int y = 31;
			int lines = 0;
			Control[] items = frameSocialNetwork.getChildren();
			for(int i=0; i<items.length; i++){
				if(items[i] instanceof Combo)
					lines++;
			}
			
			if(lines >= socialTitles.length)
				return;
			
			y += lines*30;
			
			cmbSocialNetwork = new Combo(frameSocialNetwork, SWT.NONE);
			cmbSocialNetwork.addSelectionListener(new SelectionAdapter() {
				@Override
				public void widgetSelected(SelectionEvent e) {
					if(!selectTitle(frameSocialNetwork, ((Combo)e.widget).getText()))
						((Combo)e.widget).setText("");
				}
			});
			cmbSocialNetwork.addKeyListener(new KeyAdapter() {
				@Override
				public void keyPressed(KeyEvent e) {
					cmbSocialNetwork.setText("");
				}
				@Override
				public void keyReleased(KeyEvent e) {
					cmbSocialNetwork.setText("");
				}
			});
			cmbSocialNetwork.setBounds(0, y, 125, 23);
			cmbSocialNetwork.setItems(socialTitles);
			cmbSocialNetwork.setData("id", lines);
			if(title != null)
				cmbSocialNetwork.setText(title);
			
			txtSocialNetwork = new Text(frameSocialNetwork, SWT.BORDER);
			txtSocialNetwork.setBounds(131, y, 265, 24);
			txtSocialNetwork.setData("id", lines);
			if(value != null)
				txtSocialNetwork.setText(value);
			
			lblSocialRemove = new Label(frameSocialNetwork, SWT.NONE);
			lblSocialRemove.addMouseListener(new MouseAdapter() {
				@Override
				public void mouseDown(MouseEvent e) {				
					if(((Label)e.widget).getData("id") == new Integer(0))
						return;
					
					removeField(frameSocialNetwork, ((Label)e.widget).getData("id"));
				}
			});
			lblSocialRemove.addMouseTrackListener(new MouseTrackAdapter() {
				@Override
				public void mouseEnter(MouseEvent e) {
					((Label)e.widget).setBackground(SWTResourceManager.getColor(235, 243, 247));
				}
				@Override
				public void mouseExit(MouseEvent e) {
					((Label)e.widget).setBackground(SWTResourceManager.getColor(255, 255, 255));
				}
			});
			lblSocialRemove.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
			lblSocialRemove.setBounds(402, y, 25, 25);
			lblSocialRemove.setImage(new Image(shell.getDisplay(), PersonFrame.class.getResourceAsStream("/images/remove24.png")));
			lblSocialRemove.setData("id",lines);
			
			btnAddSocial.setLocation(177, y+33);
			
			computeFrames(0);
		}catch (Exception e){
			MessageDialog dlg = new MessageDialog(shell, SWT.NONE,"Error 401 : Syetem Problems (PI1354)");
			dlg.open();
		}
	}
	
	private void addDateField(String title, int[] value){
		try{
			int y = 31;
			int lines = 0;
			Control[] items = frameDate.getChildren();
			for(int i=0; i<items.length; i++){
				if(items[i] instanceof Combo)
					lines++;
			}
			
			y += lines*30;
			
			cmbDateTitle = new Combo(frameDate, SWT.NONE);
			cmbDateTitle.addSelectionListener(new SelectionAdapter() {
				@Override
				public void widgetSelected(SelectionEvent e) {
					if(((Combo)e.widget).getText().equals("Custom"))
						((Combo)e.widget).setText("");
				}
			});
			cmbDateTitle.setBounds(0, y, 125, 23);
			cmbDateTitle.setItems(dateTitles);
			cmbDateTitle.setData("id",lines);
			if(title != null)
				cmbDateTitle.setText(title);
					
			dateTime = new DateTime(frameDate, SWT.BORDER | SWT.DROP_DOWN);
			dateTime.setBounds(131, y, 80, 24);
			dateTime.setData("id",lines);
			if(value != null){
				dateTime.setDate(value[0], value[1], value[2]);
			}
			
			lblDateRemove = new Label(frameDate, SWT.NONE);
			lblDateRemove.addMouseListener(new MouseAdapter() {
				@Override
				public void mouseDown(MouseEvent e) {				
					removeField(frameDate, ((Label)e.widget).getData("id"));
				}
			});
			lblDateRemove.addMouseTrackListener(new MouseTrackAdapter() {
				@Override
				public void mouseEnter(MouseEvent e) {
					((Label)e.widget).setBackground(SWTResourceManager.getColor(235, 243, 247));
				}
				@Override
				public void mouseExit(MouseEvent e) {
					((Label)e.widget).setBackground(SWTResourceManager.getColor(255, 255, 255));
				}
			});
			lblDateRemove.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
			lblDateRemove.setBounds(402, y, 25, 25);
			lblDateRemove.setImage(new Image(shell.getDisplay(), PersonFrame.class.getResourceAsStream("/images/remove24.png")));
			lblDateRemove.setData("id",lines);
			
			btnAddDate.setLocation(177, y+33);
			
			computeFrames(0);
		}catch (Exception e){
			MessageDialog dlg = new MessageDialog(shell, SWT.NONE,"Error 401 : Syetem Problems (PI1418)");
			dlg.open();
		}
	}
	
	private void addOtherField(String title, String value){
		try{
			int y = 31;
			int lines = 0;
			Control[] items = frameOther.getChildren();
			for(int i=0; i<items.length; i++){
				if(items[i] instanceof Combo)
					lines++;
			}
			
			y += lines*30;
			
			cmbOther = new Combo(frameOther, SWT.NONE);
			cmbOther.addSelectionListener(new SelectionAdapter() {
				@Override
				public void widgetSelected(SelectionEvent e) {
					if(((Combo)e.widget).getText().equals("Custom"))
						((Combo)e.widget).setText("");
				}
			});
			cmbOther.setBounds(0, y, 125, 23);
			cmbOther.setItems(otherTitles);
			cmbOther.setData("id",lines);
			if(title != null)
				cmbOther.setText(title);
			
			txtOther = new Text(frameOther, SWT.BORDER);
			txtOther.setBounds(131, y, 265, 24);
			txtOther.setData("id",lines);
			if(value != null)
				txtOther.setText(value);
			
			lblOtherRemove = new Label(frameOther, SWT.NONE);
			lblOtherRemove.addMouseListener(new MouseAdapter() {
				@Override
				public void mouseDown(MouseEvent e) {				
					removeField(frameOther, ((Label)e.widget).getData("id"));
				}
			});
			lblOtherRemove.addMouseTrackListener(new MouseTrackAdapter() {
				@Override
				public void mouseEnter(MouseEvent e) {
					((Label)e.widget).setBackground(SWTResourceManager.getColor(235, 243, 247));
				}
				@Override
				public void mouseExit(MouseEvent e) {
					((Label)e.widget).setBackground(SWTResourceManager.getColor(255, 255, 255));
				}
			});
			lblOtherRemove.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
			lblOtherRemove.setBounds(402, y, 25, 25);
			lblOtherRemove.setImage(new Image(shell.getDisplay(), PersonFrame.class.getResourceAsStream("/images/remove24.png")));
			lblOtherRemove.setData("id",lines);
			
			btnAddOther.setLocation(177, y+33);
			
			computeFrames(0);
		}catch (Exception e){
			MessageDialog dlg = new MessageDialog(shell, SWT.NONE,"Error 401 : Syetem Problems (PI1481)");
			dlg.open();
		}
	}
	
	public Contact getValues(){
		try{
			person.setAccountId(cmbAccount.getText());
			person.setContactId(txtSerialNo.getText());
			person.setCompany(txtCompany.getText());
			person.setJobTitle(txtPosition.getText());
			
			person.setTitle(null);person.setFirstName(null);person.setMiddleName(null);person.setLastName(null);person.setNickName(null);
			Control[] items = frameName.getChildren();
			for(int i=0; i<items.length; i++){
				if(items[i] instanceof Combo){
					if(((Combo)items[i]).getText().equals(nameTitles[0]) && ((Text)items[(i+1)]).getText().length()>0)
						person.setTitle(((Text)items[++i]).getText());
					else if(((Combo)items[i]).getText().equals(nameTitles[1]) && ((Text)items[(i+1)]).getText().length()>0)
						person.setFirstName(((Text)items[++i]).getText());
					else if(((Combo)items[i]).getText().equals(nameTitles[2]) && ((Text)items[(i+1)]).getText().length()>0)
						person.setMiddleName(((Text)items[++i]).getText());
					else if(((Combo)items[i]).getText().equals(nameTitles[3]) && ((Text)items[(i+1)]).getText().length()>0)
						person.setLastName(((Text)items[++i]).getText());
					else if(((Combo)items[i]).getText().equals(nameTitles[4]) && ((Text)items[(i+1)]).getText().length()>0)
						person.setNickName(((Text)items[++i]).getText());
				}				
			}
			
			person.setHomePhone(null);person.setMobile(null);person.setWorkPhone(null);person.setAltPhone(null);person.setHomeFax(null);person.setWorkFax(null);
			items = framePhone.getChildren();
			for(int i=0; i<items.length; i++){
				if(items[i] instanceof Combo){
					if(((Combo)items[i]).getText().equals(phoneTitles[0]) && ((Text)items[(i+1)]).getText().length()>0)
						person.setHomePhone(((Text)items[++i]).getText());
					else if(((Combo)items[i]).getText().equals(phoneTitles[1]) && ((Text)items[(i+1)]).getText().length()>0)
						person.setMobile(((Text)items[++i]).getText());
					else if(((Combo)items[i]).getText().equals(phoneTitles[2]) && ((Text)items[(i+1)]).getText().length()>0)
						person.setWorkPhone(((Text)items[++i]).getText());
					else if(((Combo)items[i]).getText().equals(phoneTitles[3]) && ((Text)items[(i+1)]).getText().length()>0)
						person.setAltPhone(((Text)items[++i]).getText());
					else if(((Combo)items[i]).getText().equals(phoneTitles[4]) && ((Text)items[(i+1)]).getText().length()>0)
						person.setHomeFax(((Text)items[++i]).getText());
					else if(((Combo)items[i]).getText().equals(phoneTitles[5]) && ((Text)items[(i+1)]).getText().length()>0)
						person.setWorkFax(((Text)items[++i]).getText());
				}				
			}
			
			person.setPersonalEmail(null);person.setWorkEmail(null);person.setOtherEmail(null);
			items = frameEmail.getChildren();
			for(int i=0; i<items.length; i++){
				if(items[i] instanceof Combo){
					if(((Combo)items[i]).getText().equals(emailTitles[0]) && ((Text)items[(i+1)]).getText().length()>0)
						person.setPersonalEmail(((Text)items[++i]).getText());
					else if(((Combo)items[i]).getText().equals(emailTitles[1]) && ((Text)items[(i+1)]).getText().length()>0)
						person.setWorkEmail(((Text)items[++i]).getText());
					else if(((Combo)items[i]).getText().equals(emailTitles[2]) && ((Text)items[(i+1)]).getText().length()>0)
						person.setOtherEmail(((Text)items[++i]).getText());
				}				
			}
			
			person.setWorkAddress(null);person.setHomeAddress(null);
			items = frameAddress.getChildren();
			for(int i=0; i<items.length; i++){
				if(items[i] instanceof Combo){
					if(((Combo)items[i]).getText().equals(addressTitles[0]))
						person.setHomeAddress(((Text)items[++i]).getText());
					else if(((Combo)items[i]).getText().equals(addressTitles[1]))
						person.setWorkAddress(((Text)items[++i]).getText());
				}				
			}
			
			person.setSocialNetworks(null);
			items = frameSocialNetwork.getChildren();
			String socialStr = "";
			for(int i=0; i<items.length; i++){
				if(items[i] instanceof Combo){
					if(((Combo)items[i]).getText().length()>0 && ((Text)items[(i+1)]).getText().length()>0)
						socialStr += ((Combo)items[i]).getText()+"&#47"+((Text)items[++i]).getText()+"&#44";
				}				
			}
			if(socialStr.length() > 0)
				person.setSocialNetworks(socialStr);
			
			person.setGroups(null);person.setCustomFields(null);
			items = frameOther.getChildren();
			String groupStr = "", customStr="", genderStr="";
			for(int i=0; i<items.length; i++){
				if(items[i] instanceof Combo && ((Combo)items[i]).getText().length() > 0){
					if(((Combo)items[i]).getText().equals(otherTitles[0]) && ((Text)items[(i+1)]).getText().length()>0)
						genderStr = ((Text)items[++i]).getText();
					else if(((Combo)items[i]).getText().equals(otherTitles[1]) && ((Text)items[(i+1)]).getText().length()>0)
						groupStr += ((Text)items[++i]).getText()+"&#44";
					else if(((Combo)items[i]).getText().length()>0 && ((Text)items[(i+1)]).getText().length()>0)
						customStr += ((Combo)items[i]).getText()+"&#47"+((Text)items[++i]).getText()+"&#44";
				}				
			}
			if(genderStr.length() > 0)
				person.setGender(genderStr);
			if(groupStr.length() > 0)
				person.setGroups(groupStr);
			if(customStr.length() > 0)
				person.setCustomFields(customStr);
			
			person.setDateFields(null);
			items = frameDate.getChildren();
			String dateStr="";
			for(int i=0; i<items.length; i++){
				if(items[i] instanceof Combo && ((Combo)items[i]).getText().length() > 0){
					if(((Combo)items[i]).getText().equals(dateTitles[0])){
						DateTime dt = ((DateTime)items[++i]);
						Calendar c = Calendar.getInstance();
						c.set(dt.getYear(), dt.getMonth(), dt.getDay(), 0, 0);  
						person.setDob(c.getTime());
					}else if(((Combo)items[i]).getText().length()>0){
						String title = ((Combo)items[i]).getText();					
						DateTime dt = ((DateTime)items[++i]);
						Calendar c = Calendar.getInstance();
						c.set(dt.getYear(), dt.getMonth(), dt.getDay(), 0, 0);  
						
						dateStr += title+"&#47"+sdf.format(c.getTime())+"&#44";
					}
				}				
			}
			if(dateStr.length() > 0)
				person.setDateFields(dateStr);
			
			person.setPhoto(null);
			if(lblPicture.getData() != null){
				person.setPhoto(FileConvertor.convertFileToByteArray((String)lblPicture.getData()));
			}
			
			return person;
		}catch (Exception e){
			MessageDialog dlg = new MessageDialog(shell, SWT.NONE,"Error 401 : Syetem Problems (PI1615)");
			dlg.open();
			
			return null;
		}
	}
	
	public void setValues(Contact person){
		try{
			this.person = person;
			cmbAccount.setText(person.getAccountId());
			txtSerialNo.setText(person.getContactId());
			txtCompany.setText(person.getCompany());
			txtPosition.setText(person.getJobTitle());
			
			Control[] items = frameName.getChildren();
			for(int i=1; i<items.length; i++){
				if(items[i] instanceof Button || items[i] instanceof CLabel)
					continue;
				items[i].dispose();
			}
			if(person.isEmptyName())
				addNameField(null, null);
			else{
				if(person.getTitle() != null)
					addNameField(nameTitles[0], person.getTitle());
				if(person.getFirstName() != null)
					addNameField(nameTitles[1], person.getFirstName());
				if(person.getMiddleName() != null)
					addNameField(nameTitles[2], person.getMiddleName());
				if(person.getLastName() != null)
					addNameField(nameTitles[3], person.getLastName());
				if(person.getNickName() != null)
					addNameField(nameTitles[4], person.getNickName());
			}
			
			items = framePhone.getChildren();
			for(int i=1; i<items.length; i++){
				if(items[i] instanceof Button || items[i] instanceof CLabel)
					continue;
				items[i].dispose();
			}
			if(person.isEmptyPhone())
				addPhoneField(null, null);
			else{
				if(person.getHomePhone() != null)
					addPhoneField(phoneTitles[0], person.getHomePhone());
				if(person.getMobile() != null)
					addPhoneField(phoneTitles[1], person.getMobile());
				if(person.getWorkPhone() != null)
					addPhoneField(phoneTitles[2], person.getWorkPhone());
				if(person.getAltPhone() != null)
					addPhoneField(phoneTitles[3], person.getAltPhone());
				if(person.getHomeFax() != null)
					addPhoneField(phoneTitles[4], person.getHomeFax());
				if(person.getWorkFax() != null)
					addPhoneField(phoneTitles[5], person.getWorkFax());
			}
			
					
			items = frameEmail.getChildren();
			for(int i=1; i<items.length; i++){
				if(items[i] instanceof Button || items[i] instanceof CLabel)
					continue;
				items[i].dispose();
			}
			if(person.isEmptyEmail())
				addEmailField(null, null);
			else{
				if(person.getPersonalEmail() != null)
					addEmailField(emailTitles[0], person.getPersonalEmail());
				if(person.getWorkEmail() != null)
					addEmailField(emailTitles[1], person.getWorkEmail());
				if(person.getOtherEmail() != null)
					addEmailField(emailTitles[2], person.getOtherEmail());
			}
			
			items = frameAddress.getChildren();
			for(int i=1; i<items.length; i++){
				if(items[i] instanceof Button || items[i] instanceof CLabel)
					continue;		
				items[i].dispose();
			}
			if(person.isEmptyAddress())
				addAddressField(null, null);
			else{
				if(person.getHomeAddress() != null)
					addAddressField(addressTitles[0], person.getHomeAddress());
				if(person.getWorkAddress() != null)
					addAddressField(addressTitles[1], person.getWorkAddress());
			}
			
			items = frameSocialNetwork.getChildren();
			for(int i=1; i<items.length; i++){
				if(items[i] instanceof Button || items[i] instanceof CLabel)
					continue;
				items[i].dispose();
			}
			if(person.getSocialNetworks() == null)
				addSocialField(null, null);
			else{
				String[] social = person.getSocialNetworks().split("&#44");
				for(int z=0; z<social.length; z++){
					String[] tmp = social[z].split("&#47");
					addSocialField(tmp[0], tmp[1]);
				}
			}
			
			items = frameOther.getChildren();
			for(int i=1; i<items.length; i++){
				if(items[i] instanceof Button || items[i] instanceof CLabel)
					continue;	
				items[i].dispose();
			}
			if(person.getGender()==null && person.getGroups()==null && person.getCustomFields()==null)
				addOtherField(null, null);
			else{
				if(person.getGroups() != null){
					String[] groups = person.getGroups().split("&#44");
					for(int z=0; z<groups.length; z++){
						addOtherField(otherTitles[1], groups[z]);
					}
				}
				if(person.getGender() != null){
					addOtherField(otherTitles[0], person.getGender());
				}
				if(person.getCustomFields() != null){
					String[] other = person.getCustomFields().split("&#44");
					for(int z=0; z<other.length; z++){
						String[] tmp = other[z].split("&#47");
						addOtherField(tmp[0], tmp[1]);
					}
				}
			}
			
			items = frameDate.getChildren();
			for(int i=1; i<items.length; i++){
				if(items[i] instanceof Button || items[i] instanceof CLabel)
					continue;	
				items[i].dispose();
			}
			if(person.getDob()==null && person.getDateFields()==null)
				addDateField(null, null);
			else{
				if(person.getDob() != null){
					addDateField(dateTitles[0], new int[]{1900+person.getDob().getYear(), person.getDob().getMonth(), person.getDob().getDate()});
				}
				if(person.getDateFields() != null){
					String[] dates = person.getDateFields().split("&#44");
					for(int z=0; z<dates.length; z++){
						try {
							String[] tmp = dates[z].split("&#47");
							Date date = sdf.parse(tmp[1]);						
							addDateField(tmp[0], new int[]{1900+date.getYear(), date.getMonth(), date.getDate()});
						} catch (ParseException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
				}
			}
			
			images = new Image[] { };
			offsets = new int[images.length];
			if(person.getPhoto() != null){
				String filepath = FileConvertor.convertByteArrayToFile(person.getPhoto(),"C:\\ProgramData\\BlackCodeCRM\\tmp.png").getPath();
				insertPicture(filepath);
				lblPicture.setData(filepath);
			}
		}catch (Exception e){
			MessageDialog dlg = new MessageDialog(shell, SWT.NONE,"Error 401 : Syetem Problems (PI1785)");
			dlg.open();
		}
		
	}
	
	private void insertPicture(String filename){
        try {
            Image image = new Image(shell.getDisplay(), filename);
            int offset = lblPicture.getCaretOffset();
            lblPicture.replaceTextRange(offset, 0, "\uFFFC");
            int index = 0;
            while (index < offsets.length) {
            	if (offsets[index] == -1 && images[index] == null)
            		break;
            	index++;
            }
            
            if (index == offsets.length) {
            	int[] tmpOffsets = new int[index + 1];
            	System.arraycopy(offsets, 0, tmpOffsets, 0, offsets.length);
            	offsets = tmpOffsets;
            	Image[] tmpImages = new Image[index + 1];
            	System.arraycopy(images, 0, tmpImages, 0, images.length);
            	images = tmpImages;
            }
            
            offsets[index] = offset;
            images[index] = image;
            addImage(image, offset);
        } catch (Exception e) {
        	  MessageDialog dlg = new MessageDialog(shell, SWT.NONE,"Error 401 : Syetem Problems (PI1816)");
  			  dlg.open();
        }
	}
	
	private void addImage(Image image, int offset) {
	    StyleRange style = new StyleRange();
	    style.start = offset;
	    style.length = 1;
	    Rectangle rect = image.getBounds();
	    style.metrics = new GlyphMetrics(rect.height, 0, rect.width);
	    lblPicture.setStyleRange(style);
	}
	
	@Override
	protected void checkSubclass() {
		// Disable the check that prevents subclassing of SWT components
	}
}
