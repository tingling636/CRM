package com.blackcode.crmgui;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.Menu;
import org.eclipse.swt.widgets.MenuItem;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.wb.swt.SWTResourceManager;
import org.eclipse.swt.custom.CLabel;
import org.eclipse.swt.custom.ScrolledComposite;
import org.eclipse.swt.events.MouseAdapter;
import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.graphics.Image;

import com.blackcode.core.SQLiteConnector;
import com.blackcode.model.FollowUpTask;

public class EventCalendarFrame extends Composite {
	private Shell shell;
	private Composite frameTopActionBar;
	private Label lblCalBack;
	private Label lblCalNext;
	private CLabel lblMonthYear;
	private Composite frameCalendarDate;
	private Composite frameCalendar;
	private ScrolledComposite scrolledComposite;
	private Composite frameDate;
	
	private Calendar calendar;
	private SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
	private SQLiteConnector dbConnector = new SQLiteConnector();
	private CLabel lblFollowUp;
	/**
	 * Create the composite.
	 * @param parent
	 * @param style
	 */
	public EventCalendarFrame(Composite parent, int style) {
		super(parent, style);
		shell = parent.getShell();
		setBackground(SWTResourceManager.getColor(255, 255, 255));
		
		frameTopActionBar = new Composite(this, SWT.NONE);
		frameTopActionBar.setBackground(SWTResourceManager.getColor(77, 99, 132));
		frameTopActionBar.setBounds(0, 0, shell.getBounds().width-60, 35);
		
		lblFollowUp = new CLabel(frameTopActionBar, SWT.NONE);
		lblFollowUp.setBackground(SWTResourceManager.getColor(77, 99, 132));
		lblFollowUp.setForeground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblFollowUp.setFont(SWTResourceManager.getFont("Georgia", 15, SWT.BOLD));
		lblFollowUp.setBounds(10, 8, 138, 21);
		lblFollowUp.setText("Follow Up");
		
		scrolledComposite = new ScrolledComposite(this, SWT.H_SCROLL | SWT.V_SCROLL);
		scrolledComposite.setBounds(0, 36, shell.getBounds().width-65, shell.getBounds().height-75);
		scrolledComposite.setBackground(SWTResourceManager.getColor(255, 255, 255));
		scrolledComposite.setExpandHorizontal(true);
		scrolledComposite.setExpandVertical(true);
		
		frameCalendar = new Composite(scrolledComposite, SWT.CENTER);
		frameCalendar.setBackground(SWTResourceManager.getColor(255, 255, 255));
		
		lblCalBack = new Label(frameCalendar, SWT.NONE);
		lblCalBack.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				selectMonth(-1);
				frameCalendarDate.dispose();
				drawCalendar();
			}
		});
		lblCalBack.setBounds(5, 5, 23, 23);
		lblCalBack.setBackground(SWTResourceManager.getColor(255, 255, 255));
		lblCalBack.setImage(new Image(shell.getDisplay(), EventCalendarFrame.class.getResourceAsStream("/images/back_small.png")));
		
		lblMonthYear = new CLabel( frameCalendar, SWT.CENTER);
		lblMonthYear.setBounds(28, 5, 128, 23);
		lblMonthYear.setBackground(SWTResourceManager.getColor(255, 255, 255));
		
		lblCalNext = new Label(frameCalendar, SWT.CENTER);
		lblCalNext.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				selectMonth(1);
				frameCalendarDate.dispose();
				drawCalendar();
			}
		});
		lblCalNext.setBounds(156, 5, 23, 23);
		lblCalNext.setBackground(SWTResourceManager.getColor(255, 255, 255));
		lblCalNext.setImage(new Image(shell.getDisplay(), EventCalendarFrame.class.getResourceAsStream("/images/next_small.png")));
				
		selectMonth(-1);
		drawCalendar();
		
		scrolledComposite.setContent(frameCalendar);
		scrolledComposite.setMinSize(frameCalendar.computeSize(SWT.DEFAULT, SWT.DEFAULT));
	}

	private void selectMonth(int month){
		if(calendar == null){
			calendar = Calendar.getInstance(); 			
		}else{
			calendar.add(Calendar.MONTH, month);
		}
		calendar.set(Calendar.DAY_OF_MONTH, 1);
		
		String[] monthStr = new String[]{"January","February","March","April","May","Jun","July","August","September","October","November","December"};
		Date theDate = calendar.getTime();
		lblMonthYear.setText(monthStr[theDate.getMonth()]+", "+(theDate.getYear()+1900));
	}
	
	private void drawCalendar(){
		try{
			String[] dayStr = new String[]{"Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"};
			int[] lastDay = new int[]{31,28,31,30,31,30,31,31,30,31,30,31};
			
			frameCalendarDate = new Composite(frameCalendar, SWT.NONE);
			frameCalendarDate.setBackground(SWTResourceManager.getColor(58, 58, 60));
			frameCalendarDate.setBounds(0, 32, scrolledComposite.getBounds().width-35, scrolledComposite.getBounds().height-50);
			
			int x = 5;
			int y = 5;
			int width = (frameCalendarDate.getBounds().width-22)/7;
			int height = (frameCalendarDate.getBounds().height-44)/6;
			for(int i=0; i<dayStr.length; i++){
				CLabel lblDay = new CLabel(frameCalendarDate, SWT.CENTER);
				lblDay.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
				lblDay.setBounds(x, y, width, 22);
				lblDay.setText(dayStr[i]);
				x += width+2;
			}
			
			Date theDate = calendar.getTime();
			int firstDay = theDate.getDay();
			int daysInMonth = lastDay[theDate.getMonth()];
			if(daysInMonth==28){
				if(isLeapYear((theDate.getYear()+1900)))
					daysInMonth=29;
			}
			
			x = firstDay*(width+2)+5;
			y += 25;
			for(int i=1; i<=daysInMonth; i++){
				final int index = i;
				
				frameDate = new Composite(frameCalendarDate, SWT.CENTER);
				frameDate.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
				frameDate.setBounds(x, y, width, height);			
				frameDate.setData(i);
				
				CLabel lblDate = new CLabel(frameDate, SWT.NONE);
				lblDate.addMouseListener(new MouseAdapter() {
					@Override
					public void mouseDoubleClick(MouseEvent e) {
						calendar.set(Calendar.DAY_OF_MONTH, (Integer)((CLabel)e.widget).getData());
						EventListDialog dlg = new EventListDialog(shell, SWT.NONE, calendar.getTime());
						dlg.open();
					}
				});
				lblDate.setBackground(SWTResourceManager.getColor(219, 235, 253));
				lblDate.setBounds(0, 0, frameDate.getBounds().width, 18);
				lblDate.setText(i+"");
				lblDate.setData(i);
				/*lblDate.setText(i+"");
				if(i == selectedDate){
					lblDate.setBackground(SWTResourceManager.getColor(235, 243, 247));
					lblDate.setForeground(SWTResourceManager.getColor(20, 58, 227));
				}*/
				
				ScrolledComposite scrolledContent = new ScrolledComposite(frameDate, SWT.V_SCROLL);
				scrolledContent.setBounds(0, 20, frameDate.getBounds().width-5, frameDate.getBounds().height-25);
				scrolledContent.setExpandHorizontal(true);
				scrolledContent.setExpandVertical(true);
				
				Composite dateContent = new Composite(scrolledContent, SWT.NONE);
				dateContent.addMouseListener(new MouseAdapter() {
					@Override
					public void mouseDoubleClick(MouseEvent e) {
						calendar.set(Calendar.DAY_OF_MONTH, (Integer)((Composite)e.widget).getData());
						
						FollowUpDialog dlg = new FollowUpDialog(shell, SWT.NONE, null, null, calendar.getTime());
						dlg.open();
						if(dlg.getTask() != null){
							Object obj = dbConnector.createTask(dlg.getTask());
							if(obj == null){
								MessageDialog dlg2 = new MessageDialog(shell, SWT.NONE, "Error 400 : Database Problems (EC185)");
								dlg2.open();
								return;
							}
							createEvent((Composite)e.widget, dlg.getTask());
						}
					}
				});
				dateContent.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
				dateContent.setData(i);
				
				displayTask(dateContent);
				
				scrolledContent.setContent(dateContent);
				scrolledContent.setMinSize(dateContent.computeSize(SWT.DEFAULT, SWT.DEFAULT));
				
				x += width+2;
				if(i<daysInMonth && x>(frameCalendarDate.getBounds().width-width)){
					x = 5;
					y += height+2;
				}
			}
			frameCalendarDate.redraw();
			frameCalendar.redraw();
		}catch (Exception e){
			MessageDialog dlg = new MessageDialog(shell, SWT.NONE,"Error 401 : System Problems (EC)");
			dlg.open();
		}
	}
	
	private boolean isLeapYear(int inputYear){
		if(inputYear%400==0||(inputYear%4==0&&inputYear%100!=0)) 
			return true;
		
		return false;
	}
	
	private void displayTask(Composite composite){
		try{
			calendar.set(Calendar.DAY_OF_MONTH, (Integer)((Composite)composite).getData());
			List<FollowUpTask> col = dbConnector.readTask(null, "DATE(date/ 1000, 'unixepoch', 'localtime')='"+sdf.format(calendar.getTime())+"'", null);
			for(int i=0; i<col.size(); i++){
				FollowUpTask tmp = (FollowUpTask)col.get(i);
				
				createEvent(composite, tmp);
			}
		}catch (Exception e){
			MessageDialog dlg = new MessageDialog(shell, SWT.NONE,"Error 400 : Database Problems (EC)");
			dlg.open();
		}
		
	}
	
	private void createEvent(Composite composite, FollowUpTask task){	
		try{
			int totalevent = composite.getChildren().length;
			int y = 2;
			if(totalevent > 0)
				y += totalevent*23;
			
			CLabel lblEvent = new CLabel(composite, SWT.SHADOW_OUT);
			lblEvent.addMouseListener(new MouseAdapter() {
				@Override
				public void mouseDoubleClick(MouseEvent e) {			
					if(((CLabel)e.widget).getData() == null)
						return;
					
					FollowUpDialog dlg = new FollowUpDialog(shell, SWT.NONE, (FollowUpTask)((CLabel)e.widget).getData(), null, null);
					dlg.open();
					if(dlg.getTask() != null){
						dbConnector.updateTask(dlg.getTask(), null);
						((CLabel)e.widget).setData(dlg.getTask());
						((CLabel)e.widget).setText(dlg.getTask().getSubject());
					}
				}
			});
			lblEvent.setBounds(5, y, composite.getParent().getBounds().width-20, 21);
			lblEvent.setBackground(SWTResourceManager.getColor(249, 255, 255));
			lblEvent.setText(task.getSubject());
			lblEvent.setData(task);
			if(task.isHighImportanceTag())
				lblEvent.setBackground(SWTResourceManager.getColor(251, 245, 246));
			
			Menu popupMenu = new Menu(lblEvent);
		    MenuItem removeItem = new MenuItem(popupMenu, SWT.NONE);
		    removeItem.setData(task);
		    removeItem.setData("parent", lblEvent);
		    removeItem.setText("Delete Event");
		    removeItem.setImage(new Image(shell.getDisplay(), EventCalendarFrame.class.getResourceAsStream("/images/remove.png")));
		    removeItem .addListener(SWT.Selection, new Listener() {
		        public void handleEvent(Event e) {
		        	FollowUpTask tmp = (FollowUpTask)((MenuItem)e.widget).getData();
		        	Object obj = dbConnector.deleteTask(tmp, null);
		        	if(obj instanceof String){
		        		return;
		        	}
		        	((CLabel)((MenuItem)e.widget).getData("parent")).dispose();
		          }
		        });
		    lblEvent.setMenu(popupMenu);
		    
			((ScrolledComposite)composite.getParent()).setContent(composite);
			((ScrolledComposite)composite.getParent()).setMinSize(composite.computeSize(SWT.DEFAULT, SWT.DEFAULT));
		}catch (Exception e){
			MessageDialog dlg = new MessageDialog(shell, SWT.NONE,"Error 401 : System Problems (EC)");
			dlg.open();
		}
	}
	
	
	@Override
	protected void checkSubclass() {
		// Disable the check that prevents subclassing of SWT components
	}
}
