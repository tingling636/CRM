package com.blackcode.crmgui;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.eclipse.swt.widgets.Dialog;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.SWT;
import org.eclipse.wb.swt.SWTResourceManager;
import org.eclipse.swt.custom.ScrolledComposite;
import org.eclipse.swt.events.MouseAdapter;
import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.events.MouseTrackAdapter;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.custom.CLabel;

import com.blackcode.core.SQLiteConnector;
import com.blackcode.model.FollowUpTask;

public class EventListDialog extends Dialog {

	protected Object result;
	protected Shell shell;
	private Composite frameTitle;
	private Label lblCloseAction;
	
	private Date theDate;
	private SimpleDateFormat sdf = new SimpleDateFormat("E dd MMM, yyyy");
	private SimpleDateFormat sqlsdf = new SimpleDateFormat("yyyy-MM-dd");
	private String[] times = new String[]{"06:00","07:00","08:00","09:00","10:00","11:00","12:00","13:00","14:00","15:00","16:00","17:00","18:00","19:00","20:00","21:00","22:00"};
	private SQLiteConnector dbConnector = new SQLiteConnector();

	/**
	 * Create the dialog.
	 * @param parent
	 * @param style
	 */
	public EventListDialog(Shell parent, int style, Date thedate) {
		super(parent, style);
		setText("SWT Dialog");
		this.theDate = thedate;
	}

	/**
	 * Open the dialog.
	 * @return the result
	 */
	public Object open() {
		createContents();
		shell.open();
		shell.layout();
		Display display = getParent().getDisplay();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
		return result;
	}

	/**
	 * Create contents of the dialog.
	 */
	private void createContents() {
		shell = new Shell(getParent(), getStyle());
		shell.setSize(585, 562);
		shell.setText(getText());
		shell.setLocation((getParent().getBounds().width/2)-(shell.getBounds().width/2), 30);
		
		ScrolledComposite scrolledComposite = new ScrolledComposite(shell, SWT.BORDER | SWT.H_SCROLL | SWT.V_SCROLL);
		scrolledComposite.setBounds(0, 0, 585, 562);
		scrolledComposite.setExpandHorizontal(true);
		scrolledComposite.setExpandVertical(true);
		
		Composite composite = new Composite(scrolledComposite, SWT.NONE);
		composite.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
				
		frameTitle = new Composite(composite, SWT.NONE);
		frameTitle.setBackground(SWTResourceManager.getColor(50, 50, 50));
		frameTitle.setBounds(0, 0, shell.getBounds().width-15, 26);
		
		Label lblTitle = new Label(frameTitle, SWT.NONE);
		lblTitle.setForeground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblTitle.setFont(SWTResourceManager.getFont("Georgia", 8, SWT.BOLD));
		lblTitle.setBounds(5, 6, 322, 15);
		lblTitle.setBackground(SWTResourceManager.getColor(50, 50, 50));
		lblTitle.setText("Event / Follow Up Task - "+sdf.format(theDate));
		
		lblCloseAction = new Label(frameTitle, SWT.CENTER);
		lblCloseAction.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				shell.close();
			}
		});
		lblCloseAction.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				lblCloseAction.setBackground(SWTResourceManager.getColor(100, 100, 100));
			}
			@Override
			public void mouseExit(MouseEvent e) {
				lblCloseAction.setBackground(SWTResourceManager.getColor(50, 50, 50));
			}
		});
		lblCloseAction.setBounds(frameTitle.getBounds().width-30, 5, 16, 16);
		lblCloseAction.setBackground(SWTResourceManager.getColor(50, 50, 50));
		lblCloseAction.setImage(new Image(shell.getDisplay(), EventListDialog.class.getResourceAsStream("/images/close.png")));
		lblCloseAction.setToolTipText("Close Window");
		
		Composite frameTask = new Composite(composite, SWT.BORDER);
		frameTask.setBounds(59, 32, 500, 52);
		
		List<FollowUpTask> col = dbConnector.readTask(null, "DATE(date/ 1000, 'unixepoch', 'localtime')='"+sqlsdf.format(theDate)+"' AND time IS NULL", null);
		int y1 = 5;
		for(int j=0; j<col.size(); j++){
			FollowUpTask task = col.get(j);
			
			CLabel lblTask = new CLabel(frameTask, SWT.NONE);
			lblTask.setBounds(5, y1, 485, 18);
			lblTask.setBackground(SWTResourceManager.getColor(249, 249, 249));
			lblTask.setMargins(2, 2, 0, 0);
			lblTask.setText(displayText(task.getType())+" :: "+displayText(task.getSubject())+" - "+displayText(task.getNotes()));
			lblTask.setData("index", j);
						
			y1 += 20;
		}
		
						
		int y = 85;
		for(int i=0; i<times.length; i++){
			CLabel lblTime = new CLabel(composite, SWT.CENTER);
			lblTime.setBounds(5, y, 51, 45);
			lblTime.setText(times[i]);
			
			Composite frameTaskWtTime = new Composite(composite, SWT.NONE);
			frameTaskWtTime.setBounds(59, y, 500, 45);
			y+= 46;
			
			col = dbConnector.readTask(null, "DATE(date/ 1000, 'unixepoch', 'localtime')='"+sqlsdf.format(theDate)+"' AND time='"+times[i]+"'", null);
			int y2 = 5;
			for(int j=0; j<col.size(); j++){
				FollowUpTask task = col.get(j);
				
				CLabel lblTask = new CLabel(frameTaskWtTime, SWT.NONE);
				lblTask.setBounds(5, y2, 485, 18);
				lblTask.setBackground(SWTResourceManager.getColor(249, 249, 249));
				lblTask.setMargins(2, 2, 0, 0);
				lblTask.setText(displayText(task.getType())+" :: "+displayText(task.getSubject())+" - "+displayText(task.getNotes()));
				lblTask.setData("index", j);
				
				y2 += 20;
			}
			
		}
		
		scrolledComposite.setContent(composite);
		scrolledComposite.setMinSize(composite.computeSize(SWT.DEFAULT, SWT.DEFAULT));
	}
	
	
	private String displayText(Object obj){
		if(obj==null)
			return "";
		else
			return obj.toString();
	}
}
