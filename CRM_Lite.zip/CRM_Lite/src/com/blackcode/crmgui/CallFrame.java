package com.blackcode.crmgui;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;

import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.ScrolledComposite;
import org.eclipse.swt.events.MouseAdapter;
import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.events.MouseTrackAdapter;
import org.eclipse.swt.graphics.Cursor;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.Menu;
import org.eclipse.swt.widgets.MenuItem;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;
import org.eclipse.wb.swt.SWTResourceManager;
import org.eclipse.swt.custom.StyleRange;
import org.eclipse.swt.custom.StyledText;
import org.eclipse.swt.custom.CLabel;

import com.blackcode.core.SQLiteConnector;
import com.blackcode.model.Contact;
import com.blackcode.model.FollowUpTask;

import org.eclipse.swt.widgets.Tree;
import org.eclipse.swt.widgets.TreeItem;
import org.eclipse.swt.widgets.DateTime;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;

public class CallFrame extends Composite {
	private Shell shell;
	private Composite frameTopActionBar;
	private Composite frameCallList;
	private Composite frameDetail;
	private ScrolledComposite scrolledComposite;
	private Composite frameMain;
	private Composite frameSide;
	private CLabel lblSubTitle;
	private Button btnSeparator;
	private Text txtCallNumber;
	private StyledText txtSplitScreen;
	private DateTime dateTimeSelectCallReminder;
	private Button btnDial, btnHangup;
	private Button btnLine1, btnLine2, btnLine3, btnLine4, btnLine5, btnLine6;
	private CLabel lblOfficeNumber, lblMobileNumber, lblHomeNumber, lblAltNumber;
	private CLabel lblFunctions;
	private Label lblSalesClick;
	private Tree treeCallSchedule;
	private CLabel lblCall;
	private CLabel lblLines;
	private CLabel lblRec;
	private Label lblLog;
	
	private int layoutMode = 0;
	private int usingLine=-1;
	private String contactId;
	private PersonSales frameSales;
	private CallLogFrame frameLogs;
	private boolean recorderOn = true;
	private SQLiteConnector dbConnector = new SQLiteConnector();
	private Menu popupMenu;
	
	/**
	 * Create the composite.
	 * @param parent
	 * @param style
	 */
	public CallFrame(Composite parent, int style) {
		super(parent, style);
		shell = parent.getShell();
		setBackground(SWTResourceManager.getColor(255, 255, 255));
		
		frameTopActionBar = new Composite(this, SWT.NONE);
		frameTopActionBar.setBackground(SWTResourceManager.getColor(77, 99, 132));
		frameTopActionBar.setBounds(0, 0, shell.getBounds().width-60, 35);
				
		lblCall = new CLabel(frameTopActionBar, SWT.NONE);
		lblCall.setFont(SWTResourceManager.getFont("Georgia", 15, SWT.BOLD));
		lblCall.setForeground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblCall.setBounds(10, 8, 61, 21);
		lblCall.setBackground(SWTResourceManager.getColor(77, 99, 132));
		lblCall.setText("Call");
		
		final Label lblMenuAction = new Label(frameTopActionBar, SWT.NONE);
		lblMenuAction.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {	
				popupMenu.setVisible(true);
			}
		});
		lblMenuAction.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				lblMenuAction.setBackground(SWTResourceManager.getColor(52, 64, 88));
				lblMenuAction.setImage(new Image(shell.getDisplay(), HistoryFrame.class.getResourceAsStream("/images/menu_selected.png")));
			}
			@Override
			public void mouseExit(MouseEvent e) {
				lblMenuAction.setBackground(SWTResourceManager.getColor(77, 99, 132));
				lblMenuAction.setImage(new Image(shell.getDisplay(), HistoryFrame.class.getResourceAsStream("/images/menu.png")));
			}
		});
		lblMenuAction.setBounds(frameTopActionBar.getBounds().width-38, 5, 33, 25);
		lblMenuAction.setBackground(SWTResourceManager.getColor(77, 99, 132));
		lblMenuAction.setToolTipText("More Functions");
		lblMenuAction.setImage(new Image(shell.getDisplay(), HistoryFrame.class.getResourceAsStream("/images/menu.png")));
		
		frameCallList = new Composite(this, SWT.NONE);
		frameCallList.setBounds(0, 36, 201, shell.getBounds().height-75);
		frameCallList.setBackground(SWTResourceManager.getColor(239, 245, 249));
		
		CLabel lblCallReminder = new CLabel(frameCallList, SWT.NONE);
		lblCallReminder.setForeground(SWTResourceManager.getColor(SWT.COLOR_BLACK));
		lblCallReminder.setFont(SWTResourceManager.getFont("Georgia", 9, SWT.BOLD));
		lblCallReminder.setBounds(10, 8, 100, 21);
		lblCallReminder.setBackground(SWTResourceManager.getColor(239, 245, 249));
		lblCallReminder.setText("Call Planner");
		
		Label lblFrom = new Label(frameCallList, SWT.NONE);
		lblFrom.setBounds(14, 35, 35, 15);
		lblFrom.setBackground(SWTResourceManager.getColor(239, 245, 249));
		lblFrom.setText("From");
		
		dateTimeSelectCallReminder = new DateTime(frameCallList, SWT.DROP_DOWN);
		dateTimeSelectCallReminder.setToolTipText("Select date of call reminder");
		dateTimeSelectCallReminder.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				refreshCallReminder();
			}
		});
		dateTimeSelectCallReminder.setBounds(51, 32, 85, 23);
		
		Label lblOnwards = new Label(frameCallList, SWT.NONE);
		lblOnwards.setBounds(144, 35, 51, 15);
		lblOnwards.setBackground(SWTResourceManager.getColor(239, 245, 249));
		lblOnwards.setText("onwards");
		
		treeCallSchedule = new Tree(frameCallList, SWT.NONE);
		treeCallSchedule.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDoubleClick(MouseEvent e) {
				if(treeCallSchedule.getSelection()[0].getData() == null)
					return;
				
				FollowUpTask task = (FollowUpTask)treeCallSchedule.getSelection()[0].getData();	
				Contact contact = (Contact)treeCallSchedule.getSelection()[0].getData("contact");	
				
				selectContactPerson(contact, task, null);
			}
		});
		treeCallSchedule.setBounds(10, 61, 181, frameCallList.getBounds().height-120);
		treeCallSchedule.setBackground(SWTResourceManager.getColor(244, 250, 254));		
												
		frameDetail = new Composite(this, SWT.NONE);
		frameDetail.setBounds(203, 36, shell.getBounds().width-265, shell.getBounds().height-75);
		frameDetail.setBackground(SWTResourceManager.getColor(255, 255, 255));
		
		scrolledComposite = new ScrolledComposite(frameDetail, SWT.H_SCROLL | SWT.V_SCROLL);
		scrolledComposite.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		scrolledComposite.setBounds(0, 0, frameDetail.getBounds().width-10, frameDetail.getBounds().height);
		scrolledComposite.setExpandHorizontal(true);
		scrolledComposite.setExpandVertical(true);
		
		frameMain = new Composite(scrolledComposite, SWT.NONE);
		frameMain.setBackground(SWTResourceManager.getColor(255, 255, 255));
		
		txtSplitScreen = new StyledText(frameMain, SWT.BORDER|SWT.WRAP);
		txtSplitScreen.setFont(SWTResourceManager.getFont("Times New Roman Greek", 9, SWT.NORMAL));
		txtSplitScreen.setEnabled(false);
		txtSplitScreen.setEditable(false);
		txtSplitScreen.setMargins(5, 5, 0, 0);
		txtSplitScreen.setBounds(10, 10, 440, 193);
		
		CLabel lblContactNumbers = new CLabel(frameMain, SWT.NONE);
		lblContactNumbers.setFont(SWTResourceManager.getFont("Segoe UI", 9, SWT.BOLD));
		lblContactNumbers.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblContactNumbers.setBounds(10, 209, 119, 18);
		lblContactNumbers.setText("Contact Numbers");
		
		lblOfficeNumber = new CLabel(frameMain, SWT.NONE);
		lblOfficeNumber.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				lblOfficeNumber.setBackground(SWTResourceManager.getColor(223,227,238));
				lblOfficeNumber.setCursor(new Cursor(shell.getDisplay(), SWT.CURSOR_HAND));
			}
			@Override
			public void mouseExit(MouseEvent e) {
				lblOfficeNumber.setBackground(SWTResourceManager.getColor(247,247,247));
			}
		});
		lblOfficeNumber.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				if(((CLabel)e.widget).getData() != null)
					txtCallNumber.setText(((String)((CLabel)e.widget).getData()).replace(" ", "").trim());
			}
		});
		lblOfficeNumber.setForeground(SWTResourceManager.getColor(59,89,152));
		lblOfficeNumber.setBackground(SWTResourceManager.getColor(247,247,247));
		lblOfficeNumber.setEnabled(false);
		lblOfficeNumber.setToolTipText("Dial office number");		
		lblOfficeNumber.setBounds(10, 230, 145, 24);
		
		lblMobileNumber = new CLabel(frameMain, SWT.NONE);
		lblMobileNumber.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				lblMobileNumber.setBackground(SWTResourceManager.getColor(223,227,238));
				lblMobileNumber.setCursor(new Cursor(shell.getDisplay(), SWT.CURSOR_HAND));
			}
			@Override
			public void mouseExit(MouseEvent e) {
				lblMobileNumber.setBackground(SWTResourceManager.getColor(247,247,247));
			}
		});
		lblMobileNumber.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				if(((CLabel)e.widget).getData() != null)
					txtCallNumber.setText(((String)((CLabel)e.widget).getData()).replace(" ", "").trim());
			}
		});
		lblMobileNumber.setForeground(SWTResourceManager.getColor(59,89,152));
		lblMobileNumber.setBackground(SWTResourceManager.getColor(247,247,247));
		lblMobileNumber.setEnabled(false);
		lblMobileNumber.setToolTipText("Dial mobile number");		
		lblMobileNumber.setBounds(10, 256, 145, 24);
		
		lblHomeNumber = new CLabel(frameMain, SWT.NONE);
		lblHomeNumber.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				lblHomeNumber.setBackground(SWTResourceManager.getColor(223,227,238));
				lblHomeNumber.setCursor(new Cursor(shell.getDisplay(), SWT.CURSOR_HAND));
			}
			@Override
			public void mouseExit(MouseEvent e) {
				lblHomeNumber.setBackground(SWTResourceManager.getColor(247,247,247));
			}
		});
		lblHomeNumber.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				if(((CLabel)e.widget).getData() != null)
					txtCallNumber.setText(((String)((CLabel)e.widget).getData()).replace(" ", "").trim());
			}
		});
		lblHomeNumber.setForeground(SWTResourceManager.getColor(59,89,152));
		lblHomeNumber.setBackground(SWTResourceManager.getColor(247,247,247));
		lblHomeNumber.setEnabled(false);
		lblHomeNumber.setToolTipText("Dial home number");		
		lblHomeNumber.setBounds(157, 230, 145, 24);
		
		lblAltNumber = new CLabel(frameMain, SWT.NONE);
		lblAltNumber.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				lblAltNumber.setBackground(SWTResourceManager.getColor(223,227,238));
				lblAltNumber.setCursor(new Cursor(shell.getDisplay(), SWT.CURSOR_HAND));
			}
			@Override
			public void mouseExit(MouseEvent e) {
				lblAltNumber.setBackground(SWTResourceManager.getColor(247,247,247));
			}
		});
		lblAltNumber.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				if(((CLabel)e.widget).getData() != null)
					txtCallNumber.setText(((String)((CLabel)e.widget).getData()).replace(" ", "").trim());
			}
		});
		lblAltNumber.setForeground(SWTResourceManager.getColor(59,89,152));
		lblAltNumber.setBackground(SWTResourceManager.getColor(247,247,247));
		lblAltNumber.setEnabled(false);		
		lblAltNumber.setToolTipText("Dial alt number");
		lblAltNumber.setBounds(157, 256, 145, 24);
		
		lblLines = new CLabel(frameMain, SWT.NONE);
		lblLines.setFont(SWTResourceManager.getFont("Segoe UI", 9, SWT.BOLD));
		lblLines.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblLines.setBounds(10, 302, 42, 18);
		lblLines.setText("Lines");
		
		btnLine1 = new Button(frameMain, SWT.NONE);
		btnLine1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				/*if(((Button)e.widget).getData() == null)
					return;
				
				setGreenLine(usingLine);
				setRedLine(1);
				usingLine = 1;*/
			}
		});
		btnLine1.setEnabled(false);
		btnLine1.setBounds(10, 321, 42, 24);
		btnLine1.setToolTipText("Line 1");
		/*if(accounts.size() >= 1){
			btnLine1.setImage(new Image(shell.getDisplay(), CallFrame.class.getResourceAsStream("/images/green-circle.png")));
			btnLine1.setText("   1");
			btnLine1.setData(accounts.get(0));
			btnLine1.setEnabled(true);
		}*/
		
		
		btnLine2 = new Button(frameMain, SWT.NONE);
		btnLine2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				/*if(((Button)e.widget).getData() == null)
					return;
				
				setGreenLine(usingLine);
				setRedLine(2);
				usingLine = 2;*/
			}
		});
		btnLine2.setEnabled(false);
		btnLine2.setBounds(54, 321, 42, 24);
		btnLine2.setToolTipText("Line 2");
		/*if(accounts.size() >= 2){
			btnLine2.setImage(new Image(shell.getDisplay(), CallFrame.class.getResourceAsStream("/images/green-circle.png")));
			btnLine2.setText("   2");
			btnLine2.setData(accounts.get(1));
			btnLine2.setEnabled(true);
		}*/
		
		btnLine3 = new Button(frameMain, SWT.NONE);
		btnLine3.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				/*if(((Button)e.widget).getData() == null)
					return;
				
				setGreenLine(usingLine);
				setRedLine(3);
				usingLine = 3;*/
			}
		});
		btnLine3.setEnabled(false);
		btnLine3.setBounds(98, 321, 42, 24);
		btnLine3.setToolTipText("Line 3");
		/*if(accounts.size() >= 3){
			btnLine3.setImage(new Image(shell.getDisplay(), CallFrame.class.getResourceAsStream("/images/green-circle.png")));
			btnLine3.setText("  3");
			btnLine3.setData(accounts.get(2));
			btnLine3.setEnabled(true);
		}*/
		
		btnLine4 = new Button(frameMain, SWT.NONE);
		btnLine4.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				/*if(((Button)e.widget).getData() == null)
					return;
				
				setGreenLine(usingLine);
				setRedLine(4);
				usingLine = 4;*/
			}
		});
		btnLine4.setEnabled(false);
		btnLine4.setBounds(142, 321, 42, 24);
		btnLine4.setToolTipText("Line 4");
		/*if(accounts.size() >= 4){
			btnLine4.setImage(new Image(shell.getDisplay(), CallFrame.class.getResourceAsStream("/images/green-circle.png")));
			btnLine4.setText("   4");
			btnLine4.setData(accounts.get(3));
			btnLine4.setEnabled(true);
		}*/
		
		btnLine5 = new Button(frameMain, SWT.NONE);
		btnLine5.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				/*if(((Button)e.widget).getData() == null)
					return;
				
				setGreenLine(usingLine);
				setRedLine(5);
				usingLine = 5;*/
			}
		});
		btnLine5.setEnabled(false);
		btnLine5.setBounds(186, 321, 42, 24);
		btnLine5.setToolTipText("Line 5");
		/*if(accounts.size() >= 5){
			btnLine5.setImage(new Image(shell.getDisplay(), CallFrame.class.getResourceAsStream("/images/green-circle.png")));
			btnLine5.setText("   5");
			btnLine5.setData(accounts.get(4));
			btnLine5.setEnabled(true);
		}*/
		
		btnLine6 = new Button(frameMain, SWT.NONE);
		btnLine6.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				/*if(((Button)e.widget).getData() == null)
					return;
				
				setGreenLine(usingLine);
				setRedLine(6);
				usingLine = 6;*/
			}
		});
		btnLine6.setEnabled(false);
		btnLine6.setBounds(230, 321, 42, 24);
		btnLine6.setToolTipText("Line 6");
		/*if(accounts.size() >= 6){
			btnLine6.setImage(new Image(shell.getDisplay(), CallFrame.class.getResourceAsStream("/images/green-circle.png")));
			btnLine6.setText("   6");
			btnLine6.setData(accounts.get(5));
			btnLine6.setEnabled(true);
		}*/
		
		lblFunctions = new CLabel(frameMain, SWT.NONE);
		lblFunctions.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblFunctions.setFont(SWTResourceManager.getFont("Trebuchet MS", 9, SWT.BOLD));
		lblFunctions.setBounds(304, 211, 70, 18);
		lblFunctions.setText("Functions");
		
		txtCallNumber = new Text(frameMain, SWT.BORDER | SWT.RIGHT);
		txtCallNumber.setFont(SWTResourceManager.getFont("Segoe UI", 11, SWT.NORMAL));
		txtCallNumber.setBounds(10, 353, 168, 25);
		
		btnDial = new Button(frameMain, SWT.NONE);
		btnDial.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
			}
		});
		btnDial.setBounds(184, 355, 55, 25);
		btnDial.setImage(new Image(shell.getDisplay(), CallFrame.class.getResourceAsStream("/images/phone_call.png")));
		btnDial.setToolTipText("Calling");
		btnDial.setEnabled(false);
		
		btnHangup = new Button(frameMain, SWT.NONE);
		btnHangup.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
			}
		});
		btnHangup.setBounds(245, 355, 55, 25);
		btnHangup.setImage(new Image(shell.getDisplay(), CallFrame.class.getResourceAsStream("/images/phone_end_call.png")));
		btnHangup.setToolTipText("End Call");
		btnHangup.setEnabled(false);
		
		lblRec = new CLabel(frameMain, SWT.SHADOW_OUT | SWT.CENTER);
		lblRec.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				lblRec.setCursor(new Cursor(shell.getDisplay(), SWT.CURSOR_HAND));
			}
			@Override
			public void mouseExit(MouseEvent e) {
			}
		});
		lblRec.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				if(recorderOn){					
					recorderOn=false;
					lblRec.setBackground(SWTResourceManager.getColor(102,205,0));
					lblRec.setToolTipText("Recorder Off");
				}else{
					recorderOn=true;
					lblRec.setBackground(SWTResourceManager.getColor(255,0,0));
					lblRec.setToolTipText("Recorder On");
				}
			}
		});
		lblRec.setForeground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblRec.setFont(SWTResourceManager.getFont("Segoe UI", 8, SWT.BOLD));
		lblRec.setBackground(SWTResourceManager.getColor(255,0,0));
		lblRec.setBounds(308, 235, 30, 30);
		lblRec.setText("REC");
		lblRec.setToolTipText("Recorder On");
		
		lblLog = new Label(frameMain, SWT.NONE);
		lblLog.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {		
				layoutMode = 0;
				changeFrameWidth();
				openLogsFrame();
				lblSubTitle.setText("Call Planner List");	
			}
		});
		lblLog.setToolTipText("Show Call Log");
		lblLog.setBounds(344, 235, 30, 30);
		lblLog.setImage(new Image(shell.getDisplay(), this.getClass().getResourceAsStream("/images/callLog.png")));
		
		lblSalesClick = new Label(frameMain, SWT.NONE);
		lblSalesClick.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {		
				if(contactId == null || contactId.length()==0)
					return;
				
				layoutMode = 0;
				changeFrameWidth();
				openSalesFrame();
				lblSubTitle.setText("Sales");	
			}
		});
		lblSalesClick.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				lblSalesClick.setImage(new Image(shell.getDisplay(), this.getClass().getResourceAsStream("/images/Suitecase30_selected.png")));
			}
			@Override
			public void mouseExit(MouseEvent e) {
				lblSalesClick.setImage(new Image(shell.getDisplay(), this.getClass().getResourceAsStream("/images/Suitecase30.png")));
			}
		});
		lblSalesClick.setBounds(380, 235, 30, 30);
		lblSalesClick.setImage(new Image(shell.getDisplay(), this.getClass().getResourceAsStream("/images/Suitecase30.png")));
		lblSalesClick.setToolTipText("Show Sales");
		
		btnSeparator = new Button(frameDetail, SWT.FLAT);
		btnSeparator.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				changeFrameWidth();
			}
		});
		btnSeparator.setBounds(scrolledComposite.getBounds().width, 0, 10, shell.getBounds().height-75);
		btnSeparator.setImage(new Image(shell.getDisplay(), PersonFrame.class.getResourceAsStream("/images/separator.png")));			
		
		frameSide = new Composite(frameDetail, SWT.NONE);
		frameSide.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		
		lblSubTitle = new CLabel(frameSide, SWT.NONE);
		lblSubTitle.setForeground(SWTResourceManager.getColor(52, 64, 88));
		lblSubTitle.setFont(SWTResourceManager.getFont("Georgia", 11, SWT.BOLD));
		lblSubTitle.setBackground(SWTResourceManager.getColor(255, 255, 255));
		lblSubTitle.setBounds(0, 0, 200, 30);
		
		scrolledComposite.setContent(frameMain);
		scrolledComposite.setMinSize(frameMain.computeSize(SWT.DEFAULT, SWT.DEFAULT));	
		
		popupMenu = new Menu(lblMenuAction);
		MenuItem exportItem = new MenuItem(popupMenu, SWT.NONE);
	    exportItem.setText("Call Plans Helper");
	    exportItem.setImage(new Image(shell.getDisplay(), this.getClass().getResourceAsStream("/images/callPlanner.gif")));
	    exportItem.addListener(SWT.Selection, new Listener() {
	        public void handleEvent(Event e) {
	        	CallPlanHelperDialog dlg = new CallPlanHelperDialog(shell, SWT.NONE);
	        	dlg.open();
	          }
	        });
	    
		refreshCallReminder();
	}
	
	/*private void setRedLine(int index){		
		Button line = getLineButton(index);
		if(line == null)
			return;
		line.setImage(new Image(shell.getDisplay(), CallFrame.class.getResourceAsStream("/images/red-circle.png")));
	}
	
	private void setGreenLine(int index){		
		Button line = getLineButton(index);
		if(line == null)
			return;
		line.setImage(new Image(shell.getDisplay(), CallFrame.class.getResourceAsStream("/images/green-circle.png")));
	}
	
	private Button getLineButton(int index){
		switch(index){
		case 1: return btnLine1;
		case 2: return btnLine2;
		case 3: return btnLine3;
		case 4: return btnLine4;
		case 5: return btnLine5;
		case 6: return btnLine6;
		}
		return null;
	}*/
	
	private void refreshCallReminder(){
		SimpleDateFormat sqlsdf = new SimpleDateFormat("yyyy-MM-dd");
		
		Calendar c = Calendar.getInstance();
		c.set(dateTimeSelectCallReminder.getYear(), dateTimeSelectCallReminder.getMonth(), dateTimeSelectCallReminder.getDay(), 0, 0); 
		List<FollowUpTask> col = dbConnector.readTask(null, "date(date / 1000, 'unixepoch', 'localtime')>='"+sqlsdf.format(c.getTime())+"' AND type='Call'", "date, time");
		
		String datetitle="";
		treeCallSchedule.removeAll();
		TreeItem parent=null;
		for(int i=0; i<col.size(); i++){
			FollowUpTask task = col.get(i);
			
			if(! sqlsdf.format(task.getDate()).equals(datetitle)){
				datetitle = sqlsdf.format(task.getDate());
				parent = new TreeItem(treeCallSchedule, SWT.NONE);
				parent.setText(new SimpleDateFormat("EEEE, dd-MMM-yyyy").format(task.getDate()));
			}
			
			Contact contact = dbConnector.readContact(null, "contactId='"+task.getContactId()+"'", null).get(0);
						
			TreeItem ti = new TreeItem(parent, SWT.NONE);
			ti.setText((task.getTime()==null?"":task.getTime())+" "+contact.getFirstName()+" "+contact.getLastName());
			ti.setData(task);
			ti.setData("contact",contact);
		}		
	}
	
	public void selectContactPerson(Contact contact, FollowUpTask task, String number){		
		if(contact == null && number == null)
			return;
		
		contactId = contact==null?null:contact.getContactId();
		
		//Show detail on Split Screen
		String note = "";		
		if(contact != null){
			note += contact.getFullName()+"\n";
			if(contact.getJobTitle() != null && contact.getCompany() != null)
				note += contact.getJobTitle()+" at "+contact.getCompany()+"\n\n";
		}
		StyleRange styleRange = new StyleRange();
		styleRange.start = 0;
		styleRange.length = note.length();
		styleRange.foreground = SWTResourceManager.getColor(59,89,152);
		styleRange.fontStyle = SWT.BOLD;
		
		if(task != null){
			if(task.getSubject() != null)
				note += "Purpose : "+task.getSubject()+"\n";
			if(task.getNotes() != null)
				note += "Remark : "+task.getNotes()+"\n";
		}
		txtSplitScreen.setText(note);		
		txtSplitScreen.setStyleRange(styleRange);
		
		//Contact numbers
		if(contact != null){
			lblMobileNumber.setData(contact.getMobile());
			lblMobileNumber.setEnabled(contact.getMobile()!=null);
			lblMobileNumber.setText(contact.getMobile()==null?"":"(M) "+contact.getMobile());
			lblOfficeNumber.setData(contact.getWorkPhone());
			lblOfficeNumber.setEnabled(contact.getWorkPhone()!=null);
			lblOfficeNumber.setText(contact.getWorkPhone()==null?"":"(O) "+contact.getWorkPhone());
			lblHomeNumber.setData(contact.getHomePhone());
			lblHomeNumber.setEnabled(contact.getHomePhone()!=null);
			lblHomeNumber.setText(contact.getHomePhone()==null?"":"(H) "+contact.getHomePhone());
			lblAltNumber.setData(contact.getAltPhone());
			lblAltNumber.setEnabled(contact.getAltPhone()!=null);
			lblAltNumber.setText(contact.getAltPhone()==null?"":"(A) "+contact.getAltPhone());
		}
		
		if(number != null)
			txtCallNumber.setText(number.replace(" ", "").trim());
		
		layoutMode = 1;
		changeFrameWidth();
		if(frameSales != null)
			frameSales.dispose();
		if(frameLogs != null)
			frameLogs.dispose();
	}
	
	private void changeFrameWidth(){		
		if(layoutMode == 0){
			layoutMode = 1;
			
			scrolledComposite.setBounds(0, 0, ((frameDetail.getBounds().width/3*2)-40)-15, frameDetail.getBounds().height);
			btnSeparator.setBounds(scrolledComposite.getBounds().width, 0, 10, shell.getBounds().height-75);
			frameSide.setBounds(((frameDetail.getBounds().width/3*2)-40), 0, (frameDetail.getBounds().width/3), frameDetail.getBounds().height);
		}else{
			layoutMode = 0;
			
			scrolledComposite.setBounds(0, 0, frameDetail.getBounds().width-10, frameDetail.getBounds().height);
			btnSeparator.setBounds(scrolledComposite.getBounds().width, 0, 10, shell.getBounds().height-75);
			frameSide.setBounds(0, 0, 0, 0);
		}		
				
		frameDetail.redraw();
	}
	
	private void openSalesFrame(){
		layoutMode = 0;
		changeFrameWidth();
		
		if(frameSales != null)
			frameSales.dispose();
		if(frameLogs != null)
			frameLogs.dispose();
		frameSales = new PersonSales(frameSide, SWT.NONE, contactId);
		frameSales.setBounds(0, 32, frameSide.getBounds().width, frameSide.getBounds().height-30);
	}
	
	private void openLogsFrame(){
		layoutMode = 0;
		changeFrameWidth();
		
		if(frameSales != null)
			frameSales.dispose();
		if(frameLogs != null)
			frameLogs.dispose();
		frameLogs = new CallLogFrame(frameSide, SWT.NONE, contactId);
		frameLogs.setBounds(0, 32, frameSide.getBounds().width, frameSide.getBounds().height-30);
	}
		
	@Override
	protected void checkSubclass() {
		// Disable the check that prevents subclassing of SWT components
	}
}
