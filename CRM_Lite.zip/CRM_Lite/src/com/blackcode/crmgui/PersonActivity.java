package com.blackcode.crmgui;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Comparator;
import java.util.Date;
import java.util.List;

import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.custom.CLabel;
import org.eclipse.swt.custom.ScrolledComposite;
import org.eclipse.swt.SWT;
import org.eclipse.wb.swt.SWTResourceManager;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.widgets.DateTime;
import org.eclipse.swt.widgets.TableItem;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;

import com.blackcode.core.SQLiteConnector;
import com.blackcode.model.FollowUpTask;
import com.blackcode.model.History;
import com.blackcode.model.Sales;

public class PersonActivity extends Composite {
	private Table tblActivity;
	private Composite composite;
	
	private String contact;
	private SQLiteConnector dbConnector = new SQLiteConnector();

	/**
	 * Create the composite.
	 * @param parent
	 * @param style
	 */
	public PersonActivity(Composite parent, int style, String contact) {
		super(parent, style);
		this.contact = contact;
		
		ScrolledComposite scrolledComposite = new ScrolledComposite(this, SWT.BORDER | SWT.H_SCROLL | SWT.V_SCROLL);
		scrolledComposite.setBounds(0, 0, parent.getBounds().width-5, parent.getBounds().height-28);
		scrolledComposite.setExpandHorizontal(true);
		scrolledComposite.setExpandVertical(true);
		
		composite = new Composite(scrolledComposite, SWT.NONE);
		composite.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		
		final DateTime dateTime = new DateTime(composite, SWT.BORDER | SWT.DROP_DOWN);
		dateTime.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {				
				Calendar selectDate = Calendar.getInstance();
				selectDate.set(dateTime.getYear(), dateTime.getMonth(), dateTime.getDay(), 0, 0); 
				
				showActivity(SQLiteConnector.DateFormat(selectDate.getTime()));
			}
		});
		dateTime.setBounds(125, 30, 17, 19);
		
		CLabel lblDatetime = new CLabel(composite, SWT.CENTER);
		lblDatetime.setForeground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblDatetime.setFont(SWTResourceManager.getFont("Segoe UI", 10, SWT.NORMAL));
		lblDatetime.setBackground(SWTResourceManager.getColor(SWT.COLOR_WIDGET_DARK_SHADOW));
		lblDatetime.setBounds(10, 26, 135, 28);
		lblDatetime.setText("DateTime");
		
		CLabel lblType = new CLabel(composite, SWT.CENTER);
		lblType.setForeground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblType.setFont(SWTResourceManager.getFont("Segoe UI", 10, SWT.NORMAL));
		lblType.setBackground(SWTResourceManager.getColor(SWT.COLOR_WIDGET_DARK_SHADOW));
		lblType.setBounds(147, 26, 70, 28);
		lblType.setText("Type");
		
		CLabel lblActivity = new CLabel(composite, SWT.CENTER);
		lblActivity.setForeground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblActivity.setFont(SWTResourceManager.getFont("Segoe UI", 10, SWT.NORMAL));
		lblActivity.setBackground(SWTResourceManager.getColor(SWT.COLOR_WIDGET_DARK_SHADOW));
		lblActivity.setBounds(218, 26, 263, 28);
		lblActivity.setText("Activity");
		
		tblActivity = new Table(composite, SWT.FULL_SELECTION);
		tblActivity.addListener(SWT.MeasureItem, new Listener() {
			public void handleEvent(Event event) {
			      event.height = 25;
			   }
			});
		tblActivity.setBounds(10, 55, 501, scrolledComposite.getBounds().height-100);
		
		TableColumn tableColumn = new TableColumn(tblActivity, SWT.NONE);
		tableColumn.setWidth(136);
		
		TableColumn tableColumn_1 = new TableColumn(tblActivity, SWT.NONE);
		tableColumn_1.setWidth(71);
		
		TableColumn tableColumn_2 = new TableColumn(tblActivity, SWT.NONE);
		tableColumn_2.setWidth(262);
		
		showActivity(null);
		scrolledComposite.setContent(composite);
		scrolledComposite.setMinSize(composite.computeSize(SWT.DEFAULT, SWT.DEFAULT));		
		
	}
	
	private void showActivity(String condition){
		SimpleDateFormat sdf = new SimpleDateFormat("EEE, dd MMM yyyy HH:mm");
		
		List<TableRow> col = new ArrayList<TableRow>();
		// Retrieve log
		String sql = "contactId='"+contact+"'";
		if(condition != null)
			sql += " AND DATE(logDateTime/ 1000, 'unixepoch', 'localtime')='"+condition+"'";
				
		List<History> logs = dbConnector.readHistory(null, sql, null);
		for(int i=0; i<logs.size(); i++){
			History activity = logs.get(i);
			col.add(new TableRow(activity.getLogDateTime(), activity));
		}
		
		// Retrieve Sales
		sql = "customer='"+contact+"'";
		if(condition != null)
			sql += " AND date(Date / 1000, 'unixepoch', 'localtime')='"+condition+"'";
		
		List<Sales> sales = dbConnector.readSales(null, sql, null);
		for(int i=0; i<sales.size(); i++){
			Sales sale = sales.get(i);
			col.add(new TableRow(sale.getDate(), sale));
		}
		
		// Retrieve FollowUp
		sql = "contactId='"+contact+"'";
		if(condition != null)
			sql += " AND date(date / 1000, 'unixepoch', 'localtime')='"+condition+"'";
		List<FollowUpTask> tasks = dbConnector.readTask(null, sql, null);
		for(int i=0; i<tasks.size(); i++){
			FollowUpTask task = tasks.get(i);
			col.add(new TableRow(task.getDate(), task));
		}
				
		//Sort by date
		TableRow[] rows = new TableRow[col.size()];
		for(int i=0; i<col.size(); i++)
			rows[i] = col.get(i);
		Arrays.sort(rows, BY_DATE);
		
		//Display logs
		tblActivity.removeAll();
		for(int i=0; i<rows.length; i++){
			TableRow row = rows[i];
			String str = "";
			
			if(row.data instanceof History){
				History activity = (History) row.data;				
				if(activity.getSubject() != null)
					str = activity.getSubject()+".";
				if(activity.getNotes() != null)
					str += activity.getNotes();
				
				TableItem ti = new TableItem(tblActivity, SWT.NONE);
				ti.setText(new String[]{sdf.format(activity.getLogDateTime()), activity.getType(), str});
				ti.setData(activity);
			}else if(row.data instanceof Sales){
				Sales sale = (Sales) row.data;
				if(sale.getType() != null)
					str = sale.getType();
				if(sale.getAmount() != null)
					str += "("+Sales.CurrencyFormat(sale.getAmount())+")";
				
				TableItem ti = new TableItem(tblActivity, SWT.NONE);
				ti.setText(new String[]{sdf.format(sale.getDate()), "Sales", str});
				ti.setData(sale);
			}else if(row.data instanceof FollowUpTask){
				FollowUpTask task = (FollowUpTask) row.data;
				if(task.getSubject() != null)
					str = task.getSubject()+".";
				if(task.getNotes() != null)
					str += task.getNotes();
				
				TableItem ti = new TableItem(tblActivity, SWT.NONE);
				ti.setText(new String[]{sdf.format(task.getDate()), "Follow Up", str});
				ti.setData(task);
			}
		}
	}
	
	public final Comparator<TableRow> BY_DATE = new Comparator<TableRow>() {
        @Override
        public int compare(TableRow o1, TableRow o2) {
            return o1.date.compareTo(o2.date);
        }
    };
    
    private class TableRow {
        private Date date;
        private Object data;

        public TableRow(Date date, Object data) {
            this.date = date;
            this.data = data;
        }
    }

	@Override
	protected void checkSubclass() {
		// Disable the check that prevents subclassing of SWT components
	}
}
