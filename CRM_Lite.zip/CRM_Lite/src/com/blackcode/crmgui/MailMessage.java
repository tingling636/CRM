package com.blackcode.crmgui;

import java.io.BufferedReader;
import java.io.File;
import java.io.PrintWriter;
import java.io.StringReader;
import java.net.URL;
import java.sql.Timestamp;
import java.util.Date;
import java.util.Properties;

import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.Message.RecipientType;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.custom.ScrolledComposite;
import org.eclipse.swt.SWT;
import org.eclipse.wb.swt.SWTResourceManager;
import org.eclipse.swt.custom.CLabel;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.custom.StyledText;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.browser.Browser;
import org.eclipse.swt.events.MouseAdapter;
import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.events.MouseTrackAdapter;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;

import com.blackcode.core.SQLiteConnector;
import com.blackcode.model.Account;
import com.blackcode.model.History;

public class MailMessage extends Composite {
	private Shell shell;
	private ScrolledComposite scrolledComposite;
	private Composite frameMessage;
	private CLabel lblSubject;
	private Label lblPrint;
	private Label lblNewWindow;
	private StyledText sytxtHeader;
	private Composite frameSendHeader;
	private Label lblTo;
	private StyledText sytxtTo;
	private Label lblCc;
	private StyledText sytxtCc;
	private Label lblCcAction;
	private StyledText sytxtSendMessage;
	private Composite frameSendTool;
	private ImageCombo cmbActionType;
	private Label lblSendAction;
	
	private Message message;
	private Account selectedAccount;
	private Browser browser;
	private int width;
	/**
	 * Create the composite.
	 * @param parent
	 * @param style
	 */
	public MailMessage(Composite parent, int style, Message message, Account account) {
		super(parent, style);
		this.shell = parent.getShell();
		this.message = message;
		this.selectedAccount = account;
		
		scrolledComposite = new ScrolledComposite(this, SWT.BORDER | SWT.H_SCROLL | SWT.V_SCROLL);
		scrolledComposite.setBounds(0, 0, parent.getBounds().width-5, parent.getBounds().height-28);
		scrolledComposite.setExpandHorizontal(true);
		scrolledComposite.setExpandVertical(true);
		width = scrolledComposite.getBounds().width-28;
		
		frameMessage = new Composite(scrolledComposite, SWT.NONE);
		frameMessage.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		
		lblSubject = new CLabel(frameMessage, SWT.NONE);
		lblSubject.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblSubject.setFont(SWTResourceManager.getFont("Segoe UI", 12, SWT.NORMAL));
		lblSubject.setBounds(10, 10, width-65, 30);
		
		lblPrint = new Label(frameMessage, SWT.NONE);
		lblPrint.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				browser.execute("javascript:window.print();");
			}
		});
		lblPrint.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				lblPrint.setImage(new Image(shell.getDisplay(), MailMessage.class.getResourceAsStream("/images/print_selected.png")));
			}
			@Override
			public void mouseExit(MouseEvent e) {
				lblPrint.setImage(new Image(shell.getDisplay(), MailMessage.class.getResourceAsStream("/images/print.png")));
			}
		});
		lblPrint.setToolTipText("Print");
		lblPrint.setBounds(width-44, 22, 16, 16);
		lblPrint.setImage(new Image(parent.getDisplay(), MailMessage.class.getResourceAsStream("/images/print.png")));
		
		lblNewWindow = new Label(frameMessage, SWT.NONE);
		lblNewWindow.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				openNewWindow();
			}
		});
		lblNewWindow.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				lblNewWindow.setImage(new Image(shell.getDisplay(), MailMessage.class.getResourceAsStream("/images/newwindow_selected.png")));
			}
			@Override
			public void mouseExit(MouseEvent e) {
				lblNewWindow.setImage(new Image(shell.getDisplay(), MailMessage.class.getResourceAsStream("/images/newwindow.gif")));
			}
		});
		lblNewWindow.setToolTipText("Open new window");
		lblNewWindow.setBounds(width-22, 22, 16, 16);
		lblNewWindow.setImage(new Image(parent.getDisplay(), MailMessage.class.getResourceAsStream("/images/newwindow.gif")));
		
		Label lblLine = new Label(frameMessage, SWT.SEPARATOR | SWT.HORIZONTAL);
		lblLine.setBounds(10, 44, width, 2);
		
		sytxtHeader = new StyledText(frameMessage, SWT.NONE);
		sytxtHeader.setForeground(SWTResourceManager.getColor(SWT.COLOR_DARK_GRAY));
		sytxtHeader.setBounds(10, 52, width-50, 30);
		
		browser = new Browser(frameMessage, SWT.NONE);
		browser.setBounds(10, 90, width-10, scrolledComposite.getBounds().height/3*2);
		
		frameSendHeader = new Composite(frameMessage, SWT.BORDER);
		frameSendHeader.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		frameSendHeader.setBounds(10, browser.getBounds().y+browser.getBounds().height+10, width-10, 37);
		
		cmbActionType = new ImageCombo(frameSendHeader, SWT.NONE);
		cmbActionType.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				selectResponseType();
			}
		});
		cmbActionType.setToolTipText("Types of reponse");
		cmbActionType.setBounds(5, 5, 51, 21);
		cmbActionType.add("Reply",new Image(parent.getDisplay(), MailMessage.class.getResourceAsStream("/images/newwindow.gif")));
		cmbActionType.add("Forward",new Image(parent.getDisplay(), MailMessage.class.getResourceAsStream("/images/newwindow.gif")));
		
		lblTo = new Label(frameSendHeader, SWT.RIGHT);
		lblTo.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblTo.setForeground(SWTResourceManager.getColor(SWT.COLOR_GRAY));
		lblTo.setBounds(72, 8, 30, 15);
		lblTo.setText("To");
		
		sytxtTo = new StyledText(frameSendHeader, SWT.NONE);
		sytxtTo.setBounds(108, 7, frameSendHeader.getBounds().width-145, 19);
		
		lblCc = new Label(frameSendHeader, SWT.RIGHT);
		lblCc.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblCc.setForeground(SWTResourceManager.getColor(SWT.COLOR_GRAY));
		lblCc.setBounds(72, 31, 30, 15);
		lblCc.setText("CC");
		lblCc.setVisible(false);
		
		sytxtCc = new StyledText(frameSendHeader, SWT.NONE);
		sytxtCc.setBounds(108, 29, frameSendHeader.getBounds().width-145, 19);
		sytxtCc.setVisible(false);
		
		lblCcAction = new Label(frameSendHeader, SWT.CENTER);
		lblCcAction.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				addCc();
			}
		});
		lblCcAction.setToolTipText("Add CC");
		lblCcAction.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblCcAction.setBounds(frameSendHeader.getBounds().width-35, 8, 30, 15);
		lblCcAction.setText("CC");
		
		sytxtSendMessage = new StyledText(frameMessage, SWT.BORDER);
		sytxtSendMessage.setBounds(10, frameSendHeader.getBounds().y+frameSendHeader.getBounds().height-1, width-10, 114);
		
		frameSendTool = new Composite(frameMessage, SWT.NONE);
		frameSendTool.setBackground(SWTResourceManager.getColor(SWT.COLOR_WIDGET_BACKGROUND));
		frameSendTool.setBounds(10, sytxtSendMessage.getBounds().y+sytxtSendMessage.getBounds().height-1, width-10, 48);
		
		lblSendAction = new Label(frameSendTool, SWT.NONE);
		lblSendAction.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				if(cmbActionType.getSelectionIndex()==0)
					reply();
				else if(cmbActionType.getSelectionIndex()==1)
					forward();
								
			}
		});
		lblSendAction.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				lblSendAction.setImage(new Image(shell.getDisplay(), MailMessage.class.getResourceAsStream("/images/send_selected.png")));
			}
			@Override
			public void mouseExit(MouseEvent e) {
				lblSendAction.setImage(new Image(shell.getDisplay(), MailMessage.class.getResourceAsStream("/images/send.png")));
			}
		});
		lblSendAction.setToolTipText("Send");
		lblSendAction.setBounds(10, 10, 72, 30);
		lblSendAction.setImage(new Image(parent.getDisplay(), MailMessage.class.getResourceAsStream("/images/send.png")));
		
		Label lblAttach = new Label(frameSendTool, SWT.NONE);
		lblAttach.setToolTipText("Attach Files");
		lblAttach.setBounds(102, 14, 24, 24);
		lblAttach.setImage(new Image(parent.getDisplay(), MailMessage.class.getResourceAsStream("/images/attachment.png")));
				
		scrolledComposite.setContent(frameMessage);
		scrolledComposite.setMinSize(frameMessage.computeSize(SWT.DEFAULT, SWT.DEFAULT));

		showMessage();
	}

	private void showMessage(){
		try {
			lblSubject.setText(message.getSubject());

			String fromAddress = message.getFrom()[0].toString();
	    	if(fromAddress.indexOf("?")>0 && message.getHeader("Reply-To")!=null)
	    		fromAddress = message.getHeader("Reply-To")[0];
	    	fromAddress = fromAddress.replace("\"", "").replace("'", "");
	    	String recipient = message.getRecipients(RecipientType.TO)[0].toString().replace("\"", "").replace("'", "");
	    	sytxtHeader.setText(fromAddress+"\nto "+recipient); 
	    	
	    	PrintWriter writer = new PrintWriter("C:/ProgramData/BlackCodeCRM/message.html", "UTF-8");
	    	writer.append("<html>");
	    	
			if(message.getContent() instanceof String){
				String text = message.getContent().toString();
				StringBuilder line =new StringBuilder();
				writer.append("<html>");
				 for(int i=0; i<text.length(); i++){
					 if(text.charAt(i)=='\n'){
						 writer.println("<br>"+line.toString()+"</br>");
						 line =new StringBuilder();
					 }else{
						 line.append(text.charAt(i));
					 }
				 }
			}else {
				Multipart mp = (Multipart) message.getContent();
				for(int i = 0; i < mp.getCount(); i++) {
					BodyPart bp = mp.getBodyPart(i);
				    String disp = bp.getDisposition();
				    if(disp != null && (disp.equals(BodyPart.ATTACHMENT))) {
				    	/*DataHandler handler = bp.getDataHandler();
				    	attachments.add(new FileManager().createFile(handler.getInputStream(), handler.getName()));*/
				    }else {
				    	if(bp.getContent() instanceof Multipart){
				    		Multipart subpart = (Multipart) bp.getContent();
						    for(int j=1; j<subpart.getCount(); j++){
						    	BodyPart subbodypart = subpart.getBodyPart(j);
						    	writer.println(subbodypart.getContent());
						    }
						}else{
							if(bp.getContent().toString().startsWith("<!DOCTYPE") || bp.getContent().toString().startsWith("<html")){
					        	writer = new PrintWriter("C:/ProgramData/BlackCodeCRM/message.html", "UTF-8");
					        }
					        
					        writer.println(bp.getContent());
						}
				    }
				}
			}			
			writer.close();
			
			File file = new File("C:/ProgramData/BlackCodeCRM/message.html");
			URL url = file.toURI().toURL(); 
			browser.setUrl(url.toString());
			
		} catch (MessagingException e) {
			MessageDialog dlg = new MessageDialog(this.shell, SWT.NONE, "Error 500 : Email Problems (MM296)");
			dlg.open();
		}catch (Exception e){
			MessageDialog dlg = new MessageDialog(this.shell, SWT.NONE, "Error 500 : Email Problems (MM296)");
			dlg.open();
		}
	}
	
	private void openNewWindow(){
		if(message == null)
			return;
		
		MailMessageDialog dlg = new MailMessageDialog(this.getShell(), SWT.DIALOG_TRIM | SWT.APPLICATION_MODAL, message, selectedAccount);
		dlg.open();
	}
	
	private void selectResponseType(){
		try{
			if(cmbActionType.getSelectionIndex() == 0)
				sytxtTo.setText(message.getHeader("From")[0]);
		} catch (MessagingException e) {
			MessageDialog dlg = new MessageDialog(this.shell, SWT.NONE, "Error 500 : Email Problems (MM316)");
			dlg.open();
		}
	}
		
	private void addCc(){
		try{
			lblCc.setVisible(true);
			sytxtCc.setVisible(true);
			lblCcAction.setVisible(false);
			
			frameSendHeader.setSize(width-10, 59);
			frameSendHeader.redraw();
			sytxtSendMessage.setLocation(10, frameSendHeader.getBounds().y+frameSendHeader.getBounds().height-1);
			sytxtSendMessage.redraw();
			frameSendTool.setLocation(10, sytxtSendMessage.getBounds().y+sytxtSendMessage.getBounds().height-1);
			frameSendTool.redraw();		
			frameMessage.redraw();
			scrolledComposite.setContent(frameMessage);
			scrolledComposite.setMinSize(frameMessage.computeSize(SWT.DEFAULT, SWT.DEFAULT));
		}catch (Exception e) {
			MessageDialog dlg = new MessageDialog(this.shell, SWT.NONE, "Error 401 : System Problems (MM336)");
			dlg.open();
		}
	}
	
	private void reply(){
		try {			
			Properties props = new Properties();
		    props.put("mail.smtp.auth", true);
		    props.put("mail.smtp.starttls.enable", true);
		    props.put("mail.smtp.host", selectedAccount.getOutgoingMailServer());
		    
		    Session session = Session.getInstance(props,
		    		new javax.mail.Authenticator() {
		                protected PasswordAuthentication getPasswordAuthentication() {
		                    return new PasswordAuthentication(selectedAccount.getEmailId(), selectedAccount.getEmailPassword());
		                }
		            });
		   		    
		    MimeMessage reply = new MimeMessage(session);	
		    reply = (MimeMessage)message.reply(false);
		    reply.addRecipients(Message.RecipientType.TO, InternetAddress.parse(sytxtTo.getText()));
			reply.setFrom(message.getFrom()[0]);
			reply.setSubject(message.getSubject());
			reply.setReplyTo(message.getReplyTo());
			
			StringBuffer buffer = new StringBuffer(sytxtSendMessage.getText()+"\n\n");
			if (message.isMimeType("text/plain")) {
				String content = (String) message.getContent();
				StringReader contentReader = new StringReader(content);
				BufferedReader br = new BufferedReader(contentReader);
				String contentLine;
				while ((contentLine = br.readLine()) != null) {
					buffer.append("> ");
					buffer.append(contentLine);
					buffer.append("\r\n");
				}
			}
			//reply.setText(buffer.toString());
			
			BodyPart messageBodyPart = new MimeBodyPart();    
			messageBodyPart.setText(buffer.toString());    
			     
			Multipart multipart = new MimeMultipart();    
			multipart.addBodyPart(messageBodyPart);    
			     
			messageBodyPart = new MimeBodyPart();  
			messageBodyPart.setDataHandler(message.getDataHandler());    
			     
			multipart.addBodyPart(messageBodyPart);
			reply.setContent(multipart); 
			   
			Transport.send(reply);
			
		} catch (MessagingException e) {
			MessageDialog dlg = new MessageDialog(this.shell, SWT.NONE, "Error 500 : Email Problems (MM387)");
			dlg.open();
		} catch (Exception e1) {
			MessageDialog dlg = new MessageDialog(this.shell, SWT.NONE, "Error 500 : Email Problems (MM387)");
			dlg.open();
		}
	}
	
	private void forward(){
		try {			
			Properties props = new Properties();
		    props.put("mail.smtp.auth", true);
		    props.put("mail.smtp.starttls.enable", true);
		    props.put("mail.smtp.host", selectedAccount.getOutgoingMailServer());
		    
		    Session session = Session.getInstance(props,
		    		new javax.mail.Authenticator() {
		                protected PasswordAuthentication getPasswordAuthentication() {
		                    return new PasswordAuthentication(selectedAccount.getEmailId(), selectedAccount.getEmailPassword());
		                }
		            });
		   		    
		    MimeMessage forward = new MimeMessage(session);	
		    forward.addRecipients(Message.RecipientType.TO, InternetAddress.parse(sytxtTo.getText()));
		    forward.setFrom(message.getFrom()[0]);
		    forward.setSubject("Fwd: "+message.getSubject());
			
		    BodyPart messageBodyPart = new MimeBodyPart();
		    messageBodyPart.setText(sytxtSendMessage.getText());
		    
		    Multipart multipart = new MimeMultipart();
		    multipart.addBodyPart(messageBodyPart);
		    
		    messageBodyPart = new MimeBodyPart();
		    messageBodyPart.setDataHandler(message.getDataHandler());

		    // Add part to multi part
		    multipart.addBodyPart(messageBodyPart);

		    // Associate multi-part with message
		    forward.setContent(multipart);
			Transport.send(forward);
			
			History history = new History(0, new Timestamp(new Date().getTime()), "Email", "", sytxtTo.getText(), "Fwd: "+message.getSubject(), selectedAccount.getEmailId(), null);
			new SQLiteConnector().createHistory(history);
		} catch (MessagingException e) {
			MessageDialog dlg = new MessageDialog(this.shell, SWT.NONE, "Error 500 : Email Problems (MM433)");
			dlg.open();
		} catch (Exception e1) {
			MessageDialog dlg = new MessageDialog(this.shell, SWT.NONE, "Error 500 : Email Problems (MM436)");
			dlg.open();
		}
	}
	
	@Override
	protected void checkSubclass() {
		// Disable the check that prevents subclassing of SWT components
	}
}
