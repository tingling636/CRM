package com.blackcode.crmgui;


import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.wb.swt.SWTResourceManager;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.events.MouseTrackAdapter;
import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.events.MouseAdapter;
import org.eclipse.swt.custom.CLabel;

public class ToolBar extends Composite {
	ApplicationLiteMain main;
	Shell shell;
	Composite toolbar;
	
	private Composite frameToolPhone;
	private Label lblToolPhone;
	private CLabel lblToolPhoneTitle;
	private Composite frameToolEmail;
	private Label lblToolEmail;
	private CLabel lblToolEmailTitle;
	private Composite frameToolHistory;
	private Label lblToolHistory;
	private CLabel lblToolHistoryTitle;
	private Composite frameToolPerson;
	private Label lblToolPerson;
	private CLabel lblToolPersonTitle;
	private Composite frameToolGroup;
	private Label lblToolGroup;
	private CLabel lblToolGroupTitle;
	private Composite frameToolMark;
	private Label lblToolMark;
	private CLabel lblToolMarkTitle;
	private CLabel lblTools;
	private Label lblHideTool;
	

	/**
	 * Create the composite.
	 * @param parent
	 * @param style
	 */
	public ToolBar(Composite parent, int style, ApplicationLiteMain main) {
		super(parent, style);
		setBackground(SWTResourceManager.getColor(235, 243, 247));
		this.main = main;
		shell = parent.getShell();
		toolbar = this;
		
		frameToolPhone = new Composite(this, SWT.NONE);
		frameToolPhone.setBounds(5, 32, 240, 56);
		frameToolPhone.setBackground(SWTResourceManager.getColor(255, 255, 255));
		
		lblToolPhone = new Label(frameToolPhone, SWT.NONE);
		lblToolPhone.setBounds(3, 3, 50, 50);
		lblToolPhone.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				toolbar.setVisible(false);
				openFrame(0);
			}
		});
		lblToolPhone.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				enterPhone();
			}
			@Override
			public void mouseExit(MouseEvent e) {
				exitPhone();
			}
		});
		lblToolPhone.setBackground(SWTResourceManager.getColor(75, 99, 132));
		lblToolPhone.setImage(declareImage(shell, "/images/phone48.png"));
		
		lblToolPhoneTitle = new CLabel(frameToolPhone, SWT.WRAP | SWT.CENTER);
		lblToolPhoneTitle.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				toolbar.setVisible(false);
				openFrame(0);
			}
		});
		lblToolPhoneTitle.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				enterPhone();
			}
			@Override
			public void mouseExit(MouseEvent e) {
				exitPhone();
			}
		});
		lblToolPhoneTitle.setFont(SWTResourceManager.getFont("Georgia", 14, SWT.BOLD));
		lblToolPhoneTitle.setBounds(54, 3, 182, 50);
		lblToolPhoneTitle.setBackground(SWTResourceManager.getColor(255, 255, 255));
		lblToolPhoneTitle.setForeground(SWTResourceManager.getColor(75, 99, 132));
		lblToolPhoneTitle.setText("Call");
		
		frameToolEmail = new Composite(this, SWT.NONE);
		frameToolEmail.setBounds(5, 94, 240, 56);
		frameToolEmail.setBackground(SWTResourceManager.getColor(255, 255, 255));
		
		lblToolEmail = new Label(frameToolEmail, SWT.NONE);
		lblToolEmail.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				toolbar.setVisible(false);
				openFrame(1);
			}
		});
		lblToolEmail.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				enterEmail();
			}
			@Override
			public void mouseExit(MouseEvent e) {
				exitEmail();
			}
		});
		lblToolEmail.setBounds(3, 3, 50, 50);
		lblToolEmail.setBackground(SWTResourceManager.getColor(75, 99, 132));
		lblToolEmail.setImage(declareImage(shell, "/images/email48.png"));
		
		lblToolEmailTitle = new CLabel(frameToolEmail, SWT.CENTER);
		lblToolEmailTitle.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				toolbar.setVisible(false);
				openFrame(1);
			}
		});
		lblToolEmailTitle.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				enterEmail();
			}
			@Override
			public void mouseExit(MouseEvent e) {
				exitEmail();
			}
		});
		lblToolEmailTitle.setFont(SWTResourceManager.getFont("Georgia", 14, SWT.BOLD));
		lblToolEmailTitle.setBounds(54, 3, 182, 50);
		lblToolEmailTitle.setBackground(SWTResourceManager.getColor(255, 255, 255));
		lblToolEmailTitle.setForeground(SWTResourceManager.getColor(75, 99, 132));
		lblToolEmailTitle.setText("Email");
		
		frameToolHistory = new Composite(this, SWT.NONE);
		frameToolHistory.setBounds(5, 156, 240, 56);
		frameToolHistory.setBackground(SWTResourceManager.getColor(255, 255, 255));
		
		lblToolHistory = new Label(frameToolHistory, SWT.NONE);
		lblToolHistory.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				toolbar.setVisible(false);
				openFrame(2);
			}
		});
		lblToolHistory.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				enterHistory();
			}
			@Override
			public void mouseExit(MouseEvent e) {
				exitHistory();
			}
		});
		lblToolHistory.setBounds(3, 3, 50, 50);
		lblToolHistory.setBackground(SWTResourceManager.getColor(75, 99, 132));
		lblToolHistory.setImage(declareImage(shell, "/images/time48.png"));
		
		lblToolHistoryTitle = new CLabel(frameToolHistory, SWT.CENTER);
		lblToolHistoryTitle.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				toolbar.setVisible(false);
				openFrame(2);
			}
		});
		lblToolHistoryTitle.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				enterHistory();
			}
			@Override
			public void mouseExit(MouseEvent e) {
				exitHistory();
			}
		});
		lblToolHistoryTitle.setFont(SWTResourceManager.getFont("Georgia", 14, SWT.BOLD));
		lblToolHistoryTitle.setBounds(54, 3, 182, 50);
		lblToolHistoryTitle.setBackground(SWTResourceManager.getColor(255, 255, 255));
		lblToolHistoryTitle.setForeground(SWTResourceManager.getColor(75, 99, 132));
		lblToolHistoryTitle.setText("Activity");
		
		frameToolPerson = new Composite(this, SWT.NONE);
		frameToolPerson.setBounds(5, 218, 240, 56);
		frameToolPerson.setBackground(SWTResourceManager.getColor(255, 255, 255));
		
		lblToolPerson = new Label(frameToolPerson, SWT.NONE);
		lblToolPerson.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				toolbar.setVisible(false);
				openFrame(3);
			}
		});
		lblToolPerson.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				enterPerson();
			}
			@Override
			public void mouseExit(MouseEvent e) {
				exitPerson();
			}
		});
		lblToolPerson.setBounds(3, 3, 50, 50);
		lblToolPerson.setBackground(SWTResourceManager.getColor(75, 99, 132));
		lblToolPerson.setImage(declareImage(shell, "/images/person48.png"));
		
		lblToolPersonTitle = new CLabel(frameToolPerson, SWT.CENTER);
		lblToolPersonTitle.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				toolbar.setVisible(false);
				openFrame(3);
			}
		});
		lblToolPersonTitle.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				enterPerson();
			}
			@Override
			public void mouseExit(MouseEvent e) {
				exitPerson();
			}
		});
		lblToolPersonTitle.setFont(SWTResourceManager.getFont("Georgia", 14, SWT.BOLD));
		lblToolPersonTitle.setBounds(54, 3, 182, 50);
		lblToolPersonTitle.setBackground(SWTResourceManager.getColor(255, 255, 255));
		lblToolPersonTitle.setForeground(SWTResourceManager.getColor(75, 99, 132));
		lblToolPersonTitle.setText("Contact");
		
		frameToolMark = new Composite(this, SWT.NONE);
		frameToolMark.setBounds(5, 280, 240, 56);
		frameToolMark.setBackground(SWTResourceManager.getColor(255, 255, 255));
		
		lblToolMark = new Label(frameToolMark, SWT.NONE);
		lblToolMark.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				toolbar.setVisible(false);
				openFrame(4);
			}
		});
		lblToolMark.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				enterMark();
			}
			@Override
			public void mouseExit(MouseEvent e) {
				exitMark();
			}
		});
		lblToolMark.setBounds(3, 3, 50, 50);
		lblToolMark.setBackground(SWTResourceManager.getColor(75, 99, 132));
		lblToolMark.setImage(declareImage(shell, "/images/star48.png"));
		
		lblToolMarkTitle = new CLabel(frameToolMark, SWT.CENTER);
		lblToolMarkTitle.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				toolbar.setVisible(false);
				openFrame(4);
			}
		});
		lblToolMarkTitle.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				enterMark();
			}
			@Override
			public void mouseExit(MouseEvent e) {
				exitMark();
			}
		});
		lblToolMarkTitle.setFont(SWTResourceManager.getFont("Georgia", 14, SWT.BOLD));
		lblToolMarkTitle.setBounds(54, 3, 182, 50);
		lblToolMarkTitle.setBackground(SWTResourceManager.getColor(255, 255, 255));
		lblToolMarkTitle.setForeground(SWTResourceManager.getColor(75, 99, 132));
		lblToolMarkTitle.setText("Follow Up");
		
		frameToolGroup = new Composite(this, SWT.NONE);
		frameToolGroup.setBounds(5, 342, 240, 56);
		frameToolGroup.setBackground(SWTResourceManager.getColor(255, 255, 255));
		
		lblToolGroup = new Label(frameToolGroup, SWT.NONE);
		lblToolGroup.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				toolbar.setVisible(false);
				openFrame(5);
			}
		});
		lblToolGroup.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				enterGroup();
			}
			@Override
			public void mouseExit(MouseEvent e) {
				exitGroup();
			}
		});
		lblToolGroup.setBounds(3, 3, 50, 50);
		lblToolGroup.setBackground(SWTResourceManager.getColor(75, 99, 132));
		lblToolGroup.setImage(declareImage(shell, "/images/group48.png"));
		
		lblToolGroupTitle = new CLabel(frameToolGroup, SWT.CENTER);
		lblToolGroupTitle.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				toolbar.setVisible(false);
				openFrame(5);
			}
		});
		lblToolGroupTitle.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				enterGroup();
			}
			@Override
			public void mouseExit(MouseEvent e) {
				exitGroup();
			}
		});
		lblToolGroupTitle.setFont(SWTResourceManager.getFont("Georgia", 14, SWT.BOLD));
		lblToolGroupTitle.setBounds(54, 3, 182, 50);
		lblToolGroupTitle.setBackground(SWTResourceManager.getColor(255, 255, 255));
		lblToolGroupTitle.setForeground(SWTResourceManager.getColor(75, 99, 132));
		lblToolGroupTitle.setText("Group");
				
		lblTools = new CLabel(this, SWT.NONE);
		lblTools.setFont(SWTResourceManager.getFont("Georgia", 14, SWT.BOLD));
		lblTools.setBounds(5, 10, 61, 21);
		lblTools.setBackground(SWTResourceManager.getColor(235, 243, 247));
		lblTools.setText("Tools ");
		
		lblHideTool = new Label(this, SWT.NONE);
		lblHideTool.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				toolbar.setVisible(false);
			}
		});
		lblHideTool.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				lblHideTool.setImage(declareImage(shell, "/images/back48_hover.png"));
			}
			@Override
			public void mouseExit(MouseEvent e) {
				lblHideTool.setImage(declareImage(shell, "/images/back48.png"));
			}
		});
		lblHideTool.setBounds(87, 450, 48, 48);
		lblHideTool.setBackground(SWTResourceManager.getColor(235, 243, 247));
		lblHideTool.setImage(declareImage(shell, "/images/back48.png"));
		
	}

	@Override
	protected void checkSubclass() {
		// Disable the check that prevents subclassing of SWT components
	}
	
	private void enterPhone(){
		frameToolPhone.setBackground(SWTResourceManager.getColor(219, 223, 230));
	}
	private void exitPhone(){
		frameToolPhone.setBackground(SWTResourceManager.getColor(255, 255, 255));
	}
	
	private void enterEmail(){
		frameToolEmail.setBackground(SWTResourceManager.getColor(219, 223, 230));
	}
	private void exitEmail(){
		frameToolEmail.setBackground(SWTResourceManager.getColor(255, 255, 255));
	}
	
	private void enterHistory(){
		frameToolHistory.setBackground(SWTResourceManager.getColor(219, 223, 230));
	}
	private void exitHistory(){
		frameToolHistory.setBackground(SWTResourceManager.getColor(255, 255, 255));
	}
	
	private void enterPerson(){
		frameToolPerson.setBackground(SWTResourceManager.getColor(219, 223, 230));
	}
	private void exitPerson(){
		frameToolPerson.setBackground(SWTResourceManager.getColor(255, 255, 255));
	}
	
	private void enterMark(){
		frameToolMark.setBackground(SWTResourceManager.getColor(219, 223, 230));
	}
	private void exitMark(){
		frameToolMark.setBackground(SWTResourceManager.getColor(255, 255, 255));
	}
	
	private void enterGroup(){
		frameToolGroup.setBackground(SWTResourceManager.getColor(219, 223, 230));
	}
	private void exitGroup(){
		frameToolGroup.setBackground(SWTResourceManager.getColor(255, 255, 255));
	}
		
	private void openFrame(int index){
		main.selectTool(index);
	}
	
	private Image declareImage(Shell shell, String path) {
		return new Image(shell.getDisplay(), ToolBar.class.getResourceAsStream(path));
	}
}
