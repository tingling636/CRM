package com.blackcode.crmgui;

import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.CLabel;
import org.eclipse.swt.custom.ScrolledComposite;
import org.eclipse.swt.events.KeyAdapter;
import org.eclipse.swt.events.KeyEvent;
import org.eclipse.swt.events.MouseAdapter;
import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.events.MouseTrackAdapter;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Dialog;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.widgets.Widget;
import org.eclipse.wb.swt.SWTResourceManager;

public class PersonDialog extends Dialog {
	protected Object result;
	protected Shell shell;
	
	private ScrolledComposite scrolledPersonInfo;
	private Composite framePersonInfo;
	private CLabel lblSaveAction;
	private CLabel lblCancelAction ;
	private Combo cmbAccount;
	private Text txtSerialNo;
	private Text txtCompany;
	private Text txtPosition;
	private Label lblPicture;
	private Composite frameName;
	private Combo cmbNameTitle;
	private Text txtNameValue;
	private Button btnAddName;
	private Composite framePhone;
	private Combo cmbPhoneTitle;
	private Text txtPhoneValue;
	private Button btnAddPhone;
	private Composite frameEmail;
	private Combo cmbEmailTitle;
	private Text txtEmailValue;	
	private Button btnAddEmail;
	private Composite frameAddress;
	private Combo cmbAddressTitle;
	private Button btnIsMailing;
	private Text txtAddressValue;
	private Button btnAddAddress;
	private Composite frameSocialNetwork;
	private Combo cmbSocialNetwork;
	private Text txtSocialNetwork;
	private Button btnAddSocial;
	private Label LblNameRemove;
	private Label lblPhoneRemove;
	private Label lblEmailRemove;
	private Label lblAddressRemove;
	private Label lblSocialRemove;

	private int showName=1,showPhone=1,showEmail=1,showAddress=1, showSocial=1;
	private String[] nameTitles = new String[]{"Title","First Name","Middle Name","Last Name","Nice Name"};
	private String[] phoneTitles = new String[]{"Home","Mobile","Work","Alternative","Home Fax","Work Fax"};
	private String[] emailTitles = new String[]{"Personal","Work","Other"};
	private String[] addressTitles = new String[]{"Home","Work"};
	private String[] socialTitles = new String[]{"Facebook","Twitter","LinkedIn"};
	

	/**
	 * Create the dialog.
	 * @param parent
	 * @param style
	 */
	public PersonDialog(Shell parent, int style) {
		super(parent, style);
		setText("Person");
	}

	/**
	 * Open the dialog.
	 * @return the result
	 */
	public Object open() {
		createContents();
		shell.open();
		shell.layout();
		Display display = getParent().getDisplay();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
		return result;
	}

	/**
	 * Create contents of the dialog.
	 */
	private void createContents() {
		shell = new Shell(getParent(), getStyle());
		shell.setSize(480, 700);
		shell.setLocation(getParent().getBounds().width/2-200, 30);
		shell.setText(getText());
				
		scrolledPersonInfo = new ScrolledComposite(shell, SWT.BORDER | SWT.H_SCROLL | SWT.V_SCROLL);
		scrolledPersonInfo.setBounds(0, 0, shell.getBounds().width-5, shell.getBounds().height-28);
		scrolledPersonInfo.setExpandHorizontal(true);
		scrolledPersonInfo.setExpandVertical(true);
		
		framePersonInfo = new Composite(scrolledPersonInfo, SWT.NONE);
		framePersonInfo.setBackground(SWTResourceManager.getColor(255, 255, 255));
		scrolledPersonInfo.setContent(framePersonInfo);
		scrolledPersonInfo.setMinSize(framePersonInfo.computeSize(SWT.DEFAULT, SWT.DEFAULT));
		
		lblSaveAction = new CLabel(framePersonInfo, SWT.CENTER);
		lblSaveAction.setForeground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblSaveAction.setFont(SWTResourceManager.getFont("Georgia", 11, SWT.BOLD));
		lblSaveAction.setBounds(10, 10, 120, 30);
		lblSaveAction.setBackground(SWTResourceManager.getColor(52, 64, 88));
		lblSaveAction.setText("Save");
		lblSaveAction.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				
			}
		});
		lblSaveAction.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				lblSaveAction.setBackground(SWTResourceManager.getColor(77, 99, 132));
				lblSaveAction.setForeground(SWTResourceManager.getColor(52, 64, 88));
			}
			@Override
			public void mouseExit(MouseEvent e) {
				lblSaveAction.setBackground(SWTResourceManager.getColor(52, 64, 88));
				lblSaveAction.setForeground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
			}
		});
		
		lblCancelAction = new CLabel(framePersonInfo, SWT.CENTER);
		lblCancelAction.setForeground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblCancelAction.setFont(SWTResourceManager.getFont("Georgia", 10, SWT.BOLD));
		lblCancelAction.setBounds(131, 10, 120, 30);
		lblCancelAction.setBackground(SWTResourceManager.getColor(52, 64, 88));
		lblCancelAction.setText("Cancel");
		lblCancelAction.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				shell.close();
			}
		});
		lblCancelAction.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				lblCancelAction.setBackground(SWTResourceManager.getColor(77, 99, 132));
				lblCancelAction.setForeground(SWTResourceManager.getColor(52, 64, 88));
			}
			@Override
			public void mouseExit(MouseEvent e) {
				lblCancelAction.setBackground(SWTResourceManager.getColor(52, 64, 88));
				lblCancelAction.setForeground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
			}
		});
		
		cmbAccount = new Combo(framePersonInfo, SWT.NONE);
		cmbAccount.setBounds(10, 70, 181, 23);
		cmbAccount.setText("Account");
		
		txtSerialNo = new Text(framePersonInfo, SWT.BORDER);
		txtSerialNo.setText("Serial No");
		txtSerialNo.setToolTipText("Serial No");
		txtSerialNo.setBounds(10, 99, 181, 24);
		
		txtCompany = new Text(framePersonInfo, SWT.BORDER);
		txtCompany.setText("Company Name");
		txtCompany.setBounds(10, 129, 276, 24);
		
		txtPosition = new Text(framePersonInfo, SWT.BORDER);
		txtPosition.setText("JobTitle");
		txtPosition.setBounds(10, 159, 276, 24);
		scrolledPersonInfo.setContent(framePersonInfo);
		scrolledPersonInfo.setMinSize(framePersonInfo.computeSize(SWT.DEFAULT, SWT.DEFAULT));
		
		lblPicture = new Label(framePersonInfo, SWT.NONE);
		lblPicture.setBounds(292, 33, 150, 150);
		
		frameName = new Composite(framePersonInfo, SWT.NONE);
		frameName.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		frameName.setBounds(10, 201, 431, 95);
		
		CLabel lblName = new CLabel(frameName, SWT.SHADOW_OUT);
		lblName.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				if(showName==1)
					showName=0;
				else
					showName=1;
				computeFrames(1);
			}
		});
		lblName.setFont(SWTResourceManager.getFont("Georgia", 10, SWT.BOLD));
		lblName.setBounds(0, 0, 431, 25);
		lblName.setImage(new Image(shell.getDisplay(), PersonDialog.class.getResourceAsStream("/images/arrowdownleft21.png")));
		lblName.setText("Name");
		
		cmbNameTitle = new Combo(frameName, SWT.NONE);
		cmbNameTitle.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				cmbNameTitle.setText("");
			}
			@Override
			public void keyReleased(KeyEvent e) {
				cmbNameTitle.setText("");
			}
		});
		cmbNameTitle.setBounds(0, 31, 125, 23);
		cmbNameTitle.setItems(nameTitles);
		cmbNameTitle.setData("id", 0);
		
		txtNameValue = new Text(frameName, SWT.BORDER);
		txtNameValue.setBounds(131, 31, 265, 24);
		txtNameValue.setData("id", 0);
		
		LblNameRemove = new Label(frameName, SWT.NONE);
		LblNameRemove.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {				
				if(((Label)e.widget).getData("id").toString().equals("0"))
					return;
				System.out.println(((Label)e.widget).getData("id")+":"+e.toString());
			}
		});
		LblNameRemove.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				LblNameRemove.setBackground(SWTResourceManager.getColor(235, 243, 247));
			}
			@Override
			public void mouseExit(MouseEvent e) {
				LblNameRemove.setBackground(SWTResourceManager.getColor(255, 255, 255));
			}
		});
		LblNameRemove.setBounds(402, 31, 24, 24);
		LblNameRemove.setBackground(SWTResourceManager.getColor(255, 255, 255));
		LblNameRemove.setImage(new Image(shell.getDisplay(), PersonDialog.class.getResourceAsStream("/images/remove24.png")));
		LblNameRemove.setData("id", 0);
		
		btnAddName = new Button(frameName, SWT.NONE);
		btnAddName.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				addNameField();
			}
		});
		btnAddName.setBounds(177, 63, 75, 25);
		btnAddName.setText("Add Field");
				
		framePhone = new Composite(framePersonInfo, SWT.NONE);
		framePhone.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		framePhone.setBounds(10, 307, 431, 95);
		
		CLabel lblPhone = new CLabel(framePhone, SWT.SHADOW_OUT);
		lblPhone.setFont(SWTResourceManager.getFont("Georgia", 10, SWT.BOLD));
		lblPhone.setBounds(0, 0, 431, 25);
		lblPhone.setImage(new Image(shell.getDisplay(), PersonDialog.class.getResourceAsStream("/images/arrowdownleft21.png")));
		lblPhone.setText("Phone");
		lblPhone.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				if(showPhone==1)
					showPhone=0;
				else
					showPhone=1;
				computeFrames(2);
			}
		});
		
		cmbPhoneTitle = new Combo(framePhone, SWT.NONE);
		cmbPhoneTitle.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				cmbPhoneTitle.setText("");
			}
			@Override
			public void keyReleased(KeyEvent e) {
				cmbPhoneTitle.setText("");
			}
		});
		cmbPhoneTitle.setBounds(0, 31, 125, 23);
		cmbPhoneTitle.setItems(phoneTitles);
		cmbPhoneTitle.setData("id",0);
		
		txtPhoneValue = new Text(framePhone, SWT.BORDER);
		txtPhoneValue.setBounds(131, 31, 265, 24);
		txtPhoneValue.setData("id", 0);
		
		lblPhoneRemove = new Label(framePhone, SWT.NONE);
		lblPhoneRemove.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {				
				if(((Label)e.widget).getData("id").toString().equals("0"))
					return;
			}
		});
		lblPhoneRemove.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				lblPhoneRemove.setBackground(SWTResourceManager.getColor(235, 243, 247));
			}
			@Override
			public void mouseExit(MouseEvent e) {
				lblPhoneRemove.setBackground(SWTResourceManager.getColor(255, 255, 255));
			}
		});
		lblPhoneRemove.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblPhoneRemove.setBounds(402, 31, 24, 24);
		lblPhoneRemove.setImage(new Image(shell.getDisplay(), PersonDialog.class.getResourceAsStream("/images/remove24.png")));
		lblPhoneRemove.setData("id", 0);
		
		btnAddPhone = new Button(framePhone, SWT.NONE);
		btnAddPhone.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				addPhoneField();
			}
		});
		btnAddPhone.setBounds(177, 63, 75, 25);
		btnAddPhone.setText("Add Field");
		btnAddPhone.setData("id", 0);
				
		frameEmail = new Composite(framePersonInfo, SWT.NONE);
		frameEmail.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		frameEmail.setBounds(10, 413, 431, 95);
		
		CLabel lblEmail = new CLabel(frameEmail, SWT.SHADOW_OUT);
		lblEmail.setFont(SWTResourceManager.getFont("Georgia", 10, SWT.BOLD));
		lblEmail.setBounds(0, 0, 431, 25);
		lblEmail.setImage(new Image(shell.getDisplay(), PersonDialog.class.getResourceAsStream("/images/arrowdownleft21.png")));
		lblEmail.setText("Email");
		lblEmail.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				if(showEmail==1)
					showEmail=0;
				else
					showEmail=1;
				computeFrames(3);
			}
		});
		
		cmbEmailTitle = new Combo(frameEmail, SWT.NONE);
		cmbEmailTitle.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				cmbEmailTitle.setText("");
			}
			@Override
			public void keyReleased(KeyEvent e) {
				cmbEmailTitle.setText("");
			}
		});
		cmbEmailTitle.setBounds(0, 31, 125, 23);
		cmbEmailTitle.setItems(emailTitles);
		cmbEmailTitle.setData("id", 0);
		
		txtEmailValue = new Text(frameEmail, SWT.BORDER);
		txtEmailValue.setBounds(131, 31, 265, 24);
		txtEmailValue.setData("id", 0);
		
		lblEmailRemove = new Label(frameEmail, SWT.NONE);
		lblEmailRemove.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {				
				if(((Label)e.widget).getData("id").toString().equals("0"))
					return;
			}
		});
		lblEmailRemove.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				lblEmailRemove.setBackground(SWTResourceManager.getColor(235, 243, 247));
			}
			@Override
			public void mouseExit(MouseEvent e) {
				lblEmailRemove.setBackground(SWTResourceManager.getColor(255, 255, 255));
			}
		});
		lblEmailRemove.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblEmailRemove.setBounds(402, 31, 24, 24);
		lblEmailRemove.setImage(new Image(shell.getDisplay(), PersonDialog.class.getResourceAsStream("/images/remove24.png")));
		lblEmailRemove.setData("id", 0);
		
		btnAddEmail = new Button(frameEmail, SWT.NONE);
		btnAddEmail.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				addEmailField();
			}
		});
		btnAddEmail.setBounds(179, 63, 75, 25);
		btnAddEmail.setText("Add Field");
		
		frameAddress = new Composite(framePersonInfo, SWT.NONE);
		frameAddress.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		frameAddress.setBounds(10, 519, 431, 117);
		
		CLabel lblAddress = new CLabel(frameAddress, SWT.SHADOW_OUT);
		lblAddress.setFont(SWTResourceManager.getFont("Georgia", 10, SWT.BOLD));
		lblAddress.setBounds(0, 0, 431, 25);
		lblAddress.setImage(new Image(shell.getDisplay(), PersonDialog.class.getResourceAsStream("/images/arrowdownleft21.png")));
		lblAddress.setText("Address");
		lblAddress.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				if(showAddress==1)
					showAddress=0;
				else
					showAddress=1;
				computeFrames(4);
			}
		});
		
		cmbAddressTitle = new Combo(frameAddress, SWT.NONE);
		cmbAddressTitle.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				cmbAddressTitle.setText("");
			}
			@Override
			public void keyReleased(KeyEvent e) {
				cmbAddressTitle.setText("");
			}
		});
		cmbAddressTitle.setBounds(0, 31, 125, 23);
		cmbAddressTitle.setItems(addressTitles);
		cmbAddressTitle.setData("id", 0);
		
		txtAddressValue = new Text(frameAddress, SWT.BORDER | SWT.MULTI);
		txtAddressValue.setBounds(131, 31, 265, 48);
		txtAddressValue.setData("id", 0);
		
		btnIsMailing = new Button(frameAddress, SWT.CHECK);
		btnIsMailing.setBounds(53, 60, 72, 16);
		btnIsMailing.setBackground(SWTResourceManager.getColor(255, 255, 255));
		btnIsMailing.setText("Is Mailing");
		btnIsMailing.setData("id", 0);
		
		lblAddressRemove = new Label(frameAddress, SWT.NONE);
		lblAddressRemove.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {				
				if(((Label)e.widget).getData("id").toString().equals("0"))
					return;
			}
		});
		lblAddressRemove.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				lblAddressRemove.setBackground(SWTResourceManager.getColor(235, 243, 247));
			}
			@Override
			public void mouseExit(MouseEvent e) {
				lblAddressRemove.setBackground(SWTResourceManager.getColor(255, 255, 255));
			}
		});
		lblAddressRemove.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblAddressRemove.setBounds(402, 31, 24, 24);
		lblAddressRemove.setImage(new Image(shell.getDisplay(), PersonDialog.class.getResourceAsStream("/images/remove24.png")));
		lblAddressRemove.setData("id",0);
		
		btnAddAddress = new Button(frameAddress, SWT.NONE);
		btnAddAddress.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				addAddressField();
			}
		});
		btnAddAddress.setBounds(177, 85, 75, 25);
		btnAddAddress.setText("Add Field");
		
		frameSocialNetwork = new Composite(framePersonInfo, SWT.READ_ONLY);
		frameSocialNetwork.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		frameSocialNetwork.setBounds(10, 647, 431, 95);
		
		CLabel lblSocialNetwork = new CLabel(frameSocialNetwork, SWT.SHADOW_OUT);
		lblSocialNetwork.setFont(SWTResourceManager.getFont("Georgia", 10, SWT.BOLD));
		lblSocialNetwork.setBounds(0, 0, 431, 25);
		lblSocialNetwork.setImage(new Image(shell.getDisplay(), PersonDialog.class.getResourceAsStream("/images/arrowdownleft21.png")));
		lblSocialNetwork.setText("Social Network");
		lblSocialNetwork.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				if(showSocial==1)
					showSocial=0;
				else
					showSocial=1;
				computeFrames(5);
			}
		});
		
		cmbSocialNetwork = new Combo(frameSocialNetwork, SWT.NONE);
		cmbSocialNetwork.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				cmbSocialNetwork.setText("");
			}
			@Override
			public void keyReleased(KeyEvent e) {
				cmbSocialNetwork.setText("");
			}
		});
		cmbSocialNetwork.setBounds(0, 31, 125, 23);
		cmbSocialNetwork.setItems(socialTitles);
		cmbSocialNetwork.setData("id",0);
		
		txtSocialNetwork = new Text(frameSocialNetwork, SWT.BORDER);
		txtSocialNetwork.setBounds(131, 31, 265, 24);
		txtSocialNetwork.setData("id",0);
		
		lblSocialRemove = new Label(frameSocialNetwork, SWT.NONE);
		lblSocialRemove.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {				
				if(((Label)e.widget).getData("id").toString().equals("0"))
					return;
			}
		});
		lblSocialRemove.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				lblSocialRemove.setBackground(SWTResourceManager.getColor(235, 243, 247));
			}
			@Override
			public void mouseExit(MouseEvent e) {
				lblSocialRemove.setBackground(SWTResourceManager.getColor(255, 255, 255));
			}
		});
		lblSocialRemove.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblSocialRemove.setBounds(402, 31, 25, 25);
		lblSocialRemove.setImage(new Image(shell.getDisplay(), PersonDialog.class.getResourceAsStream("/images/remove24.png")));
		lblSocialRemove.setData("id",0);
		
		btnAddSocial= new Button(frameSocialNetwork, SWT.NONE);
		btnAddSocial.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				addSocialField();
			}
		});
		btnAddSocial.setLocation(177, 63);
		btnAddSocial.setSize(75, 25);
		btnAddSocial.setText("Add Social");
				
		scrolledPersonInfo.setContent(framePersonInfo);
		scrolledPersonInfo.setMinSize(framePersonInfo.computeSize(SWT.DEFAULT, SWT.DEFAULT));
	}

	
	private void computeFrames(int index){
		int y = 201;
		
		if(showName == 0){
			frameName.setBounds(10, y, 431, 25);
		}else{
			frameName.setBounds(10, y, 431, calculateHeight(frameName, 1));
		}
		frameName.redraw();
		y += frameName.getBounds().height + 11;
		
		if(showPhone == 0){
			framePhone.setBounds(10, y, 431, 25);
		}else{
			framePhone.setBounds(10, y, 431, calculateHeight(framePhone, 2));
		}
		framePhone.redraw();
		y += framePhone.getBounds().height + 11;
		
		if(showEmail == 0){
			frameEmail.setBounds(10, y, 431, 25);
		}else{
			frameEmail.setBounds(10, y, 431, calculateHeight(frameEmail, 3));
		}
		frameEmail.redraw();
		y += frameEmail.getBounds().height + 11;
		
		if(showAddress == 0){
			frameAddress.setBounds(10, y, 431, 25);
		}else{
			frameAddress.setBounds(10, y, 431, calculateHeight(frameAddress, 4));
		}
		frameAddress.redraw();
		y += frameAddress.getBounds().height + 11;
		
		if(showSocial == 0){
			frameSocialNetwork.setBounds(10, y, 431, 25);
		}else{
			frameSocialNetwork.setBounds(10, y, 431, calculateHeight(frameSocialNetwork, 5));
		}
		frameSocialNetwork.redraw();
		y += frameSocialNetwork.getBounds().height + 11;
		
		scrolledPersonInfo.setContent(framePersonInfo);
		scrolledPersonInfo.setMinSize(framePersonInfo.computeSize(SWT.DEFAULT, SWT.DEFAULT));
	}
	
	private int calculateHeight(Composite frame, int id){
		int height = 25;
		int lines = 0;
		Control[] items = frame.getChildren();
		for(int i=0; i<items.length; i++){
			if(items[i] instanceof Combo)
				lines++;
		}
		
		if(id == 4)
			height += lines*53;
		else
			height += lines*30;
		height += 33;
		return height;
	}
	
	private void removeField(Composite frame, Object index){
		int y = 31;
		Control[] items = frame.getChildren();
		Button button = null;
		for(int i=0; i<items.length; i++){
			Widget item = items[i];
			if(item instanceof Button){
				button = (Button)item;
				continue;
			}
			//Remove widget
			if(item.getData("id") != null && item.getData("id") .equals(index)){
				item.dispose();
				continue;
			}
			//Reset location
			if(item.getData("id") != null){
				if(item instanceof Combo){
					((Combo) item).setLocation(0, y);
				}else if(item instanceof Text){
					((Text) item).setLocation(131, y);
				}else if(item instanceof Label){
					((Label) item).setLocation(402, y);
					 y += 30;
				}
			}
		}
		button.setLocation(177, y+3); 
		computeFrames(0);
	}
	
	private void addNameField(){
		int y = 31;
		int lines = 0;
		Control[] items = frameName.getChildren();
		for(int i=0; i<items.length; i++){
			if(items[i] instanceof Combo)
				lines++;
		}
		
		if(lines >= nameTitles.length)
			return;
		
		y += lines*30;
		
		cmbNameTitle = new Combo(frameName, SWT.NONE);
		cmbNameTitle.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				cmbNameTitle.setText("");
			}
			@Override
			public void keyReleased(KeyEvent e) {
				cmbNameTitle.setText("");
			}
		});
		cmbNameTitle.setBounds(0, y, 125, 23);
		cmbNameTitle.setItems(nameTitles);
		cmbNameTitle.setData("id", lines);
		
		txtNameValue = new Text(frameName, SWT.BORDER);
		txtNameValue.setBounds(131, y, 265, 24);
		txtNameValue.setData("id", lines);
		
		LblNameRemove = new Label(frameName, SWT.NONE);
		LblNameRemove.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				
				if(((Label)e.widget).getData("id") == new Integer(0))
					return;
				
				removeField(frameName, ((Label)e.widget).getData("id"));
			}
		});
		LblNameRemove.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				LblNameRemove.setBackground(SWTResourceManager.getColor(235, 243, 247));
			}
			@Override
			public void mouseExit(MouseEvent e) {
				LblNameRemove.setBackground(SWTResourceManager.getColor(255, 255, 255));
			}
		});
		LblNameRemove.setBounds(402, y, 24, 24);
		LblNameRemove.setBackground(SWTResourceManager.getColor(255, 255, 255));
		LblNameRemove.setImage(new Image(shell.getDisplay(), PersonDialog.class.getResourceAsStream("/images/remove24.png")));
		LblNameRemove.setData("id", lines);
		
		btnAddName.setLocation(177, y+33);
		
		computeFrames(0);
	}
	
	private void addPhoneField(){
		int y = 31;
		int lines = 0;
		Control[] items = framePhone.getChildren();
		for(int i=0; i<items.length; i++){
			if(items[i] instanceof Combo)
				lines++;
		}
		
		if(lines >= phoneTitles.length)
			return;
		
		y += lines*30;
		
		cmbPhoneTitle = new Combo(framePhone, SWT.NONE);
		cmbPhoneTitle.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				cmbPhoneTitle.setText("");
			}
			@Override
			public void keyReleased(KeyEvent e) {
				cmbPhoneTitle.setText("");
			}
		});
		cmbPhoneTitle.setBounds(0, y, 125, 23);
		cmbPhoneTitle.setItems(phoneTitles);
		cmbPhoneTitle.setData("id", lines);
		
		txtPhoneValue = new Text(framePhone, SWT.BORDER);
		txtPhoneValue.setBounds(131, y, 265, 24);
		txtPhoneValue.setData("id", lines);
		
		lblPhoneRemove = new Label(framePhone, SWT.NONE);
		lblPhoneRemove.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {				
				if(((Label)e.widget).getData("id") == new Integer(0))
					return;
				
				removeField(framePhone, ((Label)e.widget).getData("id"));
			}
		});
		lblPhoneRemove.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				lblPhoneRemove.setBackground(SWTResourceManager.getColor(235, 243, 247));
			}
			@Override
			public void mouseExit(MouseEvent e) {
				lblPhoneRemove.setBackground(SWTResourceManager.getColor(255, 255, 255));
			}
		});
		lblPhoneRemove.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblPhoneRemove.setBounds(402, y, 24, 24);
		lblPhoneRemove.setImage(new Image(shell.getDisplay(), PersonDialog.class.getResourceAsStream("/images/remove24.png")));
		lblPhoneRemove.setData("id", lines);
		
		btnAddPhone.setLocation(177, y+33);
		
		computeFrames(0);
	}
	
	private void addEmailField(){
		int y = 31;
		int lines = 0;
		Control[] items = frameEmail.getChildren();
		for(int i=0; i<items.length; i++){
			if(items[i] instanceof Combo)
				lines++;
		}
		
		if(lines >= emailTitles.length)
			return;
		
		y += lines*30;
		
		cmbEmailTitle = new Combo(frameEmail, SWT.NONE);
		cmbEmailTitle.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				cmbEmailTitle.setText("");
			}
			@Override
			public void keyReleased(KeyEvent e) {
				cmbEmailTitle.setText("");
			}
		});
		cmbEmailTitle.setBounds(0, y, 125, 23);
		cmbEmailTitle.setItems(phoneTitles);
		cmbEmailTitle.setData("id", lines);
		
		txtEmailValue = new Text(frameEmail, SWT.BORDER);
		txtEmailValue.setBounds(131, y, 265, 24);
		txtEmailValue.setData("id", lines);
		
		lblEmailRemove = new Label(frameEmail, SWT.NONE);
		lblEmailRemove.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {				
				if(((Label)e.widget).getData("id") == new Integer(0))
					return;
				
				removeField(frameEmail, ((Label)e.widget).getData("id"));
			}
		});
		lblEmailRemove.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				lblEmailRemove.setBackground(SWTResourceManager.getColor(235, 243, 247));
			}
			@Override
			public void mouseExit(MouseEvent e) {
				lblEmailRemove.setBackground(SWTResourceManager.getColor(255, 255, 255));
			}
		});
		lblEmailRemove.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblEmailRemove.setBounds(402, y, 24, 24);
		lblEmailRemove.setImage(new Image(shell.getDisplay(), PersonDialog.class.getResourceAsStream("/images/remove24.png")));
		lblEmailRemove.setData("id", lines);
		
		btnAddEmail.setLocation(177, y+33);
		
		computeFrames(0);
	}
	
	private void addAddressField(){
		int y = 31;
		int lines = 0;
		Control[] items = frameAddress.getChildren();
		for(int i=0; i<items.length; i++){
			if(items[i] instanceof Combo)
				lines++;
		}
		
		if(lines >= addressTitles.length)
			return;
		
		y += lines*53;
		
		cmbAddressTitle = new Combo(frameAddress, SWT.NONE);
		cmbAddressTitle.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				cmbAddressTitle.setText("");
			}
			@Override
			public void keyReleased(KeyEvent e) {
				cmbAddressTitle.setText("");
			}
		});
		cmbAddressTitle.setBounds(0, y, 125, 23);
		cmbAddressTitle.setItems(addressTitles);
		cmbAddressTitle.setData("id", lines);
		
		btnIsMailing = new Button(frameAddress, SWT.CHECK);
		btnIsMailing.setBounds(53, y+30, 72, 16);
		btnIsMailing.setBackground(SWTResourceManager.getColor(255, 255, 255));
		btnIsMailing.setText("Is Mailing");
		btnIsMailing.setData("id", lines);
		
		txtAddressValue = new Text(frameAddress, SWT.BORDER);
		txtAddressValue.setBounds(131, y, 265, 48);
		txtAddressValue.setData("id", lines);
		
		lblAddressRemove = new Label(frameAddress, SWT.NONE);
		lblAddressRemove.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {				
				if(((Label)e.widget).getData("id") == new Integer(0))
					return;
				
				removeField(frameAddress, ((Label)e.widget).getData("id"));
			}
		});
		lblAddressRemove.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				lblAddressRemove.setBackground(SWTResourceManager.getColor(235, 243, 247));
			}
			@Override
			public void mouseExit(MouseEvent e) {
				lblAddressRemove.setBackground(SWTResourceManager.getColor(255, 255, 255));
			}
		});
		lblAddressRemove.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblAddressRemove.setBounds(402, y, 24, 24);
		lblAddressRemove.setImage(new Image(shell.getDisplay(), PersonDialog.class.getResourceAsStream("/images/remove24.png")));
		lblAddressRemove.setData("id",lines);
		
		btnAddAddress.setLocation(177, y+56);
		
		computeFrames(0);
	}
	
	private void addSocialField(){
		int y = 31;
		int lines = 0;
		Control[] items = frameSocialNetwork.getChildren();
		for(int i=0; i<items.length; i++){
			if(items[i] instanceof Combo)
				lines++;
		}
		
		if(lines >= socialTitles.length)
			return;
		
		y += lines*30;
		
		cmbSocialNetwork = new Combo(frameSocialNetwork, SWT.NONE);
		cmbSocialNetwork.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				cmbSocialNetwork.setText("");
			}
			@Override
			public void keyReleased(KeyEvent e) {
				cmbSocialNetwork.setText("");
			}
		});
		cmbSocialNetwork.setBounds(0, y, 125, 23);
		cmbSocialNetwork.setItems(phoneTitles);
		cmbSocialNetwork.setData("id", lines);
		
		txtSocialNetwork = new Text(frameSocialNetwork, SWT.BORDER);
		txtSocialNetwork.setBounds(131, y, 265, 24);
		txtSocialNetwork.setData("id", lines);
		
		lblSocialRemove = new Label(frameSocialNetwork, SWT.NONE);
		lblSocialRemove.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {				
				if(((Label)e.widget).getData("id") == new Integer(0))
					return;
				
				removeField(frameSocialNetwork, ((Label)e.widget).getData("id"));
			}
		});
		lblSocialRemove.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				lblSocialRemove.setBackground(SWTResourceManager.getColor(235, 243, 247));
			}
			@Override
			public void mouseExit(MouseEvent e) {
				lblSocialRemove.setBackground(SWTResourceManager.getColor(255, 255, 255));
			}
		});
		lblSocialRemove.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblSocialRemove.setBounds(402, y, 25, 25);
		lblSocialRemove.setImage(new Image(shell.getDisplay(), PersonDialog.class.getResourceAsStream("/images/remove24.png")));
		lblSocialRemove.setData("id",lines);
		
		btnAddSocial.setLocation(177, y+33);
		
		computeFrames(0);
	}
}
