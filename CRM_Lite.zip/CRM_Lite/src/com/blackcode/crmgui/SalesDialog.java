package com.blackcode.crmgui;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;

import org.eclipse.swt.widgets.Dialog;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.SWT;
import org.eclipse.wb.swt.SWTResourceManager;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.widgets.DateTime;
import org.eclipse.swt.custom.CCombo;
import org.eclipse.swt.custom.StyledText;
import org.eclipse.swt.custom.CLabel;
import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.events.MouseTrackAdapter;
import org.eclipse.swt.events.MouseAdapter;
import org.eclipse.swt.graphics.Image;

import com.blackcode.model.Sales;

public class SalesDialog extends Dialog {

	protected Object result;
	protected Shell shell;
	private Text txtRefNo;
	private Text txtItem;
	private Text txtType;
	private Text txtPrice;
	private Text txtCharge1;
	private Text txtCharge2;
	private Text txtAmount;
	private Text txtSaleman;
	private Text txtCustomer;
	private Text txtStatus;
	private DateTime dateTimeSales,dateTimeStatus;
	private CCombo cmbUOM;
	private StyledText txtRemark;
	private Text txtVolume;

	private String contactId;
	private Sales sale;
	
	/**
	 * Create the dialog.
	 * @param parent
	 * @param style
	 */
	public SalesDialog(Shell parent, int style) {
		super(parent, style);
		setText("Sales Detail");
	}
	
	public SalesDialog(Shell parent, int style, String contactId) {
		super(parent, style);
		setText("Sales Detail");
		this.contactId = contactId;
	}

	/**
	 * Open the dialog.
	 * @return the result
	 */
	public Object open() {
		createContents();
		shell.open();
		shell.layout();
		Display display = getParent().getDisplay();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
		return result;
	}

	/**
	 * Create contents of the dialog.
	 */
	private void createContents() {
		shell = new Shell(getParent(), getStyle());
		shell.setSize(374, 368);
		shell.setText(getText());
		shell.setLocation((getParent().getBounds().width/2)-(shell.getBounds().width/2), 30);
		
		Composite composite = new Composite(shell, SWT.NONE);
		composite.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		composite.setBounds(0, 0, 371, 325);
		
		Composite frameTitle = new Composite(composite, SWT.NONE);
		frameTitle.setBackground(SWTResourceManager.getColor(50, 50, 50));
		frameTitle.setBounds(0, 0, shell.getBounds().width, 26);
		
		Label lblTitle = new Label(frameTitle, SWT.NONE);
		lblTitle.setForeground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblTitle.setFont(SWTResourceManager.getFont("Georgia", 8, SWT.BOLD));
		lblTitle.setBounds(5, 6, 133, 15);
		lblTitle.setBackground(SWTResourceManager.getColor(50, 50, 50));
		lblTitle.setText("Message");
		
		final Label lblCloseAction = new Label(frameTitle, SWT.CENTER);
		lblCloseAction.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				shell.close();
			}
		});
		lblCloseAction.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				lblCloseAction.setBackground(SWTResourceManager.getColor(100, 100, 100));
			}
			@Override
			public void mouseExit(MouseEvent e) {
				lblCloseAction.setBackground(SWTResourceManager.getColor(50, 50, 50));
			}
		});
		lblCloseAction.setBounds(344, 3, 20, 20);
		lblCloseAction.setBackground(SWTResourceManager.getColor(50, 50, 50));
		lblCloseAction.setImage(new Image(shell.getDisplay(), this.getClass().getResourceAsStream("/images/close.png")));
		lblCloseAction.setToolTipText("Close Window");
		
		Label lblRefNo = new Label(composite, SWT.RIGHT);
		lblRefNo.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblRefNo.setBounds(10, 35, 55, 15);
		lblRefNo.setText("Ref No. :");
		
		txtRefNo = new Text(composite, SWT.BORDER);
		txtRefNo.setBounds(71, 32, 113, 21);
		
		Label lblSalesDate = new Label(composite, SWT.RIGHT);
		lblSalesDate.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblSalesDate.setBounds(208, 35, 67, 15);
		lblSalesDate.setText("Sales Date : ");
		
		dateTimeSales = new DateTime(composite, SWT.BORDER | SWT.DROP_DOWN);
		dateTimeSales.setBounds(281, 32, 80, 22);
		
		Label lblItem = new Label(composite, SWT.RIGHT);
		lblItem.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblItem.setBounds(10, 62, 55, 15);
		lblItem.setText("Item :");
		
		txtItem = new Text(composite, SWT.BORDER);
		txtItem.setBounds(71, 59, 291, 21);
		
		Label lblUom = new Label(composite, SWT.NONE);
		lblUom.setFont(SWTResourceManager.getFont("Segoe UI", 8, SWT.ITALIC));
		lblUom.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblUom.setBounds(217, 117, 39, 15);
		lblUom.setText("UOM");
		
		txtType = new Text(composite, SWT.BORDER);
		txtType.setBounds(71, 86, 113, 21);
		
		Label lblVolume = new Label(composite, SWT.RIGHT);
		lblVolume.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblVolume.setBounds(10, 117, 55, 15);
		lblVolume.setText("Volume :");
		
		txtVolume = new Text(composite, SWT.BORDER);
		txtVolume.setBounds(71, 113, 76, 21);
		
		cmbUOM = new CCombo(composite, SWT.BORDER);
		cmbUOM.setBounds(153, 113, 55, 21);
		
		Label lblPrice = new Label(composite, SWT.RIGHT);
		lblPrice.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblPrice.setBounds(12, 143, 55, 15);
		lblPrice.setText("Price : ");
		
		txtPrice = new Text(composite, SWT.BORDER | SWT.RIGHT);
		txtPrice.addListener(SWT.Verify, new Listener() {
			public void handleEvent(Event e) {				
			    verifyNumberInput(e);
			}});
		txtPrice.setBounds(71, 140, 76, 21);
		
		Label lblAmount = new Label(composite, SWT.RIGHT);
		lblAmount.setFont(SWTResourceManager.getFont("Segoe UI", 9, SWT.BOLD));
		lblAmount.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblAmount.setBounds(220, 143, 55, 15);
		lblAmount.setText("Amount :");
		
		txtAmount = new Text(composite, SWT.BORDER | SWT.RIGHT);
		txtAmount.setFont(SWTResourceManager.getFont("Segoe UI", 9, SWT.BOLD));
		txtAmount.addListener(SWT.Verify, new Listener() {
			public void handleEvent(Event e) {				
			    verifyNumberInput(e);
			}});
		txtAmount.setBounds(285, 140, 76, 21);
		
		Label lblCharge = new Label(composite, SWT.RIGHT);
		lblCharge.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblCharge.setBounds(10, 170, 55, 15);
		lblCharge.setText("Charge :");
		
		txtCharge1 = new Text(composite, SWT.BORDER | SWT.RIGHT);
		txtCharge1.addListener(SWT.Verify, new Listener() {
			public void handleEvent(Event e) {				
			    verifyNumberInput(e);
			}});
		txtCharge1.setBounds(71, 167, 76, 21);
		
		txtCharge2 = new Text(composite, SWT.BORDER | SWT.RIGHT);
		txtCharge2.addListener(SWT.Verify, new Listener() {
			public void handleEvent(Event e) {				
			    verifyNumberInput(e);
			}});
		txtCharge2.setBounds(153, 167, 76, 21);
				
		Label lblStatus = new Label(composite, SWT.RIGHT);
		lblStatus.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblStatus.setBounds(10, 197, 55, 15);
		lblStatus.setText("Status :");
		
		txtStatus = new Text(composite, SWT.BORDER);
		txtStatus.setBounds(71, 194, 137, 21);
		
		dateTimeStatus = new DateTime(composite, SWT.BORDER | SWT.DROP_DOWN);
		dateTimeStatus.setBounds(218, 194, 80, 21);
		
		Label lblSalesman = new Label(composite, SWT.RIGHT);
		lblSalesman.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblSalesman.setBounds(3, 221, 65, 15);
		lblSalesman.setText("Salesman : ");
		
		txtSaleman = new Text(composite, SWT.BORDER);
		txtSaleman.setBounds(71, 221, 196, 21);
				
		Label lblType = new Label(composite, SWT.RIGHT);
		lblType.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblType.setBounds(10, 89, 55, 15);
		lblType.setText("Type :");
		
		Label lblCustomer = new Label(composite, SWT.RIGHT);
		lblCustomer.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblCustomer.setBounds(0, 248, 65, 15);
		lblCustomer.setText("Customer :");
		
		txtCustomer = new Text(composite, SWT.BORDER);
		txtCustomer.setBounds(71, 248, 196, 21);
		txtCustomer.setText(contactId==null?"":contactId);
		
		Label lblRemark = new Label(composite, SWT.RIGHT);
		lblRemark.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblRemark.setBounds(10, 275, 55, 15);
		lblRemark.setText("Remark :");
		
		txtRemark = new StyledText(composite, SWT.BORDER);
		txtRemark.setBounds(71, 275, 290, 42);
			
		
		final CLabel lblSave = new CLabel(shell, SWT.CENTER);
		lblSave.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				if(getValues())
					shell.close();
			}
		});
		lblSave.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				lblSave.setBackground(SWTResourceManager.getColor(86, 86, 86));
			}
			@Override
			public void mouseExit(MouseEvent e) {
				lblSave.setBackground(SWTResourceManager.getColor(45, 45, 45));
			}
		});
		lblSave.setBounds(103, 331, 70, 31);
		lblSave.setText("Save");
		lblSave.setBackground(SWTResourceManager.getColor(45, 45, 45));
		lblSave.setForeground(SWTResourceManager.getColor(245, 245, 245));
		lblSave.setFont(SWTResourceManager.getFont("Georgia", 9, SWT.BOLD));
		
		final CLabel lblCancel = new CLabel(shell, SWT.CENTER);
		lblCancel.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				sale = null;
				shell.close();
			}
		});
		lblCancel.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				lblCancel.setBackground(SWTResourceManager.getColor(86, 86, 86));
			}
			@Override
			public void mouseExit(MouseEvent e) {
				lblCancel.setBackground(SWTResourceManager.getColor(45, 45, 45));
			}
		});
		lblCancel.setBounds(188, 331, 70, 31);
		lblCancel.setText("Cancel");
		lblCancel.setBackground(SWTResourceManager.getColor(45, 45, 45));
		lblCancel.setForeground(SWTResourceManager.getColor(245, 245, 245));
		lblCancel.setFont(SWTResourceManager.getFont("Georgia", 9, SWT.BOLD));

	}
	
	private boolean getValues(){
		if(sale == null)
			sale = new Sales();
		
		try{
			SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
			sale.setRefNo(captureText(txtRefNo.getText()));
			sale.setDate(sdf.parse(dateTimeSales.getDay()+"/"+(dateTimeSales.getMonth()+1)+"/"+dateTimeSales.getYear()));
			sale.setItem(txtItem.getText());
			sale.setUom(cmbUOM.getText());
			if(txtVolume.getText().length() > 0)
				sale.setVolume(new BigDecimal(txtVolume.getText()));
			if(txtPrice.getText().length() > 0)
				sale.setPrice(new BigDecimal(txtPrice.getText()));
			if(txtCharge1.getText().length() > 0)
				sale.setCharge1(new BigDecimal(txtCharge1.getText()));
			if(txtCharge2.getText().length() > 0)
				sale.setCharge2(new BigDecimal(txtCharge2.getText()));
			if(txtAmount.getText().length() > 0)
				sale.setAmount(new BigDecimal(txtAmount.getText()));
			sale.setStatus(captureText(txtStatus.getText()));
			if(txtStatus.getText().length() > 0)
				sale.setStatusDate(sdf.parse(dateTimeStatus.getDay()+"/"+(dateTimeStatus.getMonth()+1)+"/"+dateTimeStatus.getYear()));
			sale.setSaleman(txtSaleman.getText());
			sale.setCustomer(txtCustomer.getText());
			sale.setRemark(txtRemark.getText());
			
			return true;
		}catch(Exception e){
			MessageDialog dlg = new MessageDialog(shell, SWT.NONE, "Error 401 : System Problems (FD260)");
			dlg.open();
			return false;
		}
	}
	
	private String captureText(String text){
		if(text.length() == 0)
			return null;
		else
			return text;
	}
	
	private void verifyNumberInput(Event e){
		String string = e.text;
		char[] chars = new char[string.length()];
	    string.getChars(0, chars.length, chars, 0);
	    for (int i = 0; i < chars.length; i++) {
	    	if (!('0' <= chars[i] && chars[i] <= '9')) {
	           	if(chars[i] != '.'){
	           		e.doit = false;
			        return;
	           	}
	        }
	   }
	}
	
	public Sales getSale(){
		return this.sale;
	}
}
