package com.blackcode.crmgui;

import java.awt.Dimension;
import java.awt.Toolkit;
import java.util.List;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.events.MouseListener;
import org.eclipse.swt.events.MouseMoveListener;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.wb.swt.SWTResourceManager;

import com.blackcode.core.SQLiteConnector;
import com.blackcode.model.Account;

public class ApplicationLiteMain {
	Composite titlebar;
    Composite toolbar;
    Composite person, followup, mail, history, group, call;
    
	protected Shell shell;
	static Boolean blnMouseDown=false;
    static int xPos=0;
    static int yPos=0;
    Account account;
    
	/**
	 * Launch the application.
	 * @param args
	 */
	public static void main(String[] args) {
		try {
			ApplicationLiteMain window = new ApplicationLiteMain();
			window.open();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Open the window.
	 */
	public void open() {
		Display display = Display.getDefault();		
		Dimension dimension = Toolkit.getDefaultToolkit().getScreenSize();
		
		shell = new Shell( Display.getDefault(), SWT.RESIZE | SWT.NO_TRIM); 
		shell.setBounds(0, 0, dimension.width, dimension.height-40);
		shell.setBackground(SWTResourceManager.getColor(255,255,255));
		shell.setText("CRM Application");
		
		List<Account> col = new SQLiteConnector().readAccount(null, null);
		if(col.size()==0){
			AccountDialog dlg = new AccountDialog(shell, SWT.NONE);
			dlg.open();
			account = dlg.getAccount();
		}else{
			account = col.get(0);
		}
		
		if(account==null)
			return;
		
		createContents();		
		shell.open();
		shell.layout();
		shell.addMouseListener(new MouseListener() {

            @Override
            public void mouseUp(MouseEvent arg0) {
                blnMouseDown=false;
            }

            @Override
            public void mouseDown(MouseEvent e) {
                blnMouseDown=true;
                xPos=e.x;
                yPos=e.y;
            }

            @Override
            public void mouseDoubleClick(MouseEvent arg0) {
                // TODO Auto-generated method stub

            }
        });
		shell.addMouseMoveListener(new MouseMoveListener() {

            @Override
            public void mouseMove(MouseEvent e) {
                if(e.y == 0)
                	titlebar.setVisible(true);
                else
                	titlebar.setVisible(false);
                
                if(e.x == 0)
                	toolbar.setVisible(true);
                
                if(blnMouseDown){
                    shell.setLocation(shell.getLocation().x+(e.x-xPos),shell.getLocation().y+(e.y-yPos));
                }
            }
        });

		
		
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
	}

	/**
	 * Create contents of the window.
	 */
	protected void createContents() {
		titlebar = new TitleBar(shell, SWT.NONE);
		titlebar.setBounds(0, 0, shell.getBounds().width, 30);
		titlebar.setVisible(false);
		
		toolbar = new ToolBar(shell, SWT.NONE, this);
		toolbar.setBounds(0, 0, 250, shell.getBounds().height);
		
		person = new PersonFrame(shell, SWT.NONE, this, account);
		person.setBounds(30, 32, shell.getBounds().width-30, shell.getBounds().height-32);
		person.setVisible(false);
		
		followup = new EventCalendarFrame(shell, SWT.NONE);
		followup.setBounds(30, 32, shell.getBounds().width-30, shell.getBounds().height-32);
		followup.setVisible(false);
		
		mail = new MailFrame(shell, SWT.NONE, account);
		mail.setBounds(30, 32, shell.getBounds().width-30, shell.getBounds().height-32);
		mail.setVisible(false);
		
		history = new HistoryFrame(shell, SWT.NONE);
		history.setBounds(30, 32, shell.getBounds().width-30, shell.getBounds().height-32);
		history.setVisible(false);
		
		call = new CallFrame(shell, SWT.NONE);
		call.setBounds(30, 32, shell.getBounds().width-30, shell.getBounds().height-32);
		call.setVisible(false);
		
		group = new GroupFrame(shell, SWT.NONE, account);
		group.setBounds(30, 32, shell.getBounds().width-30, shell.getBounds().height-32);
		group.setVisible(false);
		
	}
	
	public void hideTitleBar(){
		titlebar.setVisible(false);
	}
	
	public void selectTool(int tool){
		switch(tool){
		case 0 : 
			call.setVisible(true);
			mail.setVisible(false);
			history.setVisible(false);
			person.setVisible(false);
			followup.setVisible(false);			
			group.setVisible(false);
			break;
		case 1 : 
			call.setVisible(false);
			mail.setVisible(true);
			history.setVisible(false);
			person.setVisible(false);
			followup.setVisible(false);			
			group.setVisible(false);
			break;
		case 2 : 
			call.setVisible(false);
			mail.setVisible(false);
			person.setVisible(false);
			followup.setVisible(false);			
			group.setVisible(false);
			
			if(history != null)
				history.dispose();
			history = new HistoryFrame(shell, SWT.NONE);
			history.setBounds(30, 32, shell.getBounds().width-30, shell.getBounds().height-32);
			break;
		case 3 : 
			call.setVisible(false);
			mail.setVisible(false);
			history.setVisible(false);
			person.setVisible(true);
			followup.setVisible(false);			
			group.setVisible(false);
			break;
		case 4 : 
			call.setVisible(false);
			mail.setVisible(false);
			history.setVisible(false);
			person.setVisible(false);
			followup.setVisible(true);			
			group.setVisible(false);
			break;
		case 5 : 
			call.setVisible(false);
			mail.setVisible(false);
			history.setVisible(false);
			person.setVisible(false);
			followup.setVisible(false);			
			group.setVisible(true);
			break;
		default :
			break;
		}
	}
	
	public CallFrame getCallFrame(){
		return (CallFrame)this.call;
	}
}
