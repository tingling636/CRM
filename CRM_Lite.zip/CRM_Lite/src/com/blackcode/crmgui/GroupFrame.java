package com.blackcode.crmgui;

import java.io.File;
import java.io.FileOutputStream;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.eclipse.swt.custom.CLabel;
import org.eclipse.swt.custom.ScrolledComposite;
import org.eclipse.swt.custom.TableTree;
import org.eclipse.swt.custom.TableTreeItem;
import org.eclipse.swt.events.MouseAdapter;
import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.events.MouseTrackAdapter;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.Menu;
import org.eclipse.swt.widgets.MenuItem;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.SWT;
import org.eclipse.wb.swt.SWTResourceManager;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.custom.CCombo;
import org.eclipse.swt.widgets.DateTime;

import com.blackcode.core.SQLiteConnector;
import com.blackcode.model.Account;
import com.blackcode.model.Contact;
import com.blackcode.model.EmailCampaignRecipient;
import com.blackcode.model.FollowUpTask;
import com.blackcode.model.Sales;

public class GroupFrame extends Composite {

	private Shell shell;
	private Composite frameTopActionBar;
	private Label lblMenuAction;
	private Composite frameList;
	private ScrolledComposite scrolledComposite;
	private Composite frameMain;
	private Composite frameDetail;
	private Button btnSeparator;
	private Composite frameSide;
	private Button chkTotalAmount, chkTotalSales, chkSalesDate, chkLastDeal, chkLastActivity;
	private Button btnYear, btnMonth, btnQuarter;
	private Button btnSalesAmount, btnTotalSales;
	private CCombo cmbAmount, cmbSales;
	private DateTime dateTime1, dateTime2;
	private Text txtAccount;
	private Text txtAmount;
	private Text txtSales;
	private Text txtDealDay;
	private Text txtActivityDay;
	private Label lblDaysBfr;
	private Button chkType;
	private Text txtType;
	private Button chkStatus;
	private Text txtStatus;
	private TableTree salesTree;
	
	private int layoutMode = 0;
	private String[] logics = new String[]{">=","<="};
	private List<String> periodTitles = new ArrayList<String>();
	private SQLiteConnector dbConnector = new SQLiteConnector();
	private Account account;
	private SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
	private Menu popupMenu;
	
	
	/**
	 * Create the composite.
	 * @param parent
	 * @param style
	 */
	public GroupFrame(Composite parent, int style, Account account) {
		super(parent, style);
		shell = parent.getShell();
		this.account = account;
		setBackground(SWTResourceManager.getColor(255, 255, 255));

		frameTopActionBar = new Composite(this, SWT.NONE);
		frameTopActionBar.setBackground(SWTResourceManager.getColor(77, 99, 132));
		frameTopActionBar.setBounds(0, 0, shell.getBounds().width-60, 35);
		
		CLabel lblTitle = new CLabel(frameTopActionBar, SWT.NONE);
		lblTitle.setForeground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblTitle.setFont(SWTResourceManager.getFont("Georgia", 15, SWT.BOLD));
		lblTitle.setBounds(10, 5, 183, 25);
		lblTitle.setBackground(SWTResourceManager.getColor(77, 99, 132));
		lblTitle.setText("Group");
				
		lblMenuAction = new Label(frameTopActionBar, SWT.NONE);
		lblMenuAction.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {	
				popupMenu.setVisible(true);
			}
		});
		lblMenuAction.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				lblMenuAction.setBackground(SWTResourceManager.getColor(52, 64, 88));
				lblMenuAction.setImage(new Image(shell.getDisplay(), HistoryFrame.class.getResourceAsStream("/images/menu_selected.png")));
			}
			@Override
			public void mouseExit(MouseEvent e) {
				lblMenuAction.setBackground(SWTResourceManager.getColor(77, 99, 132));
				lblMenuAction.setImage(new Image(shell.getDisplay(), HistoryFrame.class.getResourceAsStream("/images/menu.png")));
			}
		});
		lblMenuAction.setBounds(frameTopActionBar.getBounds().width-38, 5, 33, 25);
		lblMenuAction.setBackground(SWTResourceManager.getColor(77, 99, 132));
		lblMenuAction.setToolTipText("More Functions");
		lblMenuAction.setImage(new Image(shell.getDisplay(), HistoryFrame.class.getResourceAsStream("/images/menu.png")));
		
		frameList = new Composite(this, SWT.NONE);
		frameList.setBounds(0, 36, 201, shell.getBounds().height-75);
		frameList.setBackground(SWTResourceManager.getColor(239, 245, 249));
		
		Group grpShowAs = new Group(frameList, SWT.NONE);
		grpShowAs.setFont(SWTResourceManager.getFont("Segoe UI", 8, SWT.BOLD));
		grpShowAs.setText("Show As");
		grpShowAs.setBounds(10, 10, 181, 131);
		
		Composite compositeShow1 = new Composite(grpShowAs, SWT.NONE);
		compositeShow1.setBounds(5, 38, 174, 21);
		
		btnYear = new Button(compositeShow1, SWT.RADIO);
		btnYear.setSelection(true);
		btnYear.setBounds(0, 0, 44, 16);
		btnYear.setText("Year");
		
		btnQuarter = new Button(compositeShow1, SWT.RADIO);
		btnQuarter.setBounds(50, 0, 61, 16);
		btnQuarter.setText("Quarter");
		
		btnMonth = new Button(compositeShow1, SWT.RADIO);
		btnMonth.setBounds(117, 0, 58, 16);
		btnMonth.setText("Month");
		
		Label lblType = new Label(grpShowAs, SWT.NONE);
		lblType.setBounds(5, 17, 44, 15);
		lblType.setText("Type");
		
		Label lblFigures = new Label(grpShowAs, SWT.NONE);
		lblFigures.setBounds(5, 65, 55, 15);
		lblFigures.setText("Figures");
		
		btnSalesAmount = new Button(grpShowAs, SWT.RADIO);
		btnSalesAmount.setSelection(true);
		btnSalesAmount.setBounds(15, 86, 90, 16);
		btnSalesAmount.setText("Sales Amount");
		
		btnTotalSales = new Button(grpShowAs, SWT.RADIO);
		btnTotalSales.setBounds(15, 106, 90, 16);
		btnTotalSales.setText("Total Sales");
		
		Group grpDisplay = new Group(frameList, SWT.NONE);
		grpDisplay.setFont(SWTResourceManager.getFont("Segoe UI", 8, SWT.BOLD));
		grpDisplay.setText("Display Sales");
		grpDisplay.setBounds(10, 147, 181, 270);
		
		Label lblAccount = new Label(grpDisplay, SWT.NONE);
		lblAccount.setBounds(5, 21, 50, 15);
		lblAccount.setText("Account");
		
		txtAccount = new Text(grpDisplay, SWT.BORDER);
		txtAccount.setBounds(56, 18, 120, 21);
		txtAccount.setText(account.getCode());
		
		Label lblSalesWith = new Label(grpDisplay, SWT.NONE);
		lblSalesWith.setBounds(5, 47, 55, 15);
		lblSalesWith.setText("Sales With");
		
		chkTotalAmount = new Button(grpDisplay, SWT.CHECK);
		chkTotalAmount.setBounds(8, 68, 93, 16);
		chkTotalAmount.setText("Total Amount");
		
		txtAmount = new Text(grpDisplay, SWT.BORDER);
		txtAmount.addListener(SWT.Verify, new Listener() {
			public void handleEvent(Event e) {				
			    verifyNumberInput(e);
			}});
		txtAmount.setBounds(84, 88, 76, 21);
		
		cmbAmount = new CCombo(grpDisplay, SWT.BORDER);
		cmbAmount.setBounds(30, 88, 48, 21);
		cmbAmount.setItems(logics);
		
		chkTotalSales = new Button(grpDisplay, SWT.CHECK);
		chkTotalSales.setBounds(8, 115, 93, 16);
		chkTotalSales.setText("Total Sales");
		
		cmbSales = new CCombo(grpDisplay, SWT.BORDER);
		cmbSales.setBounds(30, 131, 48, 21);
		cmbSales.setItems(logics);
		
		txtSales = new Text(grpDisplay, SWT.BORDER);
		txtSales.addListener(SWT.Verify, new Listener() {
			public void handleEvent(Event e) {				
			    verifyNumberInput(e);
			}});
		txtSales.setBounds(84, 131, 76, 21);
		
		chkSalesDate = new Button(grpDisplay, SWT.CHECK);
		chkSalesDate.setBounds(8, 160, 93, 16);
		chkSalesDate.setText("Sales Date");
		
		dateTime1 = new DateTime(grpDisplay, SWT.BORDER | SWT.DROP_DOWN);
		dateTime1.setBounds(5, 180, 80, 24);
		
		dateTime2 = new DateTime(grpDisplay, SWT.BORDER | SWT.DROP_DOWN);
		dateTime2.setBounds(96, 180, 80, 24);
		
		Label label = new Label(grpDisplay, SWT.NONE);
		label.setBounds(87, 183, 10, 15);
		label.setText("-");
		
		chkType = new Button(grpDisplay, SWT.CHECK);
		chkType.setBounds(8, 214, 48, 16);
		chkType.setText("Type");
		
		txtType = new Text(grpDisplay, SWT.BORDER);
		txtType.setBounds(64, 212, 112, 21);
		
		chkStatus = new Button(grpDisplay, SWT.CHECK);
		chkStatus.setBounds(8, 241, 55, 16);
		chkStatus.setText("Status");
		
		txtStatus = new Text(grpDisplay, SWT.BORDER);
		txtStatus.setBounds(64, 239, 112, 21);
		
		final CLabel lblShow = new CLabel(frameList, SWT.CENTER);
		lblShow.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				initializedSales();
			}
		});
		lblShow.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				lblShow.setBackground(SWTResourceManager.getColor(86, 86, 86));
			}
			@Override
			public void mouseExit(MouseEvent e) {
				lblShow.setBackground(SWTResourceManager.getColor(45, 45, 45));
			}
		});
		lblShow.setBounds(60, 423, 81, 26);
		lblShow.setText("Show");
		lblShow.setBackground(SWTResourceManager.getColor(45, 45, 45));
		lblShow.setForeground(SWTResourceManager.getColor(245, 245, 245));
		lblShow.setFont(SWTResourceManager.getFont("Georgia", 9, SWT.BOLD));
		
		Group grpInactiveContacts = new Group(frameList, SWT.NONE);
		grpInactiveContacts.setFont(SWTResourceManager.getFont("Segoe UI", 8, SWT.BOLD));
		grpInactiveContacts.setText("Display Inactive Contacts");
		grpInactiveContacts.setBounds(10, 459, 181, 91);
		
		chkLastDeal = new Button(grpInactiveContacts, SWT.RADIO);
		chkLastDeal.setSelection(true);
		chkLastDeal.setBounds(3, 29, 83, 16);
		chkLastDeal.setText("Last deal on");
		
		txtDealDay = new Text(grpInactiveContacts, SWT.BORDER);
		txtDealDay.setText("90");
		txtDealDay.addListener(SWT.Verify, new Listener() {
			public void handleEvent(Event e) {				
			    verifyNumberInput(e);
			}});
		txtDealDay.setBounds(87, 27, 24, 21);
		
		Label lblDaysBefore = new Label(grpInactiveContacts, SWT.NONE);
		lblDaysBefore.setBounds(115, 30, 64, 15);
		lblDaysBefore.setText("days before");
		
		chkLastActivity = new Button(grpInactiveContacts, SWT.RADIO);
		chkLastActivity.setBounds(3, 59, 94, 16);
		chkLastActivity.setText("Last activity on");
		
		txtActivityDay = new Text(grpInactiveContacts, SWT.BORDER);
		txtActivityDay.setText("30");
		txtActivityDay.setBounds(101, 57, 24, 21);
		
		lblDaysBfr = new Label(grpInactiveContacts, SWT.NONE);
		lblDaysBfr.setText("days bfr");
		lblDaysBfr.setBounds(129, 60, 48, 15);
		
		final CLabel lblShow1 = new CLabel(frameList, SWT.CENTER);
		lblShow1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				if(chkLastDeal.getSelection())
					initializedInactiveSales();
				else if(chkLastActivity.getSelection())
					initializedInactiveContact();
			}
		});
		lblShow1.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				lblShow1.setBackground(SWTResourceManager.getColor(86, 86, 86));
			}
			@Override
			public void mouseExit(MouseEvent e) {
				lblShow1.setBackground(SWTResourceManager.getColor(45, 45, 45));
			}
		});
		lblShow1.setBounds(60, 556, 81, 26);
		lblShow1.setText("Show");
		lblShow1.setBackground(SWTResourceManager.getColor(45, 45, 45));
		lblShow1.setForeground(SWTResourceManager.getColor(245, 245, 245));
		lblShow1.setFont(SWTResourceManager.getFont("Georgia", 9, SWT.BOLD));
				
		frameDetail = new Composite(this, SWT.NONE);
		frameDetail.setBounds(203, 36, shell.getBounds().width-265, shell.getBounds().height-75);
		frameDetail.setBackground(SWTResourceManager.getColor(255, 255, 255));
				
		scrolledComposite = new ScrolledComposite(frameDetail, SWT.H_SCROLL | SWT.V_SCROLL);
		scrolledComposite.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		scrolledComposite.setBounds(0, 0, frameDetail.getBounds().width-10, frameDetail.getBounds().height);
		scrolledComposite.setExpandHorizontal(true);
		scrolledComposite.setExpandVertical(true);
		
		frameMain = new Composite(scrolledComposite, SWT.NONE);
		frameMain.setBackground(SWTResourceManager.getColor(255, 255, 255));
	    		
		btnSeparator = new Button(frameDetail, SWT.FLAT);
		btnSeparator.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				changeFrameWidth();
			}
		});
		btnSeparator.setBounds(scrolledComposite.getBounds().width, 0, 10, shell.getBounds().height-75);
		btnSeparator.setImage(new Image(shell.getDisplay(), this.getClass().getResourceAsStream("/images/separator.png")));			
		
		frameSide = new Composite(frameDetail, SWT.NONE);
		frameSide.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		
		scrolledComposite.setContent(frameMain);
		scrolledComposite.setMinSize(frameMain.computeSize(SWT.DEFAULT, SWT.DEFAULT));

		popupMenu = new Menu(lblMenuAction);
		MenuItem exportItem = new MenuItem(popupMenu, SWT.NONE);
	    exportItem.setText("Export Data To Excel");
	    exportItem.setImage(new Image(shell.getDisplay(), this.getClass().getResourceAsStream("/images/excel.gif")));
	    exportItem.addListener(SWT.Selection, new Listener() {
	        public void handleEvent(Event e) {
	        	exportToExcel();
	          }
	        });
	    MenuItem emailItem = new MenuItem(popupMenu, SWT.NONE);
	    emailItem.setText("Send Group Email");
	    emailItem.setImage(new Image(shell.getDisplay(), this.getClass().getResourceAsStream("/images/send_email.gif")));
	    emailItem.addListener(SWT.Selection, new Listener() {
	        public void handleEvent(Event e) {
	        	sendGroupEmail();
	          }
	        });	    
	    MenuItem messageItem = new MenuItem(popupMenu, SWT.NONE);
	    messageItem.setText("Send Group Message");
	    messageItem.addListener(SWT.Selection, new Listener() {
	        public void handleEvent(Event e) {
	        	
	          }
	        });
	    MenuItem callItem = new MenuItem(popupMenu, SWT.NONE);
	    callItem.setText("Send To Call Reminder");
	    callItem.setImage(new Image(shell.getDisplay(), this.getClass().getResourceAsStream("/images/phone1.png")));
	    callItem.addListener(SWT.Selection, new Listener() {
	        public void handleEvent(Event e) {
	        	sendToCallReminder();
	          }
	        });
	    
	    lblMenuAction.setMenu(popupMenu);
	    
		initializedSales();
	}
	
	private void initializedInactiveSales(){
		String contactSql = null;
		if(txtAccount.getText().length() > 0 && !txtAccount.getText().equalsIgnoreCase("ALL")){
			contactSql = parseInStatement(txtAccount.getText());
		}
		List<Contact> contacts = dbConnector.readContact(null, contactSql!=null?"accountId IN ("+contactSql+")":null, "contactId");
		
		clearTable();
		
		if(txtDealDay.getText().length()==0)
			txtDealDay.setText("90");
		
		List<Object[]> dataCol = dbConnector.InactiveSalesData(contacts, Integer.parseInt(txtDealDay.getText()), definePeriod());
	    showSalesData(dataCol, periodTitles);
	}
	
	private void initializedInactiveContact(){
		if(txtActivityDay.getText().length()==0)
			txtActivityDay.setText("30");
		
		String contactSql = null;
		if(txtAccount.getText().length() > 0 && !txtAccount.getText().equalsIgnoreCase("ALL")){
			contactSql = parseInStatement(txtAccount.getText());
		}
		List<Contact> contacts = dbConnector.readInactiveContact(Integer.parseInt(txtActivityDay.getText()), contactSql!=null?"accountId IN ("+contactSql+")":null);
		
		clearTable();
		
		List<Object[]> dataCol = dbConnector.InactiveSalesData(contacts, Integer.parseInt(txtActivityDay.getText()), definePeriod());
	    showSalesData(dataCol, periodTitles);
	}
	
	private void initializedSales(){
		String contactSql = null;
		if(txtAccount.getText().length() > 0 && !txtAccount.getText().equalsIgnoreCase("ALL")){
			contactSql = parseInStatement(txtAccount.getText());
		}
		List<Contact> contacts = dbConnector.readContact(null, contactSql!=null?"accountId IN ("+contactSql+")":null, "contactId");
		
		String saleSql = "";
		if(chkTotalAmount.getSelection() && cmbAmount.getText().length() > 0 && txtAmount.getText().length() > 0){
			saleSql += " Amount "+cmbAmount.getText()+txtAmount.getText() + " AND";
		}		
		if(chkSalesDate.getSelection()){
			Calendar date1 = Calendar.getInstance();
			date1.set(dateTime1.getYear(), dateTime1.getMonth(), dateTime1.getDay(), 0, 0); 
			Calendar date2 = Calendar.getInstance();
			date2.set(dateTime2.getYear(), dateTime2.getMonth(), dateTime2.getDay(), 0, 0); 
			saleSql += " (DATE(date/ 1000, 'unixepoch', 'localtime')>='"+sdf.format(date1.getTime())+"' AND DATE(date/ 1000, 'unixepoch', 'localtime')<='"+sdf.format(date2.getTime())+"') AND";
		}
		if(chkType.getSelection() && txtType.getText().length() > 0){
			String type = parseInStatement(txtType.getText());
			if(type.length() > 0)
				saleSql += " Type IN ("+type+") AND";
		}
		if(chkStatus.getSelection() && txtStatus.getText().length() > 0){
			String status = parseInStatement(txtStatus.getText());
			if(status.length() > 0)
				saleSql += " Status IN ("+status+") AND";
		}
		if(saleSql.endsWith("AND"))
			saleSql = saleSql.substring(0, saleSql.length()-3);
				
		clearTable();
	    
	    List<Object[]> dataCol = dbConnector.GroupSalesData(contacts, saleSql, definePeriod());
	    showSalesData(dataCol, periodTitles);
	}
	
	private void showSalesData(List<Object[]> dataCol, List<String> periodTitles){
		//Create table column
		Object[] tableColumns = new Object[]{new Object[]{"Name", 150}, new Object[]{"Last Sales", 80}, new Object[]{"Total Amount", 80}, new Object[]{"Total Sales", 80}};
		for(int i=0; i<tableColumns.length; i++){
			TableColumn tc = new TableColumn(salesTree.getTable(), i>0?SWT.CENTER:SWT.NONE);
			tc.setText((String)((Object[])tableColumns[i])[0]);
			tc.setWidth((int)((Object[])tableColumns[i])[1]);
		}
		
		for(int i=0; i<periodTitles.size(); i++){
			TableColumn tc = new TableColumn(salesTree.getTable(), SWT.CENTER);
			tc.setText(periodTitles.get(i));
			tc.setWidth(70);
		}
		
		//Create parent node
		TableTreeItem node = new TableTreeItem(salesTree, SWT.NONE);
		node.setText(account.getCode());
		node.setData("parent");
		/*for(int i=0; i<accessAccounts.size(); i++){
			if(txtAccount.getText().length() > 0 && !txtAccount.getText().toLowerCase().contains(accessAccounts.get(i).getCode().toLowerCase()))				
				continue;
			TableTreeItem node = new TableTreeItem(salesTree, SWT.NONE);
			node.setText(accessAccounts.get(i).getCode());
			node.setData("parent");
		}*/
		
		//Show sales data
		TableTreeItem topSaleItem = null;
		for(int i=0; i<dataCol.size(); i++){
			Object[] data = dataCol.get(i);
			Contact contact = (Contact)data[0];
			BigDecimal[] amtValues = (BigDecimal[])data[4];
			int[] totalValues = (int[])data[5];
			
			//Total sales checking
			boolean show = false;
			if(chkTotalSales.getSelection() && cmbSales.getText().length() > 0 && txtSales.getText().length() > 0){
				if(cmbSales.getSelectionIndex()==0 && (int)data[3] >= Integer.parseInt(txtSales.getText()))
					show = true;
				if(cmbSales.getSelectionIndex()==1 && (int)data[3] <= Integer.parseInt(txtSales.getText()))
					show = true;
			}else
				show = true;
			if(!show)
				continue;
			
			//Display sales data group by account (find account node)
			int index = 0;
			
			for(int j=0; j<salesTree.getItemCount(); j++){
				if(salesTree.getItem(j).getText(0).equals(contact.getAccountId())){
					TableTreeItem child = new TableTreeItem(salesTree.getItem(j), SWT.NONE);
					child.setText(index++, contact.getFullName());
					child.setText(index++, data[1]==null?"-":data[1].toString());
					child.setText(index++, data[2].toString());
					child.setText(index++, data[3].toString());										
					if(btnSalesAmount.getSelection()){
						for(int k=0; k<amtValues.length; k++)
							child.setText(index++, Sales.CurrencyFormat(amtValues[k]));
					}else if(btnTotalSales.getSelection()){
						for(int k=0; k<totalValues.length; k++)
							child.setText(index++, totalValues[k]+"");
					}
					child.setData("contact", contact);
					child.setData("sales", data[6]);
					
					if(topSaleItem == null)
						topSaleItem = child;
					else {
						if(Double.parseDouble(child.getText(2)) > Double.parseDouble(topSaleItem.getText(2)))
							topSaleItem = child;
					}
					break;
				}
			}			
		}
		if(topSaleItem != null)
			topSaleItem.setBackground(SWTResourceManager.getColor(255,255,204));
	}
	
	private List<Date[]> definePeriod(){
		List<Date[]> periods = new ArrayList<Date[]>();
    	periodTitles = new ArrayList<String>();
    	int currYear = Calendar.getInstance().get(Calendar.YEAR);
		int minYear = dbConnector.MinYearOfSales();
		int years = 5;
		if(minYear != -1)
			years = currYear - minYear;
	    if(btnYear.getSelection()){	    					
			for(int z=0; z<=years; z++){
				periodTitles.add(currYear+"");
				Date from = new Date();from.setYear(currYear-1900);from.setMonth(0);from.setDate(1);
				Date to = new Date();to.setYear(currYear-1900);to.setMonth(11);to.setDate(31);
				periods.add(new Date[]{from, to});
				currYear--;
			}
	    }else if(btnQuarter.getSelection()){
			for(int z=0; z<=years; z++){
				String str = currYear+"";
				periodTitles.add("Q1 '"+str.substring(2));
				Date from = new Date();from.setYear(currYear-1900);from.setMonth(0);from.setDate(1);
				Date to = new Date();to.setYear(currYear-1900);to.setMonth(2);to.setDate(31);
				periods.add(new Date[]{from, to});
				
				periodTitles.add("Q2 '"+str.substring(2));
				from = new Date();from.setYear(currYear-1900);from.setMonth(3);from.setDate(1);
				to = new Date();to.setYear(currYear-1900);to.setMonth(5);to.setDate(30);
				periods.add(new Date[]{from, to});
				
				periodTitles.add("Q3 '"+str.substring(2));
				from = new Date();from.setYear(currYear-1900);from.setMonth(6);from.setDate(1);
				to = new Date();to.setYear(currYear-1900);to.setMonth(8);to.setDate(30);
				periods.add(new Date[]{from, to});
				
				periodTitles.add("Q4 '"+str.substring(2));
				from = new Date();from.setYear(currYear-1900);from.setMonth(9);from.setDate(1);
				to = new Date();to.setYear(currYear-1900);to.setMonth(11);to.setDate(31);
				periods.add(new Date[]{from, to});
				
				currYear--;
			}
	    }else if(btnMonth.getSelection()){
	    	String[] months = new String[]{"Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"};
	    	for(int z=0; z<=years; z++){
	    		for(int y=0; y<months.length; y++){
	    			String str = currYear+"";
					periodTitles.add(months[y]+" '"+str.substring(2));
					Date from = new Date();from.setYear(currYear-1900);from.setMonth(y);from.setDate(1);
					Date to = new Date();to.setYear(currYear-1900);to.setMonth(y);to.setDate(31);
					periods.add(new Date[]{from, to});
	    		}
	    		currYear--;
	    	}
	    }
	    
	    return periods;
	}
	
	private void clearTable(){
		if(salesTree != null)
			salesTree.dispose();
		salesTree = new TableTree(frameMain, SWT.BORDER|SWT.FULL_SELECTION|SWT.CHECK);
		salesTree.addListener(SWT.Selection, new Listener() {
			public void handleEvent(Event event) {
			      TableTreeItem item = (TableTreeItem)event.item;
					if(item.getData()!=null && item.getData().equals("parent")){
						TableTreeItem[] childs = item.getItems();
						for(int i=0; i<childs.length; i++)
							childs[i].setChecked(item.getChecked());
					}else{						
						item.getParentItem().setChecked(false);
						for(int i=0; i<item.getParentItem().getItemCount(); i++){
							if(item.getParentItem().getItem(i).getChecked()){
								item.getParentItem().setChecked(true);
								break;
							}
						}
					}
			   }
			});
		salesTree.setBounds(10, 10, frameMain.getBounds().width-50, frameMain.getBounds().height-100);
	    Table table = salesTree.getTable();
	    table.addListener(SWT.MeasureItem, new Listener() {
			public void handleEvent(Event event) {
			      event.height = 22;
			   }
			});
	    table.setHeaderVisible(true);
	    table.setLinesVisible(true);
	}
	
	private void changeFrameWidth(){
		if(layoutMode == 0){
			layoutMode = 1;
			
			scrolledComposite.setBounds(0, 0, (frameDetail.getBounds().width/3*2)-15, frameDetail.getBounds().height);
			btnSeparator.setBounds(scrolledComposite.getBounds().width, 0, 10, shell.getBounds().height-75);
			frameSide.setBounds((frameDetail.getBounds().width/3*2), 0, (frameDetail.getBounds().width/3), frameDetail.getBounds().height);
		}else{
			layoutMode = 0;
			
			scrolledComposite.setBounds(0, 0, frameDetail.getBounds().width-10, frameDetail.getBounds().height);
			btnSeparator.setBounds(scrolledComposite.getBounds().width, 0, 10, shell.getBounds().height-75);
			frameSide.setBounds(0, 0, 0, 0);
		}
		frameDetail.redraw();
	}

	private void verifyNumberInput(Event e){
		String string = e.text;
		char[] chars = new char[string.length()];
	    string.getChars(0, chars.length, chars, 0);
	    for (int i = 0; i < chars.length; i++) {
	    	if (!('0' <= chars[i] && chars[i] <= '9')) {
	    		e.doit = false;
		        return;
	        }
	   }
	}
	
	private String parseInStatement(String text){
		String[] strs = text.split(",");
		String str = "";
		for(int i=0; i<strs.length; i++)
			str += "'"+strs[i]+"',";
		if(str.endsWith(","))
			str = str.substring(0, str.length()-1);
		
		return str;
	}
	
	private List<Contact> getSelectedContacts(){
		List<Contact> selectedContacts = new ArrayList<Contact>();
		
		for(int i=0; i<salesTree.getItemCount(); i++){						
			for(int j=0; j<salesTree.getItem(i).getItemCount(); j++){
				TableTreeItem item = salesTree.getItem(i).getItem(j);
				if(item.getChecked() && item.getData("contact") != null)
					selectedContacts.add((Contact)item.getData("contact"));
			}
		}
		return selectedContacts;
	}
	
	private void exportToExcel(){
		try{
			HSSFWorkbook workbook = new HSSFWorkbook();
			HSSFSheet sheet = workbook.createSheet("Sales");
			
			Font font = workbook.createFont();
			font.setFontHeightInPoints((short)10);
			font.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
			font.setColor(IndexedColors.WHITE.getIndex());
			
			Font font2 = workbook.createFont();
			font2.setFontHeightInPoints((short)10);
			font2.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
			font2.setUnderline(HSSFFont.U_SINGLE);
			    
			CellStyle titleStyle = workbook.createCellStyle();	   
		    titleStyle.setFillForegroundColor(IndexedColors.GREY_80_PERCENT.getIndex());
		    titleStyle.setFillPattern(CellStyle.SOLID_FOREGROUND);
		    titleStyle.setAlignment(CellStyle.ALIGN_CENTER);
		    titleStyle.setVerticalAlignment(CellStyle.VERTICAL_CENTER);
		    titleStyle.setFont(font);
		    
		    CellStyle subtitleStyle = workbook.createCellStyle();
		    subtitleStyle.setVerticalAlignment(CellStyle.VERTICAL_CENTER);
		    subtitleStyle.setFont(font2);
		    
			CellStyle numberCellStyle = workbook.createCellStyle();
			numberCellStyle.setAlignment(CellStyle.ALIGN_RIGHT);
			numberCellStyle.setVerticalAlignment(CellStyle.VERTICAL_CENTER);
			
			CellStyle centerCellStyle = workbook.createCellStyle();
			centerCellStyle.setAlignment(CellStyle.ALIGN_CENTER);
			centerCellStyle.setVerticalAlignment(CellStyle.VERTICAL_CENTER);
			
			//Create Title
			int rowindex = 0;
			Row row = sheet.createRow(rowindex);
			row.setHeight((short)400);
			
			int column = 0;
			Object[] tableColumns = new Object[]{new Object[]{"Name", 150}, new Object[]{"Last Sales", 80}, new Object[]{"Total Amount", 80}, new Object[]{"Total Sales", 80}};
			for(int i=0; i<tableColumns.length; i++){
				Cell cell = row.createCell(column);    
				cell.setCellValue((String)((Object[])tableColumns[i])[0]);
				cell.setCellStyle(titleStyle);
				
				sheet.setColumnWidth(column++, ((int)((Object[])tableColumns[i])[1])*50);
			}			
			for(int i=0; i<periodTitles.size(); i++){
				Cell cell = row.createCell(column);    
				cell.setCellValue(periodTitles.get(i));
				cell.setCellStyle(titleStyle);
				
				sheet.setColumnWidth(column++, 2700);
			}
			
			for(int i=0; i<salesTree.getItemCount(); i++){
				row = sheet.createRow(++rowindex);
				row.setHeight((short)350);
				Cell cell = row.createCell(0);  
				cell.setCellValue(salesTree.getItem(i).getText());
				cell.setCellStyle(subtitleStyle);
				
				for(int j=0; j<salesTree.getItem(i).getItemCount(); j++){
					row = sheet.createRow(++rowindex);					
					TableTreeItem item = salesTree.getItem(i).getItem(j);
					for(int k=0; k<(periodTitles.size()+4); k++){
						cell = row.createCell(k);  
						cell.setCellValue(item.getText(k).equals("-")?"":item.getText(k));
						if(k==1 || k==3)
							cell.setCellStyle(centerCellStyle);
						else if(k > 0)
							cell.setCellStyle(numberCellStyle);
					}
				}
			}
			
			File file = new File("C:\\ProgramData\\BlackCodeCRM\\salesdata.xls");
			FileOutputStream out = new FileOutputStream(file);            
			workbook.write(out);            
			out.close();
			
			Runtime.getRuntime().exec("rundll32 url.dll,FileProtocolHandler "+file); 
		}catch(Exception e){
			MessageDialog dlg = new MessageDialog(shell, SWT.NONE, "Error 401 : System Problems (EX336)");
			dlg.open();
		}
	}
	
	private void sendGroupEmail(){
		List<Contact> contacts = getSelectedContacts();
		if(contacts.size() == 0){
			MessageDialog dlg = new MessageDialog(shell, SWT.NONE, "Not contact(s) had been selected.");
			dlg.open();
			return;
		}
		
		GroupEmailOptionDialog dlg = new GroupEmailOptionDialog(getShell(), SWT.NONE);
		dlg.open();
		
		if(dlg.getType()==null)
			return;
		
		if(dlg.getType().equalsIgnoreCase("Default")){
			MailComposeDialog composeDlg = new MailComposeDialog(getShell(), SWT.NONE, account, contacts);
			composeDlg.open();
		}else if(dlg.getType().equalsIgnoreCase("Campaign") && dlg.getCampaign() != null){
			for(int i=0; i<contacts.size(); i++){
				EmailCampaignRecipient recipient = new EmailCampaignRecipient();
				recipient.setCampaignId(dlg.getCampaign().getId());
				recipient.setContactId(contacts.get(i).getContactId());
				recipient.setContactName(contacts.get(i).getFullName());
				recipient.setEmailId(contacts.get(i).getEmails());
				recipient.setStatus("Pending");
				
				dbConnector.createEmailRecipient(recipient);
				//TODO send if schedule date is before today
			}			
		}
	}
	
	private void sendToCallReminder(){
		List<Contact> contacts = getSelectedContacts();
		if(contacts.size() == 0){
			MessageDialog dlg = new MessageDialog(shell, SWT.NONE, "Not contact(s) had been selected.");
			dlg.open();
			return;
		}
		
		FollowUpTask task = new FollowUpTask();
		task.setType("Call");
		task.setDate(new Date());
		task.setContactId("{Let it blank}");
		FollowUpDialog dlg = new FollowUpDialog(getShell(), SWT.NONE, task, null, null);
		dlg.open();
		
		task = dlg.getTask();
		if(task == null)
			return;
				
		for(int i=0; i<contacts.size(); i++){
			task.setContactId(contacts.get(i).getContactId());
			task.setContactName(contacts.get(i).getFullName());
			dbConnector.createTask(task);
		}
	}
	
	@Override
	protected void checkSubclass() {
		// Disable the check that prevents subclassing of SWT components
	}
}
