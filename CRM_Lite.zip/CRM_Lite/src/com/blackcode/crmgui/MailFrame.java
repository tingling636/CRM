package com.blackcode.crmgui;

import java.lang.reflect.InvocationTargetException;
import java.text.SimpleDateFormat;

import javax.mail.Flags;
import javax.mail.Flags.Flag;
import javax.mail.Folder;
import javax.mail.Message;
import javax.mail.Message.RecipientType;
import javax.mail.MessagingException;

import org.eclipse.jface.dialogs.ProgressMonitorDialog;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.MouseAdapter;
import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.events.MouseTrackAdapter;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.Menu;
import org.eclipse.swt.widgets.MenuItem;
import org.eclipse.swt.widgets.ProgressBar;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.TableItem;
import org.eclipse.wb.swt.SWTResourceManager;
import org.eclipse.swt.custom.CLabel;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.custom.ScrolledComposite;

import com.blackcode.core.EmailUtil;
import com.blackcode.emailmarketing.ActiveEventDialog;
import com.blackcode.emailmarketing.ActivePortfolioDialog;
import com.blackcode.emailmarketing.ActiveVacationDialog;
import com.blackcode.emailmarketing.EmailCampaignDialog;
import com.blackcode.emailmarketing.EmailDesignerDialog;
import com.blackcode.emailmarketing.OpenCampaignDialog;
import com.blackcode.model.Account;
import com.blackcode.model.EmailController;

public class MailFrame extends Composite {
	private Shell shell;
	private Composite frameTopActionBar;
	private Label lblMenuAction;
	private ScrolledComposite scrolledComposite;
	private Composite frameMain;
	private Composite frameMailList;
	private Composite frameDetail;
	private Composite frameEmailBar;
	private Combo cmbAccount;
	private Label lblCompose;
	private CLabel lblInbox;
	private CLabel lblFolder;
	private Table tblMail;
	private CLabel lblAccountTitle;
	private CLabel lblEmailTitle;
	private Label lblPages;
	private Label lblBackAction;
	private Label lblNextAction;
	private Button btnSeparator;
	private Composite frameSide;
	private MailMessage frame;
	private Menu popupMenu;
	
	private int layoutMode = 0;
	private Folder selectedFolder;
	private Account account;
	private int totalMail, totalPage, currentPage=0, startIndex, endIndex;
	private CLabel lblEmail;
	
	
	/**
	 * Create the composite.
	 * @param parent
	 * @param style
	 */
	public MailFrame(Composite parent, int style, Account emailaccount) {
		super(parent, style);
		shell = parent.getShell();
		this.account = emailaccount;
		setBackground(SWTResourceManager.getColor(255, 255, 255));

		frameTopActionBar = new Composite(this, SWT.NONE);
		frameTopActionBar.setBackground(SWTResourceManager.getColor(77, 99, 132));
		frameTopActionBar.setBounds(0, 0, shell.getBounds().width-60, 35);
		
		lblEmail = new CLabel(frameTopActionBar, SWT.NONE);
		lblEmail.setBackground(SWTResourceManager.getColor(77, 99, 132));
		lblEmail.setForeground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblEmail.setFont(SWTResourceManager.getFont("Georgia", 15, SWT.BOLD));
		lblEmail.setBounds(10, 8, 61, 21);
		lblEmail.setText("Email");
		
		lblAccountTitle = new CLabel(frameTopActionBar, SWT.NONE);
		lblAccountTitle.setForeground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblAccountTitle.setFont(SWTResourceManager.getFont("Georgia", 9, SWT.BOLD));
		lblAccountTitle.setBounds(207, 5, 350, 25);
		lblAccountTitle.setBackground(SWTResourceManager.getColor(77, 99, 132));
		lblAccountTitle.setText("");
				
		lblMenuAction = new Label(frameTopActionBar, SWT.NONE);
		lblMenuAction.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				popupMenu.setVisible(true);
			}
		});
		lblMenuAction.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				lblMenuAction.setBackground(SWTResourceManager.getColor(52, 64, 88));
				lblMenuAction.setImage(new Image(shell.getDisplay(), MailFrame.class.getResourceAsStream("/images/menu_selected.png")));
			}
			@Override
			public void mouseExit(MouseEvent e) {
				lblMenuAction.setBackground(SWTResourceManager.getColor(77, 99, 132));
				lblMenuAction.setImage(new Image(shell.getDisplay(), MailFrame.class.getResourceAsStream("/images/menu.png")));
			}
		});
		lblMenuAction.setBounds(frameTopActionBar.getBounds().width-38, 5, 33, 25);
		lblMenuAction.setBackground(SWTResourceManager.getColor(77, 99, 132));
		lblMenuAction.setImage(new Image(shell.getDisplay(), MailFrame.class.getResourceAsStream("/images/menu.png")));
		lblMenuAction.setToolTipText("More Functions");
		
		frameMailList = new Composite(this, SWT.NONE);
		frameMailList.setBounds(0, 36, 201, shell.getBounds().height-75);
		frameMailList.setBackground(SWTResourceManager.getColor(239, 245, 249));
		
		cmbAccount = new Combo(frameMailList, SWT.BORDER | SWT.CENTER);
		cmbAccount.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				if(account.getEmailId()==null || account.getEmailPassword()==null || account.getIncomingMailServer()==null || account.getOutgoingMailServer()==null){
					MessageDialog dlg = new MessageDialog(shell, SWT.NONE, "Imcomplete Email Account Setting");
					dlg.open();
					return;
				}
				lblCompose.setVisible(true);
				lblAccountTitle.setText(account.getCode()+" - "+account.getEmailId());
				lblEmailTitle.setText("");
				
			    receiveMail();
			}
		});
		cmbAccount.setBounds(2, 2, 196, 26);
		cmbAccount.setFont(SWTResourceManager.getFont("Georgia", 12, SWT.NORMAL));
		cmbAccount.setText("Select Account");
		cmbAccount.setVisibleItemCount(10);	
		cmbAccount.add(account.getCode());
		
		lblCompose = new Label(frameMailList, SWT.NONE);
		lblCompose.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				if(account == null)
					return;
				
				MailComposeDialog dlg = new MailComposeDialog(shell, SWT.NONE, account, null, null);
				dlg.open();
			}
		});
		lblCompose.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				((Label)e.widget).setImage(new Image(shell.getDisplay(), MailFrame.class.getResourceAsStream("/images/compose_selected.png")));
			}
			@Override
			public void mouseExit(MouseEvent e) {
				((Label)e.widget).setImage(new Image(shell.getDisplay(), MailFrame.class.getResourceAsStream("/images/compose.png")));
			}
		});
		lblCompose.setBounds(44, 34, 115, 31);
		lblCompose.setBackground(SWTResourceManager.getColor(239, 245, 249));
		lblCompose.setImage(new Image(shell.getDisplay(), MailFrame.class.getResourceAsStream("/images/compose.png")));
		lblCompose.setVisible(false);
		
		frameDetail = new Composite(this, SWT.NONE);
		frameDetail.setBounds(203, 36, shell.getBounds().width-265, shell.getBounds().height-75);
		frameDetail.setBackground(SWTResourceManager.getColor(255, 255, 255));
				
		scrolledComposite = new ScrolledComposite(frameDetail, SWT.H_SCROLL | SWT.V_SCROLL);
		scrolledComposite.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		scrolledComposite.setBounds(0, 0, frameDetail.getBounds().width-10, frameDetail.getBounds().height);
		scrolledComposite.setExpandHorizontal(true);
		scrolledComposite.setExpandVertical(true);
		
		frameMain = new Composite(scrolledComposite, SWT.NONE);
		frameMain.setBackground(SWTResourceManager.getColor(255, 255, 255));
		//frameMain.setVisible(false);
		
		frameEmailBar = new Composite(frameMain, SWT.NONE);
		frameEmailBar.setBounds(0, 0, frameDetail.getBounds().width-12, 31);
		frameEmailBar.setBackground(SWTResourceManager.getColor(239, 245, 249));
				
		lblEmailTitle = new CLabel(frameEmailBar, SWT.NONE);
		lblEmailTitle.setFont(SWTResourceManager.getFont("Segoe UI", 9, SWT.BOLD));
		lblEmailTitle.setBackground(SWTResourceManager.getColor(239, 245, 249));
		lblEmailTitle.setBounds(10, 5, 100, 21);
		lblEmailTitle.setText("");
		
		lblPages = new Label(frameEmailBar, SWT.NONE);
		lblPages.setFont(SWTResourceManager.getFont("Segoe UI", 8, SWT.BOLD));
		lblPages.setBackground(SWTResourceManager.getColor(239, 245, 249));
		lblPages.setBounds(frameEmailBar.getBounds().width-160, 8, 95, 15);
		
		lblBackAction = new Label(frameEmailBar, SWT.NONE);		
		lblBackAction.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				previousPage();
			}
		});
		lblBackAction.setBounds(frameEmailBar.getBounds().width-57, 8, 20, 20);
		lblBackAction.setBackground(SWTResourceManager.getColor(239, 245, 249));
		lblBackAction.setImage(new Image(shell.getDisplay(), MailFrame.class.getResourceAsStream("/images/back_small.png")));
		lblBackAction.setToolTipText("Back To Previous Page");
		lblBackAction.setVisible(false);
		
		lblNextAction = new Label(frameEmailBar, SWT.NONE);
		lblNextAction.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				nextPage();
			}
		});
		lblNextAction.setBounds(frameEmailBar.getBounds().width-35, 8, 20, 20);
		lblNextAction.setBackground(SWTResourceManager.getColor(239, 245, 249));
		lblNextAction.setImage(new Image(shell.getDisplay(), MailFrame.class.getResourceAsStream("/images/next_small.png")));
		lblNextAction.setToolTipText("Go To Next Page");
		lblNextAction.setVisible(false);
		
		tblMail = new Table(frameMain, SWT.CHECK | SWT.FULL_SELECTION);
		tblMail.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				showMessage();
			}
		});
		tblMail.addListener(SWT.MeasureItem, new Listener() {
			public void handleEvent(Event event) {
			      event.height = 30;
			   }
			});
		tblMail.setBounds(10, 32, scrolledComposite.getBounds().width-20, scrolledComposite.getBounds().height-50);
		tblMail.setLinesVisible(true);
		tblMail.setVisible(false);
		
		TableColumn tblclmn1 = new TableColumn(tblMail, SWT.NONE);
		tblclmn1.setWidth(60);
		
		TableColumn tblclmn2 = new TableColumn(tblMail, SWT.NONE);
		tblclmn2.setWidth(200);
		
		TableColumn tblclmn3 = new TableColumn(tblMail, SWT.NONE);
		tblclmn3.setWidth(400);
		
		TableColumn tblclmn4 = new TableColumn(tblMail, SWT.RIGHT);
		tblclmn4.setWidth(100);
				
		btnSeparator = new Button(frameDetail, SWT.FLAT);
		btnSeparator.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				changeFrameWidth();
			}
		});
		btnSeparator.setBounds(scrolledComposite.getBounds().width, 0, 10, shell.getBounds().height-75);
		btnSeparator.setImage(new Image(shell.getDisplay(), MailFrame.class.getResourceAsStream("/images/separator.png")));			
		
		frameSide = new Composite(frameDetail, SWT.NONE);
		frameSide.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		
		popupMenu = new Menu(lblMenuAction);		
	    MenuItem campaignItem = new MenuItem(popupMenu, SWT.NONE);
	    campaignItem.setText("Email Campaign");
	    campaignItem.addListener(SWT.Selection, new Listener() {
	        public void handleEvent(Event e) {
	        	OpenCampaignDialog dlg = new OpenCampaignDialog(shell, SWT.NONE);
	        	dlg.open();
	        	
	        	if(dlg.getCampaign() == null)
	        		return;
	        	
	        	EmailCampaignDialog dlg2 = new EmailCampaignDialog(shell, SWT.NONE, dlg.getCampaign());
	        	dlg2.open();
	          }
	        });
	    
	    MenuItem emailDesignerItem = new MenuItem(popupMenu, SWT.NONE);
	    emailDesignerItem.setText("Email Designer");
	    emailDesignerItem.addListener(SWT.Selection, new Listener() {
	        public void handleEvent(Event e) {
	        	
	        	EmailDesignerDialog designer = new EmailDesignerDialog(shell, SWT.NONE);
	        	designer.open();
	        	
	        	if(designer.getFilename() == null)
	        		return;
	        	
	        	if(designer.getLayout().equalsIgnoreCase("ActiveVacation")){
	        		ActiveVacationDialog dlg = new ActiveVacationDialog(shell, SWT.NONE, designer.getFilename());
		        	dlg.open();
	        	}else if(designer.getLayout().equalsIgnoreCase("ActivePortfolio")){
	        		ActivePortfolioDialog dlg = new ActivePortfolioDialog(shell, SWT.NONE, designer.getFilename());
		        	dlg.open();
	        	}else if(designer.getLayout().equalsIgnoreCase("ActiveEvent")){
	        		ActiveEventDialog dlg = new ActiveEventDialog(shell, SWT.NONE, designer.getFilename());
		        	dlg.open();
	        	}
	        	
	          }
	        });
	    
	    lblMenuAction.setMenu(popupMenu);
	    	   	    
		scrolledComposite.setContent(frameMain);
		scrolledComposite.setMinSize(frameMain.computeSize(SWT.DEFAULT, SWT.DEFAULT));
		
	}
	
	private void receiveMail() {
		clearAccount();
				
		try {
			EmailController controller = new EmailController();
			controller.setEmailAccount(account);	
			
			EmailUtil util = new EmailUtil(EmailUtil.ACTIONS.RECEIVE, controller);
			new ProgressMonitorDialog(shell).run(true, true, util);
			
			Folder rootFolder = util.getController().getFolder();
			lblInbox = new CLabel(frameMailList, SWT.NONE);
			lblInbox.addMouseListener(new MouseAdapter() {
				@Override
				public void mouseDown(MouseEvent e) {
					lblEmailTitle.setText("Inbox");
					selectedFolder = (Folder)lblInbox.getData();
					openMailFolder();
				}
			});
			lblInbox.addMouseTrackListener(new MouseTrackAdapter() {
				@Override
				public void mouseEnter(MouseEvent e) {
					((CLabel)e.widget).setBackground(SWTResourceManager.getColor(224, 230, 255));
				}
				@Override
				public void mouseExit(MouseEvent e) {
					((CLabel)e.widget).setBackground(SWTResourceManager.getColor(239, 245, 249));
				}
			});
			lblInbox.setFont(SWTResourceManager.getFont("Georgia", 10, SWT.NORMAL));
			lblInbox.setBackground(SWTResourceManager.getColor(239, 245, 249));
			lblInbox.setBounds(31, 85, 138, 25);
			lblInbox.setMargins(15, 5, 0, 0);
			lblInbox.setText("Inbox");
			if(rootFolder.getNewMessageCount() > 0)
				lblInbox.setText("Inbox ("+rootFolder.getNewMessageCount()+")");
			else
				lblInbox.setText("Inbox");
			
			lblInbox.setData(rootFolder);
						
			Folder[] folders = util.getController().getFolderList();//rootFolder.list();
			int y = 85;
			for(int i=0; i<folders.length; i++){
				y+=30;
				Folder folder = folders[i];
				//folder.open(Folder.READ_WRITE);
				
				Label label = new Label(frameMailList, SWT.SEPARATOR | SWT.HORIZONTAL);
				label.setBounds(30, y-2, 140, 2);
				
				lblFolder = new CLabel(frameMailList, SWT.NONE);
				lblFolder.addMouseListener(new MouseAdapter() {
					@Override
					public void mouseDown(MouseEvent e) {
						selectedFolder = (Folder)((CLabel)e.widget).getData();
						lblEmailTitle.setText(((CLabel)e.widget).getText());
						openMailFolder();
					}
				});
				lblFolder.addMouseTrackListener(new MouseTrackAdapter() {
					@Override
					public void mouseEnter(MouseEvent e) {
						((CLabel)e.widget).setBackground(SWTResourceManager.getColor(224, 230, 255));
					}
					@Override
					public void mouseExit(MouseEvent e) {
						((CLabel)e.widget).setBackground(SWTResourceManager.getColor(239, 245, 249));
					}
				});
				lblFolder.setFont(SWTResourceManager.getFont("Georgia", 10, SWT.NORMAL));
				lblFolder.setBackground(SWTResourceManager.getColor(239, 245, 249));
				lblFolder.setBounds(31, y, 138, 25);
				lblFolder.setMargins(15, 5, 0, 0);
				lblFolder.setText(folder.getName());
				lblFolder.setData(folder);
			}
			
		} catch (InvocationTargetException | InterruptedException e1) {			
			e1.printStackTrace();
		}catch (MessagingException e) {
			e.printStackTrace();
		}catch (Exception e) {
			e.printStackTrace();
		}
		
		frameMailList.redraw();
	}
	
	private void openMailFolder(){
		clearFolder();
		if(selectedFolder == null)
			return;
		
		try {
			//selectedFolder.open(Folder.READ_WRITE);
			int totalMessages = selectedFolder.getMessageCount();

		    if (totalMessages == 0) {
				System.out.println("Empty folder");
				return;
		    }

		    totalMail = selectedFolder.getMessageCount();
			totalPage = (totalMail / 25);
			if(totalMail%25 > 0)
				totalPage += 1;
			
		    nextPage();
		} catch (MessagingException e) {
			MessageDialog dlg = new MessageDialog(shell, SWT.NONE, "Error 500 : Email Problems");
			dlg.open();
		}
	}
	
	private void showEmailList(){
		tblMail.removeAll();
		if(selectedFolder == null)
			return;
		
		tblMail.setVisible(true);
		lblPages.setText(((currentPage-1)*25+1)+" to "+(((currentPage-1)*25+25)>totalMail?totalMail:((currentPage-1)*25+25))+" of "+totalMail);
		lblBackAction.setVisible(currentPage > 1);
		lblNextAction.setVisible(currentPage < totalPage);
		
		try {
			SimpleDateFormat sdf = new SimpleDateFormat("dd,MMM yyyy");
			
		    Message[] msgs = selectedFolder.getMessages(startIndex, endIndex);
		    for(int i = msgs.length-1; i>=0; i--){
		    	Message message = msgs[i];
		    	
		    	if(message.getFlags().contains(Flags.Flag.DELETED))
		    		continue;
		    	
		    	String fromAddress = message.getFrom()[0].toString();
		    	if(fromAddress.indexOf("?")>0 && message.getHeader("Reply-To")!=null)
		    		fromAddress = message.getHeader("Reply-To")[0];
		    	if(fromAddress.contains(account.getEmailId()))
		    		fromAddress = message.getRecipients(RecipientType.TO)[0].toString();
		    	String senderName = fromAddress.indexOf("<")>0?fromAddress.substring(0,  fromAddress.indexOf("<")-1):fromAddress;
		    	senderName = senderName.replace("\"", "").replace("'", "");		    	
		    	
		    	TableItem ti = new TableItem(tblMail, SWT.NONE);
		    	ti.setText(new String[]{"", senderName, message.getSubject(), sdf.format(message.getReceivedDate())});
		    	ti.setData(message);
		    	if(!message.getFlags().contains(Flags.Flag.SEEN)){
		    		ti.setFont(SWTResourceManager.getFont("Segoe UI", 9, SWT.BOLD));
		    	}
		    	/*Enumeration headers = message.getAllHeaders();
		    	while (headers.hasMoreElements()) {
		    		Header h = (Header) headers.nextElement();
		    		System.out.println(h.getName() + ": " + h.getValue());
		    	}
		    	System.out.println("--- XXX --");
		    	System.out.println("");*/		    	
		    }
		    		    
		} catch (MessagingException e) {
			MessageDialog dlg = new MessageDialog(shell, SWT.NONE, "Error 500 : Email Problems");
			dlg.open();
		}catch (Exception e) {
			MessageDialog dlg = new MessageDialog(shell, SWT.NONE, "Error 401 : System Problems (MF496)");
			dlg.open();
		}
	}
	
	private void showMessage(){
		if(tblMail.getSelectionIndex() == -1)
			return;
		
		try{
			Message msg = (Message)tblMail.getItem(tblMail.getSelectionIndex()).getData();
			msg.setFlag(Flag.SEEN, true); 
			
			layoutMode=0;
			changeFrameWidth();
			if(frame != null)
				frame.dispose();
			
			
			frame = new MailMessage(frameSide, SWT.NONE, msg, account);
			frame.setBounds(0, 32, frameSide.getBounds().width, frameSide.getBounds().height-30);
		}catch (MessagingException e) {
			MessageDialog dlg = new MessageDialog(shell, SWT.NONE, "Error 500 : Email Problems");
			dlg.open();
		}
		
	}
	
	private void clearAccount(){
		selectedFolder = null;
		
		Control[] items = frameMailList.getChildren();
		for(int i=2; i<items.length; i++){
			if(items[i] instanceof ProgressBar)
				continue;
			items[i].dispose();
		}
		
		lblEmailTitle.setText("");
		clearFolder();
	}
	
	private void clearFolder(){		
		lblPages.setText("");
		lblBackAction.setVisible(false);
		lblNextAction.setVisible(false);
		
		tblMail.removeAll();
		tblMail.setVisible(false);
		currentPage=0;
		
		if(frame != null)
			frame.dispose();
	}
	
	private void nextPage(){		
		currentPage++;	
		endIndex = totalMail - ((currentPage-1)*25);
		if(endIndex <= 0)
			endIndex = 25;
		startIndex = endIndex - 24;
		if(startIndex < 1)
			startIndex = 1;			
		
		showEmailList();
	}
	
	private void previousPage(){		
		currentPage--;		
		endIndex = totalMail - ((currentPage-1)*25);
		if(endIndex <= 0)
			endIndex = 25;
		startIndex = endIndex - 24;
		if(startIndex < 1)
			startIndex = 1;		
		
		showEmailList();
	}
	
	private void changeFrameWidth(){
		if(layoutMode == 0){
			layoutMode = 1;
			
			scrolledComposite.setBounds(0, 0, (frameDetail.getBounds().width/3*2)-15, frameDetail.getBounds().height);
			btnSeparator.setBounds(scrolledComposite.getBounds().width, 0, 10, shell.getBounds().height-75);
			frameSide.setBounds((frameDetail.getBounds().width/3*2), 0, (frameDetail.getBounds().width/3), frameDetail.getBounds().height);
		}else{
			layoutMode = 0;
			
			scrolledComposite.setBounds(0, 0, frameDetail.getBounds().width-10, frameDetail.getBounds().height);
			btnSeparator.setBounds(scrolledComposite.getBounds().width, 0, 10, shell.getBounds().height-75);
			frameSide.setBounds(0, 0, 0, 0);
		}
		frameDetail.redraw();
	}
		
	@Override
	protected void checkSubclass() {
		// Disable the check that prevents subclassing of SWT components
	}
}
