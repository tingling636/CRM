package com.blackcode.crmgui;

import java.text.SimpleDateFormat;
import java.util.List;

import org.eclipse.swt.events.MouseAdapter;
import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.events.MouseTrackAdapter;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Dialog;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.TableItem;
import org.eclipse.swt.SWT;
import org.eclipse.wb.swt.SWTResourceManager;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.widgets.DateTime;
import org.eclipse.swt.custom.CLabel;
import org.eclipse.swt.custom.ScrolledComposite;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.custom.StyledText;

import com.blackcode.core.SQLiteConnector;
import com.blackcode.model.Contact;
import com.blackcode.model.FollowUpTask;

import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;


public class CallPlanHelperDialog extends Dialog {

	protected Object result;
	protected Shell shell;
	private Text txtLastPlanDate;
	private Text txtLastSalesDate;
	private Composite framePage1, framePage2, framePage3;
	private Button btnLastSaleDate,btnLastCallDate,btnImportantDates;
	private DateTime dateTimePlan;
	private CLabel lblPage1Next,lblPage2Next,lblPage3Next;
	private CLabel lblPage2Back,lblPage3Back;
	private Combo cmbTime;
	private Text txtSubject;
	private StyledText styledTextNote;
	private ScrolledComposite scrolledComposite;
	private Composite frameContactList,frameCallPlan;
	private CLabel lblContactDetail;
	private Label label;	
	private Button btnOk;
	private Table table;
	private Combo cmbEvent, cmbMonth;
	private Button btnClear;
	
	private SQLiteConnector dbConnector = new SQLiteConnector();
	private String[] times = new String[]{"06:00","07:00","08:00","09:00","10:00","11:00","12:00","13:00","14:00","15:00","16:00","17:00","18:00","19:00","20:00","21:00","22:00","23:00","24:00"};
			
	/**
	 * Create the dialog.
	 * @param parent
	 * @param style
	 */
	public CallPlanHelperDialog(Shell parent, int style) {
		super(parent, style);
		setText("SWT Dialog");
	}

	/**
	 * Open the dialog.
	 * @return the result
	 */
	public Object open() {
		createContents();
		shell.open();
		shell.layout();
		Display display = getParent().getDisplay();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
		return result;
	}

	/**
	 * Create contents of the dialog.
	 */
	private void createContents() {
		shell = new Shell(getParent(), SWT.NONE);
		shell.setSize(526, 402);
		shell.setText(getText());
		shell.setLocation((getParent().getBounds().width/2)-(shell.getBounds().width/2), 30);
		
		Composite composite = new Composite(shell, SWT.NONE);
		composite.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		composite.setBounds(0, 0, 524, 400);

		Composite frameTitle = new Composite(composite, SWT.NONE);
		frameTitle.setBackground(SWTResourceManager.getColor(50, 50, 50));
		frameTitle.setBounds(0, 0, composite.getBounds().width, 26);
		
		Label lblTitle = new Label(frameTitle, SWT.NONE);
		lblTitle.setForeground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblTitle.setFont(SWTResourceManager.getFont("Georgia", 8, SWT.BOLD));
		lblTitle.setBounds(5, 6, 191, 15);
		lblTitle.setBackground(SWTResourceManager.getColor(50, 50, 50));
		lblTitle.setText("Call Plans Helper");
		
		final Label lblCloseAction = new Label(frameTitle, SWT.CENTER);
		lblCloseAction.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				shell.close();
			}
		});
		lblCloseAction.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				lblCloseAction.setBackground(SWTResourceManager.getColor(100, 100, 100));
			}
			@Override
			public void mouseExit(MouseEvent e) {
				lblCloseAction.setBackground(SWTResourceManager.getColor(50, 50, 50));
			}
		});
		lblCloseAction.setBounds(frameTitle.getBounds().width-25, 3, 20, 20);
		lblCloseAction.setBackground(SWTResourceManager.getColor(50, 50, 50));
		lblCloseAction.setImage(new Image(shell.getDisplay(), this.getClass().getResourceAsStream("/images/close.png")));
		lblCloseAction.setToolTipText("Close Window");
		
		framePage1 = new Composite(composite, SWT.NONE);
		framePage1.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		framePage1.setBounds(0, 26, composite.getBounds().width, composite.getBounds().height-26);
		
		CLabel lblSubTitle1 = new CLabel(framePage1, SWT.NONE);
		lblSubTitle1.setForeground(SWTResourceManager.getColor(SWT.COLOR_LINK_FOREGROUND));
		lblSubTitle1.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblSubTitle1.setFont(SWTResourceManager.getFont("Times New Roman", 8, SWT.BOLD));
		lblSubTitle1.setBounds(3, 3, 127, 21);
		lblSubTitle1.setText("1. Set Search Criteria");
		
		Label lblLine1 = new Label(framePage1, SWT.SEPARATOR | SWT.HORIZONTAL);
		lblLine1.setBounds(3, 36, 510, 2);
		
		btnLastCallDate = new Button(framePage1, SWT.CHECK);
		btnLastCallDate.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		btnLastCallDate.setBounds(10, 52, 107, 16);
		btnLastCallDate.setText("Last plan date is");
		
		txtLastPlanDate = new Text(framePage1, SWT.BORDER);
		txtLastPlanDate.setBounds(123, 50, 40, 21);
		txtLastPlanDate.addListener(SWT.Verify, new Listener() {
			public void handleEvent(Event e) {				
			    verifyNumberInput(e);
			}});
		
		Label lblTial1 = new Label(framePage1, SWT.NONE);
		lblTial1.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblTial1.setBounds(169, 53, 82, 15);
		lblTial1.setText("day(s) before");
		
		btnLastSaleDate = new Button(framePage1, SWT.CHECK);
		btnLastSaleDate.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		btnLastSaleDate.setBounds(10, 91, 107, 16);
		btnLastSaleDate.setText("Last sales date is");
		
		txtLastSalesDate = new Text(framePage1, SWT.BORDER);
		txtLastSalesDate.setBounds(123, 89, 40, 21);
		txtLastSalesDate.addListener(SWT.Verify, new Listener() {
			public void handleEvent(Event e) {				
			    verifyNumberInput(e);
			}});
		
		Label lblTial2 = new Label(framePage1, SWT.NONE);
		lblTial2.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblTial2.setBounds(169, 92, 87, 15);
		lblTial2.setText("days(s) before");
		
		btnImportantDates = new Button(framePage1, SWT.CHECK);
		btnImportantDates.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		btnImportantDates.setBounds(10, 128, 143, 16);
		btnImportantDates.setText("Important event dates (");
		
		Label lblBetween = new Label(framePage1, SWT.NONE);
		lblBetween.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblBetween.setBounds(233, 129, 30, 15);
		lblBetween.setText(") on");
		
		cmbEvent = new Combo(framePage1, SWT.READ_ONLY);
		cmbEvent.setBounds(154, 126, 73, 23);
		cmbEvent.setItems(new String[]{"All", "DOB only"});
		
		cmbMonth = new Combo(framePage1, SWT.READ_ONLY);
		cmbMonth.setBounds(269, 126, 82, 23);
		cmbMonth.setItems(new String[]{"Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"});
				
		lblPage1Next = new CLabel(framePage1, SWT.CENTER);
		lblPage1Next.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				framePage1.setVisible(false);
				framePage2.setVisible(true);
				framePage3.setVisible(false);
				
				searchContact();
			}
		});
		lblPage1Next.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				lblPage1Next.setBackground(SWTResourceManager.getColor(86, 86, 86));
			}
			@Override
			public void mouseExit(MouseEvent e) {
				lblPage1Next.setBackground(SWTResourceManager.getColor(45, 45, 45));
			}
		});
		lblPage1Next.setBounds(453, 334, 61, 30);
		lblPage1Next.setBackground(SWTResourceManager.getColor(45, 45, 45));
		lblPage1Next.setForeground(SWTResourceManager.getColor(245, 245, 245));
		lblPage1Next.setFont(SWTResourceManager.getFont("Georgia", 9, SWT.BOLD));
		lblPage1Next.setText("Next");		
						
		framePage2 = new Composite(composite, SWT.NONE);
		framePage2.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		framePage2.setBounds(0, 26, composite.getBounds().width, composite.getBounds().height-26);
		framePage2.setVisible(false);
		
		CLabel lblSubTitle2 = new CLabel(framePage2, SWT.NONE);
		lblSubTitle2.setForeground(SWTResourceManager.getColor(SWT.COLOR_LINK_FOREGROUND));
		lblSubTitle2.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblSubTitle2.setFont(SWTResourceManager.getFont("Times New Roman", 8, SWT.BOLD));
		lblSubTitle2.setBounds(3, 3, 264, 21);
		lblSubTitle2.setText("2. Define date to call the particular contact");
		
		Label lblLine2 = new Label(framePage2, SWT.SEPARATOR | SWT.HORIZONTAL);
		lblLine2.setBounds(3, 36, 510, 2);
		
		scrolledComposite = new ScrolledComposite(framePage2, SWT.BORDER | SWT.H_SCROLL | SWT.V_SCROLL);
		scrolledComposite.setBounds(3, 42, 155, 322);
		scrolledComposite.setExpandHorizontal(true);
		scrolledComposite.setExpandVertical(true);
		
		frameContactList = new Composite(scrolledComposite, SWT.NONE);
		frameContactList.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
				
		scrolledComposite.setContent(frameContactList);
		scrolledComposite.setMinSize(frameContactList.computeSize(SWT.DEFAULT, SWT.DEFAULT));
		
		lblContactDetail = new CLabel(framePage2, SWT.TOP);
		lblContactDetail.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblContactDetail.setFont(SWTResourceManager.getFont("Times New Roman", 10, SWT.NORMAL));
		lblContactDetail.setBounds(164, 42, 349, 139);
		lblContactDetail.setVisible(false);
		
		frameCallPlan = new Composite(framePage2, SWT.NONE);
		frameCallPlan.setBackground(SWTResourceManager.getColor(247,250,252));
		frameCallPlan.setBounds(164, 187, 349, 141);
		frameCallPlan.setVisible(false);
		
		label = new Label(frameCallPlan, SWT.SEPARATOR | SWT.HORIZONTAL);
		label.setLocation(0, 3);
		label.setSize(349, 2);
		
		Label lblPlanCallOn = new Label(frameCallPlan, SWT.RIGHT);
		lblPlanCallOn.setBackground(SWTResourceManager.getColor(247,250,252));
		lblPlanCallOn.setBounds(10, 10, 72, 15);
		lblPlanCallOn.setText("Plan Call On");
		
		dateTimePlan = new DateTime(frameCallPlan, SWT.BORDER | SWT.DROP_DOWN);
		dateTimePlan.setBounds(88, 8, 87, 24);
		
		cmbTime = new Combo(frameCallPlan, SWT.NONE);
		cmbTime.setBounds(178, 8, 62, 24);
		cmbTime.setItems(times);
		
		Label lblSubject = new Label(frameCallPlan, SWT.RIGHT);
		lblSubject.setBackground(SWTResourceManager.getColor(247,250,252));
		lblSubject.setBounds(27, 40, 55, 15);
		lblSubject.setText("Subject");
		
		txtSubject = new Text(frameCallPlan, SWT.BORDER);
		txtSubject.setBounds(88, 37, 230, 21);
		
		Label lblNotes = new Label(frameCallPlan, SWT.RIGHT);
		lblNotes.setBackground(SWTResourceManager.getColor(247,250,252));
		lblNotes.setBounds(27, 64, 55, 15);
		lblNotes.setText("Notes");
		
		styledTextNote = new StyledText(frameCallPlan, SWT.BORDER);
		styledTextNote.setBounds(88, 64, 230, 43);
		
		btnOk = new Button(frameCallPlan, SWT.NONE);
		btnOk.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				setCallPlan();
			}
		});
		btnOk.setBounds(120, 113, 62, 25);
		btnOk.setText("OK");
		
		btnClear = new Button(frameCallPlan, SWT.NONE);
		btnClear.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				clearCallPlan();
			}
		});
		btnClear.setBounds(188, 113, 62, 25);
		btnClear.setText("Clear");
				
		lblPage2Next = new CLabel(framePage2, SWT.CENTER);
		lblPage2Next.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				framePage1.setVisible(false);
				framePage2.setVisible(false);
				framePage3.setVisible(true);
				
				showPlan();
			}
		});
		lblPage2Next.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				lblPage2Next.setBackground(SWTResourceManager.getColor(86, 86, 86));
			}
			@Override
			public void mouseExit(MouseEvent e) {
				lblPage2Next.setBackground(SWTResourceManager.getColor(45, 45, 45));
			}
		});
		lblPage2Next.setBounds(453, 334, 61, 30);
		lblPage2Next.setBackground(SWTResourceManager.getColor(45, 45, 45));
		lblPage2Next.setForeground(SWTResourceManager.getColor(245, 245, 245));
		lblPage2Next.setFont(SWTResourceManager.getFont("Georgia", 9, SWT.BOLD));
		lblPage2Next.setText("Next");
		
		lblPage2Back = new CLabel(framePage2, SWT.CENTER);
		lblPage2Back.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				framePage1.setVisible(true);
				framePage2.setVisible(false);
				framePage3.setVisible(false);
			}
		});
		lblPage2Back.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				lblPage2Back.setBackground(SWTResourceManager.getColor(86, 86, 86));
			}
			@Override
			public void mouseExit(MouseEvent e) {
				lblPage2Back.setBackground(SWTResourceManager.getColor(45, 45, 45));
			}
		});
		lblPage2Back.setBounds(384, 334, 61, 30);
		lblPage2Back.setBackground(SWTResourceManager.getColor(45, 45, 45));
		lblPage2Back.setForeground(SWTResourceManager.getColor(245, 245, 245));
		lblPage2Back.setFont(SWTResourceManager.getFont("Georgia", 9, SWT.BOLD));
		lblPage2Back.setText("Back");
		
		framePage3 = new Composite(composite, SWT.NONE);
		framePage3.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		framePage3.setBounds(0, 26, composite.getBounds().width, composite.getBounds().height-26);
		framePage3.setVisible(false);
		
		CLabel lblSubTitle3 = new CLabel(framePage3, SWT.NONE);
		lblSubTitle3.setForeground(SWTResourceManager.getColor(SWT.COLOR_LINK_FOREGROUND));
		lblSubTitle3.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblSubTitle3.setFont(SWTResourceManager.getFont("Times New Roman", 8, SWT.BOLD));
		lblSubTitle3.setBounds(3, 3, 127, 21);
		lblSubTitle3.setText("3. Confirm and Save");
		
		Label lblLine3 = new Label(framePage3, SWT.SEPARATOR | SWT.HORIZONTAL);
		lblLine3.setBounds(3, 36, 510, 2);
		
		table = new Table(framePage3, SWT.BORDER | SWT.FULL_SELECTION);
		table.setLinesVisible(true);
		table.setBounds(10, 53, 489, 230);
		
		TableColumn tblclmnNewColumn = new TableColumn(table, SWT.NONE);
		tblclmnNewColumn.setWidth(140);
		
		TableColumn tblclmnNewColumn_1 = new TableColumn(table, SWT.NONE);
		tblclmnNewColumn_1.setWidth(150);
		
		TableColumn tblclmnNewColumn_2 = new TableColumn(table, SWT.NONE);
		tblclmnNewColumn_2.setWidth(180);
		
		lblPage3Next = new CLabel(framePage3, SWT.CENTER);
		lblPage3Next.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				framePage1.setVisible(false);
				framePage2.setVisible(false);
				framePage3.setVisible(true);
				savePlan();
			}
		});
		lblPage3Next.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				lblPage3Next.setBackground(SWTResourceManager.getColor(86, 86, 86));
			}
			@Override
			public void mouseExit(MouseEvent e) {
				lblPage3Next.setBackground(SWTResourceManager.getColor(45, 45, 45));
			}
		});
		lblPage3Next.setBounds(453, 334, 61, 30);
		lblPage3Next.setBackground(SWTResourceManager.getColor(45, 45, 45));
		lblPage3Next.setForeground(SWTResourceManager.getColor(245, 245, 245));
		lblPage3Next.setFont(SWTResourceManager.getFont("Georgia", 9, SWT.BOLD));
		lblPage3Next.setText("Next");
		
		lblPage3Back = new CLabel(framePage3, SWT.CENTER);
		lblPage3Back.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				framePage1.setVisible(false);
				framePage2.setVisible(true);
				framePage3.setVisible(false);
			}
		});
		lblPage3Back.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				lblPage3Back.setBackground(SWTResourceManager.getColor(86, 86, 86));
			}
			@Override
			public void mouseExit(MouseEvent e) {
				lblPage3Back.setBackground(SWTResourceManager.getColor(45, 45, 45));
			}
		});
		lblPage3Back.setBounds(384, 334, 61, 30);
		lblPage3Back.setBackground(SWTResourceManager.getColor(45, 45, 45));
		lblPage3Back.setForeground(SWTResourceManager.getColor(245, 245, 245));
		lblPage3Back.setFont(SWTResourceManager.getFont("Georgia", 9, SWT.BOLD));
		lblPage3Back.setText("Back");
	}
	
	private void searchContact(){
		int planDay = -1, salesDay = -1;
		String event=null, eventMonth=null;
		
		if(btnLastCallDate.getSelection() && txtLastPlanDate.getText().length()>0)
			planDay = Integer.parseInt(txtLastPlanDate.getText());
		if(btnLastSaleDate.getSelection() && txtLastSalesDate.getText().length()>0)
			salesDay = Integer.parseInt(txtLastSalesDate.getText());
		if(btnImportantDates.getSelection() && cmbMonth.getSelectionIndex() >=0){
			if(cmbEvent.getText().equals("DOB only"))
				event = "dob";
			else
				event = "all";
			
			if(cmbMonth.getSelectionIndex()<9)
				eventMonth = "0"+(cmbMonth.getSelectionIndex()+1);
			else
				eventMonth = ""+(cmbMonth.getSelectionIndex()+1);
		}
		
		Control[] control = frameContactList.getChildren();
		for(int i=0; i<control.length; i++){
			control[i].dispose();
		}
		
		List<Object[]> dataCol = dbConnector.CallPlanHelper(planDay, salesDay, event, eventMonth);
		int x = 3;
		for(int i=0; i<dataCol.size(); i++){
			Object[] data = dataCol.get(i);
			
			CLabel lblContact = new CLabel(frameContactList, SWT.NONE);
			lblContact.setBackground(SWTResourceManager.getColor(232,240,245));
			lblContact.addMouseListener(new MouseAdapter() {
				@Override
				public void mouseDown(MouseEvent e) {
					changeColor();
					
					((CLabel)e.widget).setBackground(SWTResourceManager.getColor(76,140,181));
					((CLabel)e.widget).setData("selected", Boolean.TRUE);
					showDetail((Contact)((CLabel)e.widget).getData(), (String)((CLabel)e.widget).getData("planDate"), (String)((CLabel)e.widget).getData("salesDate"),
							 (FollowUpTask)((CLabel)e.widget).getData("plan"));
				}
			});
			lblContact.addMouseTrackListener(new MouseTrackAdapter() {
				@Override
				public void mouseEnter(MouseEvent e) {
					if(((CLabel)e.widget).getData("selected").equals(Boolean.FALSE))
						((CLabel)e.widget).setBackground(SWTResourceManager.getColor(201,220,233));
				}
				@Override
				public void mouseExit(MouseEvent e) {
					if(((CLabel)e.widget).getData("selected").equals(Boolean.FALSE))
						((CLabel)e.widget).setBackground(SWTResourceManager.getColor(232,240,245));
				}
			});
			lblContact.setFont(SWTResourceManager.getFont("Times New Roman", 9, SWT.NORMAL));
			lblContact.setBounds(3, x, 145, 33);
			lblContact.setText(((Contact)data[0]).getFullName());
			lblContact.setData(data[0]);
			lblContact.setData("planDate", data[1]);
			lblContact.setData("salesDate", data[2]);
			lblContact.setData("selected", Boolean.FALSE);
			
			x += 36;
		}
		scrolledComposite.redraw();
		
	}
	
	private void changeColor(){
		Control[] control = frameContactList.getChildren();
		for(int i=0; i<control.length; i++){
			control[i].setData("selected", Boolean.FALSE);
			control[i].setBackground(SWTResourceManager.getColor(232,240,245));
		}
	}
	
	private void showDetail(Contact contact, String lastPlanDate, String lastSaleDate, FollowUpTask plan){		
		clear();
		
		String detail = contact.getJobTitle()+" at "+contact.getCompany()+"\n"
				+ "Last Call Plan On "+(lastPlanDate==null?"-":lastPlanDate)+"\n"
				+ "Last Sales On "+(lastSaleDate==null?"-":lastSaleDate)+"\n\nImportance Dates : \nDOB : "+(contact.getDob()==null?"-":contact.getDob())+"\n";
		
		if(contact.getDateFields() != null){
			String[] dates = contact.getDateFields().split("&#44");
			for(int z=0; z<dates.length; z++){
				String[] tmp = dates[z].split("&#47");
				detail += tmp[0]+" : "+tmp[1]+", ";
				System.out.println(z%3);
				if((z+1)%3==0)
					detail += "\n";
			}			
		}
		lblContactDetail.setText(detail);
		lblContactDetail.setVisible(true);
		
		frameCallPlan.setVisible(true);		
		if(plan != null){
			dateTimePlan.setTime(1900+plan.getDate().getYear(), plan.getDate().getMonth(), plan.getDate().getDate());
			cmbTime.setText(plan.getTime());
			txtSubject.setText(plan.getSubject()==null?"":plan.getSubject());
			styledTextNote.setText(plan.getNotes()==null?"":plan.getNotes());
		}
	}
	
	private void clear(){
		lblContactDetail.setText("");
		cmbTime.deselectAll();
		txtSubject.setText("");
		styledTextNote.setText("");		
		
		lblContactDetail.setVisible(false);
		frameCallPlan.setVisible(false);
	}
	
	private void setCallPlan(){
		try {
			CLabel selected = null;		
			Control[] control = frameContactList.getChildren();
			for(int i=0; i<control.length; i++){
				if(control[i].getData("selected").equals(Boolean.TRUE)){
					selected = (CLabel)control[i];
					break;
				}
			}
			
			if(selected == null)
				return;
			
			Contact contact = (Contact)selected.getData();
			FollowUpTask task = new FollowUpTask();
			task.setDate(new SimpleDateFormat("dd/MM/yyyy").parse(dateTimePlan.getDay()+"/"+(dateTimePlan.getMonth()+1)+"/"+dateTimePlan.getYear()));		
			task.setTime(captureText(cmbTime.getText()));
			task.setType("Call");
			task.setContactId(captureText(contact.getContactId()));
			task.setContactName(captureText(contact.getFullName()));
			task.setSubject(captureText(txtSubject.getText()));
			task.setNotes(captureText(styledTextNote.getText()));
			
			selected.setText(contact.getFullName()+"\n"+new SimpleDateFormat("E, dd-MM-yyyy").format(task.getDate()));
			selected.setData("plan", task);
			selected.setData("selected", Boolean.FALSE);
			selected.setBackground(SWTResourceManager.getColor(232,240,245));
			clear();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	private void clearCallPlan(){
		Control[] control = frameContactList.getChildren();
		for(int i=0; i<control.length; i++){
			if(control[i].getData("selected").equals(Boolean.TRUE)){
				control[i].setData("plan", null);
				control[i].setData("selected", Boolean.FALSE);
				control[i].setBackground(SWTResourceManager.getColor(232,240,245));
				break;
			}
		}
		clear();
	}
	
	private void showPlan(){
		table.removeAll();
		
		Control[] control = frameContactList.getChildren();
		for(int i=0; i<control.length; i++){
			if(control[i].getData("plan") != null){
				FollowUpTask task = (FollowUpTask)control[i].getData("plan");
				TableItem ti = new TableItem(table, SWT.NONE);
				ti.setText(new String[]{new SimpleDateFormat("E, dd-MM-yyyy").format(task.getDate())+" "+task.getTime(), task.getContactName(), task.getSubject()});
				ti.setData(task);
			}
		}
	}
	
	private void savePlan(){
		for(int i=0; i<table.getItemCount(); i++){
			FollowUpTask task = (FollowUpTask)table.getItem(i).getData();
			dbConnector.createTask(task);
		}
		shell.close();
	}
	
	private void verifyNumberInput(Event e){
		String string = e.text;
		char[] chars = new char[string.length()];
	    string.getChars(0, chars.length, chars, 0);
	    for (int i = 0; i < chars.length; i++) {
	    	if (!('0' <= chars[i] && chars[i] <= '9')) {
	           	if(chars[i] != '.'){
	           		e.doit = false;
			        return;
	           	}
	        }
	   }
	}
	
	private String captureText(String text){
		if(text.length() == 0)
			return null;
		else
			return text;
	}
}
