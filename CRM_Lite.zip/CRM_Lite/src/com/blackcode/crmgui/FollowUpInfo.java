package com.blackcode.crmgui;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.custom.ScrolledComposite;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Label;
import org.eclipse.wb.swt.SWTResourceManager;
import org.eclipse.swt.custom.StyledText;
import org.eclipse.swt.custom.CLabel;
import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.events.MouseTrackAdapter;
import org.eclipse.swt.events.MouseAdapter;
import org.eclipse.swt.widgets.Button;

import com.blackcode.core.SQLiteConnector;
import com.blackcode.model.FollowUpTask;

public class FollowUpInfo extends Composite {
	private Shell shell;
	private Composite composite;
	private Composite frameCalendar;
	private Label lblCalBack;
	private Label lblCalNext;
	private CLabel lblMonthYear;
	private Composite frameCalendarDate;
	private CLabel lblDate;
	private Composite frameTasks;
	private Button btnAdd;
	
	private Calendar calendar;
	private int selectedDate = -1;
	private SimpleDateFormat sdf = new SimpleDateFormat("E, yyyy MMM dd");
	private SimpleDateFormat sqlsdf = new SimpleDateFormat("yyyy-MM-dd");
	private String person;
	private List<FollowUpTask> taskCol;
	private SQLiteConnector dbConnector = new SQLiteConnector();
		
	public FollowUpInfo(Composite parent, int style, String person) {
		super(parent, style);
		shell = parent.getShell();
		this.person = person;
		
		ScrolledComposite scrolledComposite = new ScrolledComposite(this, SWT.BORDER | SWT.H_SCROLL | SWT.V_SCROLL);
		scrolledComposite.setBounds(0, 0, parent.getBounds().width-5, parent.getBounds().height-28);
		scrolledComposite.setExpandHorizontal(true);
		scrolledComposite.setExpandVertical(true);
		
		composite = new Composite(scrolledComposite, SWT.NONE);
		composite.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		
		Label lblCanledarHeader = new Label(composite, SWT.NONE);
		lblCanledarHeader.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblCanledarHeader.setBounds(149, 10, 184, 35);
		lblCanledarHeader.setImage(new Image(parent.getDisplay(), FollowUpInfo.class.getResourceAsStream("/images/calendar.png")));
		
		frameCalendar = new Composite(composite, SWT.NONE);
		frameCalendar.setBackground(SWTResourceManager.getColor(58, 58, 60));
		frameCalendar.setBounds(149, 47, 184, 210);
		
		lblCalBack = new Label(frameCalendar, SWT.NONE);
		lblCalBack.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				selectMonth(-1);
				frameCalendarDate.dispose();
				drawCalendar();
			}
		});
		lblCalBack.setBounds(5, 5, 23, 23);
		lblCalBack.setBackground(SWTResourceManager.getColor(255, 255, 255));
		lblCalBack.setImage(new Image(shell.getDisplay(), EventCalendarFrame.class.getResourceAsStream("/images/back_small.png")));
		
		lblMonthYear = new CLabel( frameCalendar, SWT.CENTER);
		lblMonthYear.setBounds(28, 5, 128, 23);
		lblMonthYear.setBackground(SWTResourceManager.getColor(255, 255, 255));
		
		lblCalNext = new Label(frameCalendar, SWT.NONE);
		lblCalNext.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				selectMonth(1);
				frameCalendarDate.dispose();
				drawCalendar();
			}
		});
		lblCalNext.setBounds(156, 5, 23, 23);
		lblCalNext.setBackground(SWTResourceManager.getColor(255, 255, 255));
		lblCalNext.setImage(new Image(shell.getDisplay(), EventCalendarFrame.class.getResourceAsStream("/images/next_small.png")));
		
		selectMonth(-1);
		drawCalendar();
		
		frameTasks = new Composite(composite, SWT.NONE);
		frameTasks.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		frameTasks.setBounds(25, 274, 425, 90);
		
		btnAdd = new Button(composite, SWT.NONE);
		btnAdd.setBounds(186, 381, 75, 25);
		btnAdd.setText("Add");
		btnAdd.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				addTask();
			}
		});
		
		selectCalendar(new Date().getDate());
		scrolledComposite.setContent(composite);
		scrolledComposite.setMinSize(composite.computeSize(SWT.DEFAULT, SWT.DEFAULT));

	}
	
	private void selectMonth(int month){
		if(calendar == null){
			calendar = Calendar.getInstance(); 			
		}else{
			calendar.add(Calendar.MONTH, month);
		}
		calendar.set(Calendar.DAY_OF_MONTH, 1);
		
		String[] monthStr = new String[]{"January","February","March","April","May","Jun","July","August","September","October","November","December"};
		Date theDate = calendar.getTime();
		lblMonthYear.setText(monthStr[theDate.getMonth()]+", "+(theDate.getYear()+1900));
	}
	
	private void selectCalendar(int date){
		Control[] items = frameCalendarDate.getChildren();
		for(int i=0; i<items.length; i++){
			if(((CLabel) items[i]).getData() == null)
				continue;
			
			int data = (Integer)((CLabel) items[i]).getData();
			if(data == selectedDate){
				((CLabel) items[i]).setBackground(SWTResourceManager.getColor(255, 255, 255));
				((CLabel) items[i]).setForeground(SWTResourceManager.getColor(0, 0, 0));
			}
			if(data == date){
				((CLabel) items[i]).setBackground(SWTResourceManager.getColor(235, 243, 247));
				((CLabel) items[i]).setForeground(SWTResourceManager.getColor(20, 58, 227));
			}
		}
		selectedDate = date;
		
		calendar.set(Calendar.DAY_OF_MONTH, selectedDate);
		displayTask(calendar.getTime());
	}

	private void drawCalendar(){
		try{
			String[] dayStr = new String[]{"S","M","T","W","T","F","S"};
			int[] lastDay = new int[]{31,28,31,30,31,30,31,31,30,31,30,31};
			
			frameCalendarDate = new Composite(frameCalendar, SWT.NONE);
			frameCalendarDate.setBackground(SWTResourceManager.getColor(58, 58, 60));
			frameCalendarDate.setBounds(0, 32, 184, 278);
			
			int x = 5;
			int y = 0;
			for(int i=0; i<dayStr.length; i++){
				CLabel lblDay = new CLabel(frameCalendarDate, SWT.CENTER);
				lblDay.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
				lblDay.setBounds(x, y, 22, 22);
				lblDay.setText(dayStr[i]);
				x += 25;
			}
			
			Date theDate = calendar.getTime();
			int firstDay = theDate.getDay();
			int daysInMonth = lastDay[theDate.getMonth()];
			if(daysInMonth==28){
				if(isLeapYear((theDate.getYear()+1900)))
					daysInMonth=29;
			}
			
			x = firstDay*25+5;
			y += 25;
			for(int i=1; i<=daysInMonth; i++){
				final int index = i;
				lblDate = new CLabel(frameCalendarDate, SWT.CENTER);
				lblDate.addMouseListener(new MouseAdapter() {
					@Override
					public void mouseDown(MouseEvent e) {
						selectCalendar((Integer)((CLabel)e.widget).getData());
					}
				});
				lblDate.addMouseTrackListener(new MouseTrackAdapter() {
					@Override
					public void mouseEnter(MouseEvent e) {
						((CLabel)e.widget).setBackground(SWTResourceManager.getColor(235, 243, 247));
						((CLabel)e.widget).setForeground(SWTResourceManager.getColor(20, 58, 227));
					}
					@Override
					public void mouseExit(MouseEvent e) {
						if(index != selectedDate){
							((CLabel)e.widget).setBackground(SWTResourceManager.getColor(255, 255, 255));
							((CLabel)e.widget).setForeground(SWTResourceManager.getColor(0, 0, 0));
						}
					}
				});
				lblDate.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
				lblDate.setBounds(x, y, 22, 22);
				lblDate.setText(i+"");
				lblDate.setData(i);
				if(i == selectedDate){
					lblDate.setBackground(SWTResourceManager.getColor(235, 243, 247));
					lblDate.setForeground(SWTResourceManager.getColor(20, 58, 227));
				}
				
				x += 25;
				if(i<daysInMonth && x>155){
					x = 5;
					y += 25;
				}
			}
			 frameCalendarDate.setSize(184, y+27);
			 frameCalendar.setSize(184, frameCalendarDate.getBounds().height+32);
			 frameCalendarDate.redraw();
			 frameCalendar.redraw();
		}catch (Exception e){
			MessageDialog dlg = new MessageDialog(shell, SWT.NONE, "Error 401 : System Problems (FI228)");
			dlg.open();
		}
	}
	
	private boolean isLeapYear(int inputYear){
		if(inputYear%400==0||(inputYear%4==0&&inputYear%100!=0)) 
			return true;
		
		return false;
	}
	
	public void displayTask(Date theDate){
		try{
			Control[] items = frameTasks.getChildren();
			for(int i=0; i<items.length; i++){
				items[i].dispose();
			}
			
			int y = 0;
			
			taskCol = dbConnector.readTask(null, "contactId='"+person+"' AND date(Date / 1000, 'unixepoch', 'localtime')='"+sqlsdf.format(theDate)+"'", null);
			for(int i=0; i<taskCol.size(); i++){
				FollowUpTask task = (FollowUpTask)taskCol.get(i);
				
				Composite frameTask = new Composite(frameTasks, SWT.NONE);
				frameTask.setBackground(SWTResourceManager.getColor(255, 255, 255));
				frameTask.setBounds(0, y, 425, 84);
				
				Label lblTaskDate = new Label(frameTask, SWT.NONE);
				lblTaskDate.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
				lblTaskDate.setText(sdf.format(task.getDate()));
				lblTaskDate.setFont(SWTResourceManager.getFont("Georgia", 8, SWT.BOLD | SWT.ITALIC));
				lblTaskDate.setBounds(0, 0, 120, 15);
				
				CLabel lblName = new CLabel(frameTask, SWT.RIGHT);
				lblName.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
				lblName.setFont(SWTResourceManager.getFont("Georgia", 8, SWT.BOLD | SWT.ITALIC));
				lblName.setText(displayText(task.getContactName()));
				lblName.setBounds(140, 0, 250, 15);
				
				Label lblTaskTime = new Label(frameTask, SWT.NONE);
				lblTaskTime.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
				lblTaskTime.setText(displayText(task.getTime()));
				lblTaskTime.setBounds(0, 21, 65, 15);
				
				Label lblTaskGroup = new Label(frameTask, SWT.NONE);
				lblTaskGroup.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
				lblTaskGroup.setText(displayText(task.getType()));
				lblTaskGroup.setBounds(71, 21, 65, 15);
				
				StyledText sytxtTask = new StyledText(frameTask, SWT.BORDER);
				sytxtTask.setBounds(142, 21, 250, 57);
				sytxtTask.setMargins(7, 3, 7, 0);
				sytxtTask.setText(displayText(task.getSubject())+"\n"+displayText(task.getNotes()));
				
				Label lblEditRemove = new Label(frameTask, SWT.NONE);
				lblEditRemove.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
				lblEditRemove.setBounds(395, 23, 24, 24);
				lblEditRemove.setImage(new Image(shell.getDisplay(), FollowUpInfo.class.getResourceAsStream("/images/modify.png")));
				lblEditRemove.setData(i);
				lblEditRemove.addMouseListener(new MouseAdapter() {
					@Override
					public void mouseDown(MouseEvent e) {
						modifyTask((Integer)((Label)e.widget).getData());
					}
				});
				lblEditRemove.addMouseTrackListener(new MouseTrackAdapter() {
					@Override
					public void mouseEnter(MouseEvent e) {
						((Label)e.widget).setBackground(SWTResourceManager.getColor(235, 243, 247));
					}
					@Override
					public void mouseExit(MouseEvent e) {
						((Label)e.widget).setBackground(SWTResourceManager.getColor(255, 255, 255));
					}
				});
				
				Label lblTaskRemove = new Label(frameTask, SWT.NONE);
				lblTaskRemove.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
				lblTaskRemove.setBounds(395, 53, 24, 24);
				lblTaskRemove.setImage(new Image(shell.getDisplay(), FollowUpInfo.class.getResourceAsStream("/images/remove24.png")));
				lblTaskRemove.setData(i);
				lblTaskRemove.addMouseListener(new MouseAdapter() {
					@Override
					public void mouseDown(MouseEvent e) {
						removeTask((Integer)((Label)e.widget).getData());
					}
				});
				lblTaskRemove.addMouseTrackListener(new MouseTrackAdapter() {
					@Override
					public void mouseEnter(MouseEvent e) {
						((Label)e.widget).setBackground(SWTResourceManager.getColor(235, 243, 247));
					}
					@Override
					public void mouseExit(MouseEvent e) {
						((Label)e.widget).setBackground(SWTResourceManager.getColor(255, 255, 255));
					}
				});
				
				y+=86;
			}
					
			frameTasks.setSize(425, y);
			frameTasks.redraw();
			btnAdd.setLocation(186, frameTasks.getBounds().y+frameTasks.getBounds().height+10);
			btnAdd.redraw();
		}catch (Exception e){
			MessageDialog dlg = new MessageDialog(shell, SWT.NONE, "Error 401 : System Problems (FI336)");
			dlg.open();
		}
	}
	
	private void addTask(){
		FollowUpDialog dlg = new FollowUpDialog(shell, SWT.NONE, null, person, calendar.getTime());
		dlg.open();
		if(dlg.getTask() != null){
			Object obj = dbConnector.createTask(dlg.getTask());
			if(obj instanceof String){
				MessageDialog dlg2 = new MessageDialog(shell, SWT.NONE, "Error 400 : Database Problems (FI366)");
				dlg2.open();
				return;
			}
			
			taskCol.add(dlg.getTask());
			displayTask(calendar.getTime());
		}
	}
	
	private void modifyTask(int index){
		if(index == -1)
			return;
		
		FollowUpDialog dlg = new FollowUpDialog(shell, SWT.NONE, taskCol.get(index), null, null);
		dlg.open();
		if(dlg.getTask() != null){
			Object obj = dbConnector.updateTask(dlg.getTask(), null);
			if(obj instanceof String){
				MessageDialog dlg2 = new MessageDialog(shell, SWT.NONE, "Error 400 : Database Problems (FI366)");
				dlg2.open();
				return;
			}
			
			taskCol.set(index, dlg.getTask());
			displayTask(calendar.getTime());
		}
	}
	
	private void removeTask(int index){
		if(index == -1)
			return;
		
		Object obj = dbConnector.deleteTask(taskCol.get(index), null);
		if(obj instanceof String){
			MessageDialog dlg = new MessageDialog(shell, SWT.NONE, "Error 400 : Database Problems (FI366)");
			dlg.open();
			return;
		}
		
		taskCol.remove(index);
		displayTask(calendar.getTime());
	}
	
	private String displayText(Object obj){
		if(obj==null)
			return "";
		else
			return obj.toString();
	}
	
	@Override
	protected void checkSubclass() {
		// Disable the check that prevents subclassing of SWT components
	}
}
