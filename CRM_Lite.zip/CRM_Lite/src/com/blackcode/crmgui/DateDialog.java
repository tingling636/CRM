package com.blackcode.crmgui;

import java.util.Calendar;
import java.util.Date;

import org.eclipse.swt.events.MouseAdapter;
import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.events.MouseTrackAdapter;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.widgets.Dialog;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.SWT;
import org.eclipse.wb.swt.SWTResourceManager;
import org.eclipse.swt.widgets.DateTime;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.custom.CLabel;

public class DateDialog extends Dialog {

	protected Object result;
	protected Shell shell;

	private DateTime dateTimeFrom, dateTimeTo;
	
	private Date fromDate, toDate;
	/**
	 * Create the dialog.
	 * @param parent
	 * @param style
	 */
	public DateDialog(Shell parent, int style) {
		super(parent, style);
		setText("SWT Dialog");
	}

	/**
	 * Open the dialog.
	 * @return the result
	 */
	public Object open() {
		createContents();
		shell.open();
		shell.layout();
		Display display = getParent().getDisplay();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
		return result;
	}

	/**
	 * Create contents of the dialog.
	 */
	private void createContents() {
		shell = new Shell(getParent(), getStyle());
		shell.setSize(216, 110);
		shell.setText(getText());
		shell.setLocation((getParent().getBounds().width/2)-(shell.getBounds().width/2), 30);
		
		Composite composite = new Composite(shell, SWT.NONE);
		composite.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		composite.setBounds(0, 0, 214, 70);
		
		Composite frameTitle = new Composite(composite, SWT.NONE);
		frameTitle.setBackground(SWTResourceManager.getColor(50, 50, 50));
		frameTitle.setBounds(0, 0, shell.getBounds().width, 26);
		
		Label lblTitle = new Label(frameTitle, SWT.NONE);
		lblTitle.setForeground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblTitle.setFont(SWTResourceManager.getFont("Georgia", 8, SWT.BOLD));
		lblTitle.setBounds(5, 6, 133, 15);
		lblTitle.setBackground(SWTResourceManager.getColor(50, 50, 50));
		lblTitle.setText("Date Range");
		
		final Label lblCloseAction = new Label(frameTitle, SWT.CENTER);
		lblCloseAction.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				shell.close();
			}
		});
		lblCloseAction.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				lblCloseAction.setBackground(SWTResourceManager.getColor(100, 100, 100));
			}
			@Override
			public void mouseExit(MouseEvent e) {
				lblCloseAction.setBackground(SWTResourceManager.getColor(50, 50, 50));
			}
		});
		lblCloseAction.setBounds(186, 3, 20, 20);
		lblCloseAction.setBackground(SWTResourceManager.getColor(50, 50, 50));
		lblCloseAction.setImage(new Image(shell.getDisplay(), this.getClass().getResourceAsStream("/images/close.png")));
		lblCloseAction.setToolTipText("Close Window");
		
		dateTimeFrom = new DateTime(composite, SWT.BORDER | SWT.DROP_DOWN);
		dateTimeFrom.setBounds(13, 36, 80, 24);
		
		Label label = new Label(composite, SWT.NONE);
		label.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		label.setBounds(100, 41, 10, 15);
		label.setText("-");
		
		dateTimeTo = new DateTime(composite, SWT.BORDER | SWT.DROP_DOWN);
		dateTimeTo.setBounds(117, 36, 80, 24);
		
		final CLabel lblOk = new CLabel(shell, SWT.CENTER);
		lblOk.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				Calendar c = Calendar.getInstance();
				c.set(dateTimeFrom.getYear(), dateTimeFrom.getMonth(), dateTimeFrom.getDay(), 0, 0);  
				fromDate = c.getTime();
				c.set(dateTimeTo.getYear(), dateTimeTo.getMonth(), dateTimeTo.getDay(), 0, 0);  
				toDate = c.getTime();
				shell.close();
			}
		});
		lblOk.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				lblOk.setBackground(SWTResourceManager.getColor(86, 86, 86));
			}
			@Override
			public void mouseExit(MouseEvent e) {
				lblOk.setBackground(SWTResourceManager.getColor(45, 45, 45));
			}
		});
		lblOk.setBounds(77, 75, 70, 26);
		lblOk.setBackground(SWTResourceManager.getColor(45, 45, 45));
		lblOk.setForeground(SWTResourceManager.getColor(245, 245, 245));
		lblOk.setFont(SWTResourceManager.getFont("Georgia", 9, SWT.BOLD));
		lblOk.setText("OK");

	}
	
	public Date[] getSelectedDate(){
		return new Date[]{fromDate, toDate};
	}
}
