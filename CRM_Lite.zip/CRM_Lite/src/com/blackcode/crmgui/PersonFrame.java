package com.blackcode.crmgui;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.events.MouseTrackAdapter;
import org.eclipse.swt.events.VerifyEvent;
import org.eclipse.swt.events.VerifyListener;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.TraverseListener;
import org.eclipse.swt.events.TraverseEvent;
import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.graphics.GlyphMetrics;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.wb.swt.SWTResourceManager;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.Menu;
import org.eclipse.swt.widgets.MenuItem;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.TableItem;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.custom.CLabel;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.events.MouseAdapter;
import org.eclipse.swt.custom.PaintObjectEvent;
import org.eclipse.swt.custom.PaintObjectListener;
import org.eclipse.swt.custom.ScrolledComposite;
import org.eclipse.swt.custom.StyleRange;
import org.eclipse.swt.custom.StyledText;

import com.blackcode.core.CalendarUtil;
import com.blackcode.core.FileConvertor;
import com.blackcode.core.SQLiteConnector;
import com.blackcode.model.Account;
import com.blackcode.model.Contact;
import com.blackcode.model.EmailController;

public class PersonFrame extends Composite {	
	private ApplicationLiteMain main;
	private Shell shell;
	private Text txtFind;
	private Composite frameTopActionBar;
	private Label lblAddAction;
	private Label lblEditAction;
	private Label lblDeleteAction;
	private Label lblMenuAction;
	private Combo cmbAccount;
	private Table tblPerson;
	private Composite framePersonTitle;
	private Composite framePersonList;
	private Composite framePersonDetail;
	private ScrolledComposite scrolledComposite;
	private Composite frameMain;
	private Composite frameSide;
	private Button btnSeparator;
	private CLabel lblTitleName;
	private Label lblMarkAction;
	private CLabel lblSubTitle;
	private CLabel lblSaveAction;
	private CLabel lblCancelAction;
	private Composite frameInfo;
	private CLabel lblInformation;
	private StyledText lblPicture;
	private CLabel lblPosition;
	private CLabel lblCompany;
	private Label lblSalesClick;
	private Label lblReminderClick;
	private Label lblHistoryClick;
	private Label lblEmailClick;
	private Label lblLinkedInClick;
	private Label lblFacebookClick;
	private Label lblTwitterClick;
	private Composite frameActions;
	private StyledText styledText;
	private CLabel lblInfoTitle;
	private StyledText sytxtInfoValue;
	private Table tblContact;
	private Menu popupMenu;
	private CLabel lblTag;

	private int layoutMode = 0;
	private int selectedIndex = -1;
	private PersonInfo frameNewPerson=null;
	private FollowUpInfo frameFollowup=null;
	private PersonEmail frameEmail= null;
	private PersonActivity frameActivity = null;
	private PersonSales frameSales = null;
	private Contact selectedPerson = null;	
	private String framePersonMode;
	private Account account;
	private List<Contact> personCol = null;
	private Image[] images = new Image[] { };
	private int[] offsets = new int[images.length];	 
	private SQLiteConnector dbConnector = new SQLiteConnector();
	private SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");	
	private String orderBy = "firstName";
	private EmailController controller;
	private Object[] tblColumns = new Object[]{new Object[]{"Account",70}, new Object[]{"Contact Id",70}, new Object[]{"Name",220}, new Object[]{"Gender",65},
			new Object[]{"DOB",80}, new Object[]{"Position",120}, new Object[]{"Company",180}, new Object[]{"Group",100}, new Object[]{"Home Phone",90}, new Object[]{"Mobile",90},
			new Object[]{"Work Phone",90}, new Object[]{"Personal Email",120}, new Object[]{"Work Email",120}};
	private String[] tags = new String[]{"A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z"};
	
	/**
	 * Create the composite.
	 * @param parent
	 * @param style
	 */
	public PersonFrame(Composite parent, int style, ApplicationLiteMain main, Account myaccount) {
		super(parent, style);
		shell = parent.getShell();
		this.main = main;
		this.account = myaccount;
		setBackground(SWTResourceManager.getColor(255, 255, 255));
		
		frameTopActionBar = new Composite(this, SWT.NONE);
		frameTopActionBar.setBackground(SWTResourceManager.getColor(77, 99, 132));
		frameTopActionBar.setBounds(0, 0, shell.getBounds().width-60, 35);
		
		txtFind = new Text(frameTopActionBar, SWT.BORDER);
		txtFind.addTraverseListener(new TraverseListener() {
			public void keyTraversed(TraverseEvent e) {
				quickSearch();
			}
		});
		txtFind.setText("Find");
		txtFind.setFont(SWTResourceManager.getFont("Georgia", 12, SWT.NORMAL));
		txtFind.setBounds(5, 5, 195, 25);
		
		lblAddAction = new Label(frameTopActionBar, SWT.NONE);
		lblAddAction.setToolTipText("Create New Account");
		lblAddAction.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {	
				framePersonMode = "ADD";
				
				if(frameNewPerson != null)
					frameNewPerson.dispose();
				openAddFrame(new Contact());
				hideFrameSide(0);
				selectedPerson = null;
				frameMain.setVisible(false);
			}
		});
		lblAddAction.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				lblAddAction.setBackground(SWTResourceManager.getColor(52, 64, 88));
				lblAddAction.setImage(new Image(shell.getDisplay(), PersonFrame.class.getResourceAsStream("/images/add25_selected.png")));
			}
			@Override
			public void mouseExit(MouseEvent e) {
				lblAddAction.setBackground(SWTResourceManager.getColor(77, 99, 132));
				lblAddAction.setImage(new Image(shell.getDisplay(), PersonFrame.class.getResourceAsStream("/images/add25.png")));
			}
		});
		lblAddAction.setBounds(frameTopActionBar.getBounds().width-158, 5, 25, 25);
		lblAddAction.setBackground(SWTResourceManager.getColor(77, 99, 132));
		lblAddAction.setImage(new Image(shell.getDisplay(), PersonFrame.class.getResourceAsStream("/images/add25.png")));
		
		lblEditAction = new Label(frameTopActionBar, SWT.NONE);
		lblEditAction.setToolTipText("Modify Selected Account");
		lblEditAction.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {				
				if(selectedPerson == null)
					return;
				
				selectedIndex = tblPerson.getSelectionIndex();
				framePersonMode = "EDIT";
				openAddFrame(selectedPerson);
				hideFrameSide(0);
				frameNewPerson.setValues(selectedPerson);
			}
		});
		lblEditAction.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				lblEditAction.setBackground(SWTResourceManager.getColor(52, 64, 88));
				lblEditAction.setImage(new Image(shell.getDisplay(), PersonFrame.class.getResourceAsStream("/images/edit25_selected.png")));
			}
			@Override
			public void mouseExit(MouseEvent e) {
				lblEditAction.setBackground(SWTResourceManager.getColor(77, 99, 132));
				lblEditAction.setImage(new Image(shell.getDisplay(), PersonFrame.class.getResourceAsStream("/images/edit25.png")));
			}
		});
		lblEditAction.setBounds(frameTopActionBar.getBounds().width-118, 5, 25, 25);
		lblEditAction.setBackground(SWTResourceManager.getColor(77, 99, 132));
		lblEditAction.setImage(new Image(shell.getDisplay(), PersonFrame.class.getResourceAsStream("/images/edit25.png")));
		
		lblDeleteAction = new Label(frameTopActionBar, SWT.NONE);
		lblDeleteAction.setToolTipText("Delete Selected Account");
		lblDeleteAction.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {				
				deleteContact();
			}
		});
		lblDeleteAction.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				lblDeleteAction.setBackground(SWTResourceManager.getColor(52, 64, 88));
				lblDeleteAction.setImage(new Image(shell.getDisplay(), PersonFrame.class.getResourceAsStream("/images/delete25_selected.png")));
			}
			@Override
			public void mouseExit(MouseEvent e) {
				lblDeleteAction.setBackground(SWTResourceManager.getColor(77, 99, 132));
				lblDeleteAction.setImage(new Image(shell.getDisplay(), PersonFrame.class.getResourceAsStream("/images/delete25.png")));
			}
		});
		lblDeleteAction.setBounds(frameTopActionBar.getBounds().width-78, 5, 25, 25);
		lblDeleteAction.setBackground(SWTResourceManager.getColor(77, 99, 132));
		lblDeleteAction.setImage(new Image(shell.getDisplay(), PersonFrame.class.getResourceAsStream("/images/delete25.png")));
		
		lblMenuAction = new Label(frameTopActionBar, SWT.NONE);
		lblMenuAction.setToolTipText("More Functions");
		lblMenuAction.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {	
				popupMenu.setVisible(true);
			}
		});
		lblMenuAction.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				lblMenuAction.setBackground(SWTResourceManager.getColor(52, 64, 88));
				lblMenuAction.setImage(new Image(shell.getDisplay(), PersonFrame.class.getResourceAsStream("/images/menu_selected.png")));
			}
			@Override
			public void mouseExit(MouseEvent e) {
				lblMenuAction.setBackground(SWTResourceManager.getColor(77, 99, 132));
				lblMenuAction.setImage(new Image(shell.getDisplay(), PersonFrame.class.getResourceAsStream("/images/menu.png")));
			}
		});
		lblMenuAction.setBounds(frameTopActionBar.getBounds().width-38, 5, 33, 25);
		lblMenuAction.setBackground(SWTResourceManager.getColor(77, 99, 132));
		lblMenuAction.setImage(new Image(shell.getDisplay(), PersonFrame.class.getResourceAsStream("/images/menu.png")));
			    
		framePersonList = new Composite(this, SWT.NONE);
		framePersonList.setBounds(0, 36, 201, shell.getBounds().height-75);
		framePersonList.setBackground(SWTResourceManager.getColor(239, 245, 249));
		
		cmbAccount = new Combo(framePersonList, SWT.BORDER | SWT.CENTER);
		cmbAccount.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				if(cmbAccount.getSelectionIndex() == -1)
					return;
				
				refreshPersonList(null);
				clear();
			}
		});
		cmbAccount.setBounds(2, 2, 196, 26);
		cmbAccount.setFont(SWTResourceManager.getFont("Georgia", 11, SWT.NORMAL));
		cmbAccount.setText("Select Account");
		cmbAccount.setVisibleItemCount(10);
		
		tblPerson = new Table(framePersonList, SWT.BORDER | SWT.FULL_SELECTION);
		tblPerson.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				selectPerson();
			}
		});
		tblPerson.addListener(SWT.MeasureItem, new Listener() {
			public void handleEvent(Event event) {
			      event.height = 25;
			      
			     /* if ((event.detail & SWT.SELECTED) == 0) return; /// item not selected

				  	Table table =(Table)event.widget;
				  	TableItem item =(TableItem)event.item;
				  	int clientWidth = table.getClientArea().width;
	
				  	GC gc = event.gc;				
				  	Color oldForeground = gc.getForeground();
				  	Color oldBackground = gc.getBackground();
	
				  	gc.setBackground(SWTResourceManager.getColor(249,176,1));
				  	item.setForeground(SWTResourceManager.getColor(255, 255, 255));				
				  	gc.fillRectangle(0, event.y, clientWidth, event.height);
	
				  	gc.setBackground(oldBackground);
				  	item.setForeground(SWTResourceManager.getColor(0, 0, 0));
				  	event.detail &= ~SWT.SELECTED;*/
			   }
			});
		tblPerson.setBounds(23, 30, 174, 520);
		tblPerson.setLinesVisible(true);
		tblPerson.setFont(SWTResourceManager.getFont("Georgia", 9, SWT.NORMAL));
		
		TableColumn tblclmnNewColumn = new TableColumn(tblPerson, SWT.NONE);
		tblclmnNewColumn.setWidth(170);
		tblclmnNewColumn.setText("New Column");
		
		for(int i=0; i<tags.length; i++){
			lblTag = new CLabel(framePersonList, SWT.BORDER | SWT.SHADOW_OUT | SWT.CENTER);
			lblTag.addMouseListener(new MouseAdapter() {
				@Override
				public void mouseDown(MouseEvent e) {
					String tag = ((CLabel)e.widget).getText();
					refreshPersonList("firstName LIKE '"+tag+"%'");
				}
			});
			lblTag.addMouseTrackListener(new MouseTrackAdapter() {
				@Override
				public void mouseEnter(MouseEvent e) {
					((CLabel)e.widget).setForeground(SWTResourceManager.getColor(255, 185, 90));
					((CLabel)e.widget).setBackground(SWTResourceManager.getColor(150, 177, 243));
				}
				@Override
				public void mouseExit(MouseEvent e) {
					((CLabel)e.widget).setForeground(SWTResourceManager.getColor(105, 144, 238));
					((CLabel)e.widget).setBackground(SWTResourceManager.getColor(181, 200, 246));
				}
			});
			lblTag.setFont(SWTResourceManager.getFont("Segoe UI", 9, SWT.BOLD));
			lblTag.setForeground(SWTResourceManager.getColor(105, 144, 238));
			lblTag.setBackground(SWTResourceManager.getColor(181, 200, 246));
			lblTag.setBounds(1, 30+(i*20), 20, 20);
			lblTag.setText(tags[i]);
		}		
		
		framePersonDetail = new Composite(this, SWT.NONE);
		framePersonDetail.setBounds(203, 36, shell.getBounds().width-265, shell.getBounds().height-75);
		framePersonDetail.setBackground(SWTResourceManager.getColor(255, 255, 255));
		
		scrolledComposite = new ScrolledComposite(framePersonDetail, SWT.H_SCROLL | SWT.V_SCROLL);
		scrolledComposite.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		scrolledComposite.setBounds(0, 0, framePersonDetail.getBounds().width-10, framePersonDetail.getBounds().height);
		scrolledComposite.setExpandHorizontal(true);
		scrolledComposite.setExpandVertical(true);
		
		tblContact = new Table(scrolledComposite, SWT.BORDER | SWT.FULL_SELECTION);
		tblContact.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDoubleClick(MouseEvent e) {
				if(tblContact.getSelectionIndex()==-1 )
					return;
				
				selectContact();
			}
		});
		tblContact.setBounds(5, 5, 85, 45);
		tblContact.setHeaderVisible(true);
		tblContact.setLinesVisible(true);
		tblContact.setVisible(false);
		
		for(int i=0; i<tblColumns.length; i++){
			Object[] tmp = (Object[])tblColumns[i];
			TableColumn tblclmn = new TableColumn(tblContact, SWT.NONE);
			tblclmn.setWidth((Integer)tmp[1]);
			tblclmn.setText((String)tmp[0]);
		}
		frameMain = new Composite(scrolledComposite, SWT.NONE);
		frameMain.setBackground(SWTResourceManager.getColor(255, 255, 255));
		frameMain.setVisible(false);
				
		framePersonTitle = new Composite(frameMain, SWT.NONE);
		framePersonTitle.setBounds(0, 0, framePersonDetail.getBounds().width-12, 31);
		framePersonTitle.setBackground(SWTResourceManager.getColor(239, 245, 249));
		
		lblTitleName = new CLabel(framePersonTitle, SWT.NONE);
		lblTitleName.setText("Person Name");
		lblTitleName.setFont(SWTResourceManager.getFont("Georgia", 10, SWT.BOLD));
		lblTitleName.setBounds(35, 5, 308, 21);
		lblTitleName.setBackground(SWTResourceManager.getColor(239, 245, 249));
		
		lblMarkAction = new Label(framePersonTitle, SWT.NONE);
		lblMarkAction.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				if(selectedPerson == null)
					return;
				
				boolean flag = selectedPerson.isFlag();
				selectedPerson.isFlag(!flag);
				dbConnector.updateContactFlag(selectedPerson, null);
				if(selectedPerson.isFlag())
					lblMarkAction.setImage(new Image(shell.getDisplay(), PersonFrame.class.getResourceAsStream("/images/star25_selected.png")));
				else
					lblMarkAction.setImage(new Image(shell.getDisplay(), PersonFrame.class.getResourceAsStream("/images/star25.png")));
			}
		});
		lblMarkAction.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				lblMarkAction.setBackground(SWTResourceManager.getColor(209, 231, 249));
			}
			@Override
			public void mouseExit(MouseEvent e) {
				lblMarkAction.setBackground(SWTResourceManager.getColor(239, 245, 249));
			}
		});
		lblMarkAction.setBounds(5, 3, 25, 25);
		lblMarkAction.setBackground(SWTResourceManager.getColor(239, 245, 249));
		lblMarkAction.setImage(new Image(shell.getDisplay(), PersonFrame.class.getResourceAsStream("/images/star25.png")));
		
		lblPicture = new StyledText(frameMain, SWT.NONE);
		lblPicture.setBounds(10, 37, 150, 150);
		lblPicture.setEnabled(false);
		lblPicture.addPaintObjectListener(new PaintObjectListener() {
		      public void paintObject(PaintObjectEvent event) {
		          GC gc = event.gc;
		          StyleRange style = event.style;
		          int start = style.start;
		          for (int i = 0; i < offsets.length; i++) {
		            int offset = offsets[i];
		            if (start == offset) {
		              Image image = images[i];
		              int x = event.x;
		              int y = event.y + event.ascent - style.metrics.ascent;
		              gc.drawImage(image, x, y);
		            }
		          }
		        }
		      });
		lblPicture.addVerifyListener(new VerifyListener() {
		      public void verifyText(VerifyEvent e) {
		          int start = e.start;
		          int replaceCharCount = e.end - e.start;
		          int newCharCount = e.text.length();
		          for (int i = 0; i < offsets.length; i++) {
		            int offset = offsets[i];
		            if (start <= offset && offset < start + replaceCharCount) {
		              // this image is being deleted from the text
		              if (images[i] != null && !images[i].isDisposed()) {
		                images[i].dispose();
		                images[i] = null;
		              }
		              offset = -1;
		            }
		            if (offset != -1 && offset >= start)
		              offset += newCharCount - replaceCharCount;
		            offsets[i] = offset;
		          }
		        }
		      });
		
		lblPosition = new CLabel(frameMain, SWT.NONE);
		lblPosition.setFont(SWTResourceManager.getFont("Georgia", 12, SWT.BOLD));
		lblPosition.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblPosition.setBounds(179, 55, 500, 28);
		lblPosition.setText("Postion");
		
		lblCompany = new CLabel(frameMain, SWT.NONE);
		lblCompany.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblCompany.setFont(SWTResourceManager.getFont("Georgia", 11, SWT.NORMAL));
		lblCompany.setBounds(179, 89, 500, 28);
		lblCompany.setText("Company");
		
		lblSalesClick = new Label(frameMain, SWT.NONE);
		lblSalesClick.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblSalesClick.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				layoutMode = 0;
				changeFrameWidth();
				//if(frameSales==null)
					openSalesFrame();
				hideFrameSide(1);
				lblSubTitle.setText("Sales");	
			}
		});
		lblSalesClick.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				lblSalesClick.setImage(new Image(shell.getDisplay(), PersonFrame.class.getResourceAsStream("/images/Suitecase30_selected.png")));
			}
			@Override
			public void mouseExit(MouseEvent e) {
				lblSalesClick.setImage(new Image(shell.getDisplay(), PersonFrame.class.getResourceAsStream("/images/Suitecase30.png")));
			}
		});
		lblSalesClick.setBounds(179, 150, 30, 30);
		lblSalesClick.setImage(new Image(shell.getDisplay(), PersonFrame.class.getResourceAsStream("/images/Suitecase30.png")));
		lblSalesClick.setToolTipText("Show Sales");
		
		lblReminderClick = new Label(frameMain, SWT.NONE);
		lblReminderClick.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblReminderClick.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {				
				layoutMode = 0;
				changeFrameWidth();
				if(frameFollowup==null)
					openFollowUpFrame();
				hideFrameSide(2);
				lblSubTitle.setText("Follow Up Task");
			}
		});
		lblReminderClick.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				lblReminderClick.setImage(new Image(shell.getDisplay(), PersonFrame.class.getResourceAsStream("/images/reminder30_selected.png")));
			}
			@Override
			public void mouseExit(MouseEvent e) {
				lblReminderClick.setImage(new Image(shell.getDisplay(), PersonFrame.class.getResourceAsStream("/images/reminder30.png")));
			}
		});
		lblReminderClick.setBounds(215, 150, 30, 30);
		lblReminderClick.setImage(new Image(shell.getDisplay(), PersonFrame.class.getResourceAsStream("/images/reminder30.png")));
		lblReminderClick.setToolTipText("Show Follow Up Tasks");
		
		lblHistoryClick = new Label(frameMain, SWT.NONE);
		lblHistoryClick.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblHistoryClick.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				layoutMode = 0;
				changeFrameWidth();
				//if(frameActivity==null)
					openHistoryFrame();
				hideFrameSide(3);
				lblSubTitle.setText("Activities");				
			}
		});
		lblHistoryClick.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				lblHistoryClick.setImage(new Image(shell.getDisplay(), PersonFrame.class.getResourceAsStream("/images/historytime30_selected.png")));
			}
			@Override
			public void mouseExit(MouseEvent e) {
				lblHistoryClick.setImage(new Image(shell.getDisplay(), PersonFrame.class.getResourceAsStream("/images/historytime30.png")));
			}
		});
		lblHistoryClick.setBounds(250, 150, 30, 30);
		lblHistoryClick.setImage(new Image(shell.getDisplay(), PersonFrame.class.getResourceAsStream("/images/historytime30.png")));
		lblHistoryClick.setToolTipText("Show Activities");
		
		lblEmailClick = new Label(frameMain, SWT.NONE);
		lblEmailClick.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblEmailClick.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {				
				layoutMode = 0;
				changeFrameWidth();
				if(frameEmail==null)
					openEmailFrame();
				hideFrameSide(4);
				lblSubTitle.setText("Emails");
			}
		});
		lblEmailClick.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				lblEmailClick.setImage(new Image(shell.getDisplay(), PersonFrame.class.getResourceAsStream("/images/email30_selected.png")));
			}
			@Override
			public void mouseExit(MouseEvent e) {
				lblEmailClick.setImage(new Image(shell.getDisplay(), PersonFrame.class.getResourceAsStream("/images/email30.png")));
			}
		});
		lblEmailClick.setBounds(285, 150, 30, 30);
		lblEmailClick.setImage(new Image(shell.getDisplay(), PersonFrame.class.getResourceAsStream("/images/email30.png")));
		lblEmailClick.setToolTipText("Show Emails");
		
		lblLinkedInClick = new Label(frameMain, SWT.NONE);
		lblLinkedInClick.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblLinkedInClick.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				lblLinkedInClick.setImage(new Image(shell.getDisplay(), PersonFrame.class.getResourceAsStream("/images/Linkedin30_selected.png")));
			}
			@Override
			public void mouseExit(MouseEvent e) {
				lblLinkedInClick.setImage(new Image(shell.getDisplay(), PersonFrame.class.getResourceAsStream("/images/linkedin30.png")));
			}
		});
		lblLinkedInClick.setBounds(320, 150, 30, 30);
		lblLinkedInClick.setImage(new Image(shell.getDisplay(), PersonFrame.class.getResourceAsStream("/images/linkedin30.png")));
		lblLinkedInClick.setToolTipText("Link to LinkedIn");
		
		lblTwitterClick = new Label(frameMain, SWT.NONE);
		lblTwitterClick.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblTwitterClick.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				lblTwitterClick.setImage(new Image(shell.getDisplay(), PersonFrame.class.getResourceAsStream("/images/twitter30.png")));
			}
			@Override
			public void mouseExit(MouseEvent e) {
				lblTwitterClick.setImage(new Image(shell.getDisplay(), PersonFrame.class.getResourceAsStream("/images/twitter30.png")));
			}
		});
		lblTwitterClick.setBounds(355, 150, 30, 30);
		lblTwitterClick.setImage(new Image(shell.getDisplay(), PersonFrame.class.getResourceAsStream("/images/twitter30.png")));
		lblTwitterClick.setToolTipText("Link to Twitter");
		
		lblFacebookClick = new Label(frameMain, SWT.NONE);
		lblFacebookClick.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblFacebookClick.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				lblFacebookClick.setImage(new Image(shell.getDisplay(), PersonFrame.class.getResourceAsStream("/images/facebook30_selected.png")));
			}
			@Override
			public void mouseExit(MouseEvent e) {
				lblFacebookClick.setImage(new Image(shell.getDisplay(), PersonFrame.class.getResourceAsStream("/images/facebook30.png")));
			}
		});
		lblFacebookClick.setBounds(390, 150, 30, 30);
		lblFacebookClick.setImage(new Image(shell.getDisplay(), PersonFrame.class.getResourceAsStream("/images/facebook30.png")));
		lblFacebookClick.setToolTipText("Link to Facebook");
		
		btnSeparator = new Button(framePersonDetail, SWT.FLAT);
		btnSeparator.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				changeFrameWidth();
			}
		});
		btnSeparator.setBounds(scrolledComposite.getBounds().width, 0, 10, shell.getBounds().height-75);
		btnSeparator.setImage(new Image(shell.getDisplay(), PersonFrame.class.getResourceAsStream("/images/separator.png")));			
		
		frameSide = new Composite(framePersonDetail, SWT.NONE);
		frameSide.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
				
		lblSubTitle = new CLabel(frameSide, SWT.NONE);
		lblSubTitle.setForeground(SWTResourceManager.getColor(52, 64, 88));
		lblSubTitle.setFont(SWTResourceManager.getFont("Georgia", 11, SWT.BOLD));
		lblSubTitle.setBackground(SWTResourceManager.getColor(255, 255, 255));
		lblSubTitle.setBounds(0, 0, 200, 30);
		lblSubTitle.setVisible(false);
		
		lblSaveAction = new CLabel(frameSide, SWT.CENTER);
		lblSaveAction.setForeground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblSaveAction.setFont(SWTResourceManager.getFont("Georgia", 11, SWT.BOLD));
		lblSaveAction.setBounds(0, 0, 120, 30);
		lblSaveAction.setBackground(SWTResourceManager.getColor(52, 64, 88));
		lblSaveAction.setText("Done");
		lblSaveAction.setVisible(false);
		lblSaveAction.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				if(frameNewPerson == null)
					return;
				saveContact();
			}
		});
		lblSaveAction.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				lblSaveAction.setBackground(SWTResourceManager.getColor(77, 99, 132));
				lblSaveAction.setForeground(SWTResourceManager.getColor(52, 64, 88));
			}
			@Override
			public void mouseExit(MouseEvent e) {
				lblSaveAction.setBackground(SWTResourceManager.getColor(52, 64, 88));
				lblSaveAction.setForeground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
			}
		});
		
		lblCancelAction = new CLabel(frameSide, SWT.CENTER);
		lblCancelAction.setForeground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblCancelAction.setFont(SWTResourceManager.getFont("Georgia", 10, SWT.BOLD));
		lblCancelAction.setBounds(122, 0, 120, 30);
		lblCancelAction.setBackground(SWTResourceManager.getColor(52, 64, 88));
		lblCancelAction.setText("Cancel");
		lblCancelAction.setVisible(false);
		lblCancelAction.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				layoutMode = 1;
				changeFrameWidth();
			}
		});
		lblCancelAction.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				lblCancelAction.setBackground(SWTResourceManager.getColor(77, 99, 132));
				lblCancelAction.setForeground(SWTResourceManager.getColor(52, 64, 88));
			}
			@Override
			public void mouseExit(MouseEvent e) {
				lblCancelAction.setBackground(SWTResourceManager.getColor(52, 64, 88));
				lblCancelAction.setForeground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
			}
		});
		
		popupMenu = new Menu(lblMenuAction);
	    MenuItem exportContactsItem = new MenuItem(popupMenu, SWT.NONE);
	    exportContactsItem.setText("Export Contact List");
	    exportContactsItem.addListener(SWT.Selection, new Listener() {
	        public void handleEvent(Event e) {
	        	PersonExportDialog dlg = new PersonExportDialog(shell, SWT.DIALOG_TRIM, personCol);
	        	dlg.open();
	          }
	        });
	    MenuItem exportContactItem = new MenuItem(popupMenu, SWT.NONE);
	    exportContactItem.setText("Export Selected Contact");
	    exportContactItem.addListener(SWT.Selection, new Listener() {
	        public void handleEvent(Event e) {
	        	if(selectedPerson == null)
	        		return;
	        	PersonExportDialog dlg = new PersonExportDialog(shell, SWT.DIALOG_TRIM, selectedPerson);
	        	dlg.open();
	          }
	        });
	    MenuItem filterItem = new MenuItem(popupMenu, SWT.NONE);
	    filterItem.addListener(SWT.Selection, new Listener() {
	        public void handleEvent(Event e) {
	        	PersonFilterDialog dlg = new PersonFilterDialog(shell, SWT.NONE);
	        	dlg.open();
	        	if(dlg.isSearch()){
	        		refreshPersonList(dlg.getSearchSQL());
        			refreshMainFrame();
        			
	        		clear();
	        	}
	          }
	        });
	    filterItem.setText("Filter");
	    MenuItem accountItem = new MenuItem(popupMenu, SWT.NONE);
	    accountItem.addListener(SWT.Selection, new Listener() {
	        public void handleEvent(Event e) {
	        	AccountDialog dlg = new AccountDialog(shell, SWT.NONE, account);
	        	dlg.open();
	          }
	        });
	    accountItem.setText("Account");
	    
	    lblMenuAction.setMenu(popupMenu);
	    
		scrolledComposite.setBounds(0, 0, 0, 0);
		scrolledComposite.setContent(frameMain);
		scrolledComposite.setMinSize(frameMain.computeSize(SWT.DEFAULT, SWT.DEFAULT));		
		
		initialize();
	}
	
	private void initialize(){		
		try{
			framePersonList.setBounds(0, 36, 201, shell.getBounds().height-75);
			framePersonList.setVisible(true);
			framePersonDetail.setBounds(203, 36, shell.getBounds().width-265, shell.getBounds().height-75);
			tblContact.setSize(0, 0);
			tblContact.setVisible(false);
			
			scrolledComposite.setBounds(0, 0, framePersonDetail.getBounds().width-10, framePersonDetail.getBounds().height);
			btnSeparator.setBounds(scrolledComposite.getBounds().width, 0, 10, shell.getBounds().height-75);
			shell.redraw();
			
			cmbAccount.removeAll();
			cmbAccount.add(account.getCode());
			cmbAccount.select(0);				
			refreshPersonList(null);
		}catch(Exception e){
			MessageDialog dlg = new MessageDialog(framePersonDetail.getShell(), SWT.NONE, "Error 401 : System Problems (PF733)");
			dlg.open();
		}
	}
	
	private void changeFrameWidth(){
		popupMenu.setVisible(false);
		
		if(layoutMode == 0){
			layoutMode = 1;
			
			scrolledComposite.setBounds(0, 0, ((framePersonDetail.getBounds().width/3*2)-40)-15, framePersonDetail.getBounds().height);
			btnSeparator.setBounds(scrolledComposite.getBounds().width, 0, 10, shell.getBounds().height-75);
			frameSide.setBounds(((framePersonDetail.getBounds().width/3*2)-40), 0, (framePersonDetail.getBounds().width/3), framePersonDetail.getBounds().height);
		}else{
			layoutMode = 0;
			
			scrolledComposite.setBounds(0, 0, framePersonDetail.getBounds().width-10, framePersonDetail.getBounds().height);
			btnSeparator.setBounds(scrolledComposite.getBounds().width, 0, 10, shell.getBounds().height-75);
			frameSide.setBounds(0, 0, 0, 0);
		}
		
		framePersonDetail.redraw();
	}
	
	private void selectContact(){		
		try{
			clear();
			selectedPerson = personCol.get(tblContact.getSelectionIndex());
			selectedIndex = tblPerson.getSelectionIndex();
			framePersonMode = "EDIT";
			openAddFrame(selectedPerson);
			hideFrameSide(0);
			frameNewPerson.setValues(selectedPerson);
		}catch(Exception e){
			MessageDialog dlg = new MessageDialog(framePersonDetail.getShell(), SWT.NONE, "Error 401 : System Problems (PF825)");
			dlg.open();
		}
	}
	
	// Profile Detail Mode
	private void refreshPersonList(String whereClause){
		try{
			//reset email account
			controller = null;
			
			String sql = null;
			if(whereClause != null)
				sql = whereClause;
			else{
				sql = "accountId='"+account.getCode()+"'";
			}
			
			Object obj = dbConnector.readContact(null, sql, orderBy);
			if(obj instanceof String){
				MessageDialog dlg = new MessageDialog(framePersonDetail.getShell(), SWT.NONE, "Error 400 : Database Problems (PF1090)");
				dlg.open();
				return;
			}
			personCol = (List<Contact>)obj;
			tblPerson.removeAll();
			
			for(int i=0; i<personCol.size(); i++){
				TableItem ti = new TableItem(tblPerson, SWT.NONE);
				ti.setText(((Contact)personCol.get(i)).getFullName());
				ti.setData(personCol.get(i));
			}
			
			tblPerson.redraw();
		} catch (Exception e) {
        	MessageDialog dlg = new MessageDialog(framePersonDetail.getShell(), SWT.NONE, "Error 401 : System Problems (PF1130)");
  			dlg.open();
        }		
	}
	
	
	private void selectPerson(){
		if(tblPerson.getSelectionIndex() == -1)
			return;
				
		clear();
		selectedPerson = (Contact)tblPerson.getItem(tblPerson.getSelectionIndex()).getData();
		refreshMainFrame();
	}
	
	// Display contact's detail
	private void refreshMainFrame(){
		try{
			if(frameActions != null)
				frameActions.dispose();
			if(frameInfo != null)
				frameInfo.dispose();
			
			if(selectedPerson == null){
				frameMain.setVisible(false);
				return;
			}
			
			frameMain.setVisible(true);
			lblTitleName.setText(selectedPerson.getFullNameWithNick());
			lblPosition.setText(selectedPerson.getJobTitle());
			lblCompany.setText(selectedPerson.getCompany());
			if(selectedPerson.isFlag())
				lblMarkAction.setImage(new Image(shell.getDisplay(), PersonFrame.class.getResourceAsStream("/images/star25_selected.png")));
			else
				lblMarkAction.setImage(new Image(shell.getDisplay(), PersonFrame.class.getResourceAsStream("/images/star25.png")));
			
			frameActions = new Composite(frameMain, SWT.NONE);
			frameActions.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
			frameActions.setBounds(10, 198, 697, 137);
			
			CLabel lblActions = new CLabel(frameActions, SWT.SHADOW_OUT | SWT.CENTER);
			lblActions.setFont(SWTResourceManager.getFont("Georgia", 9, SWT.BOLD));
			lblActions.setBounds(0, 0, 687, 25);
			lblActions.setText("Actions");
			
			org.eclipse.swt.graphics.Cursor cursor = new org.eclipse.swt.graphics.Cursor(shell.getDisplay(), SWT.CURSOR_ARROW);
			
			int py = 31;
			List<String[]> phones = selectedPerson.phonesDisplayDetail();
			for(int i=0; i<phones.size(); i++){
				String[] phoneStr = (String[])phones.get(i);
				
				styledText = new StyledText(frameActions, SWT.CENTER);
				styledText.addMouseListener(new MouseAdapter() {
					@Override
					public void mouseDown(MouseEvent e) {				
						String[] lines = ((StyledText)e.widget).getText().split("\n");					
						call(lines[1]);
					}
				});
				styledText.addMouseTrackListener(new MouseTrackAdapter() {
					@Override
					public void mouseEnter(MouseEvent e) {
						((StyledText)e.widget).setBackgroundImage(new Image(shell.getDisplay(), PersonFrame.class.getResourceAsStream("/images/phoneAction_selected2.png")));
					}
					@Override
					public void mouseExit(MouseEvent e) {
						((StyledText)e.widget).setBackgroundImage(new Image(shell.getDisplay(), PersonFrame.class.getResourceAsStream("/images/phoneAction.png")));
					}
				});
				styledText.setBounds(10, py,220, 45);
				styledText.setBackgroundImage(new Image(shell.getDisplay(), PersonFrame.class.getResourceAsStream("/images/phoneAction.png")));
				styledText.setMargins(10, 7, 5, 5);
				styledText.setText(phoneStr[0]+"\n"+phoneStr[1]);
				styledText.setCursor(cursor);
				styledText.setToolTipText("Call");
				styledText.setEditable(false);
				
				py+= 49;
			}
			
			int ey = 31;
			List<String[]> emails = selectedPerson.emailsDisplayDetail();
			for(int i=0; i<emails.size(); i++){
				String[] emailStr = (String[])emails.get(i);
				
				styledText = new StyledText(frameActions, SWT.CENTER);
				styledText.addMouseListener(new MouseAdapter() {
					@Override
					public void mouseDown(MouseEvent e) {				
						String[] lines = ((StyledText)e.widget).getText().split("\n");					
						sendEmail(lines[1]);
					}
				});
				styledText.addMouseTrackListener(new MouseTrackAdapter() {
					@Override
					public void mouseEnter(MouseEvent e) {
						((StyledText)e.widget).setBackgroundImage(new Image(shell.getDisplay(), PersonFrame.class.getResourceAsStream("/images/emailAction_selected.png")));
					}
					@Override
					public void mouseExit(MouseEvent e) {
						((StyledText)e.widget).setBackgroundImage(new Image(shell.getDisplay(), PersonFrame.class.getResourceAsStream("/images/emailAction.png")));
					}
				});
				styledText.setBounds(290, ey,280, 45);
				styledText.setBackgroundImage(new Image(shell.getDisplay(), PersonFrame.class.getResourceAsStream("/images/emailAction.png")));
				styledText.setMargins(10, 7, 5, 5);
				styledText.setText(emailStr [0]+"\n"+emailStr [1]);
				styledText.setCursor(cursor);
				styledText.setToolTipText("Send Email");
				styledText.setEditable(false);
				
				ey+= 49;
			}
			
			frameActions.setSize(697, py>ey?(py+5):(ey+5));
			frameActions.redraw();
			
			frameInfo = new Composite(frameMain, SWT.NONE);
			frameInfo.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
			frameInfo.setBounds(10, 341, 697, 137);
			
			lblInformation = new CLabel(frameInfo, SWT.SHADOW_OUT | SWT.CENTER);
			lblInformation.setFont(SWTResourceManager.getFont("Georgia", 9, SWT.BOLD));
			lblInformation.setBounds(0, 0, 687, 25);
			lblInformation.setText("Information");	
			
			int iy = 31;
			lblInfoTitle = new CLabel(frameInfo, SWT.RIGHT);
			lblInfoTitle.setBounds(10, iy, 150, 25);
			lblInfoTitle.setMargins(10, 5, 10, 5);
			lblInfoTitle.setBackground(SWTResourceManager.getColor(235, 243, 247));
			lblInfoTitle.setText("Account");
			
			sytxtInfoValue = new StyledText(frameInfo, SWT.BORDER);
			sytxtInfoValue.setBounds(170, iy, 320, 25);
			sytxtInfoValue.setMargins(10, 2, 10, 0);
			sytxtInfoValue.setEditable(false);
			sytxtInfoValue.setText(selectedPerson.getAccountId());
			iy += 28;
			
			lblInfoTitle = new CLabel(frameInfo, SWT.RIGHT);
			lblInfoTitle.setBounds(10, iy, 150, 25);
			lblInfoTitle.setMargins(10, 5, 10, 5);
			lblInfoTitle.setBackground(SWTResourceManager.getColor(235, 243, 247));
			lblInfoTitle.setText("Contact Id");
			
			sytxtInfoValue = new StyledText(frameInfo, SWT.BORDER);
			sytxtInfoValue.setBounds(170, iy, 320, 25);
			sytxtInfoValue.setMargins(10, 2, 10, 0);
			sytxtInfoValue.setEditable(false);
			sytxtInfoValue.setText(selectedPerson.getContactId());
			iy += 28;
			
			if(selectedPerson.getWorkAddress() != null){
				lblInfoTitle = new CLabel(frameInfo, SWT.RIGHT);
				lblInfoTitle.setBounds(10, iy, 150, 25);
				lblInfoTitle.setMargins(10, 5, 10, 5);
				lblInfoTitle.setBackground(SWTResourceManager.getColor(235, 243, 247));
				lblInfoTitle.setText("Work Address");
				
				sytxtInfoValue = new StyledText(frameInfo, SWT.BORDER);
				sytxtInfoValue.setBounds(170, iy, 320, 75);
				sytxtInfoValue.setMargins(10, 2, 10, 0);
				sytxtInfoValue.setEditable(false);
				sytxtInfoValue.setText(selectedPerson.getWorkAddress());
				iy += 78;
			}
			
			if(selectedPerson.getHomeAddress() != null){
				lblInfoTitle = new CLabel(frameInfo, SWT.RIGHT);
				lblInfoTitle.setBounds(10, iy, 150, 25);
				lblInfoTitle.setMargins(10, 5, 10, 5);
				lblInfoTitle.setBackground(SWTResourceManager.getColor(235, 243, 247));
				lblInfoTitle.setText("Home Address");
				
				sytxtInfoValue = new StyledText(frameInfo, SWT.BORDER);
				sytxtInfoValue.setBounds(170, iy, 320, 75);
				sytxtInfoValue.setMargins(10, 2, 10, 0);
				sytxtInfoValue.setEditable(false);
				sytxtInfoValue.setText(selectedPerson.getHomeAddress());
				iy += 78;
			}
			
			if(selectedPerson.getDob() != null){
				lblInfoTitle = new CLabel(frameInfo, SWT.RIGHT);
				lblInfoTitle.setBounds(10, iy, 150, 25);
				lblInfoTitle.setMargins(10, 5, 10, 5);
				lblInfoTitle.setBackground(SWTResourceManager.getColor(235, 243, 247));
				lblInfoTitle.setText("DOB");
				
				sytxtInfoValue = new StyledText(frameInfo, SWT.BORDER);
				sytxtInfoValue.setBounds(170, iy, 320, 25);
				sytxtInfoValue.setMargins(10, 2, 10, 0);
				sytxtInfoValue.setEditable(false);
				sytxtInfoValue.setText(sdf.format(selectedPerson.getDob())+" ( "+CalendarUtil.calculateAgaingInYear(
						selectedPerson.getDob().getYear()+1900, selectedPerson.getDob().getMonth(), selectedPerson.getDob().getDate())+" years old )");
				iy += 28;
			}
			
			List<String[]>customFields = selectedPerson.dataDisplayDetail();
			for(int i=0; i<customFields.size(); i++){
				String[] field = customFields.get(i);
				
				lblInfoTitle = new CLabel(frameInfo, SWT.RIGHT);
				lblInfoTitle.setBounds(10, iy, 150, 25);
				lblInfoTitle.setMargins(10, 5, 10, 5);
				lblInfoTitle.setBackground(SWTResourceManager.getColor(235, 243, 247));
				lblInfoTitle.setText(field[0]);
				
				sytxtInfoValue = new StyledText(frameInfo, SWT.BORDER);
				sytxtInfoValue.setBounds(170, iy, 320, 25);
				sytxtInfoValue.setMargins(10, 2, 10, 0);
				sytxtInfoValue.setEditable(false);
				sytxtInfoValue.setText(field[1]);
				iy += 28;
			}
			
			int y = frameActions.getBounds().y + frameActions.getBounds().height + 7;
			frameInfo.setBounds(10, y, 697, iy);
			frameInfo.redraw();
			
			if(selectedPerson.getSocialNetworks() != null){
				lblLinkedInClick.setEnabled(selectedPerson.getSocialNetworks().contains("LinkedIn"));
				lblTwitterClick.setEnabled(selectedPerson.getSocialNetworks().contains("Twitter"));
				lblFacebookClick.setEnabled(selectedPerson.getSocialNetworks().contains("Facebook"));
			}else{
				lblLinkedInClick.setEnabled(false);
				lblTwitterClick.setEnabled(false);
				lblFacebookClick.setEnabled(false);
			}
			
			images = new Image[] { };
			offsets = new int[images.length];
			lblPicture.setText("");
			if(selectedPerson.getPhoto() != null){
				String filepath = FileConvertor.convertByteArrayToFile(selectedPerson.getPhoto(),"C:\\ProgramData\\BlackCodeCRM\\tmp.png").getPath();
				insertPicture(filepath);
			}
		}catch(Exception e){
			MessageDialog dlg = new MessageDialog(framePersonDetail.getShell(), SWT.NONE, "Error 401 : System Problems (PF1058)");
			dlg.open();
		}
	}
	
	private void insertPicture(String filename){
		try {
			Image image = new Image(shell.getDisplay(), filename);
            int offset = lblPicture.getCaretOffset();
            lblPicture.replaceTextRange(offset, 0, "\uFFFC");
            int index = 0;
            while (index < offsets.length) {
            	if (offsets[index] == -1 && images[index] == null)
            		break;
            	index++;
            }
            
            if (index == offsets.length) {
            	int[] tmpOffsets = new int[index + 1];
            	System.arraycopy(offsets, 0, tmpOffsets, 0, offsets.length);
            	offsets = tmpOffsets;
            	Image[] tmpImages = new Image[index + 1];
            	System.arraycopy(images, 0, tmpImages, 0, images.length);
            	images = tmpImages;
            }
            
            offsets[index] = offset;
            images[index] = image;
            addImage(image, offset);
		} catch (Exception e) {
        	MessageDialog dlg = new MessageDialog(framePersonDetail.getShell(), SWT.NONE, "Error 401 : System Problems (PF1088)");
  			dlg.open();
        }
	}
	
	private void addImage(Image image, int offset) {
	    StyleRange style = new StyleRange();
	    style.start = offset;
	    style.length = 1;
	    Rectangle rect = image.getBounds();
	    style.metrics = new GlyphMetrics(rect.height, 0, rect.width);
	    lblPicture.setStyleRange(style);
	}
	
	private void clear(){
		//selectedIndex = -1;
		layoutMode = 1;
		changeFrameWidth();
		
		if(frameNewPerson != null){
			frameNewPerson.dispose();
			frameNewPerson = null;
		}
		if(frameEmail != null){
			frameEmail.dispose();
			frameEmail = null;
		}
		if(frameFollowup != null){
			frameFollowup.dispose();
			frameFollowup = null;
		}
		if(frameActivity != null){
			frameActivity.dispose();
			frameActivity = null;
		}
		if(frameSales != null){
			frameSales.dispose();
			frameSales = null;
		}
		
		lblSaveAction.setVisible(false);
		lblCancelAction.setVisible(false);
		lblSubTitle.setVisible(false);
	}
	
	private void openAddFrame(Contact person){				
		layoutMode = 0;
		changeFrameWidth();
		frameNewPerson = new PersonInfo(frameSide, SWT.NONE, person);
		frameNewPerson.setBounds(0, 32, frameSide.getBounds().width, frameSide.getBounds().height-30);
	}
	
	private void openFollowUpFrame(){		
		layoutMode = 0;
		changeFrameWidth();		
		
		frameFollowup = new FollowUpInfo(frameSide, SWT.NONE, selectedPerson.getContactId());
		frameFollowup.setBounds(0, 32, frameSide.getBounds().width, frameSide.getBounds().height-30);
	}
	
	private void openEmailFrame(){	
		layoutMode = 0;
		changeFrameWidth();
		
		frameEmail = new PersonEmail(frameSide, SWT.NONE, selectedPerson, controller);
		frameEmail.setBounds(0, 32, frameSide.getBounds().width, frameSide.getBounds().height-30);
		controller = frameEmail.getController();
	}
	
	private void openSalesFrame(){
		layoutMode = 0;
		changeFrameWidth();
		
		if(frameSales != null)
			frameSales.dispose();
		frameSales = new PersonSales(frameSide, SWT.NONE, selectedPerson.getContactId());
		frameSales.setBounds(0, 32, frameSide.getBounds().width, frameSide.getBounds().height-30);
	}
	
	private void openHistoryFrame(){
		layoutMode = 0;
		changeFrameWidth();
		
		if(frameActivity != null)
			frameActivity.dispose();
		frameActivity = new PersonActivity(frameSide, SWT.NONE, selectedPerson.getContactId());
		frameActivity.setBounds(0, 32, frameSide.getBounds().width, frameSide.getBounds().height-30);
	}
	
	private void hideFrameSide(int index){
		if(frameNewPerson != null){
			frameNewPerson.setVisible(index==0);
		}
		if(frameSales != null){
			frameSales.setVisible(index==1);			
		}
		if(frameFollowup != null){
			frameFollowup.setVisible(index==2);			
		}
		if(frameActivity != null){
			frameActivity.setVisible(index==3);			
		}
		if(frameEmail != null){
			frameEmail.setVisible(index==4);			
		}
		
		if(index == 0){
			lblSaveAction.setVisible(true);
			lblCancelAction.setVisible(true);
			lblSubTitle.setVisible(false);
		}else{
			lblSaveAction.setVisible(false);
			lblCancelAction.setVisible(false);
			lblSubTitle.setVisible(true);
		}
		
	}
	
	private void call(String number){
		if(selectedPerson == null)
			return;
		
		try{
			main.selectTool(0);
			main.getCallFrame().selectContactPerson(selectedPerson, null, number);
		}catch (Exception e){
			MessageDialog dlg = new MessageDialog(framePersonDetail.getShell(), SWT.NONE, "Error 500 : Email Problems (PF1198)");
			dlg.open();
		}
	}
	
	private void sendEmail(String emailId){		
		if(selectedPerson == null)
			return;
		
		try{
			
			if(account == null){
				MessageDialog dlg = new MessageDialog(framePersonDetail.getShell(), SWT.NONE, "Error 500 : System Problems (PF1234)");
				dlg.open();
				return;
			}
			
			MailComposeDialog dlg = new MailComposeDialog(shell, SWT.NONE, account, emailId, selectedPerson);
			dlg.open();
		}catch (Exception e){
			e.printStackTrace();
			MessageDialog dlg = new MessageDialog(framePersonDetail.getShell(), SWT.NONE, "Error 500 : Email Problems (PF1198)");
			dlg.open();
		}
	}
			
	private void saveContact(){
		Contact contactValues = frameNewPerson.getValues();
		
		try{
			Calendar c = Calendar.getInstance();
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-mm-dd hh:mm:ss");
			Date now = sdf.parse(sdf.format(c.getTime()));
			
			if(framePersonMode.equalsIgnoreCase("ADD")){
				contactValues.setCreatedOn(new Timestamp(now.getTime()));
				
				Object obj = dbConnector.createContact(contactValues);
				if(obj instanceof String){
					MessageDialog dlg = new MessageDialog(framePersonDetail.getShell(), SWT.NONE,"Error 400 : Database Problems (PF1217)");
					dlg.open();
					return;
				}
				
			}else if(framePersonMode.equalsIgnoreCase("EDIT")){
				contactValues.setUpdatedOn(new Timestamp(now.getTime()));
				
				Object obj = dbConnector.updateContact(contactValues, null);
				if(obj instanceof String){
					MessageDialog dlg = new MessageDialog(framePersonDetail.getShell(), SWT.NONE,"Error 400 : Database Problems (PF1229)");
					dlg.open();
					return;
				}
			}		
			selectedPerson = contactValues;
			
			refreshPersonList(null);
			
			for(int i=0; i<personCol.size(); i++){
				if(((Contact)personCol.get(i)).getContactId().equals(selectedPerson.getContactId())){
					selectedIndex = i;
					tblPerson.select(selectedIndex);
					break;
				}
			}
			
			refreshMainFrame();
			clear();
			
		}catch (Exception e){
			MessageDialog dlg = new MessageDialog(framePersonDetail.getShell(), SWT.NONE, "Error 401 : System Problems (PF1257)");
			dlg.open();
		}
	}
	
	private void deleteContact(){
		if(selectedPerson == null)
			return;
		
		try{
			Object obj = dbConnector.deleteContact(selectedPerson, null);
			if(obj instanceof String){
				MessageDialog dlg = new MessageDialog(framePersonDetail.getShell(), SWT.NONE,"Error 400 : Database Problems (PF1268)");
				dlg.open();
				return;
			}
			
			selectedIndex = tblPerson.getSelectionIndex();
			personCol.remove(selectedIndex);
			tblPerson.remove(selectedIndex);
			
			int max = framePersonList.getBounds().height-45;
			int height = (personCol.size()*40) > max?max:(personCol.size()*40);
			tblPerson.setSize(196, height);
			tblPerson.redraw();
			
			selectedIndex = personCol.size()==0?-1:0;
			if(personCol.size() == 0){
				tblPerson.deselectAll();
				selectedPerson = null;
				selectedIndex = -1;
				clear();
				frameMain.setVisible(false);
			}else{
				selectedIndex = 0;
				selectedPerson = personCol.get(0);
				tblPerson.setSelection(0);
				selectPerson();
			}
		}catch(Exception e){
			MessageDialog dlg = new MessageDialog(framePersonDetail.getShell(), SWT.NONE, "Error 401 : System Problems (PF1303)");
			dlg.open();
		}
	}
	
	private void quickSearch(){
		if(txtFind.getText().length() == 0 || txtFind.getText().equalsIgnoreCase("FIND"))
			return;
		
		String sql = "(firstName LIKE '%"+txtFind.getText()+"%' OR middleName LIKE '%"+txtFind.getText()+"%' "
				+ "OR lastName LIKE '%"+txtFind.getText()+"%' OR contactId LIKE '%"+txtFind.getText()+"%')";
		
		refreshPersonList(sql);
		refreshMainFrame();
		
		clear();
	}
	
	/*private String displayText(Object obj){
		if(obj==null)
			return "";
		else
			return obj.toString();
	}*/
		
	@Override
	protected void checkSubclass() {
		// Disable the check that prevents subclassing of SWT components
	}
}
