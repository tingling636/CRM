package com.blackcode.crmgui;

import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.CLabel;
import org.eclipse.swt.custom.ScrolledComposite;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.wb.swt.SWTResourceManager;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.DateTime;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.widgets.Combo;

public class HistoryInfo extends Composite {
	private Shell shell;
	private ScrolledComposite scrolledPersonInfo;
	private Composite frameHistoryInfo;
	private Combo txtTime;
	private Text txtCustomer;
	private Text txtSubject;
	private Text txtNote;
	
	private String[] times = new String[]{"06:00","07:00","08:00","09:00","10:00","11:00","12:00","13:00","14:00","15:00","16:00","17:00","18:00","19:00","20:00","21:00","22:00","23:00","24:00"};
	
	/**
	 * Create the composite.
	 * @param parent
	 * @param style
	 */
	public HistoryInfo(Composite parent, int style) {
		super(parent, style);
		shell = parent.getShell();

		scrolledPersonInfo = new ScrolledComposite(this, SWT.BORDER | SWT.H_SCROLL | SWT.V_SCROLL);
		scrolledPersonInfo.setBounds(0, 0, parent.getBounds().width-5, parent.getBounds().height-28);
		scrolledPersonInfo.setExpandHorizontal(true);
		scrolledPersonInfo.setExpandVertical(true);
		
		frameHistoryInfo = new Composite(scrolledPersonInfo, SWT.NONE);
		frameHistoryInfo.setBackground(SWTResourceManager.getColor(255, 255, 255));
		scrolledPersonInfo.setContent(frameHistoryInfo);
		scrolledPersonInfo.setMinSize(frameHistoryInfo.computeSize(SWT.DEFAULT, SWT.DEFAULT));
		
		CLabel lblTitle = new CLabel(frameHistoryInfo, SWT.NONE);
		lblTitle.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblTitle.setForeground(SWTResourceManager.getColor(52, 64, 88));
		lblTitle.setFont(SWTResourceManager.getFont("Georgia", 14, SWT.BOLD));
		lblTitle.setBounds(10, 10, 276, 24);
		lblTitle.setText("Add New Log");
		
		Label lblDate = new Label(frameHistoryInfo, SWT.RIGHT);
		lblDate.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblDate.setFont(SWTResourceManager.getFont("Georgia", 9, SWT.NORMAL));
		lblDate.setBounds(62, 55, 55, 15);
		lblDate.setText("Date : ");
		
		DateTime dateTime = new DateTime(frameHistoryInfo, SWT.BORDER | SWT.DROP_DOWN);
		dateTime.setBounds(123, 50, 80, 24);
		
		Label lblTime = new Label(frameHistoryInfo, SWT.RIGHT);
		lblTime.setFont(SWTResourceManager.getFont("Georgia", 9, SWT.NORMAL));
		lblTime.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblTime.setBounds(62, 83, 55, 15);
		lblTime.setText("Time : ");
		
		txtTime = new Combo(frameHistoryInfo, SWT.BORDER);
		txtTime.setBounds(123, 80, 80, 24);
		txtTime.setItems(times);
		
		Label lblType = new Label(frameHistoryInfo, SWT.RIGHT);
		lblType.setFont(SWTResourceManager.getFont("Georgia", 9, SWT.NORMAL));
		lblType.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblType.setBounds(62, 112, 55, 15);
		lblType.setText("Type : ");
		
		Combo cmbType = new Combo(frameHistoryInfo, SWT.NONE);
		cmbType.setBounds(123, 109, 125, 23);
		
		Label lblCustomer = new Label(frameHistoryInfo, SWT.CENTER);
		lblCustomer.setFont(SWTResourceManager.getFont("Georgia", 9, SWT.NORMAL));
		lblCustomer.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblCustomer.setBounds(52, 141, 65, 15);
		lblCustomer.setText("Customer : ");
		
		txtCustomer = new Text(frameHistoryInfo, SWT.BORDER);
		txtCustomer.setBounds(123, 138, 125, 24);
		
		Label lblSubject = new Label(frameHistoryInfo, SWT.RIGHT);
		lblSubject.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblSubject.setFont(SWTResourceManager.getFont("Georgia", 9, SWT.NORMAL));
		lblSubject.setBounds(62, 171, 55, 15);
		lblSubject.setText("Subject : ");
		
		txtSubject = new Text(frameHistoryInfo, SWT.BORDER);
		txtSubject.setBounds(123, 168, 262, 24);
		
		Label lblNotes = new Label(frameHistoryInfo, SWT.RIGHT);
		lblNotes.setFont(SWTResourceManager.getFont("Georgia", 9, SWT.NORMAL));
		lblNotes.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblNotes.setBounds(62, 196, 55, 15);
		lblNotes.setText("Notes : ");
		
		txtNote = new Text(frameHistoryInfo, SWT.BORDER | SWT.MULTI);
		txtNote.setBounds(123, 198, 262, 89);
	}

	@Override
	protected void checkSubclass() {
		// Disable the check that prevents subclassing of SWT components
	}
}
