package com.blackcode.crmgui;

import java.io.File;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.CellRangeAddress;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.ClientAnchor;
import org.apache.poi.ss.usermodel.CreationHelper;
import org.apache.poi.ss.usermodel.Drawing;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Picture;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Workbook;
import org.eclipse.swt.widgets.Dialog;
import org.eclipse.swt.widgets.DirectoryDialog;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.TableItem;
import org.eclipse.swt.SWT;
import org.eclipse.wb.swt.SWTResourceManager;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.custom.CLabel;
import org.eclipse.swt.events.MouseAdapter;
import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.events.MouseTrackAdapter;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.widgets.Button;

import com.blackcode.core.CalendarUtil;
import com.blackcode.model.Contact;

public class PersonExportDialog extends Dialog {

	protected Object result;
	protected Shell shell;
	private Text txtFileName;
	private Text txtLocation;
	private Label lblLocationAction;
	private Table tblAvailableFields;
	private Table tblDisplayFields;
	private Label lblDeselectAction;
	private Label lblSelectAction;

	private List<Contact> contacts = null;
	private Contact contact = null;
	private SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
	private String[] fields = new String[]{"Account","Contact Id","Compony","Position","Title","First Name", "Middle Name","Last Name", "Nick Name", "Gender", "DOB",
			"Home Number","Mobile Number ","Work Number","Alternative Number","Home Fax","Work Fax", "Personal Email Id","Work Email Id","Other Email Id",
			"Home Address","Work Address", "Facebook","Twitter","LinkedIn", "Group","Custom"};
	/**
	 * Create the dialog.
	 * @param parent
	 * @param style
	 */
	public PersonExportDialog(Shell parent, int style) {
		super(parent, style);
		setText("Export Contact(s) Dialog");
	}
	
	public PersonExportDialog(Shell parent, int style, List<Contact> contacts) {
		super(parent, style);
		setText("Export Contact(s) Dialog");
		this.contacts = contacts;
	}
	
	public PersonExportDialog(Shell parent, int style, Contact contact) {
		super(parent, style);
		setText("Export Contact(s) Dialog");
		this.contact = contact;
	}

	/**
	 * Open the dialog.
	 * @return the result
	 */
	public Object open() {
		createContents();
		shell.open();
		shell.layout();
		Display display = getParent().getDisplay();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
		return result;
	}

	/**
	 * Create contents of the dialog.
	 */
	private void createContents() {
		shell = new Shell(getParent(), getStyle());
		shell.setSize(385, 403);
		shell.setText(getText());
		shell.setLocation((getParent().getBounds().width/2)-(shell.getBounds().width/2), 30);
		
		Composite composite = new Composite(shell, SWT.BORDER);
		composite.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		composite.setBounds(5, 5, 365, 332);
		
		Label lblFileName = new Label(composite, SWT.RIGHT);
		lblFileName.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblFileName.setBounds(26, 10, 55, 15);
		lblFileName.setText("File Name");
		
		txtFileName = new Text(composite, SWT.BORDER);
		txtFileName.setBounds(87, 7, 234, 21);
		
		Label lblSaveTo = new Label(composite, SWT.RIGHT);
		lblSaveTo.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblSaveTo.setBounds(26, 37, 55, 15);
		lblSaveTo.setText("Save To");
		
		txtLocation = new Text(composite, SWT.BORDER);
		txtLocation.setBounds(87, 34, 234, 21);
		
		lblLocationAction = new Label(composite, SWT.CENTER);
		lblLocationAction.addMouseListener(new MouseAdapter() {
			public void mouseDown(MouseEvent evt) {
				DirectoryDialog dlg = new DirectoryDialog(new Shell(Display.getDefault()));
		        dlg.setText("Directory Dialog");
		        dlg.setMessage("Select a directory");
		        String dir = dlg.open();
		        if (dir != null) {
		        	txtLocation.setText(dir);
		        }
			}
		});
		lblLocationAction.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				lblLocationAction.setBackground(SWTResourceManager.getColor(235, 235, 235));
			}
			@Override
			public void mouseExit(MouseEvent e) {
				lblLocationAction.setBackground(SWTResourceManager.getColor(245, 245, 245));
			}
		});
		lblLocationAction.setBackground(SWTResourceManager.getColor(245, 245, 245));
		lblLocationAction.setText("...");
		lblLocationAction.setBounds(327, 34, 21, 21);
		
		CLabel lblAvailableFields = new CLabel(composite, SWT.CENTER);
		lblAvailableFields.setFont(SWTResourceManager.getFont("Segoe UI", 9, SWT.BOLD));
		lblAvailableFields.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblAvailableFields.setBounds(30, 73, 99, 21);
		lblAvailableFields.setText("Available Fields");
		lblAvailableFields.setEnabled(contact==null);
		
		CLabel lblDisplayFields = new CLabel(composite, SWT.CENTER);
		lblDisplayFields.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblDisplayFields.setFont(SWTResourceManager.getFont("Segoe UI", 9, SWT.BOLD));
		lblDisplayFields.setBounds(233, 73, 99, 21);
		lblDisplayFields.setText("Display Fields");
		lblDisplayFields.setEnabled(contact==null);
		
		tblAvailableFields = new Table(composite, SWT.BORDER | SWT.FULL_SELECTION | SWT.MULTI);
		tblAvailableFields.setBounds(10, 100, 141, 222);
		tblAvailableFields.setEnabled(contact==null);
		
		TableColumn tblclmnNewColumn = new TableColumn(tblAvailableFields, SWT.NONE);
		tblclmnNewColumn.setWidth(115);
		
		tblDisplayFields = new Table(composite, SWT.BORDER | SWT.FULL_SELECTION | SWT.MULTI);
		tblDisplayFields.setBounds(207, 100, 141, 222);
		tblDisplayFields.setEnabled(contact==null);
		
		TableColumn tblclmnNewColumn_1 = new TableColumn(tblDisplayFields, SWT.NONE);
		tblclmnNewColumn_1.setWidth(115);
		
		lblSelectAction = new Label(composite, SWT.CENTER);
		lblSelectAction.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				addField();
			}
		});
		lblSelectAction.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				lblSelectAction.setBackground(SWTResourceManager.getColor(235, 235, 235));
			}
			@Override
			public void mouseExit(MouseEvent e) {
				lblSelectAction.setBackground(SWTResourceManager.getColor(245, 245, 245));
			}
		});
		lblSelectAction.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));		
		lblSelectAction.setBackground(SWTResourceManager.getColor(245, 245, 245));
		lblSelectAction.setImage(new Image(shell.getDisplay(), PersonExportDialog.class.getResourceAsStream("/images/next_small.png")));
		lblSelectAction.setBounds(168, 170, 25, 25);
		lblSelectAction.setEnabled(contact==null);
		
		lblDeselectAction = new Label(composite, SWT.CENTER);		
		lblDeselectAction.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				removeField();
			}
		});
		lblDeselectAction.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				lblDeselectAction.setBackground(SWTResourceManager.getColor(235, 235, 235));
			}
			@Override
			public void mouseExit(MouseEvent e) {
				lblDeselectAction.setBackground(SWTResourceManager.getColor(245, 245, 245));
			}
		});
		lblDeselectAction.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblDeselectAction.setBounds(168, 211, 25, 25);
		lblDeselectAction.setBackground(SWTResourceManager.getColor(245, 245, 245));
		lblDeselectAction.setImage(new Image(shell.getDisplay(), PersonExportDialog.class.getResourceAsStream("/images/back_small.png")));
		lblDeselectAction.setEnabled(contact==null);
		
		Button btnExport = new Button(shell, SWT.NONE);
		btnExport.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				if(contacts != null)
					exportList();
				if(contact != null)
					exportContact();
			}
		});
		btnExport.setBounds(5, 343, 182, 30);
		btnExport.setText("Export");
		
		Button btnCancel = new Button(shell, SWT.NONE);
		btnCancel.setBounds(187, 343, 182, 30);
		btnCancel.setText("Cancel");
		btnCancel.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				shell.close();
			}
		});

		init();
	}
	
	private void init(){
		for(int i=0; i<fields.length; i++){
			TableItem ti = new TableItem(tblAvailableFields, SWT.NONE);
			ti.setText(fields[i]);
			ti.setData(i);
		}
	}
	
	private void addField(){
		if(tblAvailableFields.getSelectionIndex() == -1)
			return;
		
		TableItem[] items = tblAvailableFields.getSelection();
		for(int i=0; i<items.length; i++){
			TableItem ti = new TableItem(tblDisplayFields, SWT.NONE);
			ti.setText(items[i].getText());
		}
		
		tblAvailableFields.remove(tblAvailableFields.getSelectionIndices());
	}
	
	private void removeField(){
		if(tblDisplayFields.getSelectionIndex() == -1)
			return;
		
		tblDisplayFields.remove(tblDisplayFields.getSelectionIndices());
		
		tblAvailableFields.removeAll();
		outter:
		for(int i=0; i<fields.length; i++){
			for(int j=0; j<tblDisplayFields.getItemCount(); j++){
				if(fields[i].equals(tblDisplayFields.getItem(j).getText()))
					continue outter;
			}
			TableItem ti = new TableItem(tblAvailableFields, SWT.NONE);
			ti.setText(fields[i]);
			ti.setData(i);
		}
	}
	
	private void exportList(){
		if(txtLocation.getText().length()==0 || txtFileName.getText().length()==0)
			return;
		
		try{
			HSSFWorkbook workbook = new HSSFWorkbook();
			HSSFSheet sheet = workbook.createSheet("Contacts List");
			 
			//Excel Header
			int rowindex = 0;
			Row row = sheet.createRow(rowindex);
			for(int i=0; i<tblDisplayFields.getItemCount(); i++){
				Cell cell = row.createCell(i);    
				cell.setCellValue(tblDisplayFields.getItem(i).getText());
				
				sheet.setColumnWidth(i, getWidth(tblDisplayFields.getItem(i).getText()));
			}
			
			for(int i=0; i<contacts.size(); i++){
				Contact person = contacts.get(i);
				row = sheet.createRow(++rowindex);
				for(int j=0; j<tblDisplayFields.getItemCount();j++){
					Object value = getValue(person, tblDisplayFields.getItem(j).getText());
					Cell cell = row.createCell(j);  
					if(value instanceof String)                    
						cell.setCellValue((String)value);                
					else if(value instanceof Integer)                    
						cell.setCellValue((Integer)value);
					else if(value instanceof Date)					
						cell.setCellValue(sdf.format(value));					
				}
			}
			
			File file = new File(txtLocation.getText()+"/"+txtFileName.getText()+".xls");
			FileOutputStream out = new FileOutputStream(file);            
			workbook.write(out);            
			out.close();
			
			Runtime.getRuntime().exec("rundll32 url.dll,FileProtocolHandler "+file); 
			shell.close();
		}catch(Exception e){
			MessageDialog dlg = new MessageDialog(shell, SWT.NONE, "Error 401 : System Problems (EX336)");
			dlg.open();
		}
	}
	
	private void exportContact(){
		if(txtLocation.getText().length()==0 || txtFileName.getText().length()==0)
			return;
		
		try{
			HSSFWorkbook workbook = new HSSFWorkbook();
			HSSFSheet sheet = workbook.createSheet("Contact Detail");
			
			if(contact.getPhoto() != null){
				int pictureIdx = workbook.addPicture(contact.getPhoto(), Workbook.PICTURE_TYPE_PNG);
				CreationHelper helper = workbook.getCreationHelper();
				Drawing drawing = sheet.createDrawingPatriarch();
				ClientAnchor anchor = helper.createClientAnchor();
				anchor.setCol1(0);
			    anchor.setRow1(1);
			    Picture pict = drawing.createPicture(anchor, pictureIdx);
			    pict.resize();
			}
			 
			//Excel Header
			int rowindex = -1;
			Row row = sheet.createRow(0);
			
			Font font_britannic = workbook.createFont();
			font_britannic.setFontHeightInPoints((short)14);
			font_britannic.setFontName("Britannic Bold");
		    			
		    CellStyle style_header = workbook.createCellStyle();
		    style_header.setFont(font_britannic);
		    
			sheet.addMergedRegion(new CellRangeAddress(1, 7, 0, 2 ));
			row = sheet.createRow(1);
			Cell cell = row.createCell(3);
			cell.setCellValue(contact.getContactId());
			cell.setCellStyle(style_header);
			
			row = sheet.createRow(3);
			cell = row.createCell(3);
			cell.setCellValue(contact.getFullNameWithNick());
			cell.setCellStyle(style_header);
			
			row = sheet.createRow(5);
			cell = row.createCell(3);
			cell.setCellValue(contact.getJobTitle());
			cell.setCellStyle(style_header);
			
			row = sheet.createRow(7);
			cell = row.createCell(3);
			cell.setCellValue(contact.getCompany());
			cell.setCellStyle(style_header);
			    
			Font font_cambria = workbook.createFont();
			font_cambria.setFontHeightInPoints((short)12);
			font_cambria.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
			font_cambria.setFontName("Cambria");
			
		    CellStyle style_title = workbook.createCellStyle();
		    style_title.setFont(font_cambria);
		    style_title.setAlignment(HSSFCellStyle.ALIGN_CENTER);
		    style_title.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
		    style_title.setFillPattern(CellStyle.SOLID_FOREGROUND);
		    
			sheet.addMergedRegion(new CellRangeAddress(9, 9, 0, 2 ));
			sheet.addMergedRegion(new CellRangeAddress(9, 9, 4, 6 ));
			row = sheet.createRow(9);
			cell = row.createCell(0);
			cell.setCellValue("Phone");
			cell.setCellStyle(style_title);
			
			cell = row.createCell(4);
			cell.setCellValue("Email");
			cell.setCellStyle(style_title);
			
			Font font_cambria_bold10 = workbook.createFont();
			font_cambria_bold10.setFontHeightInPoints((short)10);
			font_cambria_bold10.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
			font_cambria_bold10.setFontName("Cambria");
			
			CellStyle style_title_bold10 = workbook.createCellStyle();
			style_title_bold10.setFont(font_cambria_bold10);
		    style_title_bold10.setAlignment(HSSFCellStyle.ALIGN_RIGHT);
		    
		    Font font_cambria_10 = workbook.createFont();
			font_cambria_10.setFontHeightInPoints((short)10);
			font_cambria_10.setFontName("Cambria");
			
			CellStyle style_title_10 = workbook.createCellStyle();
			style_title_10.setFont(font_cambria_10);
		    
			row = sheet.createRow(10);
			cell = row.createCell(0);
			cell.setCellValue("Home  ");
			cell.setCellStyle(style_title_bold10);
			
			cell = row.createCell(1);
			cell.setCellValue(contact.getHomePhone()==null?"-":contact.getHomePhone());
			cell.setCellStyle(style_title_10);
			
			cell = row.createCell(4);
			cell.setCellValue("Personal  ");
			cell.setCellStyle(style_title_bold10);
			
			cell = row.createCell(5);
			cell.setCellValue(contact.getPersonalEmail()==null?"-":contact.getPersonalEmail());
			cell.setCellStyle(style_title_10);
			
			row = sheet.createRow(11);
			cell = row.createCell(0);
			cell.setCellValue("Work  ");
			cell.setCellStyle(style_title_bold10);
			
			cell = row.createCell(1);
			cell.setCellValue(contact.getWorkPhone()==null?"-":contact.getWorkPhone());
			cell.setCellStyle(style_title_10);
			
			cell = row.createCell(4);
			cell.setCellValue("Work  ");
			cell.setCellStyle(style_title_bold10);
			
			cell = row.createCell(5);
			cell.setCellValue(contact.getWorkEmail()==null?"-":contact.getWorkEmail());
			cell.setCellStyle(style_title_10);
			
			row = sheet.createRow(12);
			cell = row.createCell(0);
			cell.setCellValue("Alt  ");
			cell.setCellStyle(style_title_bold10);
			
			cell = row.createCell(1);
			cell.setCellValue(contact.getAltPhone()==null?"-":contact.getAltPhone());
			cell.setCellStyle(style_title_10);
			
			cell = row.createCell(4);
			cell.setCellValue("Other  ");
			cell.setCellStyle(style_title_bold10);
			
			cell = row.createCell(5);
			cell.setCellValue(contact.getOtherEmail()==null?"-":contact.getOtherEmail());
			cell.setCellStyle(style_title_10);
			
			row = sheet.createRow(13);
			cell = row.createCell(0);
			cell.setCellValue("Mobile  ");
			cell.setCellStyle(style_title_bold10);
			
			cell = row.createCell(1);
			cell.setCellValue(contact.getMobile()==null?"-":contact.getMobile());
			cell.setCellStyle(style_title_10);
			
			sheet.addMergedRegion(new CellRangeAddress(15, 15, 0, 6 ));
			row = sheet.createRow(15);
			cell = row.createCell(0);
			cell.setCellValue("Other Information");
			cell.setCellStyle(style_title);
			
			sheet.addMergedRegion(new CellRangeAddress(16,16, 0, 1 ));
			row = sheet.createRow(16);
			cell = row.createCell(0);
			cell.setCellValue("Account");
			cell.setCellStyle(style_title_bold10);
			
			cell = row.createCell(2);
			cell.setCellValue(contact.getAccountId());
			cell.setCellStyle(style_title_10);
						
			sheet.addMergedRegion(new CellRangeAddress(17,17, 0, 1 ));
			row = sheet.createRow(17);
			cell = row.createCell(0);
			cell.setCellValue("DOB");
			cell.setCellStyle(style_title_bold10);
			
			cell = row.createCell(2);
			cell.setCellValue(contact.getDob()==null?"-":(sdf.format(contact.getDob())+"( "+CalendarUtil.calculateAgaingInYear(
					contact.getDob().getYear()+1900, contact.getDob().getMonth(), contact.getDob().getDate())+" years old )"));
			cell.setCellStyle(style_title_10);
			
			sheet.addMergedRegion(new CellRangeAddress(18,18, 0, 1 ));
			row = sheet.createRow(18);
			cell = row.createCell(0);
			cell.setCellValue("Work Address");
			cell.setCellStyle(style_title_bold10);
			
			cell = row.createCell(2);
			cell.setCellValue(contact.getWorkAddress()==null?"-":contact.getWorkAddress());
			cell.setCellStyle(style_title_10);
			
			sheet.addMergedRegion(new CellRangeAddress(19,19, 0, 1 ));
			row = sheet.createRow(19);
			cell = row.createCell(0);
			cell.setCellValue("Home Address");
			cell.setCellStyle(style_title_bold10);
			
			cell = row.createCell(2);
			cell.setCellValue(contact.getHomeAddress()==null?"-":contact.getHomeAddress());
			cell.setCellStyle(style_title_10);
			
			List details = contact.dataDisplayDetail();
			int rowIdx = 20;
			for(int i=0; i<details.size(); i++){
				String[] detail = (String[])details.get(i);
				
				sheet.addMergedRegion(new CellRangeAddress(rowIdx, rowIdx, 0, 1 ));
				row = sheet.createRow(rowIdx++);
				cell = row.createCell(0);
				cell.setCellValue(detail[0]);
				cell.setCellStyle(style_title_bold10);
				
				cell = row.createCell(2);
				cell.setCellValue(detail[1]);
				cell.setCellStyle(style_title_10);
			}
			
			File file = new File(txtLocation.getText()+"/"+txtFileName.getText()+".xls");
			FileOutputStream out = new FileOutputStream(file);            
			workbook.write(out);            
			out.close();
			
			Runtime.getRuntime().exec("rundll32 url.dll,FileProtocolHandler "+file); 
			shell.close();
		}catch(Exception e){
			MessageDialog dlg = new MessageDialog(shell, SWT.NONE, "Error 401 : System Problems (EX557)");
			dlg.open();
		}
	}
	
	public Object getValue(Contact person, String title){
		if(fields[0].equals(title))
			return person.getAccountId();
		else if(fields[1].equals(title))
			return person.getContactId();
		else if(fields[2].equals(title))
			return person.getCompany();
		else if(fields[3].equals(title))
			return person.getJobTitle();
		else if(fields[4].equals(title))
			return person.getTitle();
		else if(fields[5].equals(title))
			return person.getFirstName();
		else if(fields[6].equals(title))
			return person.getMiddleName();
		else if(fields[7].equals(title))
			return person.getLastName();
		else if(fields[8].equals(title))
			return person.getNickName();
		else if(fields[9].equals(title))
			return person.getGender();
		else if(fields[10].equals(title))
			return person.getDob();
		else if(fields[11].equals(title))
			return person.getHomePhone();
		else if(fields[12].equals(title))
			return person.getMobile();
		else if(fields[13].equals(title))
			return person.getWorkPhone();
		else if(fields[14].equals(title))
			return person.getAltPhone();
		else if(fields[15].equals(title))
			return person.getHomeFax();
		else if(fields[16].equals(title))
			return person.getWorkFax();
		else if(fields[17].equals(title))
			return person.getPersonalEmail();
		else if(fields[18].equals(title))
			return person.getWorkEmail();
		else if(fields[19].equals(title))
			return person.getOtherEmail();
		else if(fields[20].equals(title))
			return person.getHomeAddress();
		else if(fields[21].equals(title))
			return person.getWorkAddress();
		
		return null;
	}
	
	public int getWidth(String title){
		if(fields[0].equals(title))
			return 2700;
		else if(fields[1].equals(title))
			return 3340;
		else if(fields[2].equals(title))
			return 11700;
		else if(fields[3].equals(title))
			return 9000;
		else if(fields[4].equals(title))
			return 2700;
		else if(fields[5].equals(title))
			return 3900;
		else if(fields[6].equals(title))
			return 3900;
		else if(fields[7].equals(title))
			return 3900;
		else if(fields[8].equals(title))
			return 3900;
		else if(fields[9].equals(title))
			return 2700;
		else if(fields[10].equals(title))
			return 2700;
		else if(fields[11].equals(title))
			return 5000;
		else if(fields[12].equals(title))
			return 5000;
		else if(fields[13].equals(title))
			return 5000;
		else if(fields[14].equals(title))
			return 5000;
		else if(fields[15].equals(title))
			return 5000;
		else if(fields[16].equals(title))
			return 5000;
		else if(fields[17].equals(title))
			return 9000;
		else if(fields[18].equals(title))
			return 9000;
		else if(fields[19].equals(title))
			return 9000;
		else if(fields[20].equals(title))
			return 9000;
		else if(fields[21].equals(title))
			return 9000;
		
		return 2700;
	}
}
