package com.blackcode.crmgui;

import java.awt.Dimension;
import java.awt.Toolkit;

import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.SWT;
import org.eclipse.wb.swt.SWTResourceManager;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.events.MouseAdapter;
import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.events.MouseTrackAdapter;

public class TitleBar extends Composite {

	final Shell shell;
	private Composite composite;
	private Label lblTitle;
	private Label lblMin;
	private Label lblClose;
	
	public TitleBar(Composite parent, int style) {
		super(parent, style);
		shell = parent.getShell();
		
		Dimension dimension = Toolkit.getDefaultToolkit().getScreenSize();
		composite = new Composite(this, SWT.NONE);
		composite.setBounds(0, 0, dimension.width, 30);
		composite.setBackground(SWTResourceManager.getColor(52, 64, 88));
		
		lblTitle = new Label(composite, SWT.CENTER);
		lblTitle.setFont(SWTResourceManager.getFont("Georgia", 9, SWT.NORMAL));
		lblTitle.setForeground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblTitle.setBackground(SWTResourceManager.getColor(52, 64, 88));
		lblTitle.setBounds(7, 7, composite.getBounds().width-75, 15);
		lblTitle.setText("Customer Relationship Management");
		
		lblMin = new Label(composite, SWT.NONE);
		lblMin.setToolTipText("Minimize");
		lblMin.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				setSize();
			}
		});
		lblMin.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				lblMin.setImage(new Image(shell.getDisplay(), TitleBar.class.getResourceAsStream("/images/minus_selected.png")));
			}
			@Override
			public void mouseExit(MouseEvent e) {
				lblMin.setImage(new Image(shell.getDisplay(), TitleBar.class.getResourceAsStream("/images/minus.png")));
			}
		});		
		lblMin.setBounds(composite.getBounds().width-55, 3, 21, 21);
		lblMin.setBackground(SWTResourceManager.getColor(52, 64, 88));
		lblMin.setImage(new Image(shell.getDisplay(), TitleBar.class.getResourceAsStream("/images/minus.png")));
		
		lblClose = new Label(composite, SWT.NONE);
		lblClose.setToolTipText("Close");
		lblClose.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				shell.close();
			}
		});
		lblClose.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				lblClose.setImage(new Image(shell.getDisplay(), TitleBar.class.getResourceAsStream("/images/close21_hover.png")));
			}
			@Override
			public void mouseExit(MouseEvent e) {
				lblClose.setImage(new Image(shell.getDisplay(), TitleBar.class.getResourceAsStream("/images/close21.png")));
			}
		});		
		lblClose.setBounds(composite.getBounds().width-30, 3, 21, 21);
		lblClose.setImage(new Image(shell.getDisplay(), TitleBar.class.getResourceAsStream("/images/close21.png")));

	}

	private void setSize(){
		final Dimension dimension = Toolkit.getDefaultToolkit().getScreenSize();
		
		if(shell.getBounds().height > 30){
			shell.setBounds((dimension.width/2)-((shell.getBounds().width/3)/2), 0, shell.getBounds().width/3, 30);
			composite.setBounds(0, 0, shell.getBounds().width, 30);
			lblTitle.setBounds(7, 7, composite.getBounds().width-75, 15);
			lblMin.setBounds(composite.getBounds().width-55, 3, 21, 21);
			lblClose.setBounds(composite.getBounds().width-30, 3, 21, 21);
			lblMin.setToolTipText("Maximize");
		}else{
			shell.setBounds(0, 0, dimension.width, dimension.height-40);
			composite.setBounds(0, 0, shell.getBounds().width, 30);
			lblTitle.setBounds(7, 7, composite.getBounds().width-75, 15);
			lblMin.setBounds(composite.getBounds().width-55, 3, 21, 21);
			lblClose.setBounds(composite.getBounds().width-30, 3, 21, 21);
			lblMin.setToolTipText("Minimize");
		}
		composite.redraw();
	}
	
	@Override
	protected void checkSubclass() {
		// Disable the check that prevents subclassing of SWT components
	}
}
