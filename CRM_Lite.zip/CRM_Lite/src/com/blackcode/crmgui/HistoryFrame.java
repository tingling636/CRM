package com.blackcode.crmgui;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Comparator;
import java.util.Date;
import java.util.List;

import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.ScrolledComposite;
import org.eclipse.swt.events.MouseAdapter;
import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.events.MouseTrackAdapter;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.TableItem;
import org.eclipse.swt.widgets.Text;
import org.eclipse.wb.swt.SWTResourceManager;
import org.eclipse.swt.custom.CLabel;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;

import com.blackcode.core.SQLiteConnector;
import com.blackcode.model.Contact;
import com.blackcode.model.FollowUpTask;
import com.blackcode.model.History;
import com.blackcode.model.Sales;

import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.DateTime;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;

public class HistoryFrame extends Composite {

	private Shell shell;
	private Composite frameTopActionBar;
	private Label lblAddAction;
	private Composite frameList;
	private ScrolledComposite scrolledComposite;
	private Composite frameMain;
	private Composite frameDetail;
	private Table tblHistory;
	private Button btnSeparator;
	private Composite frameSide;
	private CLabel lblSaveAction;
	private CLabel lblCancelAction;
	private Text txtDay;
	private Table tblCustomer;
	private DateTime dateTimeFrom, dateTimeTo;
	private Button btnAllCustomer, btnAllPeriod;
	
	private int layoutMode = 0;
	private String frameHistoryMode;
	private HistoryInfo frameNewHistory;
	private SQLiteConnector dbConnector = new SQLiteConnector();
	private SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
	
	/**
	 * Create the composite.
	 * @param parent
	 * @param style
	 */
	public HistoryFrame(Composite parent, int style) {
		super(parent, style);
		shell = parent.getShell();
		setBackground(SWTResourceManager.getColor(255, 255, 255));

		frameTopActionBar = new Composite(this, SWT.NONE);
		frameTopActionBar.setBackground(SWTResourceManager.getColor(77, 99, 132));
		frameTopActionBar.setBounds(0, 0, shell.getBounds().width-60, 35);
		
		CLabel lblTitle = new CLabel(frameTopActionBar, SWT.NONE);
		lblTitle.setForeground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblTitle.setFont(SWTResourceManager.getFont("Georgia", 15, SWT.BOLD));
		lblTitle.setBounds(10, 5, 183, 25);
		lblTitle.setBackground(SWTResourceManager.getColor(77, 99, 132));
		lblTitle.setText("Activity");
		
		lblAddAction = new Label(frameTopActionBar, SWT.NONE);
		lblAddAction.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {	
				frameHistoryMode = "ADD";
				
				if(frameNewHistory != null)
					frameNewHistory.dispose();
				openAddFrame();
				hideFrameSide(0);
			}
		});
		lblAddAction.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				lblAddAction.setBackground(SWTResourceManager.getColor(52, 64, 88));
				lblAddAction.setImage(new Image(shell.getDisplay(), HistoryFrame.class.getResourceAsStream("/images/add25_selected.png")));
			}
			@Override
			public void mouseExit(MouseEvent e) {
				lblAddAction.setBackground(SWTResourceManager.getColor(77, 99, 132));
				lblAddAction.setImage(new Image(shell.getDisplay(), HistoryFrame.class.getResourceAsStream("/images/add25.png")));
			}
		});
		lblAddAction.setBounds(frameTopActionBar.getBounds().width-38, 5, 33, 25);
		lblAddAction.setBackground(SWTResourceManager.getColor(77, 99, 132));
		lblAddAction.setImage(new Image(shell.getDisplay(), HistoryFrame.class.getResourceAsStream("/images/add25.png")));
		
		frameList = new Composite(this, SWT.NONE);
		frameList.setBounds(0, 36, 201, shell.getBounds().height-75);
		frameList.setBackground(SWTResourceManager.getColor(239, 245, 249));
		
		Group grpPeriod = new Group(frameList, SWT.NONE);
		grpPeriod.setText("Period");
		grpPeriod.setBounds(10, 10, 181, 122);
		
		Label lblFrom = new Label(grpPeriod, SWT.NONE);
		lblFrom.setBounds(10, 20, 41, 15);
		lblFrom.setText("From");
		
		dateTimeFrom = new DateTime(grpPeriod, SWT.BORDER | SWT.DROP_DOWN);
		dateTimeFrom.setBounds(57, 16, 80, 24);
		dateTimeFrom.setEnabled(false);
		
		Label lblTo = new Label(grpPeriod, SWT.NONE);
		lblTo.setBounds(10, 50, 41, 15);
		lblTo.setText("To");
		
		dateTimeTo = new DateTime(grpPeriod, SWT.BORDER | SWT.DROP_DOWN);
		dateTimeTo.setBounds(57, 46, 80, 24);
		dateTimeTo.setEnabled(false);
		
		Label lblWithin = new Label(grpPeriod, SWT.NONE);
		lblWithin.setBounds(10, 77, 41, 15);
		lblWithin.setText("Within");
		
		txtDay = new Text(grpPeriod, SWT.BORDER);
		txtDay.setBounds(57, 74, 33, 21);
		txtDay.setEnabled(false);
		
		Label lblDays = new Label(grpPeriod, SWT.NONE);
		lblDays.setBounds(96, 77, 41, 15);
		lblDays.setText("days");
		
		btnAllPeriod = new Button(grpPeriod, SWT.CHECK);
		btnAllPeriod.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				txtDay.setEnabled(!btnAllPeriod.getSelection());
				dateTimeTo.setEnabled(!btnAllPeriod.getSelection());
				dateTimeFrom.setEnabled(!btnAllPeriod.getSelection());
			}
		});
		btnAllPeriod.setSelection(true);
		btnAllPeriod.setFont(SWTResourceManager.getFont("Segoe UI", 8, SWT.ITALIC));
		btnAllPeriod.setBounds(105, 100, 75, 16);
		btnAllPeriod.setText("Any Period");
		
		Group grpShowCustomer = new Group(frameList, SWT.NONE);
		grpShowCustomer.setText("Show Customer");
		grpShowCustomer.setBounds(10, 138, 181, 145);
		
		tblCustomer = new Table(grpShowCustomer, SWT.BORDER | SWT.CHECK | SWT.FULL_SELECTION);
		tblCustomer.setBounds(10, 16, 161, 103);
		tblCustomer.setEnabled(false);
		
		TableColumn tableColumn_6 = new TableColumn(tblCustomer, SWT.NONE);
		tableColumn_6.setWidth(140);
		
		btnAllCustomer = new Button(grpShowCustomer, SWT.CHECK);
		btnAllCustomer.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				if(btnAllCustomer.getSelection()){
					for(int i=0; i<tblCustomer.getItemCount(); i++)
						tblCustomer.getItem(i).setChecked(false);					
				}
				tblCustomer.setEnabled(!btnAllCustomer.getSelection());
			}
		});
		btnAllCustomer.setSelection(true);
		btnAllCustomer.setFont(SWTResourceManager.getFont("Segoe UI", 8, SWT.ITALIC));
		btnAllCustomer.setBounds(105, 125, 38, 16);
		btnAllCustomer.setText("All ");
		
		final CLabel lblShow = new CLabel(frameList, SWT.CENTER);
		lblShow.setBounds(54, 289, 81, 26);
		lblShow.setText("Show");
		lblShow.setBackground(SWTResourceManager.getColor(45, 45, 45));
		lblShow.setForeground(SWTResourceManager.getColor(245, 245, 245));
		lblShow.setFont(SWTResourceManager.getFont("Georgia", 9, SWT.BOLD));
		lblShow.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				readHistory();
			}
		});
		lblShow.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				lblShow.setBackground(SWTResourceManager.getColor(86, 86, 86));
			}
			@Override
			public void mouseExit(MouseEvent e) {
				lblShow.setBackground(SWTResourceManager.getColor(45, 45, 45));
			}
		});
		
		frameDetail = new Composite(this, SWT.NONE);
		frameDetail.setBounds(203, 36, shell.getBounds().width-265, shell.getBounds().height-75);
		frameDetail.setBackground(SWTResourceManager.getColor(255, 255, 255));
				
		scrolledComposite = new ScrolledComposite(frameDetail, SWT.H_SCROLL | SWT.V_SCROLL);
		scrolledComposite.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		scrolledComposite.setBounds(0, 0, frameDetail.getBounds().width-10, frameDetail.getBounds().height);
		scrolledComposite.setExpandHorizontal(true);
		scrolledComposite.setExpandVertical(true);
		
		frameMain = new Composite(scrolledComposite, SWT.NONE);
		frameMain.setBackground(SWTResourceManager.getColor(255, 255, 255));
		
		CLabel lblDate = new CLabel(frameMain, SWT.CENTER);
		lblDate.setFont(SWTResourceManager.getFont("Georgia", 10, SWT.BOLD));
		lblDate.setBounds(10, 33, 120, 24);
		lblDate.setText("Date");
		
		CLabel lblTime = new CLabel(frameMain, SWT.CENTER);
		lblTime.setFont(SWTResourceManager.getFont("Georgia", 10, SWT.BOLD));
		lblTime.setBounds(132, 33, 83, 24);
		lblTime.setText("Time");
		
		CLabel lblType = new CLabel(frameMain, SWT.CENTER);
		lblType.setFont(SWTResourceManager.getFont("Georgia", 10, SWT.BOLD));
		lblType.setBounds(217, 33, 100, 24);
		lblType.setText("Type");
		
		CLabel lblCustomer = new CLabel(frameMain, SWT.CENTER);
		lblCustomer.setFont(SWTResourceManager.getFont("Georgia", 10, SWT.BOLD));
		lblCustomer.setBounds(318, 33, 187, 24);
		lblCustomer.setText("Customer");
		
		CLabel lblSubject = new CLabel(frameMain, SWT.CENTER);
		lblSubject.setFont(SWTResourceManager.getFont("Georgia", 10, SWT.BOLD));
		lblSubject.setBounds(507, 33, 234, 24);
		lblSubject.setText("Subject");
		
		CLabel lblFollowUpBy = new CLabel(frameMain, SWT.CENTER);
		lblFollowUpBy.setFont(SWTResourceManager.getFont("Georgia", 10, SWT.BOLD));
		lblFollowUpBy.setBounds(743, 33, 120, 24);
		lblFollowUpBy.setText("Owner");
		
		tblHistory = new Table(frameMain, SWT.FULL_SELECTION);
		tblHistory.setBounds(10, 63, 870, 302);
		tblHistory.addListener(SWT.MeasureItem, new Listener() {
			public void handleEvent(Event event) {
			      event.height = 30;
			   }
			});
		
		TableColumn tableColumn = new TableColumn(tblHistory, SWT.NONE);
		tableColumn.setWidth(120);
		
		TableColumn tableColumn_1 = new TableColumn(tblHistory, SWT.CENTER);
		tableColumn_1.setResizable(false);
		tableColumn_1.setWidth(86);
		
		TableColumn tableColumn_2 = new TableColumn(tblHistory, SWT.CENTER);
		tableColumn_2.setResizable(false);
		tableColumn_2.setWidth(102);
		
		TableColumn tableColumn_3 = new TableColumn(tblHistory, SWT.NONE);
		tableColumn_3.setResizable(false);
		tableColumn_3.setWidth(190);
		
		TableColumn tableColumn_4 = new TableColumn(tblHistory, SWT.NONE);
		tableColumn_4.setResizable(false);
		tableColumn_4.setWidth(234);
		
		TableColumn tableColumn_5 = new TableColumn(tblHistory, SWT.NONE);
		tableColumn_5.setResizable(false);
		tableColumn_5.setWidth(120);
		
		btnSeparator = new Button(frameDetail, SWT.FLAT);
		btnSeparator.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				changeFrameWidth();
			}
		});
		btnSeparator.setBounds(scrolledComposite.getBounds().width, 0, 10, shell.getBounds().height-75);
		btnSeparator.setImage(new Image(shell.getDisplay(), this.getClass().getResourceAsStream("/images/separator.png")));			
		
		frameSide = new Composite(frameDetail, SWT.NONE);
		frameSide.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		
		lblSaveAction = new CLabel(frameSide, SWT.CENTER);
		lblSaveAction.setForeground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblSaveAction.setFont(SWTResourceManager.getFont("Georgia", 11, SWT.BOLD));
		lblSaveAction.setBounds(0, 0, 120, 30);
		lblSaveAction.setBackground(SWTResourceManager.getColor(52, 64, 88));
		lblSaveAction.setText("Done");
		lblSaveAction.setVisible(false);
		lblSaveAction.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				if(frameNewHistory == null)
					return;
			}
		});
		lblSaveAction.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				lblSaveAction.setBackground(SWTResourceManager.getColor(77, 99, 132));
				lblSaveAction.setForeground(SWTResourceManager.getColor(52, 64, 88));
			}
			@Override
			public void mouseExit(MouseEvent e) {
				lblSaveAction.setBackground(SWTResourceManager.getColor(52, 64, 88));
				lblSaveAction.setForeground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
			}
		});
		
		lblCancelAction = new CLabel(frameSide, SWT.CENTER);
		lblCancelAction.setForeground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblCancelAction.setFont(SWTResourceManager.getFont("Georgia", 10, SWT.BOLD));
		lblCancelAction.setBounds(122, 0, 120, 30);
		lblCancelAction.setBackground(SWTResourceManager.getColor(52, 64, 88));
		lblCancelAction.setText("Cancel");
		lblCancelAction.setVisible(false);
		lblCancelAction.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				layoutMode = 1;
				changeFrameWidth();
			}
		});
		lblCancelAction.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				lblCancelAction.setBackground(SWTResourceManager.getColor(77, 99, 132));
				lblCancelAction.setForeground(SWTResourceManager.getColor(52, 64, 88));
			}
			@Override
			public void mouseExit(MouseEvent e) {
				lblCancelAction.setBackground(SWTResourceManager.getColor(52, 64, 88));
				lblCancelAction.setForeground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
			}
		});
		
		scrolledComposite.setContent(frameMain);
		scrolledComposite.setMinSize(frameMain.computeSize(SWT.DEFAULT, SWT.DEFAULT));
		
		initialize();
	}

	private void initialize(){
		try{
			List<Contact> col = dbConnector.readContact(null, null, "firstName");
			for(int i=0; i<col.size(); i++){
				Contact contact = col.get(i);
				TableItem ti = new TableItem(tblCustomer, SWT.NONE);
				ti.setText(contact.getFullName());
				ti.setData(contact);
			}
		}catch(Exception e){
			MessageDialog dlg = new MessageDialog(shell, SWT.NONE, "Error 400 : Database Problems");
			dlg.open();
		}
		
	}
	
	public void readHistory(){
		try{
			SimpleDateFormat sdf = new SimpleDateFormat("EEE, dd MMM yyyy");
			SimpleDateFormat stf = new SimpleDateFormat("HH:mm:ss z");
			
			String person = "";
			for(int i=0; i<tblCustomer.getItemCount(); i++){
				if(!tblCustomer.getItem(i).getChecked())
					continue;
				
				Contact contact = (Contact)tblCustomer.getItem(i).getData();
				person += "'"+contact.getContactId()+"',";
			}
			if(person.endsWith(","))
				person = person.substring(0, person.length()-1);	
			
			List<TableRow> col = new ArrayList<TableRow>();
			// Retrieve log
			String condition = getDateCondition("logDateTime");
			String sql = "";
			if(condition != null)
				sql = condition+" AND ";
			if(person.length() > 0)
				sql +="contactId IN ("+person+")";
			if(sql.endsWith("AND "))
				sql = sql.substring(0, sql.length()-4);
								
			List<History> logs = dbConnector.readHistory(null, sql, null);
			for(int i=0; i<logs.size(); i++){
				History activity = logs.get(i);
				col.add(new TableRow(activity.getLogDateTime(), activity));
			}
			
			// Retrieve Sales
			condition = getDateCondition("date");
			sql = "";
			if(condition != null)
				sql = condition+" AND ";
			if(person.length() > 0)
				sql +="customer IN ("+person+")";
			if(sql.endsWith("AND "))
				sql = sql.substring(0, sql.length()-4);
			
			List<Sales> sales = dbConnector.readSales(null, sql, null);
			for(int i=0; i<sales.size(); i++){
				Sales sale = sales.get(i);
				col.add(new TableRow(sale.getDate(), sale));
			}
			
			// Retrieve FollowUp
			condition = getDateCondition("date");
			sql = "";
			if(condition != null)
				sql  = condition+" AND ";
			if(person.length() > 0)
				sql +="contactId IN ("+person+")";
			if(sql.endsWith("AND "))
				sql = sql.substring(0, sql.length()-4);
				
			List<FollowUpTask> tasks = dbConnector.readTask(null, sql, null);
			for(int i=0; i<tasks.size(); i++){
				FollowUpTask task = tasks.get(i);
				col.add(new TableRow(task.getDate(), task));
			}
						
			//Sort by date
			TableRow[] rows = new TableRow[col.size()];
			for(int i=0; i<col.size(); i++)
				rows[i] = col.get(i);
			Arrays.sort(rows, BY_DATE);
			
			//Display logs
			tblHistory.removeAll();
			for(int i=0; i<rows.length; i++){
				TableRow row = rows[i];
				String str = "";
				
				if(row.data instanceof History){
					History activity = (History) row.data;				
					if(activity.getSubject() != null)
						str = activity.getSubject()+".";
					if(activity.getNotes() != null)
						str += activity.getNotes();
					
					TableItem ti = new TableItem(tblHistory, SWT.NONE);
					ti.setText(new String[]{sdf.format(activity.getLogDateTime()), stf.format(activity.getLogDateTime()), activity.getType(), 
							activity.getContactId()+" - "+activity.getContactName(), str, activity.getCreatedBy()});
					ti.setData(activity);
				}else if(row.data instanceof Sales){
					Sales sale = (Sales) row.data;
					if(sale.getType() != null)
						str = sale.getType();
					if(sale.getAmount() != null)
						str += "("+Sales.CurrencyFormat(sale.getAmount())+")";
					
					TableItem ti = new TableItem(tblHistory, SWT.NONE);
					ti.setText(new String[]{sdf.format(sale.getDate()), "-", "Sales", sale.getCustomer(), str, "-"});
					ti.setData(sale);
				}else if(row.data instanceof FollowUpTask){
					FollowUpTask task = (FollowUpTask) row.data;
					if(task.getSubject() != null)
						str = task.getSubject()+".";
					if(task.getNotes() != null)
						str += task.getNotes();
					
					TableItem ti = new TableItem(tblHistory, SWT.NONE);
					ti.setText(new String[]{sdf.format(task.getDate()), task.getTime(), "Follow Up", task.getContactId()+" - "+task.getContactName(), str, task.getCreatedBy()});
					ti.setData(task);
				}
			}
		}catch(Exception e){
			e.printStackTrace();
			MessageDialog dlg = new MessageDialog(shell, SWT.NONE, "Error 400 : Database Problems");
			dlg.open();
		}
		
	}	
	
	private String getDateCondition(String dateFieldName){
		String condition = null;
		if(!btnAllPeriod.getSelection()){
			if(txtDay.getText().length()>0)
				condition = "DATEDIFF(CURDATE(),DATE("+dateFieldName+")) <= "+txtDay.getText();
			else {
				Calendar from = Calendar.getInstance();
				from.set(dateTimeFrom.getYear(), dateTimeFrom.getMonth(), dateTimeFrom.getDay(), 0, 0); 
				Calendar to = Calendar.getInstance();
				to.set(dateTimeTo.getYear(), dateTimeTo.getMonth(), dateTimeTo.getDay(), 0, 0); 
				
				condition = "(DATE("+dateFieldName+" / 1000, 'unixepoch', 'localtime') >='"+sdf.format(from.getTime())+"' AND DATE("+dateFieldName+" / 1000, 'unixepoch', 'localtime')<='"+sdf.format(to.getTime())+"')";
			}
		}else{
			condition = "DATE("+dateFieldName+" / 1000, 'unixepoch', 'localtime') >='"+sdf.format(new Date().getTime())+"'";
		}
		
		return condition;
	}
		
	public final Comparator<TableRow> BY_DATE = new Comparator<TableRow>() {
        @Override
        public int compare(TableRow o1, TableRow o2) {
            return o1.date.compareTo(o2.date);
        }
    };
        
    private class TableRow {
        private Date date;
        private Object data;

        public TableRow(Date date, Object data) {
            this.date = date;
            this.data = data;
        }
    }
    
	private void changeFrameWidth(){
		if(layoutMode == 0){
			layoutMode = 1;
			
			scrolledComposite.setBounds(0, 0, (frameDetail.getBounds().width/3*2)-15, frameDetail.getBounds().height);
			btnSeparator.setBounds(scrolledComposite.getBounds().width, 0, 10, shell.getBounds().height-75);
			frameSide.setBounds((frameDetail.getBounds().width/3*2), 0, (frameDetail.getBounds().width/3), frameDetail.getBounds().height);
		}else{
			layoutMode = 0;
			
			scrolledComposite.setBounds(0, 0, frameDetail.getBounds().width-10, frameDetail.getBounds().height);
			btnSeparator.setBounds(scrolledComposite.getBounds().width, 0, 10, shell.getBounds().height-75);
			frameSide.setBounds(0, 0, 0, 0);
		}
		frameDetail.redraw();
	}
	
	private void openAddFrame(){				
		layoutMode = 0;
		changeFrameWidth();
		frameNewHistory = new HistoryInfo(frameSide, SWT.NONE);
		frameNewHistory.setBounds(0, 32, frameSide.getBounds().width, frameSide.getBounds().height-30);
	}
	
	private void hideFrameSide(int index){
		if(frameNewHistory != null){
			frameNewHistory.setVisible(index==0);
		}
		
		if(index == 0){
			lblSaveAction.setVisible(true);
			lblCancelAction.setVisible(true);
		}else{
			lblSaveAction.setVisible(false);
			lblCancelAction.setVisible(false);
		}
		
	}
	
	@Override
	protected void checkSubclass() {
		// Disable the check that prevents subclassing of SWT components
	}
}
