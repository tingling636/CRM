package com.blackcode.crmgui;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;

import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.custom.CLabel;
import org.eclipse.swt.custom.ScrolledComposite;
import org.eclipse.swt.SWT;
import org.eclipse.wb.swt.SWTResourceManager;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.DateTime;
import org.eclipse.swt.widgets.TableItem;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.events.MouseAdapter;
import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.events.MouseTrackAdapter;

import com.blackcode.core.SQLiteConnector;
import com.blackcode.model.FollowUpTask;

public class CallLogFrame extends Composite {
	private Text txtContactId;
	private Table tblLog;
	private DateTime dateTimeTo, dateTimeFrom;

	/**
	 * Create the composite.
	 * @param parent
	 * @param style
	 */
	public CallLogFrame(Composite parent, int style, String numbers) {
		super(parent, style);
		
		ScrolledComposite scrolledComposite = new ScrolledComposite(this, SWT.BORDER | SWT.H_SCROLL | SWT.V_SCROLL);
		scrolledComposite.setBounds(0, 0, parent.getBounds().width-5, parent.getBounds().height-28);
		scrolledComposite.setExpandHorizontal(true);
		scrolledComposite.setExpandVertical(true);
		
		Composite composite = new Composite(scrolledComposite, SWT.NONE);
		composite.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		
		Label lblDate = new Label(composite, SWT.NONE);
		lblDate.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblDate.setBounds(39, 18, 36, 15);
		lblDate.setText("Date");
		
		dateTimeFrom = new DateTime(composite, SWT.BORDER | SWT.DROP_DOWN);
		dateTimeFrom.setBounds(81, 15, 104, 24);
		
		Label lblTo = new Label(composite, SWT.NONE);
		lblTo.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblTo.setBounds(191, 18, 20, 15);
		lblTo.setText("To");
		
		dateTimeTo = new DateTime(composite, SWT.BORDER | SWT.DROP_DOWN);
		dateTimeTo.setBounds(217, 15, 104, 24);
		
		Label lblContactId = new Label(composite, SWT.RIGHT);
		lblContactId.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblContactId.setBounds(20, 48, 92, 15);
		lblContactId.setText("Contact Id");
		
		txtContactId = new Text(composite, SWT.BORDER);
		txtContactId.setBounds(125, 45, 196, 21);
		if(numbers != null)
			txtContactId.setText(numbers);
		
		final CLabel lblSearch = new CLabel(composite, SWT.CENTER);
		lblSearch.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				refresh();
			}
		});
		lblSearch.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				lblSearch.setBackground(SWTResourceManager.getColor(86, 86, 86));
			}
			@Override
			public void mouseExit(MouseEvent e) {
				lblSearch.setBackground(SWTResourceManager.getColor(45, 45, 45));
			}
		});
		lblSearch.setText("Search");
		lblSearch.setBounds(337, 45, 62, 24);
		lblSearch.setBackground(SWTResourceManager.getColor(45, 45, 45));
		lblSearch.setForeground(SWTResourceManager.getColor(245, 245, 245));
		lblSearch.setFont(SWTResourceManager.getFont("Georgia", 9, SWT.BOLD));
				
		tblLog = new Table(composite, SWT.BORDER | SWT.FULL_SELECTION);
		tblLog.setBounds(10, 85, 435, 559);
		tblLog.setHeaderVisible(true);
		tblLog.setLinesVisible(true);
		
		TableColumn tblclmnDateTime = new TableColumn(tblLog, SWT.NONE);
		tblclmnDateTime.setWidth(120);
		tblclmnDateTime.setText("Date Time");
		
		TableColumn tblclmnCallee = new TableColumn(tblLog, SWT.CENTER);
		tblclmnCallee.setWidth(140);
		tblclmnCallee.setText("Contact");
		
		TableColumn tblclmnCallee_1 = new TableColumn(tblLog, SWT.NONE);
		tblclmnCallee_1.setWidth(170);
		tblclmnCallee_1.setText("Subject");
		
		scrolledComposite.setContent(composite);
		scrolledComposite.setMinSize(composite.computeSize(SWT.DEFAULT, SWT.DEFAULT));
		
		refresh();
	}
	
	
	private void refresh(){
		SimpleDateFormat sqlsdf = new SimpleDateFormat("yyyy-MM-dd");
		
		Calendar c1 = Calendar.getInstance();
		c1.set(dateTimeFrom.getYear(), dateTimeFrom.getMonth(), dateTimeFrom.getDay(), 0, 0); 
		Calendar c2 = Calendar.getInstance();
		c2.set(dateTimeTo.getYear(), dateTimeTo.getMonth(), dateTimeTo.getDay(), 0, 0);
		String sql = "(DATE(date/ 1000, 'unixepoch', 'localtime')>='"+sqlsdf.format(c1.getTime())+"' "
				+ "AND DATE(date/ 1000, 'unixepoch', 'localtime')<='"+sqlsdf.format(c2.getTime())+"') AND type='Call' AND";
		if(txtContactId.getText().length()>0){
			String numbers="";
			String[] strs = txtContactId.getText().split(",");
			for(int i=0;i<strs.length; i++)
				numbers +="'"+strs[i]+"',";
			if(numbers.endsWith(","))
				numbers = numbers.substring(0, numbers.length()-1);
			
			sql += " contactId IN ("+numbers+") AND";
		}
				
		if(sql.endsWith("AND"))
			sql = sql.substring(0, sql.length()-3);
				
		List<FollowUpTask> col = new SQLiteConnector().readTask(null, sql, "date, time desc");
		tblLog.removeAll();
		for(int i=0; i<col.size(); i++){
			FollowUpTask log = col.get(i);
			
			TableItem ti = new TableItem(tblLog, SWT.NONE);
			ti.setText(new String[]{log.getDate()+"  "+log.getTime(), log.getContactId()+" "+log.getContactName(), log.getSubject()});
			ti.setData(log);
		}
	}
	
	@Override
	protected void checkSubclass() {
		// Disable the check that prevents subclassing of SWT components
	}
}
