package com.blackcode.crmgui;

import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.custom.CLabel;
import org.eclipse.swt.custom.ScrolledComposite;
import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.events.MouseTrackAdapter;
import org.eclipse.swt.SWT;
import org.eclipse.wb.swt.SWTResourceManager;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.widgets.TableItem;
import org.eclipse.swt.events.MouseAdapter;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.layout.FormAttachment;
import org.eclipse.swt.layout.FormData;
import org.eclipse.swt.layout.GridData;

import com.blackcode.core.SQLiteConnector;
import com.blackcode.model.Sales;

import org.eclipse.swt.widgets.Label;
import org.swtchart.Chart;
import org.swtchart.IBarSeries;
import org.swtchart.ISeries.SeriesType;

public class PersonSales extends Composite {
	private Composite composite;
	private Composite frameDetail, frameSummary, frameDashboard;
	private Table tblOrder;
	private CLabel lblPeriod;
	private CLabel lblRefNo, lblDate, lblType, lblItem, lblVolume, lblPrice, lblCharge1, lblCharge2, lblAmount, lblStatus, lblStatusDate, lblSalesman;
	private CLabel lblSummary, lblDetail, lblDashboard;
	
	private String[] monthStr = new String[]{"January","February","March","April","May","Jun","July","August","September","October","November","December"};
	private SQLiteConnector dbConnector = new SQLiteConnector();
	private String contactId = null;
	private int currentOption=0;
	private String[] categorySeriesX;
	private double[][] bars = new double[][]{new double[5],new double[5],new double[5],new double[5],new double[5],new double[5],new double[5],
			new double[5],new double[5],new double[5],new double[5],new double[5]};
	
	/**
	 * Create the composite.
	 * @param parent
	 * @param style
	 */
	public PersonSales(Composite parent, int style, String contactId) {
		super(parent, style);
		this.contactId = contactId;
		
		ScrolledComposite scrolledComposite = new ScrolledComposite(this, SWT.BORDER | SWT.H_SCROLL | SWT.V_SCROLL);
		scrolledComposite.setBounds(0, 0, parent.getBounds().width-5, parent.getBounds().height-28);
		scrolledComposite.setExpandHorizontal(true);
		scrolledComposite.setExpandVertical(true);
		
		composite = new Composite(scrolledComposite, SWT.NONE);
		composite.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));		
		
		lblSummary = new CLabel(composite, SWT.CENTER);
		lblSummary.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				frameSummary.setVisible(true);
				frameDetail.setVisible(false);
				frameDashboard.setVisible(false);
				currentOption = 0;
				lblSummary.setBackground(SWTResourceManager.getColor(86, 86, 86));
				lblDetail.setBackground(SWTResourceManager.getColor(45, 45, 45));
				lblDashboard.setBackground(SWTResourceManager.getColor(45, 45, 45));
			}
		});
		lblSummary.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				lblSummary.setBackground(SWTResourceManager.getColor(86, 86, 86));
			}
			@Override
			public void mouseExit(MouseEvent e) {
				if(currentOption != 0)
					lblSummary.setBackground(SWTResourceManager.getColor(45, 45, 45));
			}
		});
		lblSummary.setBounds(10, 10, 94, 27);
		lblSummary.setText("Summary");
		lblSummary.setBackground(SWTResourceManager.getColor(86, 86, 86));
		lblSummary.setForeground(SWTResourceManager.getColor(245, 245, 245));
		lblSummary.setFont(SWTResourceManager.getFont("Georgia", 9, SWT.BOLD));
		lblSummary.setToolTipText("Show Sales Summary");
				
		lblDetail = new CLabel(composite, SWT.CENTER);
		lblDetail.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				frameSummary.setVisible(false);
				frameDetail.setVisible(true);
				frameDashboard.setVisible(false);
				currentOption = 1;
				lblDetail.setBackground(SWTResourceManager.getColor(86, 86, 86));
				lblSummary.setBackground(SWTResourceManager.getColor(45, 45, 45));
				lblDashboard.setBackground(SWTResourceManager.getColor(45, 45, 45));
			}
		});
		lblDetail.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				lblDetail.setBackground(SWTResourceManager.getColor(86, 86, 86));
			}
			@Override
			public void mouseExit(MouseEvent e) {
				if(currentOption != 1)
					lblDetail.setBackground(SWTResourceManager.getColor(45, 45, 45));
			}
		});
		lblDetail.setBounds(110, 10, 94, 27);
		lblDetail.setText("Detail");
		lblDetail.setBackground(SWTResourceManager.getColor(45, 45, 45));
		lblDetail.setForeground(SWTResourceManager.getColor(245, 245, 245));
		lblDetail.setFont(SWTResourceManager.getFont("Georgia", 9, SWT.BOLD));
		lblDetail.setToolTipText("Show Sales Transaction Detail");
				
		lblDashboard = new CLabel(composite, SWT.CENTER);
		lblDashboard.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				frameSummary.setVisible(false);
				frameDetail.setVisible(false);
				frameDashboard.setVisible(true);
				currentOption = 2;
				lblDashboard.setBackground(SWTResourceManager.getColor(86, 86, 86));
				lblSummary.setBackground(SWTResourceManager.getColor(45, 45, 45));
				lblDetail.setBackground(SWTResourceManager.getColor(45, 45, 45));
			}
		});
		lblDashboard.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				lblDashboard.setBackground(SWTResourceManager.getColor(86, 86, 86));
			}
			@Override
			public void mouseExit(MouseEvent e) {
				if(currentOption != 2)
					lblDashboard.setBackground(SWTResourceManager.getColor(45, 45, 45));
			}
		});
		lblDashboard.setBounds(210, 10, 94, 27);
		lblDashboard.setText("Dashboard");
		lblDashboard.setBackground(SWTResourceManager.getColor(45, 45, 45));
		lblDashboard.setForeground(SWTResourceManager.getColor(245, 245, 245));
		lblDashboard.setFont(SWTResourceManager.getFont("Georgia", 9, SWT.BOLD));	
		lblDashboard.setToolTipText("Show Dashboard");
		
		final CLabel lblNewSales = new CLabel(composite, SWT.CENTER);
		lblNewSales.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				salesDetail();
			}
		});
		lblNewSales.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				lblNewSales.setBackground(SWTResourceManager.getColor(86, 86, 86));
			}
			@Override
			public void mouseExit(MouseEvent e) {
				lblNewSales.setBackground(SWTResourceManager.getColor(45, 45, 45));
			}
		});
		lblNewSales.setBounds(310, 10, 94, 27);
		lblNewSales.setText("New Sales");
		lblNewSales.setBackground(SWTResourceManager.getColor(45, 45, 45));
		lblNewSales.setForeground(SWTResourceManager.getColor(245, 245, 245));
		lblNewSales.setFont(SWTResourceManager.getFont("Georgia", 9, SWT.BOLD));
		lblNewSales.setToolTipText("Add New Sales Transaction");
				
		frameDashboard = new Composite(composite, SWT.NONE);
		frameDashboard.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		frameDashboard.setBounds(10, 43, 434, 433);
		frameDashboard.setVisible(false);
		
		frameSummary = new Composite(composite, SWT.NONE);
		frameSummary.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		frameSummary.setBounds(10, 43, 434, 433);
						
		int y=33;
		for(int i=0; i<monthStr.length; i++){
			CLabel lblJanuary = new CLabel(frameSummary, SWT.RIGHT);
			lblJanuary.setRightMargin(5);
			lblJanuary.setBounds(5, y, 72, 21);
			lblJanuary.setText(monthStr[i]);
			lblJanuary.setBackground(SWTResourceManager.getColor(193, 205, 193));
			lblJanuary.setForeground(SWTResourceManager.getColor(45, 48, 39));
			y+=24;
		}
		
		frameDetail = new Composite(composite, SWT.NONE);
		frameDetail.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		frameDetail.setLocation(10, 43);
		frameDetail.setSize(426, 403);
		frameDetail.setVisible(false);
		
		lblPeriod = new CLabel(frameDetail, SWT.NONE);
		lblPeriod.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblPeriod.setFont(SWTResourceManager.getFont("Times New Roman", 11, SWT.BOLD));
		lblPeriod.setBounds(35, 10, 367, 21);		
		
		tblOrder = new Table(frameDetail, SWT.FULL_SELECTION);
		tblOrder.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDoubleClick(MouseEvent e) {
				if(tblOrder.getSelectionIndex() == -1)
					return;
				
				showSaleDetail((Sales)tblOrder.getSelection()[0].getData());
			}
		});
		tblOrder.setBackground(SWTResourceManager.getColor(248, 248, 242));
		tblOrder.setLocation(10, 37);
		tblOrder.setSize(114, 324);
		
		TableColumn tableColumn = new TableColumn(tblOrder, SWT.NONE);
		tableColumn.setWidth(100);
		
		CLabel lblRefNoTitle = new CLabel(frameDetail, SWT.RIGHT);
		lblRefNoTitle.setFont(SWTResourceManager.getFont("Times New Roman", 9, SWT.BOLD));
		lblRefNoTitle.setRightMargin(5);
		lblRefNoTitle.setBounds(130, 37, 81, 21);
		lblRefNoTitle.setText("Ref No :");
		
		CLabel lblTypeTitle = new CLabel(frameDetail, SWT.RIGHT);
		lblTypeTitle.setFont(SWTResourceManager.getFont("Times New Roman", 10, SWT.BOLD));
		lblTypeTitle.setBounds(130, 64, 81, 21);
		lblTypeTitle.setText("Type : ");
		
		CLabel lblDateTitle = new CLabel(frameDetail, SWT.RIGHT);
		lblDateTitle.setFont(SWTResourceManager.getFont("Times New Roman", 10, SWT.BOLD));
		lblDateTitle.setBounds(130, 91, 81, 21);
		lblDateTitle.setText("Date : ");
		
		CLabel lblVolumeTitle = new CLabel(frameDetail, SWT.RIGHT);
		lblVolumeTitle.setFont(SWTResourceManager.getFont("Times New Roman", 10, SWT.BOLD));
		lblVolumeTitle.setBounds(130, 147, 81, 21);
		lblVolumeTitle.setText("Volume : ");
		
		CLabel lblPriceTitle = new CLabel(frameDetail, SWT.RIGHT);
		lblPriceTitle.setFont(SWTResourceManager.getFont("Times New Roman", 10, SWT.BOLD));
		lblPriceTitle.setBounds(130, 174, 81, 21);
		lblPriceTitle.setText("Price : ");
		
		CLabel lblCharge1Title = new CLabel(frameDetail, SWT.RIGHT);
		lblCharge1Title.setFont(SWTResourceManager.getFont("Times New Roman", 10, SWT.BOLD));
		lblCharge1Title.setBounds(130, 201, 81, 21);
		lblCharge1Title.setText("Charge 1 : ");
		
		CLabel lblCharge = new CLabel(frameDetail, SWT.RIGHT);
		lblCharge.setFont(SWTResourceManager.getFont("Times New Roman", 10, SWT.BOLD));
		lblCharge.setBounds(130, 228, 81, 21);
		lblCharge.setText("Charge 2 : ");
		
		CLabel lblAmountTitle = new CLabel(frameDetail, SWT.RIGHT);
		lblAmountTitle.setFont(SWTResourceManager.getFont("Times New Roman", 10, SWT.BOLD));
		lblAmountTitle.setBounds(130, 255, 81, 21);
		lblAmountTitle.setText("Amount : ");
		
		CLabel lblStatusTitle = new CLabel(frameDetail, SWT.RIGHT);
		lblStatusTitle.setFont(SWTResourceManager.getFont("Times New Roman", 10, SWT.BOLD));
		lblStatusTitle.setBounds(130, 282, 81, 21);
		lblStatusTitle.setText("Status : ");
		
		CLabel lblStatusDateTitle = new CLabel(frameDetail, SWT.RIGHT);
		lblStatusDateTitle.setFont(SWTResourceManager.getFont("Times New Roman", 10, SWT.BOLD));
		lblStatusDateTitle.setBounds(130, 309, 81, 21);
		lblStatusDateTitle.setText("Status Date : ");
		
		CLabel lblSalesmanTitle = new CLabel(frameDetail, SWT.RIGHT);
		lblSalesmanTitle.setFont(SWTResourceManager.getFont("Times New Roman", 10, SWT.BOLD));
		lblSalesmanTitle.setBounds(130, 340, 81, 21);
		lblSalesmanTitle.setText("Salesman : ");
		
		lblRefNo = new CLabel(frameDetail, SWT.NONE);
		lblRefNo.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblRefNo.setBounds(216, 37, 160, 21);
		
		lblType = new CLabel(frameDetail, SWT.NONE);
		lblType.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblType.setBounds(217, 64, 159, 21);
		
		lblDate = new CLabel(frameDetail, SWT.NONE);
		lblDate.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblDate.setBounds(217, 91, 159, 21);
		
		lblVolume = new CLabel(frameDetail, SWT.NONE);
		lblVolume.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblVolume.setBounds(217, 147, 159, 21);
		
		lblPrice = new CLabel(frameDetail, SWT.NONE);
		lblPrice.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblPrice.setBounds(217, 174, 159, 21);
		
		lblCharge1 = new CLabel(frameDetail, SWT.NONE);
		lblCharge1.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblCharge1.setBounds(217, 201, 159, 21);
		
		lblCharge2 = new CLabel(frameDetail, SWT.NONE);
		lblCharge2.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblCharge2.setBounds(217, 228, 159, 21);
		
		lblAmount = new CLabel(frameDetail, SWT.NONE);
		lblAmount.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblAmount.setBounds(217, 255, 159, 21);
		
		lblStatus = new CLabel(frameDetail, SWT.NONE);
		lblStatus.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblStatus.setBounds(216, 282, 160, 21);
		
		lblStatusDate = new CLabel(frameDetail, SWT.NONE);
		lblStatusDate.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblStatusDate.setBounds(217, 309, 159, 21);
		
		lblSalesman = new CLabel(frameDetail, SWT.NONE);
		lblSalesman.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblSalesman.setBounds(217, 340, 159, 21);
		
		CLabel lblItemTitle = new CLabel(frameDetail, SWT.RIGHT);
		lblItemTitle.setFont(SWTResourceManager.getFont("Times New Roman", 9, SWT.BOLD));
		lblItemTitle.setBounds(130, 118, 81, 21);
		lblItemTitle.setText("Item : ");
		
		lblItem = new CLabel(frameDetail, SWT.NONE);
		lblItem.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblItem.setBounds(216, 118, 160, 21);
		
		CLabel lblDetailPeriod = new CLabel(frameDetail, SWT.NONE);
		lblDetailPeriod.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				refreshDefaultSaleByPeriod();
			}
		});
		lblDetailPeriod.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblDetailPeriod.setBounds(10, 10, 21, 21);
		lblDetailPeriod.setImage(new Image(parent.getDisplay(), this.getClass().getResourceAsStream("/images/back_small.png")));
		
		Label line = new Label(composite, SWT.SEPARATOR | SWT.HORIZONTAL);
		line.setBounds(10, 39, 430, 2);

		scrolledComposite.setContent(composite);
		scrolledComposite.setMinSize(composite.computeSize(SWT.DEFAULT, SWT.DEFAULT));	
		
		defaultSalesSource();
		createSalesChart();
	}

	private void defaultSalesSource(){
		categorySeriesX = new String[5];
		int year = Calendar.getInstance().get(Calendar.YEAR);
		int x = 79;
		for(int i=0; i<5; i++){
			categorySeriesX[i] = year+"";
			
			CLabel lblYear = new CLabel(frameSummary, SWT.CENTER);
			lblYear.setBounds(x, 10, 61, 21);
			lblYear.setText(year+"");
			lblYear.setBackground(SWTResourceManager.getColor(166, 226, 46));
			lblYear.setForeground(SWTResourceManager.getColor(33, 38, 18));
			
			int y=33;
			for(int j=1; j<=12; j++){
				String month = j+"";
				if(j<10)
					month = "0"+j;
				
				String sql = "date(Date / 1000, 'unixepoch', 'localtime')>='"+year+"-"+month+"-01' AND date(Date / 1000, 'unixepoch', 'localtime')<='"+year+"-"+month+"-31'";
				if(contactId != null)
					sql += " AND Customer='"+contactId+"'";
				List<Sales> salesCol = dbConnector.readSales(null, sql, null);
				BigDecimal salesAmt = new BigDecimal(0);
				for(int z=0; z<salesCol.size(); z++){
					Sales sale = salesCol.get(z);
					salesAmt =salesAmt.add(sale.getAmount());
				}
				
				if(salesAmt.compareTo(new BigDecimal(0)) > 0){
					CLabel lblSales = new CLabel(frameSummary, SWT.CENTER);
					lblSales.addMouseListener(new MouseAdapter() {
						@Override
						public void mouseDown(MouseEvent e) {
							List<Sales> data = (List<Sales>) ((CLabel)e.widget).getData();
							String title = (String) ((CLabel)e.widget).getData("period");
							tblOrder.removeAll();
							clearSaleDetail();
							for(int z=0; z<data.size(); z++){
								Sales sale = data.get(z);
								TableItem ti = new TableItem(tblOrder, SWT.NONE);
								ti.setText(sale.getRefNo()==null? Sales.DateFormat(sale.getDate()): sale.getRefNo());
								ti.setData(sale);
							}
							lblPeriod.setText("Sales Transactions On "+title);
							
							frameSummary.setVisible(false);
							frameDetail.setVisible(true);
							currentOption = 1;
							lblDetail.setBackground(SWTResourceManager.getColor(86, 86, 86));
							lblSummary.setBackground(SWTResourceManager.getColor(45, 45, 45));
							lblDashboard.setBackground(SWTResourceManager.getColor(45, 45, 45));
							
						}
					});
					lblSales.setBackground(SWTResourceManager.getColor(246, 243, 230));
					lblSales.setBounds(x, y, 61, 21);
					lblSales.setText(salesAmt+"");
					lblSales.setData(salesCol);
					lblSales.setData("period", monthStr[j-1]+", "+year);
					
					bars[j-1][i] = salesAmt.doubleValue();
				}				
				y+=24;
			}
			x += 67;
			year--;
		}
	}
		
	private void refreshDefaultSaleByPeriod(){
		DateDialog dlg = new DateDialog(getShell(), SWT.NONE);
		dlg.open();
		Date[] selectedDates = dlg.getSelectedDate();
		if(selectedDates[0] == null || selectedDates[1]==null)
			return;
		
		clearSaleDetail();
		tblOrder.removeAll();
		String sql = "date(Date / 1000, 'unixepoch', 'localtime')>='"+SQLiteConnector.DateFormat(selectedDates[0])+"' AND date(Date / 1000, 'unixepoch', 'localtime')<='"+SQLiteConnector.DateFormat(selectedDates[1])+"'";
		if(contactId != null)
			sql += " AND Customer='"+contactId+"'";
		List<Sales> salesCol = dbConnector.readSales(null, sql, null);
		
		for(int z=0; z<salesCol.size(); z++){
			Sales sale = salesCol.get(z);
			TableItem ti = new TableItem(tblOrder, SWT.NONE);
			ti.setText(sale.getRefNo()==null? Sales.DateFormat(sale.getDate()): sale.getRefNo());
			ti.setData(sale);
		}
		lblPeriod.setText("Sales Transactions On "+Sales.DateFormat(selectedDates[0])+" - "+Sales.DateFormat(selectedDates[1]));
	}
	
	private void clearSaleDetail(){
		lblRefNo.setText("");
		lblType.setText("");
		lblDate.setText("");
		lblItem.setText("");
		lblVolume.setText("");
		lblPrice.setText("");
		lblCharge1.setText("");
		lblCharge2.setText("");
		lblAmount.setText("");
		lblStatus.setText("");
		lblStatusDate.setText("");
		lblSalesman.setText("");
	}
	
	private void showSaleDetail(Sales sale){
		SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
		
		lblRefNo.setText(displayText(sale.getRefNo()));
		lblType.setText(displayText(sale.getType()));
		if(sale.getDate() != null)
			lblDate.setText(sdf.format(sale.getDate()));
		lblItem.setText(displayText(sale.getItem()));
		lblVolume.setText(sale.getVolume()+" "+displayText(sale.getUom()));
		lblPrice.setText(Sales.CurrencyFormat(sale.getPrice()));
		lblCharge1.setText(Sales.CurrencyFormat(sale.getCharge1()));
		lblCharge2.setText(Sales.CurrencyFormat(sale.getCharge2()));
		lblAmount.setText(Sales.CurrencyFormat(sale.getAmount()));
		lblStatus.setText(displayText(sale.getStatus()));
		if(sale.getStatusDate() != null)
			lblStatusDate.setText(sdf.format(sale.getStatusDate()));
		lblSalesman.setText(displayText(sale.getSaleman()));
	}
	
	private void salesDetail(){
		SalesDialog dlg = new SalesDialog(getShell(), SWT.NONE, contactId);
		dlg.open();
		
		if(dlg.getSale()==null)
			return;
		
		Object sale = dbConnector.createSales(dlg.getSale());
		if(sale instanceof String){
			MessageDialog errdlg = new MessageDialog(this.getShell(), SWT.NONE, "Error 401 : System Problems (PS474)\nPlease Try Again");
			errdlg.open();
		}
	}
	
	private String displayText(Object obj){
		if(obj==null)
			return "";
		else
			return obj.toString();
	}
	
	private void createSalesChart(){
		frameDashboard.setLayout(new FillLayout());
		frameDashboard.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true));
        
		Chart chart = new Chart(frameDashboard, SWT.NONE);
		FormData formData = new FormData();
		formData.bottom = new FormAttachment(0, 483);
		formData.right = new FormAttachment(0, 444);
		formData.top = new FormAttachment(0, 43);
		formData.left = new FormAttachment(0, 10);
		chart.getPlotArea().setLayoutData(formData);
		
		// set titles
		chart.getTitle().setText("Sales Bar Chart");
		chart.getAxisSet().getXAxis(0).getTitle().setText("Year");
		chart.getAxisSet().getYAxis(0).getTitle().setText("Amount ($)/ Month");
		chart.getAxisSet().getYAxis(0).getTick().setFormat(new DecimalFormat("#,###"));

		// set category
		chart.getAxisSet().getXAxis(0).enableCategory(true);
		chart.getAxisSet().getXAxis(0).setCategorySeries(categorySeriesX);

		// create bar series
		IBarSeries barSeries1 = (IBarSeries) chart.getSeriesSet().createSeries( SeriesType.BAR, "Jan");
		barSeries1.setYSeries(bars[0]);
		barSeries1.setBarColor(SWTResourceManager.getColor(255, 255, 153));

		IBarSeries barSeries2 = (IBarSeries) chart.getSeriesSet().createSeries(SeriesType.BAR, "Feb");
		barSeries2.setYSeries(bars[1]);
		barSeries2.setBarColor(SWTResourceManager.getColor(204, 255, 255));
		
		IBarSeries barSeries3 = (IBarSeries) chart.getSeriesSet().createSeries(SeriesType.BAR, "Mar");
		barSeries3.setYSeries(bars[2]);
		barSeries3.setBarColor(SWTResourceManager.getColor(204, 255, 204));
		
		IBarSeries barSeries4 = (IBarSeries) chart.getSeriesSet().createSeries(SeriesType.BAR, "Apr");
		barSeries4.setYSeries(bars[3]);
		barSeries4.setBarColor(SWTResourceManager.getColor(204, 204, 255));
		
		IBarSeries barSeries5 = (IBarSeries) chart.getSeriesSet().createSeries(SeriesType.BAR, "May");
		barSeries5.setYSeries(bars[4]);
		barSeries5.setBarColor(SWTResourceManager.getColor(255, 204, 255));
		
		IBarSeries barSeries6 = (IBarSeries) chart.getSeriesSet().createSeries(SeriesType.BAR, "Jun");
		barSeries6.setYSeries(bars[5]);
		barSeries6.setBarColor(SWTResourceManager.getColor(255, 204, 153));
		
		IBarSeries barSeries7 = (IBarSeries) chart.getSeriesSet().createSeries(SeriesType.BAR, "Jul");
		barSeries7.setYSeries(bars[6]);
		barSeries7.setBarColor(SWTResourceManager.getColor(255, 204, 0));
		
		IBarSeries barSeries8 = (IBarSeries) chart.getSeriesSet().createSeries(SeriesType.BAR, "Aug");
		barSeries8.setYSeries(bars[7]);
		barSeries8.setBarColor(SWTResourceManager.getColor(153, 51, 153));
		
		IBarSeries barSeries9 = (IBarSeries) chart.getSeriesSet().createSeries(SeriesType.BAR, "Sep");
		barSeries9.setYSeries(bars[8]);
		barSeries9.setBarColor(SWTResourceManager.getColor(0, 153, 102));
		
		IBarSeries barSeries10 = (IBarSeries) chart.getSeriesSet().createSeries(SeriesType.BAR, "Oct");
		barSeries10.setYSeries(bars[9]);
		barSeries10.setBarColor(SWTResourceManager.getColor(51, 153, 204));
		
		IBarSeries barSeries11 = (IBarSeries) chart.getSeriesSet().createSeries(SeriesType.BAR, "Nov");
		barSeries11.setYSeries(bars[10]);
		barSeries11.setBarColor(SWTResourceManager.getColor(153, 153, 102));
		
		IBarSeries barSeries12 = (IBarSeries) chart.getSeriesSet().createSeries(SeriesType.BAR, "Dec");
		barSeries12.setYSeries(bars[11]);
		barSeries12.setBarColor(SWTResourceManager.getColor(204, 204, 204));

		// enable stack series
		barSeries1.enableStack(true);
		barSeries2.enableStack(true);
		barSeries3.enableStack(true);
		barSeries4.enableStack(true);
		barSeries5.enableStack(true);
		barSeries6.enableStack(true);
		barSeries7.enableStack(true);
		barSeries8.enableStack(true);
		barSeries9.enableStack(true);
		barSeries10.enableStack(true);
		barSeries11.enableStack(true);
		barSeries12.enableStack(true);

		// adjust the axis range
		chart.getAxisSet().adjustRange();
	}
	
	@Override
	protected void checkSubclass() {
		// Disable the check that prevents subclassing of SWT components
	}
}
