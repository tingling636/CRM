package com.blackcode.crmgui;

import java.util.List;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.MouseAdapter;
import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.events.MouseTrackAdapter;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Dialog;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.wb.swt.SWTResourceManager;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.custom.CCombo;
import org.eclipse.swt.custom.CLabel;

import com.blackcode.core.SQLiteConnector;
import com.blackcode.model.EmailCampaign;

public class GroupEmailOptionDialog extends Dialog {

	protected Object result;
	protected Shell shell;
	private Button btnDefaultEmail, btnEmailCampaign;
	private CCombo cmbCampaign;

	private SQLiteConnector dbConnector = new SQLiteConnector();
	private List<EmailCampaign> col = dbConnector.readEmailCampaign(null, "active=1", null);
	private String type;
	private EmailCampaign campaign;
	/**
	 * Create the dialog.
	 * @param parent
	 * @param style
	 */
	public GroupEmailOptionDialog(Shell parent, int style) {
		super(parent, style);
		setText("SWT Dialog");
	}

	/**
	 * Open the dialog.
	 * @return the result
	 */
	public Object open() {
		createContents();
		shell.open();
		shell.layout();
		Display display = getParent().getDisplay();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
		return result;
	}

	/**
	 * Create contents of the dialog.
	 */
	private void createContents() {
		shell = new Shell(getParent(), getStyle());
		shell.setSize(346, 150);
		shell.setText(getText());
		shell.setLocation((getParent().getBounds().width/2)-(shell.getBounds().width/2), 30);
		
		Composite composite = new Composite(shell, SWT.NONE);
		composite.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		composite.setBounds(0, 0, 345, 156);

		Composite frameTitle = new Composite(composite, SWT.NONE);
		frameTitle.setBackground(SWTResourceManager.getColor(50, 50, 50));
		frameTitle.setBounds(0, 0, 350, 26);
		
		Label lblTitle = new Label(frameTitle, SWT.NONE);
		lblTitle.setForeground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblTitle.setFont(SWTResourceManager.getFont("Georgia", 8, SWT.BOLD));
		lblTitle.setBounds(5, 6, 133, 15);
		lblTitle.setBackground(SWTResourceManager.getColor(50, 50, 50));
		lblTitle.setText("Send Email By");
		
		final Label lblCloseAction = new Label(frameTitle, SWT.CENTER);
		lblCloseAction.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				shell.close();
			}
		});
		lblCloseAction.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				lblCloseAction.setBackground(SWTResourceManager.getColor(100, 100, 100));
			}
			@Override
			public void mouseExit(MouseEvent e) {
				lblCloseAction.setBackground(SWTResourceManager.getColor(50, 50, 50));
			}
		});
		lblCloseAction.setBounds(312, 3, 20, 20);
		lblCloseAction.setBackground(SWTResourceManager.getColor(50, 50, 50));
		lblCloseAction.setImage(new Image(shell.getDisplay(), this.getClass().getResourceAsStream("/images/close.png")));
		lblCloseAction.setToolTipText("Close Window");
		
		btnDefaultEmail = new Button(composite, SWT.RADIO);
		btnDefaultEmail.setImage(new Image(shell.getDisplay(), this.getClass().getResourceAsStream("/images/E-Mail.png")));
		btnDefaultEmail.setBounds(22, 32, 185, 32);
		btnDefaultEmail.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		btnDefaultEmail.setText(" Default Email Account");
		
		btnEmailCampaign = new Button(composite, SWT.RADIO);
		btnEmailCampaign.setBounds(22, 70, 148, 32);
		btnEmailCampaign.setImage(new Image(shell.getDisplay(), this.getClass().getResourceAsStream("/images/campaign.png")));
		btnEmailCampaign.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		btnEmailCampaign.setText(" Email Campaign");
		
		cmbCampaign = new CCombo(composite, SWT.BORDER);
		cmbCampaign.setBounds(188, 75, 120, 21);
		for(int i=0; i<col.size(); i++){
			cmbCampaign.add(col.get(i).getName());
		}
		
		final CLabel lblOk = new CLabel(composite, SWT.CENTER);
		lblOk.setBackground(SWTResourceManager.getColor(45, 45, 45));
		lblOk.setForeground(SWTResourceManager.getColor(245, 245, 245));
		lblOk.setFont(SWTResourceManager.getFont("Georgia", 9, SWT.BOLD));
		lblOk.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				if(btnDefaultEmail.getSelection())
					type = "Default";
				else {
					if(cmbCampaign.getSelectionIndex() == -1)
						return;
					campaign = col.get(cmbCampaign.getSelectionIndex());
					type = "Campaign";
				}
				shell.close();
			}
		});
		lblOk.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				lblOk.setBackground(SWTResourceManager.getColor(86, 86, 86));
			}
			@Override
			public void mouseExit(MouseEvent e) {
				lblOk.setBackground(SWTResourceManager.getColor(45, 45, 45));
			}
		});
		lblOk.setBounds(76, 110, 81, 26);
		lblOk.setText("OK");
		
		final CLabel lblCancel = new CLabel(composite, SWT.CENTER);
		lblCancel.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				type = null;
				shell.close();
			}
		});
		lblCancel.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				lblCancel.setBackground(SWTResourceManager.getColor(86, 86, 86));
			}
			@Override
			public void mouseExit(MouseEvent e) {
				lblCancel.setBackground(SWTResourceManager.getColor(45, 45, 45));
			}
		});
		lblCancel.setBounds(190, 110, 81, 26);
		lblCancel.setBackground(SWTResourceManager.getColor(45, 45, 45));
		lblCancel.setForeground(SWTResourceManager.getColor(245, 245, 245));
		lblCancel.setFont(SWTResourceManager.getFont("Georgia", 9, SWT.BOLD));
		lblCancel.setText("Cancel");
	}
	
	public String getType(){
		return this.type;
	}
	
	public EmailCampaign getCampaign(){
		return this.campaign;
	}
}
