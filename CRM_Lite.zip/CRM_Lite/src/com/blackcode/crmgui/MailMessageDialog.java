package com.blackcode.crmgui;

import javax.mail.Message;

import org.eclipse.swt.widgets.Dialog;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.SWT;
import org.eclipse.wb.swt.SWTResourceManager;

import com.blackcode.model.Account;

public class MailMessageDialog extends Dialog {

	protected Object result;
	protected Shell shell;
	private Message message;
	private Account selectedAccount;

	/**
	 * Create the dialog.
	 * @param parent
	 * @param style
	 */
	public MailMessageDialog(Shell parent, int style) {
		super(parent, style);
		setText("Email Message");
	}
	
	public MailMessageDialog(Shell parent, int style, Message message, Account account) {
		super(parent, style);
		setText("Email Message");
		this.message = message;
		this.selectedAccount = account;
	}

	/**
	 * Open the dialog.
	 * @return the result
	 */
	public Object open() {
		createContents();
		shell.open();
		shell.layout();
		Display display = getParent().getDisplay();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
		return result;
	}

	/**
	 * Create contents of the dialog.
	 */
	private void createContents() {
		shell = new Shell(getParent(), getStyle());
		shell.setSize(920, 770);
		shell.setLocation((getParent().getBounds().width/2)-(shell.getBounds().width/2), 30);
		shell.setText(getText());
		
		Composite composite = new Composite(shell, SWT.NONE);
		composite.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		composite.setBounds(0, 0, shell.getBounds().width, shell.getBounds().height);
		
		MailMessage frame = new MailMessage(composite, SWT.NONE, message, selectedAccount);
		frame.setBounds(0, 0, composite.getBounds().width, composite.getBounds().height);
	}

}
