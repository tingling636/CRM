package com.blackcode.crmgui;

import org.eclipse.swt.widgets.Dialog;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.SWT;
import org.eclipse.wb.swt.SWTResourceManager;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.events.MouseAdapter;
import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.events.MouseTrackAdapter;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.custom.CLabel;

public class PersonFilterDialog extends Dialog {

	protected Object result;
	protected Shell shell;
	private Composite frameTitle;
	private Label lblCloseAction;
	private Combo cmbField1;
	private Combo cmbLogic1;
	private Text txtValue1;
	private Combo cmbField2;
	private Combo cmbLogic2;
	private Text txtValue2;
	private Button btnAnd;
	private Button btnOr;

	private String[] logic = new String[]{"Equals","Does Not Equal", "Begins With", "Ends With", "Contains", "Does Not Contain"};
	private String[] logic2 = new String[]{"Equals","Greater Than", "Greater Than or Equal To", "Less Than", "Between"};
	private String[] fields = new String[]{"Account","Contact Id", "Age", "Gender", "Position", "Name", "Phone", "Email","Group", "Custom"};
	
	private String sql = null;
	private boolean search;
	/**
	 * Create the dialog.
	 * @param parent
	 * @param style
	 */
	public PersonFilterDialog(Shell parent, int style) {
		super(parent, style);
		setText("Filter Dialog");
	}

	/**
	 * Open the dialog.
	 * @return the result
	 */
	public Object open() {
		createContents();
		shell.open();
		shell.layout();
		Display display = getParent().getDisplay();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
		return result;
	}

	/**
	 * Create contents of the dialog.
	 */
	private void createContents() {
		shell = new Shell(getParent(), getStyle());
		shell.setSize(488, 160);
		shell.setText(getText());
		shell.setLocation((getParent().getBounds().width/2)-(shell.getBounds().width/2), 30);
		
		Composite composite = new Composite(shell, SWT.BORDER);
		composite.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		composite.setBounds(0, 0, 490, 162);
		
		frameTitle = new Composite(composite, SWT.NONE);
		frameTitle.setBackground(SWTResourceManager.getColor(50, 50, 50));
		frameTitle.setBounds(0, 0, shell.getBounds().width, 26);
		
		Label lblTitle = new Label(frameTitle, SWT.NONE);
		lblTitle.setForeground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblTitle.setFont(SWTResourceManager.getFont("Georgia", 8, SWT.BOLD));
		lblTitle.setBounds(5, 6, 133, 15);
		lblTitle.setBackground(SWTResourceManager.getColor(50, 50, 50));
		lblTitle.setText("Contact Filter");
		
		lblCloseAction = new Label(frameTitle, SWT.CENTER);
		lblCloseAction.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				search = false;
				shell.close();
			}
		});
		lblCloseAction.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				lblCloseAction.setBackground(SWTResourceManager.getColor(100, 100, 100));
			}
			@Override
			public void mouseExit(MouseEvent e) {
				lblCloseAction.setBackground(SWTResourceManager.getColor(50, 50, 50));
			}
		});
		lblCloseAction.setBounds(458, 3, 20, 20);
		lblCloseAction.setBackground(SWTResourceManager.getColor(50, 50, 50));
		lblCloseAction.setImage(new Image(shell.getDisplay(), PersonFilterDialog.class.getResourceAsStream("/images/close.png")));
		lblCloseAction.setToolTipText("Close Window");
		
		cmbField1 = new Combo(composite, SWT.NONE);
		cmbField1.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				if(cmbField1.getSelectionIndex()==2)
					cmbLogic1.setItems(logic2);
				else
					cmbLogic1.setItems(logic);
			}
		});
		cmbField1.setBounds(10, 29, 120, 23);
		cmbField1.setItems(fields);
		
		cmbLogic1 = new Combo(composite, SWT.NONE);
		cmbLogic1.setBounds(136, 29, 120, 23);
		cmbLogic1.setItems(logic);
		
		txtValue1 = new Text(composite, SWT.BORDER);
		txtValue1.setBounds(263, 29, 212, 23);
		
		btnAnd = new Button(composite, SWT.RADIO);
		btnAnd.setSelection(true);
		btnAnd.setBounds(17, 58, 52, 16);
		btnAnd.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		btnAnd.setText("And");
		
		btnOr = new Button(composite, SWT.RADIO);
		btnOr.setBounds(75, 58, 42, 16);
		btnOr.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		btnOr.setText("Or");
		
		cmbField2 = new Combo(composite, SWT.NONE);
		cmbField2.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				if(cmbField2.getSelectionIndex()==2)
					cmbLogic2.setItems(logic2);
				else
					cmbLogic2.setItems(logic);
			}
		});
		cmbField2.setBounds(10, 80, 120, 23);
		cmbField2.setItems(fields);
		
		cmbLogic2 = new Combo(composite, SWT.NONE);
		cmbLogic2.setBounds(136, 80, 120, 23);
		cmbLogic2.setItems(logic);
		
		txtValue2 = new Text(composite, SWT.BORDER);
		txtValue2.setBounds(263, 80, 212, 23);
		
		final CLabel lblSearchAction = new CLabel(composite, SWT.CENTER);
		lblSearchAction.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				search();
				search = true;
				shell.close();
			}
		});
		lblSearchAction.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				lblSearchAction.setBackground(SWTResourceManager.getColor(86, 86, 86));
			}
			@Override
			public void mouseExit(MouseEvent e) {
				lblSearchAction.setBackground(SWTResourceManager.getColor(45, 45, 45));
			}
		});
		lblSearchAction.setBounds(403, 118, 72, 26);
		lblSearchAction.setBackground(SWTResourceManager.getColor(45, 45, 45));
		lblSearchAction.setForeground(SWTResourceManager.getColor(245, 245, 245));
		lblSearchAction.setFont(SWTResourceManager.getFont("Georgia", 9, SWT.BOLD));
		lblSearchAction.setText("Search");
		
		final CLabel lblShowAllAction = new CLabel(composite, SWT.CENTER);
		lblShowAllAction.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				sql = null;
				search = true;
				shell.close();
			}
		});
		lblShowAllAction.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				lblShowAllAction.setBackground(SWTResourceManager.getColor(86, 86, 86));
			}
			@Override
			public void mouseExit(MouseEvent e) {
				lblShowAllAction.setBackground(SWTResourceManager.getColor(45, 45, 45));
			}
		});
		lblShowAllAction.setBounds(325, 118, 72, 26);
		lblShowAllAction.setBackground(SWTResourceManager.getColor(45, 45, 45));
		lblShowAllAction.setForeground(SWTResourceManager.getColor(245, 245, 245));
		lblShowAllAction.setFont(SWTResourceManager.getFont("Georgia", 9, SWT.BOLD));
		lblShowAllAction.setText("Show All");

	}
	
	private void search(){
		String condition1 = null;
		if(cmbField1.getText().length()>0 && cmbLogic1.getText().length()>0 && txtValue1.getText().length()>0)
			condition1 = generateCondition(cmbField1.getSelectionIndex(), cmbLogic1.getSelectionIndex(), txtValue1.getText());
		
		String condition2 = null;
		if(cmbField2.getText().length()>0 && cmbLogic2.getText().length()>0 && txtValue2.getText().length()>0)
			condition2 = generateCondition(cmbField2.getSelectionIndex(), cmbLogic2.getSelectionIndex(), txtValue2.getText());
		
		if(condition1!=null && condition2!=null){
			String str="";
			if(btnAnd.getSelection())
				str=" AND ";
			else
				str=" OR ";
			sql = condition1+str+condition2;
		}else{
			if(condition1 != null)
				sql = condition1;
			else if(condition2 != null)
				sql = condition2;
		}
		
	}
	
	private String generateCondition(int field, int logic, String value){
		fields = new String[]{"Account","Contact Id", "Age", "Gender", "Position", "Name", "Phone", "Email","Group", "Custom"};
		String str = conditionWithLogic1(logic, value);
		if(str == null)
			return null;
		
		switch(field){
		case 0 :
			return "accountId "+str;
		case 1 :
			return "contactId "+str;
		case 3 :
			return "gender "+str;
		case 4 :
			return "jobTitle "+str;
		case 5 :
			String firstname = "(firstName "+str+")";
			String middlename = "(middleName "+str+")";
			String lastname = "(lastName "+str+")";
			return "("+firstname+" OR "+middlename+" OR "+lastname+")";
		case 6 :
			String homephone = "(homePhone "+str+")";
			String workphone = "(workPhone "+str+")";
			String mobile = "(mobile "+str+")";
			String altphone = "(altPhone "+str+")";
			return "("+homephone+" OR "+workphone+" OR "+mobile+" OR "+altphone+")";
		case 7 :
			String personalemail = "(personEmail "+str+")";
			String otheremail = "(otherEmail "+str+")";
			String workemail = "(workEmail "+str+")";
			return "("+personalemail+" OR "+otheremail+" OR "+workemail+")";
		case 8 :
			return "groups "+str;
		case 9 :
			return "customFields "+str;
		}
		
		return null;
	}
	
	private String conditionWithLogic1(int logic, String value){
		switch(logic){
		case 0 :
			return "='"+value+"'";
		case 1 :
			return "<>'"+value+"'";
		case 2 :
			return "LIKE '"+value+"%'";
		case 3 :
			return "LIKE '%"+value+"'";
		case 4 :
			String [] values = value.split(",");
			String newvalue = "";
			for(int i=0; i<values.length; i++)
				newvalue += "'"+values[i]+"',";
			if(newvalue.endsWith(","))
				newvalue = newvalue.substring(0, newvalue.length()-1);
			
			return "IN ("+newvalue+")";
		case 5 :
			values = value.split(",");
			newvalue = "";
			for(int i=0; i<values.length; i++)
				newvalue += "'"+values[i]+"',";
			if(newvalue.endsWith(","))
				newvalue = newvalue.substring(0, newvalue.length()-1);
			
			return "NOT IN ("+newvalue+")";
		}
		
		return null;
	}
	
	public String getSearchSQL(){
		return sql;
	}
	
	public boolean isSearch(){
		return this.search;
	}
}
