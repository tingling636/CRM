package com.blackcode.crmgui;

import java.lang.reflect.InvocationTargetException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Comparator;
import java.util.List;

import javax.mail.FetchProfile;
import javax.mail.Flags;
import javax.mail.Folder;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.NoSuchProviderException;
import javax.mail.search.AndTerm;
import javax.mail.search.ComparisonTerm;
import javax.mail.search.FromStringTerm;
import javax.mail.search.OrTerm;
import javax.mail.search.ReceivedDateTerm;
import javax.mail.search.RecipientStringTerm;
import javax.mail.search.SearchTerm;
import javax.mail.search.SentDateTerm;

import org.eclipse.jface.dialogs.ProgressMonitorDialog;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.custom.ScrolledComposite;
import org.eclipse.swt.events.MouseAdapter;
import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.SWT;
import org.eclipse.wb.swt.SWTResourceManager;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.widgets.TableItem;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;

import com.blackcode.core.EmailUtil;
import com.blackcode.core.SQLiteConnector;
import com.blackcode.model.Account;
import com.blackcode.model.Contact;
import com.blackcode.model.EmailController;

public class PersonEmail extends Composite {
	private Table tblEmail;
	private Combo cmbView;
	private Contact selectedPerson;
	private Account selectedAccount = null;
	private EmailController controller;
	//private boolean or = false;
	private Folder rootFolder, sentFolder;

	/**
	 * Create the composite.
	 * @param parent
	 * @param style
	 */
	public PersonEmail(Composite parent, int style, Contact selectedPerson, EmailController controller) {
		super(parent, style);
		setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		this.selectedPerson = selectedPerson;
		this.controller = controller;
		
		ScrolledComposite scrolledComposite = new ScrolledComposite(this, SWT.BORDER | SWT.H_SCROLL | SWT.V_SCROLL);
		scrolledComposite.setBounds(0, 0, parent.getBounds().width-5, parent.getBounds().height-28);
		scrolledComposite.setExpandHorizontal(true);
		scrolledComposite.setExpandVertical(true);
		
		Composite composite = new Composite(scrolledComposite, SWT.NONE);
		composite.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		
		Label lblView = new Label(composite, SWT.RIGHT);
		lblView.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblView.setBounds(10, 10, 37, 15);
		lblView.setText("View");
		
		cmbView = new Combo(composite, SWT.NONE);
		cmbView.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				searchEmail();
			}
		});
		cmbView.setBounds(53, 7, 144, 23);
		cmbView.setItems(new String[]{"All", "Within One Month"});
		cmbView.select(1);
		
		tblEmail = new Table(composite,  SWT.FULL_SELECTION);
		tblEmail.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDoubleClick(MouseEvent e) {
				showMessage();
			}
		});
		tblEmail.addListener(SWT.MeasureItem, new Listener() {
			   public void handleEvent(Event event) {
				      // height cannot be per row so simply set
				      event.height = 28;
				   }
				});
		tblEmail.setBounds(10, 45, 431, scrolledComposite.getBounds().height-80);
		tblEmail.setLinesVisible(true);
		
		TableColumn tblclmnDate = new TableColumn(tblEmail, SWT.NONE);
		tblclmnDate.setWidth(75);
		
		TableColumn tblclmnType = new TableColumn(tblEmail, SWT.NONE);
		tblclmnType.setWidth(50);
		
		TableColumn tblclmnSubject = new TableColumn(tblEmail, SWT.NONE);
		tblclmnSubject.setWidth(250);				
		
		scrolledComposite.setContent(composite);
		scrolledComposite.setMinSize(composite.computeSize(SWT.DEFAULT, SWT.DEFAULT));
		synchronizeEmail();
	}

	private void synchronizeEmail(){				
		try {
			if(controller == null){
				List<Account> accounts = new SQLiteConnector().readAccount(null, null);
				for(int i=0; i<accounts.size(); i++){
					Account tmp = (Account) accounts.get(i);
					if(tmp.getCode().equals(selectedPerson.getAccountId())){
						selectedAccount = tmp;
						break;
					}
				}
				
				if(selectedAccount == null)
					return;
				
				controller = new EmailController();
				controller.setEmailAccount(selectedAccount);	
				
				EmailUtil util = new EmailUtil(EmailUtil.ACTIONS.RECEIVE, controller);
				new ProgressMonitorDialog(getShell()).run(true, true, util);
				controller = util.getController();
			}else{
				selectedAccount = controller.getEmailAccount();
				
				if(selectedAccount == null)
					return;
			}
			
			rootFolder = controller.getFolder();
			Folder[] folders = controller.getFolderList();
		    for(int i=0; i<folders.length; i++){
				Folder folder = folders[i];				
				
				if(folder.getName().equals("Sent")){
					sentFolder = folder;
					break;
				}
		    }    
		    
		    searchEmail();
		} catch (InvocationTargetException | InterruptedException e) {
			MessageDialog dlg = new MessageDialog(this.getShell(), SWT.NONE, "Error 500 : Email Problems (PE154)");
			dlg.open();
			e.printStackTrace();
		}catch (Exception e) {
			MessageDialog dlg = new MessageDialog(this.getShell(), SWT.NONE, "Error 500 : Email Problems (PE154)");
			dlg.open();
			e.printStackTrace();
		}
	}
	
	/*private void synchronizeEmail(){		
		List<Account> accounts = new MySQLConnector().readAccount(null, null);
		for(int i=0; i<accounts.size(); i++){
			Account tmp = (Account) accounts.get(i);
			if(tmp.getCode().equals(selectedPerson.getAccountId())){
				selectedAccount = tmp;
				break;
			}
		}
		
		if(selectedAccount == null)
			return;
		
		try {
			Properties properties = new Properties();
			properties.put("mail.store.protocol",  "imaps");
			Session session = Session.getDefaultInstance(properties);

			Store store = (Store) session.getStore("imaps");
			store.connect(selectedAccount.getIncomingMailServer(), selectedAccount.getEmailId(), selectedAccount.getEmailPassword());

			rootFolder = store.getFolder("INBOX");
			rootFolder.open(Folder.READ_WRITE);
			
		    Folder[] folders = rootFolder.list();
		    for(int i=0; i<folders.length; i++){
				Folder folder = folders[i];				
				
				if(folder.getName().equals("Sent")){
					folder.open(Folder.READ_WRITE);
					sentFolder = folder;
					break;
				}
		    }    
		    
		    searchEmail();
		} catch (NoSuchProviderException e) {
			MessageDialog dlg = new MessageDialog(this.getShell(), SWT.NONE, "Error 500 : Email Problems (PE154)");
			dlg.open();
		} catch (MessagingException e) {
			MessageDialog dlg = new MessageDialog(this.getShell(), SWT.NONE, "Error 500 : Email Problems (PE154)");
			dlg.open();
		}catch (Exception e) {
			MessageDialog dlg = new MessageDialog(this.getShell(), SWT.NONE, "Error 500 : Email Problems (PE154)");
			dlg.open();
		}
	}*/
	
	private void searchEmail(){
		tblEmail.removeAll();
		
		try {			
			Message[] msgsIn = rootFolder.search(searhTermInbox());
			FetchProfile fp = new FetchProfile();
			fp.add(FetchProfile.Item.ENVELOPE);
			rootFolder.fetch(msgsIn, fp);
			
		    Message[] msgsSent = null;
		    msgsSent = sentFolder.search(searhTermSent());
			FetchProfile fp1 = new FetchProfile();
			fp1.add(FetchProfile.Item.ENVELOPE);
			sentFolder.fetch(msgsSent, fp1);
		    
		    Message[] msgs;
		    if(msgsSent == null)
		    	msgs = msgsIn;
		    else{
		    	msgs = new Message[msgsIn.length+msgsSent.length];
		    	int index = 0;
		    	for(int i=0; i<msgsIn.length; i++){
		    		msgs[index] = msgsIn[i];
		    		index++;
		    	}
		    	for(int i=0; i<msgsSent.length; i++){
		    		msgs[index] = msgsSent[i];
		    		index++;
		    	}
		    }
		    		    
		    //sort message by date
		    java.util.Arrays.sort(msgs, new Comparator<Message>() {
		    	  public int compare(Message m1, Message m2) {
		    		  try{
			    	      if (m1.getSentDate() == null || m2.getSentDate() == null)
			    	        return 0;
			    	      return m2.getSentDate().compareTo(m1.getSentDate());
		    		  }catch(Exception e){
		    			  return 0;
		    		  }
		    	  }
		    });
		    
		    SimpleDateFormat sdf = new SimpleDateFormat("dd,MMM yyyy");
		    for (int i = 0; i < msgs.length; i++) {
				Message message = msgs[i];
				
				if(message.getFlags().contains(Flags.Flag.DELETED))
		    		continue;
				
				String type = "";
				String fromAddress = message.getFrom()[0].toString();
				if(fromAddress.contains(selectedAccount.getEmailId()))
					type = "Sent";
				else 
					type = "Inbox";
				TableItem ti = new TableItem(tblEmail, SWT.NONE);
				ti.setText(new String[]{sdf.format(message.getSentDate()),type, message.getSubject(), ""});
				ti.setData(message);
		    }

		} catch (NoSuchProviderException e) {
			e.printStackTrace();
			MessageDialog dlg = new MessageDialog(this.getShell(), SWT.NONE, "Error 500 : Email Problems (PE230)");
			dlg.open();
		} catch (MessagingException e) {
			e.printStackTrace();
			MessageDialog dlg = new MessageDialog(this.getShell(), SWT.NONE, "Error 500 : Email Problems (PE230)");
			dlg.open();
		}catch (Exception e) {
			e.printStackTrace();
			MessageDialog dlg = new MessageDialog(this.getShell(), SWT.NONE, "Error 500 : Email Problems (PE230)");
			dlg.open();
		}
	}
	
	private SearchTerm searhTermInbox(){
		try{
			SearchTerm term = null;
			SearchTerm dateTerm = null;
			SearchTerm emailIdTerm = null;
			
			if (cmbView.getSelectionIndex() == 1) {
				Calendar c = Calendar.getInstance();
				ReceivedDateTerm endDateTerm = new ReceivedDateTerm(ComparisonTerm.LT, c.getTime());
				c.add(Calendar.DATE, -45);	// next day
				ReceivedDateTerm startDateTerm = new ReceivedDateTerm(ComparisonTerm.GE, c.getTime());
				dateTerm = new AndTerm(startDateTerm, endDateTerm);		
			}
			
			if(selectedPerson.getPersonalEmail() !=null){
				FromStringTerm fromTerm = new FromStringTerm(selectedPerson.getPersonalEmail());
				if (emailIdTerm != null)
					emailIdTerm = new OrTerm(emailIdTerm, fromTerm);
				else
					emailIdTerm = fromTerm;
			}
			if(selectedPerson.getWorkEmail() !=null){
				FromStringTerm fromTerm = new FromStringTerm(selectedPerson.getWorkEmail());
				if (emailIdTerm != null)
					emailIdTerm = new OrTerm(emailIdTerm, fromTerm);
				else
					emailIdTerm = fromTerm;
			}
			if(selectedPerson.getOtherEmail() !=null){
				FromStringTerm fromTerm = new FromStringTerm(selectedPerson.getOtherEmail());
				if (emailIdTerm != null)
					emailIdTerm = new OrTerm(emailIdTerm, fromTerm);
				else
					emailIdTerm = fromTerm;
			}		
			
			if(dateTerm != null && emailIdTerm != null){
				term = new AndTerm(dateTerm, emailIdTerm);
			}else if(dateTerm != null && emailIdTerm == null){
				term = dateTerm;
			}else if(dateTerm == null && emailIdTerm != null){
				term = emailIdTerm;
			}
			
			return term;
		}catch (Exception e) {
			MessageDialog dlg = new MessageDialog(this.getShell(), SWT.NONE, "Error 401 : System Problems (PE283)");
			dlg.open();
			
			return null;
		}		
	}
	
	private SearchTerm searhTermSent(){
		try{			
			SearchTerm term = null;
			SearchTerm dateTerm = null;
			SearchTerm emailIdTerm = null;
			
			if (cmbView.getSelectionIndex() == 1) {
				Calendar c = Calendar.getInstance();
				SentDateTerm endDateTerm = new SentDateTerm(ComparisonTerm.LT, c.getTime());
				c.add(Calendar.DATE, -45);	// next day
				SentDateTerm startDateTerm = new SentDateTerm(ComparisonTerm.GE, c.getTime());
				dateTerm = new AndTerm(startDateTerm, endDateTerm);		
			}
			
			if(selectedPerson.getPersonalEmail() !=null){
				RecipientStringTerm fromTerm = new RecipientStringTerm(Message.RecipientType.TO,selectedPerson.getPersonalEmail());
				if (emailIdTerm != null)
					emailIdTerm = new OrTerm(emailIdTerm, fromTerm);
				else
					term = fromTerm;
			}
			if(selectedPerson.getWorkEmail() !=null){
				RecipientStringTerm fromTerm = new RecipientStringTerm(Message.RecipientType.TO,selectedPerson.getWorkEmail());
				if (emailIdTerm != null)
					emailIdTerm = new OrTerm(emailIdTerm, fromTerm);
				else
					emailIdTerm = fromTerm;
			}
			if(selectedPerson.getOtherEmail() !=null){
				RecipientStringTerm fromTerm = new RecipientStringTerm(Message.RecipientType.TO,selectedPerson.getOtherEmail());
				if (emailIdTerm != null)
					emailIdTerm = new OrTerm(emailIdTerm, fromTerm);
				else
					emailIdTerm = fromTerm;
			}
			
			if(dateTerm != null && emailIdTerm != null){
				term = new AndTerm(dateTerm, emailIdTerm);
			}else if(dateTerm != null && emailIdTerm == null){
				term = dateTerm;
			}else if(dateTerm == null && emailIdTerm != null){
				term = emailIdTerm;
			}
			
			return term;
		}catch (Exception e) {
			MessageDialog dlg = new MessageDialog(this.getShell(), SWT.NONE, "Error 401 : System Problems (PE336)");
			dlg.open();
			
			return null;
		}
	}
	
	private void showMessage(){
		if(tblEmail.getSelectionIndex() == -1)
			return;
		
		Message msg = (Message)tblEmail.getItem(tblEmail.getSelectionIndex()).getData();
		
		MailMessageDialog dlg = new MailMessageDialog(this.getShell(), SWT.DIALOG_TRIM | SWT.APPLICATION_MODAL, msg, selectedAccount);
		dlg.open();
	}
	
	public EmailController getController(){
		return this.controller;
	}
	@Override
	protected void checkSubclass() {
		// Disable the check that prevents subclassing of SWT components
	}
}
