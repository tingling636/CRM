package com.blackcode.crmgui;

import org.eclipse.swt.events.MouseAdapter;
import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.events.MouseTrackAdapter;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.widgets.Dialog;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.SWT;
import org.eclipse.wb.swt.SWTResourceManager;
import org.eclipse.swt.custom.CLabel;

public class MessageDialog extends Dialog {

	protected Object result;
	protected Shell shell;
	private Composite frameTitle;
	private Label lblCloseAction;
	private String message;

	/**
	 * Create the dialog.
	 * @param parent
	 * @param style
	 */
	public MessageDialog(Shell parent, int style) {
		super(parent, style);
		setText("SWT Dialog");
	}
	
	public MessageDialog(Shell parent, int style, String message) {
		super(parent, style);
		setText("SWT Dialog");
		this.message = message;
	}

	/**
	 * Open the dialog.
	 * @return the result
	 */
	public Object open() {
		createContents();
		shell.open();
		shell.layout();
		Display display = getParent().getDisplay();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
		return result;
	}

	/**
	 * Create contents of the dialog.
	 */
	private void createContents() {
		shell = new Shell(getParent(), getStyle());
		shell.setSize(402, 150);
		shell.setText(getText());
		shell.setLocation((getParent().getBounds().width/2)-(shell.getBounds().width/2), 30);
		
		Composite composite = new Composite(shell, SWT.NONE);
		composite.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		composite.setBounds(0, 0, 405, 156);

		frameTitle = new Composite(composite, SWT.NONE);
		frameTitle.setBackground(SWTResourceManager.getColor(50, 50, 50));
		frameTitle.setBounds(0, 0, shell.getBounds().width, 26);
		
		Label lblTitle = new Label(frameTitle, SWT.NONE);
		lblTitle.setForeground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblTitle.setFont(SWTResourceManager.getFont("Georgia", 8, SWT.BOLD));
		lblTitle.setBounds(5, 6, 133, 15);
		lblTitle.setBackground(SWTResourceManager.getColor(50, 50, 50));
		lblTitle.setText("Message");
		
		lblCloseAction = new Label(frameTitle, SWT.CENTER);
		lblCloseAction.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				shell.close();
			}
		});
		lblCloseAction.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				lblCloseAction.setBackground(SWTResourceManager.getColor(100, 100, 100));
			}
			@Override
			public void mouseExit(MouseEvent e) {
				lblCloseAction.setBackground(SWTResourceManager.getColor(50, 50, 50));
			}
		});
		lblCloseAction.setBounds(372, 3, 20, 20);
		lblCloseAction.setBackground(SWTResourceManager.getColor(50, 50, 50));
		lblCloseAction.setImage(new Image(shell.getDisplay(), MessageDialog.class.getResourceAsStream("/images/close.png")));
		lblCloseAction.setToolTipText("Close Window");
		
		CLabel lblMessage = new CLabel(composite, SWT.NONE);
		lblMessage.setForeground(SWTResourceManager.getColor(255, 0, 0));
		lblMessage.setFont(SWTResourceManager.getFont("Georgia", 13, SWT.BOLD));
		lblMessage.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblMessage.setBounds(10, 43, 377, 21);
		lblMessage.setText(message);
		
		CLabel lblMessage2 = new CLabel(composite, SWT.CENTER);
		lblMessage2.setForeground(SWTResourceManager.getColor(255, 0, 0));
		lblMessage2.setFont(SWTResourceManager.getFont("Georgia", 12, SWT.BOLD));
		lblMessage2.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblMessage2.setBounds(10, 74, 377, 21);
		lblMessage2.setText("Try Again !");
		
		final CLabel lblClose = new CLabel(composite, SWT.CENTER);
		lblClose.setBackground(SWTResourceManager.getColor(45, 45, 45));
		lblClose.setForeground(SWTResourceManager.getColor(245, 245, 245));
		lblClose.setFont(SWTResourceManager.getFont("Georgia", 9, SWT.BOLD));
		lblClose.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				shell.close();
			}
		});
		lblClose.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				lblClose.setBackground(SWTResourceManager.getColor(86, 86, 86));
			}
			@Override
			public void mouseExit(MouseEvent e) {
				lblClose.setBackground(SWTResourceManager.getColor(45, 45, 45));
			}
		});
		lblClose.setBounds(155, 108, 81, 26);
		lblClose.setText("Close");
	}
}
