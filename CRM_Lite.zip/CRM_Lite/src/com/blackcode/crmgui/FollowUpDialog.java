package com.blackcode.crmgui;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.eclipse.swt.widgets.Dialog;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.SWT;
import org.eclipse.wb.swt.SWTResourceManager;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.DateTime;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.custom.CLabel;
import org.eclipse.swt.custom.StyledText;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.events.MouseAdapter;
import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.events.MouseTrackAdapter;
import org.eclipse.swt.graphics.Image;

import com.blackcode.model.FollowUpTask;

public class FollowUpDialog extends Dialog {

	protected Object result;
	protected Shell shell;
	private Composite frameTitle;
	private Label lblCloseAction;
	private Text txtPerson;
	private DateTime date;
	private Combo cmbTime;
	private Combo cmbType;
	private StyledText sytxtNotes;
	private Button btnHighImportance;
	private Button btnLowImportance;
	private Button btnPrivate;

	private FollowUpTask task;
	private String personId;
	private Date selectedDate;
	private String[] times = new String[]{"06:00","07:00","08:00","09:00","10:00","11:00","12:00","13:00","14:00","15:00","16:00","17:00","18:00","19:00","20:00","21:00","22:00","23:00","24:00"};
	private String[] types = new String[]{"Event","Call","Email"};
	private Text txtSubject;
	/**
	 * Create the dialog.
	 * @param parent
	 * @param style
	 */
	public FollowUpDialog(Shell parent, int style, FollowUpTask task, String person, Date selectedDate) {
		super(parent, style);
		setText("Follow Up Task");
		this.task = task;
		this.personId = person;
		this.selectedDate = selectedDate;
	}

	/**
	 * Open the dialog.
	 * @return the result
	 */
	public Object open() {
		createContents();
		shell.open();
		shell.layout();
		Display display = getParent().getDisplay();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
		return result;
	}

	/**
	 * Create contents of the dialog.
	 */
	private void createContents() {
		shell = new Shell(getParent(), getStyle());
		shell.setSize(370, 325);
		shell.setLocation((getParent().getBounds().width/2)-(shell.getBounds().width/2), 30);
		shell.setText(getText());
		
		Composite composite = new Composite(shell, SWT.BORDER);
		composite.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		composite.setBounds(0, 0, 370, 326);
		
		frameTitle = new Composite(composite, SWT.NONE);
		frameTitle.setBackground(SWTResourceManager.getColor(50, 50, 50));
		frameTitle.setBounds(0, 0, shell.getBounds().width, 26);
		
		Label lblTitle = new Label(frameTitle, SWT.NONE);
		lblTitle.setForeground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblTitle.setFont(SWTResourceManager.getFont("Georgia", 8, SWT.BOLD));
		lblTitle.setBounds(5, 6, 152, 15);
		lblTitle.setBackground(SWTResourceManager.getColor(50, 50, 50));
		lblTitle.setText("Event / Follow up Task");
		
		lblCloseAction = new Label(frameTitle, SWT.CENTER);
		lblCloseAction.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				task = null;
				shell.close();
			}
		});
		lblCloseAction.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				lblCloseAction.setBackground(SWTResourceManager.getColor(100, 100, 100));
			}
			@Override
			public void mouseExit(MouseEvent e) {
				lblCloseAction.setBackground(SWTResourceManager.getColor(50, 50, 50));
			}
		});
		lblCloseAction.setBounds(340, 3, 20, 20);
		lblCloseAction.setBackground(SWTResourceManager.getColor(50, 50, 50));
		lblCloseAction.setImage(new Image(shell.getDisplay(), FollowUpDialog.class.getResourceAsStream("/images/close.png")));
		lblCloseAction.setToolTipText("Close Window");
		
		Label lblDate = new Label(composite, SWT.RIGHT);
		lblDate.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblDate.setBounds(10, 32, 55, 15);
		lblDate.setText("Start On");
		
		date = new DateTime(composite, SWT.BORDER | SWT.DROP_DOWN);
		date.setBounds(71, 31, 80, 24);
		
		cmbTime = new Combo(composite, SWT.NONE);
		cmbTime.setBounds(157, 32, 91, 23);
		cmbTime.setItems(times);
		
		btnPrivate = new Button(composite, SWT.CHECK);
		btnPrivate.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		btnPrivate.setBounds(288, 35, 57, 16);
		btnPrivate.setText("Private");
		
		Label lblType = new Label(composite, SWT.RIGHT);
		lblType.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblType.setBounds(10, 64, 55, 15);
		lblType.setText("Type");
		
		cmbType = new Combo(composite, SWT.NONE);
		cmbType.setBounds(71, 61, 177, 23);
		cmbType.setItems(types);
		cmbType.select(0);
		
		Label lblPerson = new Label(composite, SWT.RIGHT);
		lblPerson.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblPerson.setBounds(10, 93, 55, 15);
		lblPerson.setText("Contact Id");
		
		txtPerson = new Text(composite, SWT.BORDER);
		txtPerson.setBounds(71, 90, 177, 21);
		
		Label lblTag = new Label(composite, SWT.RIGHT);
		lblTag.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblTag.setBounds(10, 120, 55, 15);
		lblTag.setText("Tags");
		
		btnHighImportance = new Button(composite, SWT.RADIO);
		btnHighImportance.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		btnHighImportance.setBounds(72, 120, 113, 16);
		btnHighImportance.setText("High Importance");
		
		btnLowImportance = new Button(composite, SWT.RADIO);
		btnLowImportance.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		btnLowImportance.setSelection(true);
		btnLowImportance.setBounds(216, 119, 113, 16);
		btnLowImportance.setText("Low Importance");
		
		Label lblSubject = new Label(composite, SWT.RIGHT);
		lblSubject.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblSubject.setBounds(10, 145, 55, 15);
		lblSubject.setText("Subject");
		
		txtSubject = new Text(composite, SWT.BORDER);
		txtSubject.setBounds(71, 142, 283, 21);
		
		sytxtNotes = new StyledText(composite, SWT.BORDER);
		sytxtNotes.setBounds(11, 169, 343, 111);
		
		final CLabel lblSave = new CLabel(composite, SWT.CENTER);
		lblSave.setBackground(SWTResourceManager.getColor(45, 45, 45));
		lblSave.setForeground(SWTResourceManager.getColor(245, 245, 245));
		lblSave.setFont(SWTResourceManager.getFont("Georgia", 9, SWT.BOLD));
		lblSave.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				setValues();
				shell.close();
			}
		});
		lblSave.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				lblSave.setBackground(SWTResourceManager.getColor(86, 86, 86));
			}
			@Override
			public void mouseExit(MouseEvent e) {
				lblSave.setBackground(SWTResourceManager.getColor(45, 45, 45));
			}
		});
		lblSave.setBounds(146, 290, 69, 26);
		lblSave.setText("Save");

		initial();
	}
	
	private void initial(){
		try{
			if(selectedDate != null){
				date.setDay(selectedDate.getDate());
				date.setMonth(selectedDate.getMonth());
				date.setYear(selectedDate.getYear());
			}
			if(personId != null)
				txtPerson.setText(personId);
			if(task != null){
				date.setDay(task.getDate().getDate());
				date.setMonth(task.getDate().getMonth());
				date.setYear(task.getDate().getYear());
				cmbTime.setText(displayText(task.getTime()));
				btnPrivate.setSelection(task.isPrivateTag());
				cmbType.setText(displayText(task.getType()));
				txtPerson.setText(displayText(task.getContactId()));
				btnHighImportance.setSelection(task.isHighImportanceTag());
				btnLowImportance.setSelection(task.isHighImportanceTag());
				txtSubject.setText(displayText(task.getSubject()));
				sytxtNotes.setText(displayText(task.getNotes()));
			}
		}catch(Exception e){
			task = null;
			MessageDialog dlg = new MessageDialog(shell, SWT.NONE, "Error 401 : System Problems (FD241)");
			dlg.open();
		}
	}
	
	private void setValues(){
		if(task == null)
			task = new FollowUpTask();
		
		try{
			SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
			task.setDate(sdf.parse(date.getDay()+"/"+(date.getMonth()+1)+"/"+date.getYear()));
			task.setTime(captureText(cmbTime.getText()));
			task.setType(captureText(cmbType.getText()));
			task.setContactId(captureText(txtPerson.getText()));
			task.setContactName(captureText(txtPerson.getText()));
			task.isPrivateTag(btnPrivate.getSelection());
			task.isHighImportantTag(btnHighImportance.getSelection());
			task.setSubject(captureText(txtSubject.getText()));
			task.setNotes(captureText(sytxtNotes.getText()));
			
		}catch(Exception e){
			task = null;
			MessageDialog dlg = new MessageDialog(shell, SWT.NONE, "Error 401 : System Problems (FD260)");
			dlg.open();
		}
	}
	
	private String displayText(Object obj){
		if(obj==null)
			return "";
		else
			return obj.toString();
	}
	
	private String captureText(String text){
		if(text.length() == 0)
			return null;
		else
			return text;
	}
	
	
	public FollowUpTask getTask(){
		return this.task;
	}
}
