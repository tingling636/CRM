package com.blackcode.crmgui;

import java.awt.Dimension;
import java.io.File;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.Part;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.eclipse.jface.dialogs.ProgressMonitorDialog;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Dialog;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.FileDialog;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.SWT;
import org.eclipse.wb.swt.SWTResourceManager;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.browser.Browser;
import org.eclipse.swt.custom.StyleRange;
import org.eclipse.swt.custom.StyledText;
import org.eclipse.swt.graphics.FontData;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.events.MouseAdapter;
import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.events.MouseTrackAdapter;

import com.blackcode.core.EmailUtil;
import com.blackcode.core.SQLiteConnector;
import com.blackcode.emailmarketing.ActiveEventDialog;
import com.blackcode.emailmarketing.ActivePortfolioDialog;
import com.blackcode.emailmarketing.ActiveVacationDialog;
import com.blackcode.model.Account;
import com.blackcode.model.Contact;
import com.blackcode.model.EmailController;
import com.blackcode.model.History;

import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.events.FocusAdapter;
import org.eclipse.swt.events.FocusEvent;
import org.eclipse.swt.custom.ScrolledComposite;
import org.eclipse.swt.custom.CLabel;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.w3c.dom.Document;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;

public class MailComposeDialog extends Dialog {

	protected Object result;
	protected Shell shell;
	
	private Composite composite;
	private Composite frameTitle;
	private Label lblNewMessage;
	private Composite frameRecipient;
	private Label lblCcAction;
	private Label lblCc;
	private StyledText sytxtTo;
	private StyledText sytxtCc;
	private StyledText sytxtSubject;
	private Composite frameMessage;
	private Composite frameTool;
	private Label lblCloseAction;
	private Label lblSizeAction;
	private Label lblHideAction;
	private Composite frameAccount;
	private Text txtAccount;
	private Label lblTo;
	private ScrolledComposite scrolledAttachment;
	private Composite frameAttachment;
	private Combo cmbTemplate;
	private TextEditorFrame textEditor;
	private Browser browser;
	
	private boolean minWindow = true;
	private boolean visible = true;
	private Account account;
	private String recipient = null;
	private Contact person;	
	private List<Contact> contacts;
	private Object[] emailTemplate;
	final String templatepath = "C:\\ProgramData\\BlackCodeCRM\\EmailTemplate\\template";
	
	
	/**
	 * Create the dialog.
	 * @param parent
	 * @param style
	 */
	public MailComposeDialog(Shell parent, int style) {
		super(parent, style);
		setText("SWT Dialog");
	}
	
	public MailComposeDialog(Shell parent, int style, Account defaulAccount, String recipientEmailId, Contact person) {
		super(parent, style);
		setText("Compose MEssage");
		this.account = defaulAccount;
		this.recipient = recipientEmailId;
		this.person = person;
	}
	
	public MailComposeDialog(Shell parent, int style, Account defaulAccount, List<Contact> contacts) {
		super(parent, style);
		setText("Compose MEssage");
		this.account = defaulAccount;
		this.contacts = contacts;
	}

	/**
	 * Open the dialog.
	 * @return the result
	 */
	public Object open() {
		createContents();
		shell.open();
		shell.layout();
		Display display = getParent().getDisplay();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
		return result;
	}

	/**
	 * Create contents of the dialog.
	 */
	private void createContents() {
		shell = new Shell(getParent(), getStyle());
		shell.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		shell.setSize(525, 482);
		shell.setText(getText());
		Dimension dim = java.awt.Toolkit.getDefaultToolkit().getScreenSize(); 
		shell.setLocation(new Point((int)dim.getWidth()-531, (int)dim.getHeight()-530));
		
		composite = new Composite(shell, SWT.NONE);
		composite.setBounds(0, 0, 598, 507);
		composite.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		
		frameTitle = new Composite(composite, SWT.NONE);
		frameTitle.setBackground(SWTResourceManager.getColor(50, 50, 50));
		frameTitle.setBounds(0, 0, shell.getBounds().width, 26);
		
		lblNewMessage = new Label(frameTitle, SWT.NONE);
		lblNewMessage.setForeground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblNewMessage.setBackground(SWTResourceManager.getColor(50, 50, 50));
		lblNewMessage.setBounds(10, 5, 198, 15);
		lblNewMessage.setText(contacts==null?"New Message":"New Message (Contact Group)");
		
		lblCloseAction = new Label(frameTitle, SWT.CENTER);
		lblCloseAction.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				shell.close();
			}
		});
		lblCloseAction.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				lblCloseAction.setBackground(SWTResourceManager.getColor(100, 100, 100));
			}
			@Override
			public void mouseExit(MouseEvent e) {
				lblCloseAction.setBackground(SWTResourceManager.getColor(50, 50, 50));
			}
		});
		lblCloseAction.setBounds(shell.getBounds().width-26, 3, 20, 20);
		lblCloseAction.setBackground(SWTResourceManager.getColor(50, 50, 50));
		lblCloseAction.setImage(new Image(shell.getDisplay(), MailComposeDialog.class.getResourceAsStream("/images/close.png")));
		lblCloseAction.setToolTipText("Close");
		
		lblSizeAction = new Label(frameTitle, SWT.CENTER);
		lblSizeAction.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				setWindowSize();
			}
		});
		lblSizeAction.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				lblSizeAction.setBackground(SWTResourceManager.getColor(100, 100, 100));
			}
			@Override
			public void mouseExit(MouseEvent e) {
				lblSizeAction.setBackground(SWTResourceManager.getColor(50, 50, 50));
			}
		});
		lblSizeAction.setBounds(lblCloseAction.getBounds().x-19, 3, 20, 20);
		lblSizeAction.setBackground(SWTResourceManager.getColor(50, 50, 50));
		lblSizeAction.setImage(new Image(shell.getDisplay(), MailComposeDialog.class.getResourceAsStream("/images/fullScreen.png")));
		
		lblHideAction = new Label(frameTitle, SWT.CENTER);
		lblHideAction.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				setVisible();
			}
		});
		lblHideAction.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				lblHideAction.setBackground(SWTResourceManager.getColor(100, 100, 100));
			}
			@Override
			public void mouseExit(MouseEvent e) {
				lblHideAction.setBackground(SWTResourceManager.getColor(50, 50, 50));
			}
		});
		lblHideAction.setBounds(lblSizeAction.getBounds().x-19, 3, 20, 20);
		lblHideAction.setBackground(SWTResourceManager.getColor(50, 50, 50));
		lblHideAction.setImage(new Image(shell.getDisplay(), MailComposeDialog.class.getResourceAsStream("/images/minimize.png")));
		
		frameAccount = new Composite(composite, SWT.BORDER);
		frameAccount.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		frameAccount.setBounds(0, 26, 525, 32);
		
		Label lblAccount = new Label(frameAccount, SWT.NONE);
		lblAccount.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblAccount.setForeground(SWTResourceManager.getColor(SWT.COLOR_GRAY));
		lblAccount.setBounds(10, 8, 46, 15);
		lblAccount.setText("Account");
						
		txtAccount = new Text(frameAccount, SWT.NONE);
		txtAccount.setBounds(84, 8, 379, 19);		
		
		frameRecipient = new Composite(composite, SWT.BORDER);
		frameRecipient.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		frameRecipient.setBounds(0, 57, shell.getBounds().width, 32);
				
		lblTo = new Label(frameRecipient, SWT.RIGHT);
		lblTo.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblTo.setForeground(SWTResourceManager.getColor(SWT.COLOR_GRAY));
		lblTo.setBounds(36, 5, 36, 15);
		lblTo.setText("To");
		
		sytxtTo = new StyledText(frameRecipient, SWT.WRAP);
		sytxtTo.setBounds(84, 5, 410, 19);		
		
		lblCc = new Label(frameRecipient, SWT.RIGHT);
		lblCc.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblCc.setForeground(SWTResourceManager.getColor(SWT.COLOR_GRAY));
		lblCc.setBounds(42, 31, 31, 15);
		lblCc.setText("CC");
		lblCc.setVisible(false);
		
		sytxtCc = new StyledText(frameRecipient, SWT.NONE);
		sytxtCc.setBounds(84, 31, 410, 19);
		sytxtCc.setVisible(false);
		
		lblCcAction = new Label(frameRecipient, SWT.CENTER);
		lblCcAction.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				showCc();
			}
		});
		lblCcAction.setToolTipText("Add Cc");
		lblCcAction.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblCcAction.setBounds(frameRecipient.getBounds().width-40, 6, 36, 15);
		lblCcAction.setText("Cc");
		
		sytxtSubject = new StyledText(composite, SWT.BORDER);
		sytxtSubject.addFocusListener(new FocusAdapter() {
			@Override
			public void focusGained(FocusEvent e) {
				if(sytxtSubject.getText().equals("Subject"))
					sytxtSubject.setText("");
			}
			@Override
			public void focusLost(FocusEvent e) {
				if(sytxtSubject.getText().length()==0)
					sytxtSubject.setText("Subject");
			}
		});
		sytxtSubject.setLeftMargin(10);
		sytxtSubject.setTopMargin(7);
		sytxtSubject.setText("Subject");
		sytxtSubject.setBounds(0, 88, shell.getBounds().width, 32);
		
		frameMessage = new Composite(composite, SWT.BORDER);
		frameMessage.setBounds(0, 120, 525, 312);
		textEditor = new TextEditorFrame(frameMessage, SWT.NONE);
	    textEditor.setBounds(0, 0, 525, 312);	  
	    browser = new Browser(frameMessage, SWT.NONE);
		browser.setBounds(0, 0, 525, 312);
		browser.setVisible(false);
		
		frameTool = new Composite(composite, SWT.NONE);
		frameTool.setBounds(0, frameMessage.getBounds().y+frameMessage.getBounds().height, shell.getBounds().width, 48);
		frameTool.setBackground(SWTResourceManager.getColor(SWT.COLOR_WIDGET_BACKGROUND));
		
		Label lblSendAction = new Label(frameTool, SWT.NONE);
		lblSendAction.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				if(cmbTemplate.getSelectionIndex()==0){
					compose();
				}else{
					composeTemplate();
				}
				
			}
		});
		lblSendAction.setToolTipText("Send");
		lblSendAction.setBounds(10, 10, 72, 30);
		lblSendAction.setImage(new Image(shell.getDisplay(), MailComposeDialog.class.getResourceAsStream("/images/send.png")));
		
		final Label lblAttachAction = new Label(frameTool, SWT.NONE);
		lblAttachAction.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				FileDialog dlg = new FileDialog(shell);
		        dlg.setText("File Dialog");
		        String dir = dlg.open();
		        if (dir != null) {
		        	insertAttachment(new File(dir));
		        }
			}
		});
		lblAttachAction.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				lblAttachAction.setBackground(SWTResourceManager.getColor(230, 230, 230));
			}
			@Override
			public void mouseExit(MouseEvent e) {
				lblAttachAction.setBackground(SWTResourceManager.getColor(240, 240, 240));
			}
		});
		lblAttachAction.setToolTipText("Attach Files");
		lblAttachAction.setBounds(88, 15, 24, 24);
		lblAttachAction.setImage(new Image(shell.getDisplay(), this.getClass().getResourceAsStream("/images/attachment.png")));
		
		scrolledAttachment = new ScrolledComposite(frameTool, SWT.H_SCROLL | SWT.V_SCROLL);
		scrolledAttachment.setBounds(120, 3, 250, 42);
		scrolledAttachment.setExpandHorizontal(true);
		scrolledAttachment.setExpandVertical(true);
		
		frameAttachment = new Composite(scrolledAttachment, SWT.NONE);
				
		scrolledAttachment.setContent(frameAttachment);
		scrolledAttachment.setMinSize(frameAttachment.computeSize(SWT.DEFAULT, SWT.DEFAULT));
		
		cmbTemplate = new Combo(frameTool, SWT.NONE);
		cmbTemplate.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				getTemplate();
			}
		});
		cmbTemplate.setBounds(frameTool.getBounds().width-170, 7, 160, 23);
		
		initialize();
	}
	
	private void initialize(){
		if(account != null){
			txtAccount.setText(account.getEmailId());
			insertSignature();
		}
		
		if(recipient!= null)
			sytxtTo.setText(recipient);
		
		if(contacts != null){
			sytxtTo.setEditable(false);
			lblTo.setText("Group");
			
			String ids="";
			for(int i=0; i<contacts.size(); i++)
				ids += contacts.get(i).getFullName()+",";
			sytxtTo.setText(ids);
		}
		
		cmbTemplate.add("");
		File folder = new File(templatepath);
		File[] templates = folder.listFiles(); 		 
		for (int i = 0; i < templates.length; i++){	
			if (templates[i].isFile()) {
		        if (templates[i].getName().endsWith(".xml")){
		        	cmbTemplate.add(templates[i].getName());
		        }
		    }
		}
	}
	
	private void setWindowSize(){
		int y = 312;
		
		if(minWindow){
			minWindow = false;
			y = 512;
			shell.setSize(988, 682);
			shell.setLocation((getParent().getBounds().width/2)-(shell.getBounds().width/2), (getParent().getBounds().height/2)-(shell.getBounds().height/2));
			lblSizeAction.setImage(new Image(shell.getDisplay(), MailComposeDialog.class.getResourceAsStream("/images/fullscreen_exit.png")));
		}else{
			minWindow = true;
			shell.setSize(525, 482);
			Dimension dim = java.awt.Toolkit.getDefaultToolkit().getScreenSize(); 
			shell.setLocation(new Point((int)dim.getWidth()-531, (int)dim.getHeight()-530));
			lblSizeAction.setImage(new Image(shell.getDisplay(), MailComposeDialog.class.getResourceAsStream("/images/fullScreen.png")));
		}
		
		if(!lblCcAction.getVisible())
			y-=32;
		
		composite.setBounds(0, 0, shell.getBounds().width, shell.getBounds().height);
		frameTitle.setBounds(0, 0, shell.getBounds().width, 26);
		frameAccount.setBounds(0, frameTitle.getBounds().y+frameTitle.getBounds().height-1, shell.getBounds().width, 32);
		frameRecipient.setBounds(0, frameAccount.getBounds().y+frameAccount.getBounds().height-1, shell.getBounds().width, lblCcAction.getVisible()?32:64);
		sytxtSubject.setBounds(0, frameRecipient.getBounds().y+frameRecipient.getBounds().height-1, shell.getBounds().width, 32);
		frameMessage.setBounds(0, sytxtSubject.getBounds().y+sytxtSubject.getBounds().height-1, shell.getBounds().width, y);
		textEditor.resize(frameMessage.getBounds().width, frameMessage.getBounds().height);
		browser.setBounds(0, 0, frameMessage.getBounds().width, frameMessage.getBounds().height);
		frameTool.setBounds(0, frameMessage.getBounds().y+frameMessage.getBounds().height-1, shell.getBounds().width, 48);		
		cmbTemplate.setBounds(frameTool.getBounds().width-170, 7, 160, 23);
		
		lblCloseAction.setBounds(shell.getBounds().width-26, 3, 20, 20);
		lblSizeAction.setBounds(lblCloseAction.getBounds().x-19, 3, 20, 20);
		lblHideAction.setBounds(lblSizeAction.getBounds().x-19, 3, 20, 20);
		sytxtTo.setBounds(84, 5, frameRecipient.getBounds().width-112, 19);
		sytxtCc.setBounds(84, 31, frameRecipient.getBounds().width-112, 19);
		lblCcAction.setBounds(frameRecipient.getBounds().width-40, 6, 36, 15);
		
		composite.redraw();
	}
	
	private void showCc(){
		lblCc.setVisible(true);
		sytxtCc.setVisible(true);
		lblCcAction.setVisible(false);
		
		int y=frameMessage.getBounds().height;
		frameRecipient.setSize(shell.getBounds().width, 64);
		sytxtSubject.setLocation(0, frameRecipient.getBounds().y+frameRecipient.getBounds().height-1);
		frameMessage.setBounds(0, sytxtSubject.getBounds().y+sytxtSubject.getBounds().height-1,shell.getBounds().width, y-32);
		frameTool.setLocation(0, frameMessage.getBounds().y+frameMessage.getBounds().height-1);
		cmbTemplate.setBounds(frameTool.getBounds().width-170, 7, 160, 23);
		
		composite.redraw();
	}
	
	private void setVisible(){
		if(visible){
			visible = false;
			
			shell.setSize(200, 26);
			Dimension dim = java.awt.Toolkit.getDefaultToolkit().getScreenSize(); 
			shell.setLocation(new Point((int)dim.getWidth()-206, (int)dim.getHeight()-74));
			
			composite.setBounds(0, 0, shell.getBounds().width, shell.getBounds().height);
			frameTitle.setBounds(0, 0, shell.getBounds().width, 26);
			lblCloseAction.setBounds(shell.getBounds().width-26, 5, 15, 15);
			lblSizeAction.setBounds(lblCloseAction.getBounds().x-19, 5, 15, 15);
			lblHideAction.setBounds(lblSizeAction.getBounds().x-19, 5, 15, 15);
			
			lblCloseAction.setBounds(shell.getBounds().width-26, 5, 15, 15);
			lblSizeAction.setBounds(lblCloseAction.getBounds().x-19, 5, 15, 15);
			lblHideAction.setBounds(lblSizeAction.getBounds().x-19, 5, 15, 15);
		}else{
			visible = true;
			setWindowSize();
		}
	}
	
	private void insertSignature(){
		if(account == null)
			return;
		
		if(textEditor.getContent().length() > 0)
			return;
		
		textEditor.displayContent(account.getEmailSignature(), account.getEmailSignatureStyle(), null);
	}
	
	private void insertAttachment(File file){
		int cnt = frameAttachment.getChildren().length;
		final CLabel lblAttachment = new CLabel(frameAttachment, SWT.NONE);
		lblAttachment.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				((CLabel)e.widget).dispose();
				computeAttachmentFrame();
			}
		});
		lblAttachment.setTopMargin(1);
		lblAttachment.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				lblAttachment.setBackground(SWTResourceManager.getColor(230, 230, 230));
			}
			@Override
			public void mouseExit(MouseEvent e) {
				lblAttachment.setBackground(SWTResourceManager.getColor(240, 240, 240));
			}
		});
		lblAttachment.setFont(SWTResourceManager.getFont("Segoe UI", 7, SWT.BOLD));
		lblAttachment.setBounds(3, 3+(cnt*20), 220, 18);
		lblAttachment.setImage(new Image(shell.getDisplay(), MailComposeDialog.class.getResourceAsStream("/images/Delete.gif")));
		lblAttachment.setText("   "+file.getName());
		lblAttachment.setData(file);
		
		frameAttachment.redraw();
		scrolledAttachment.setContent(frameAttachment);
		scrolledAttachment.setMinSize(frameAttachment.computeSize(SWT.DEFAULT, SWT.DEFAULT));
	}
	
	private void computeAttachmentFrame(){
		Control[] items = frameAttachment.getChildren();
		for(int i=0; i<items.length; i++){
			((CLabel)items[i]).setBounds(3, 3+(i*20), 220, 18);
		}
		
		frameAttachment.redraw();
		scrolledAttachment.setContent(frameAttachment);
		scrolledAttachment.setMinSize(frameAttachment.computeSize(SWT.DEFAULT, SWT.DEFAULT));
	}
		
	private void compose(){		
		SQLiteConnector dbConnector = new SQLiteConnector();
		
		EmailController controller = new EmailController();
		controller.setEmailAccount(account);		
		controller.setCCRecipient(sytxtCc.getText());
		controller.setEmailSubject(sytxtSubject.getText());
		controller.setEmailContent(parse());
		if(contacts != null)
			controller.setRecipients(contacts);
		else
			controller.setToRecipient(sytxtTo.getText());
		
		Control[] items = frameAttachment.getChildren();
    	for(int i=0; i<items.length; i++){
    		if(items[i].getData() == null)
    			continue;
    			    		
    		File file = (File)((CLabel)items[i]).getData();
    		controller.addEmailAttachments(file);
    	}
		
    	try {
			new ProgressMonitorDialog(shell).run(true, true, new EmailUtil(EmailUtil.ACTIONS.SEND, controller));
			
			//create history logs
			if(contacts != null){
				for(int i=0; i<contacts.size(); i++){
					History history = new History(0, null, "Email", contacts.get(i).getContactId(), contacts.get(i).getFullName(), sytxtSubject.getText(), account.getEmailId(), null);
					dbConnector.createHistory(history);	
				}
			}else{
				History history = new History(0, null, "Email", person==null?"":person.getContactId(), sytxtTo.getText(), sytxtSubject.getText(), account.getEmailId(), null);
				dbConnector.createHistory(history);
			}
				
			shell.close();
		} catch (Exception e1) {
			MessageDialog dlg = new MessageDialog(shell, SWT.NONE, e1.getMessage());
			dlg.open();
			e1.printStackTrace();
		} 
	}
		
	private String parse(){
		StringBuilder html = new StringBuilder();
		html.append("<html><head></head><body>");
		StringBuilder text = new StringBuilder();	
		text.append(textEditor.getContent());
		
		int readChar = 0;
		StyleRange[] ranges = textEditor.getContentStyleRange();		
		for(int i=0; i<ranges.length; i++){
			List<String> startTags = new ArrayList<String>();
			List<String> closeTags = new ArrayList<String>();
			StyleRange range = ranges[i];
			boolean bold=true, italic=true;
			
			if(range.foreground != null){
				String hex = String.format("#%02x%02x%02x", range.foreground.getRed(), range.foreground.getGreen(), range.foreground.getBlue());
				
				if(!hex.equals("#000000")){
					startTags.add("<font color='"+hex+"'>");
					closeTags.add("</font>");
				}
			}
			
			if(range.font != null){
				FontData data = range.font.getFontData()[0];
				startTags.add("<font size='"+(data.getHeight()-7)+"' face='"+data.getName()+"'>");
				closeTags.add("</font>");
				
				if(data.getStyle() == 1){
					startTags.add("<b>");
					closeTags.add("</b>");
					bold = false;
				}else if(data.getStyle() == 2){
					startTags.add("<i>");
					closeTags.add("</i>");
					italic = false;
				}else if(data.getStyle() == 1){
					startTags.add("<b><i>");
					closeTags.add("</i></b>");
					bold = false; italic = false;
				}
			}
			
			if(bold && range.fontStyle == SWT.BOLD){
				startTags.add("<b>");
				closeTags.add("</b>");
			}
			if(italic && range.fontStyle == SWT.ITALIC){
				startTags.add("<i>");
				closeTags.add("</i>");
			}
			if(bold && italic && range.fontStyle == (SWT.ITALIC | SWT.BOLD)){
				startTags.add("<b><i>");
				closeTags.add("</i></b>");
			}
			if(range.underline){
				startTags.add("<u>");
				closeTags.add("</u>");
			}
			
			if(readChar < range.start)
				html.append(text.substring(readChar, range.start-1));
			for(int z=0; z<startTags.size(); z++)
				html.append(startTags.get(z));
			html.append(text.substring(range.start, range.start+range.length));
			for(int z=closeTags.size()-1; z>=0; z--)
				html.append(closeTags.get(z));
			readChar = range.start+range.length;
		}
		
		html.append("</body></html>");
		return html.toString().replaceAll("\n", "</br>").replaceAll("\r", "&nbsp;&nbsp;&nbsp;&nbsp;").replaceAll("\t", "&nbsp;&nbsp;&nbsp;&nbsp;");
	}	
	
	private void getTemplate(){
		if(cmbTemplate.getSelectionIndex()==0){
			textEditor.setVisible(true);
			browser.setVisible(false);
		}else{
			textEditor.setVisible(false);
			browser.setVisible(true);
		}
		
		try{
			File file = new File(templatepath+"\\"+cmbTemplate.getText());
			
			DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
			Document doc = docBuilder.parse(file);
			
			Node template = doc.getElementsByTagName("template").item(0);
			NamedNodeMap attr = template.getAttributes();
			String layout = attr.getNamedItem("layout").getTextContent();
			
			if(layout.equalsIgnoreCase("ActiveVacation")){
				ActiveVacationDialog dlg = new ActiveVacationDialog(shell, SWT.NONE, cmbTemplate.getText());
				emailTemplate = dlg.getTemplate();
        	}else if(layout.equalsIgnoreCase("ActivePortfolio")){
        		ActivePortfolioDialog dlg = new ActivePortfolioDialog(shell, SWT.NONE, cmbTemplate.getText());
        		emailTemplate = dlg.getTemplate();
        	}else if(layout.equalsIgnoreCase("ActiveEvent")){
        		ActiveEventDialog dlg = new ActiveEventDialog(shell, SWT.NONE, cmbTemplate.getText());
        		emailTemplate = dlg.getTemplate();
        	}
			
			File f = new File("C:\\ProgramData\\BlackCodeCRM\\EmailTemplate\\tmppreview.htm");
			URL url = f.toURI().toURL(); 
			browser.setUrl(url.toString());
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	private void composeTemplate(){		
		String content = (String)emailTemplate[0];
		List<Object[]> images = (List)emailTemplate[1];
				
		Properties props = new Properties();
	    props.put("mail.smtp.auth", true);
	    props.put("mail.smtp.starttls.enable", true);
	    props.put("mail.smtp.host", account.getOutgoingMailServer());
	    
	    Session session = Session.getInstance(props,
	    		new javax.mail.Authenticator() {
	                protected PasswordAuthentication getPasswordAuthentication() {
	                    return new PasswordAuthentication(account.getEmailId(), account.getEmailPassword());
	                }
	            });

	    try {
	        MimeMessage message = new MimeMessage(session);
	        message.setFrom(new InternetAddress(account.getEmailId()));
	        message.addRecipients(Message.RecipientType.TO, InternetAddress.parse(sytxtTo.getText()));
	        message.setSubject(sytxtSubject.getText());
	                
	        Multipart multipart = new MimeMultipart();	       
	         
	        // Fill the message
	        BodyPart messageBodyPart = new MimeBodyPart();	 
	        messageBodyPart.setContent(content,"text/html");
	        multipart.addBodyPart(messageBodyPart);
	        
	    	// Picture in content
	        for(int i=0; i<images.size(); i++){
	        	MimeBodyPart embImagePart = new MimeBodyPart();
	        	DataSource iconDataSource = new FileDataSource((File)images.get(i)[1]);
	        	embImagePart.setDataHandler(new DataHandler(iconDataSource));
	        	embImagePart.setDisposition(Part.INLINE);
	        	embImagePart.setContentID("<" + images.get(i)[0]+ ">");
	        	embImagePart.addHeader("Content-Type", "image/png");
	        	multipart.addBodyPart(embImagePart);
	        }
	        
	    	message.setContent(multipart);
	    	Transport.send(message);
	        
	    	/*if(contacts != null){
				for(int i=0; i<contacts.size(); i++){
					History history = new History(0, null, "Email", contacts.get(i).getContactId(), contacts.get(i).getFullName(), sytxtSubject.getText(), account.getEmailId(), null);
					dbConnector.createHistory(history);	
				}
			}else{
				History history = new History(0, null, "Email", person==null?"":person.getContactId(), sytxtTo.getText(), sytxtSubject.getText(), account.getEmailId(), null);
				dbConnector.createHistory(history);
			}*/
	    	shell.close();
	    } catch (MessagingException e) {
	        e.printStackTrace();
	        
	    } catch (Exception e) {
	        e.printStackTrace();
	    } 
	}
}
