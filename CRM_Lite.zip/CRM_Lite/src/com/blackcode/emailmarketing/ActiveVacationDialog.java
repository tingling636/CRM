package com.blackcode.emailmarketing;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.eclipse.swt.custom.CLabel;
import org.eclipse.swt.custom.StyleRange;
import org.eclipse.swt.custom.StyledText;
import org.eclipse.swt.widgets.ColorDialog;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Dialog;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.Menu;
import org.eclipse.swt.widgets.MenuItem;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.SWT;
import org.eclipse.wb.swt.SWTResourceManager;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.custom.ScrolledComposite;

import com.blackcode.core.FileConvertor;

import org.eclipse.swt.events.ControlAdapter;
import org.eclipse.swt.events.ControlEvent;
import org.eclipse.swt.events.MouseTrackAdapter;
import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.Cursor;
import org.eclipse.swt.graphics.Font;
import org.eclipse.swt.graphics.FontData;
import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.graphics.RGB;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.events.MouseAdapter;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class ActiveVacationDialog extends Dialog {

	protected Object result;
	protected Shell shell;
	
	private CLabel lblTopFrame1, lblHeaderFrame, txtTopFrame2, txtTitleFrame1,lblPicFrame1, txtTitleFrame2;
	private StyledText txtTextFrame1;
	private Composite composite_layout, composite;
	private ScrolledComposite scrolledComposite;
	private int rectX, rectY, rectWidth, rectHeight;

	private String imageDirectory = "C:\\ProgramData\\BlackCodeCRM\\EmailTemplate\\image";
	private String layoutDirectory = "C:\\ProgramData\\BlackCodeCRM\\EmailTemplate\\layout";
	private String layoutFile;
	private String templateFile;
	private Menu imageOptionMenu, titleOptionMenu;
	private CLabel selectedFrame;
	private boolean freeze;
	/**
	 * Create the dialog.
	 * @param parent
	 * @param style
	 */
	public ActiveVacationDialog(Shell parent, int style) {
		super(parent, style);
		setText("Email Designer");
	}
	
	public ActiveVacationDialog(Shell parent, int style, String templatename) {
		super(parent, style);
		setText("Email Designer");
		templateFile = "C:\\ProgramData\\BlackCodeCRM\\EmailTemplate\\template\\"+templatename;
	}
	
	public ActiveVacationDialog(Shell parent, int style, String layoutname, boolean freeze) {
		super(parent, style);
		setText("Email Designer");
		templateFile = "C:\\ProgramData\\BlackCodeCRM\\EmailTemplate\\layout\\"+layoutname;
		this.freeze = freeze;
	}

	/**
	 * Open the dialog.
	 * @return the result
	 */
	public Object open() {
		createContents();
		shell.open();
		shell.layout();
		Display display = getParent().getDisplay();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
		return result;
	}

	/**
	 * Create contents of the dialog.
	 */
	private void createContents() {
		shell = new Shell(getParent(), SWT.DIALOG_TRIM | SWT.RESIZE);
		shell.addControlListener(new ControlAdapter() {
			@Override
			public void controlResized(ControlEvent e) {
				if(scrolledComposite == null)
					return;
				
				Rectangle r = shell.getClientArea();
				scrolledComposite.setBounds(0, 0, r.width, r.height);
	            shell.redraw();
			}
		});
		shell.setSize(560, getParent().getBounds().height-80);
		shell.setLocation(getParent().getBounds().width/2-380, 40);
		shell.setText(getText());
		
		scrolledComposite = new ScrolledComposite(shell, SWT.BORDER | SWT.H_SCROLL | SWT.V_SCROLL);
		scrolledComposite.setBounds(0, 0, shell.getBounds().width, shell.getBounds().height);
		scrolledComposite.setExpandHorizontal(true);
		scrolledComposite.setExpandVertical(true);
		
		composite = new Composite(scrolledComposite, SWT.NONE);
		
		Composite composite_action = new Composite(composite, SWT.BORDER);
		composite_action.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		composite_action.setBounds(3, 3, 520, 41);
		composite_action.setEnabled(!freeze);
		
		final CLabel lblSave = new CLabel(composite_action, SWT.CENTER);
		lblSave.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				saveTemplate();
			}
		});
		lblSave.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				lblSave.setForeground(SWTResourceManager.getColor(255, 102, 0));
				lblSave.setCursor(new Cursor(shell.getDisplay(), SWT.CURSOR_HAND));
			}
			@Override
			public void mouseExit(MouseEvent e) {
				lblSave.setForeground(SWTResourceManager.getColor(0, 0, 0));
				lblSave.setCursor(new Cursor(shell.getDisplay(), SWT.CURSOR_ARROW));
			}
		});		
		lblSave.setBackground(SWTResourceManager.getColor(255, 215, 0));
		lblSave.setBounds(8, 8, 61, 24);
		lblSave.setText("Save");
		
		final CLabel lblPreview = new CLabel(composite_action, SWT.CENTER);
		lblPreview.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				generateHtml(false);
			}
		});
		lblPreview.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				lblPreview.setForeground(SWTResourceManager.getColor(255, 102, 0));
				lblPreview.setCursor(new Cursor(shell.getDisplay(), SWT.CURSOR_HAND));
			}
			@Override
			public void mouseExit(MouseEvent e) {
				lblPreview.setForeground(SWTResourceManager.getColor(0, 0, 0));
				lblPreview.setCursor(new Cursor(shell.getDisplay(), SWT.CURSOR_ARROW));
			}
		});		
		lblPreview.setBackground(SWTResourceManager.getColor(255, 215, 0));
		lblPreview.setBounds(70, 8, 61, 24);
		lblPreview.setText("Preview");
		
		final CLabel lblTest = new CLabel(composite_action, SWT.CENTER);
		lblTest.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				testSend();
			}
		});
		lblTest.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				lblTest.setForeground(SWTResourceManager.getColor(255, 102, 0));
				lblTest.setCursor(new Cursor(shell.getDisplay(), SWT.CURSOR_HAND));
			}
			@Override
			public void mouseExit(MouseEvent e) {
				lblTest.setForeground(SWTResourceManager.getColor(0, 0, 0));
				lblTest.setCursor(new Cursor(shell.getDisplay(), SWT.CURSOR_ARROW));
			}
		});		
		lblTest.setBackground(SWTResourceManager.getColor(255, 215, 0));
		lblTest.setBounds(132, 8, 61, 24);
		lblTest.setText("Test");
		
		Label label = new Label(composite, SWT.SEPARATOR | SWT.HORIZONTAL);
		label.setBounds(3, 50, 520, 2);
		
		composite_layout = new Composite(composite, SWT.BORDER);
		composite_layout.addListener(SWT.Paint, new Listener() {
	        public void handleEvent(Event event) {
	            GC gc = event.gc;
	            gc.setLineWidth(1);
	            gc.setLineStyle(SWT.LINE_DASH);
	            gc.drawRectangle(rectX, rectY, rectWidth, rectHeight);
	        }});
		composite_layout.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		composite_layout.setBounds(3, 55, 520, 838);
		
		lblTopFrame1 = new CLabel(composite_layout, SWT.NONE);		
		lblTopFrame1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				lblTopFrame1.getMenu().setVisible(true);
				selectedFrame = (CLabel)e.widget;
			}
		});
		lblTopFrame1.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				rectX=lblTopFrame1.getBounds().x-1;
				rectY=lblTopFrame1.getBounds().y-1;
				rectWidth=lblTopFrame1.getBounds().width+1;
				rectHeight=lblTopFrame1.getBounds().height+1;
				composite_layout.redraw();
			}
			@Override
			public void mouseExit(MouseEvent e) {
				rectX=0;
				rectY=0;
				rectWidth=0;
				rectHeight=0;
				composite_layout.redraw();
			}
		});
		lblTopFrame1.setTopMargin(0);
		lblTopFrame1.setRightMargin(0);
		lblTopFrame1.setLeftMargin(0);
		lblTopFrame1.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblTopFrame1.setData("id", "lblTopFrame1");
			
		txtTopFrame2 = new CLabel(composite_layout, SWT.CENTER);
		txtTopFrame2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				txtTopFrame2.getMenu().setVisible(true);
				selectedFrame = (CLabel)e.widget;
			}
		});
		txtTopFrame2.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				rectX=txtTopFrame2.getBounds().x-1;
				rectY=txtTopFrame2.getBounds().y-1;
				rectWidth=txtTopFrame2.getBounds().width+1;
				rectHeight=txtTopFrame2.getBounds().height+1;
				composite_layout.redraw();
			}
			@Override
			public void mouseExit(MouseEvent e) {
				rectX=0;
				rectY=0;
				rectWidth=0;
				rectHeight=0;
				composite_layout.redraw();
			}
		});		
		txtTopFrame2.setTopMargin(7);
		txtTopFrame2.setBounds(281, 25, 185, 50);
		
		lblHeaderFrame = new CLabel(composite_layout, SWT.NONE);
		lblHeaderFrame.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				lblHeaderFrame.getMenu().setVisible(true);
				selectedFrame = (CLabel)e.widget;
			}
		});
		lblHeaderFrame.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				rectX=lblHeaderFrame.getBounds().x-1;
				rectY=lblHeaderFrame.getBounds().y-1;
				rectWidth=lblHeaderFrame.getBounds().width+1;
				rectHeight=lblHeaderFrame.getBounds().height+1;
				composite_layout.redraw();
			}
			@Override
			public void mouseExit(MouseEvent e) {
				rectX=0;
				rectY=0;
				rectWidth=0;
				rectHeight=0;
				composite_layout.redraw();
			}
		});
		lblHeaderFrame.setLeftMargin(0);
		lblHeaderFrame.setRightMargin(0);
		lblHeaderFrame.setTopMargin(0);
		lblHeaderFrame.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblHeaderFrame.setData("id", "lblHeaderFrame");
		
		txtTitleFrame1 = new CLabel(composite_layout, SWT.CENTER);
		txtTitleFrame1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				txtTitleFrame1.getMenu().setVisible(true);
				selectedFrame = (CLabel)e.widget;
			}
		});
		txtTitleFrame1.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				rectX=txtTitleFrame1.getBounds().x-1;
				rectY=txtTitleFrame1.getBounds().y-1;
				rectWidth=txtTitleFrame1.getBounds().width+1;
				rectHeight=txtTitleFrame1.getBounds().height+1;
				composite_layout.redraw();
			}
			@Override
			public void mouseExit(MouseEvent e) {
				rectX=0;
				rectY=0;
				rectWidth=0;
				rectHeight=0;
				composite_layout.redraw();
			}
		});
		txtTitleFrame1.setSize(456, 30);
		
		txtTextFrame1 = new StyledText(composite_layout, SWT.WRAP);
		txtTextFrame1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				EditContentDialog dlg = new EditContentDialog(shell, SWT.NONE, txtTextFrame1.getText(), 
						txtTextFrame1.getData("style")==null?null:(String)txtTextFrame1.getData("style"), txtTextFrame1.getAlignment());
				dlg.open();
				
				if(dlg.getContent() == null)
					return;
				
				txtTextFrame1.setText(dlg.getContent());
				txtTextFrame1.setAlignment(dlg.getAlignment());
				if(dlg.getStyleRange() != null)
					txtTextFrame1.setStyleRanges(dlg.getStyleRange());
				txtTextFrame1.setData("style", dlg.getContentStyle());
				txtTextFrame1.redraw();
			}
		});
		txtTextFrame1.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				rectX=txtTextFrame1.getBounds().x-1;
				rectY=txtTextFrame1.getBounds().y-1;
				rectWidth=txtTextFrame1.getBounds().width+1;
				rectHeight=txtTextFrame1.getBounds().height+1;
				composite_layout.redraw();
			}
			@Override
			public void mouseExit(MouseEvent e) {
				rectX=0;
				rectY=0;
				rectWidth=0;
				rectHeight=0;
				composite_layout.redraw();
			}
		});
		txtTextFrame1.setEditable(false);
		txtTextFrame1.setSize(456, 84);
		txtTextFrame1.setCursor(new Cursor(shell.getDisplay(), SWT.CURSOR_ARROW));
		
		lblPicFrame1 = new CLabel(composite_layout, SWT.NONE);
		lblPicFrame1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				lblPicFrame1.getMenu().setVisible(true);
				selectedFrame = (CLabel)e.widget;
			}
		});
		lblPicFrame1.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				rectX=lblPicFrame1.getBounds().x-1;
				rectY=lblPicFrame1.getBounds().y-1;
				rectWidth=lblPicFrame1.getBounds().width+1;
				rectHeight=lblPicFrame1.getBounds().height+1;
				composite_layout.redraw();
			}
			@Override
			public void mouseExit(MouseEvent e) {
				rectX=0;
				rectY=0;
				rectWidth=0;
				rectHeight=0;
				composite_layout.redraw();
			}
		});
		lblPicFrame1.setTopMargin(0);
		lblPicFrame1.setRightMargin(0);
		lblPicFrame1.setLeftMargin(0);
		lblPicFrame1.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblPicFrame1.setData("id", "lblPicFrame1");
						
		txtTitleFrame2 = new CLabel(composite_layout, SWT.CENTER);
		txtTitleFrame2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				txtTitleFrame2.getMenu().setVisible(true);
				selectedFrame = (CLabel)e.widget;
			}
		});
		txtTitleFrame2.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				rectX=txtTitleFrame2.getBounds().x-1;
				rectY=txtTitleFrame2.getBounds().y-1;
				rectWidth=txtTitleFrame2.getBounds().width+1;
				rectHeight=txtTitleFrame2.getBounds().height+1;
				composite_layout.redraw();
			}
			@Override
			public void mouseExit(MouseEvent e) {
				rectX=0;
				rectY=0;
				rectWidth=0;
				rectHeight=0;
				composite_layout.redraw();
			}
		});
		txtTitleFrame2.setSize(456, 21);
		
		//Menu
		imageOptionMenu = new Menu(composite);
		MenuItem IMNew = new MenuItem(imageOptionMenu, SWT.NONE);
		IMNew.setText("New Image");
		IMNew.addListener(SWT.Selection, new Listener() {
	        public void handleEvent(Event e) {
	        	editImage();
	          }
	        });
		MenuItem IMSize = new MenuItem(imageOptionMenu, SWT.NONE);
		IMSize.setText("Change Size");
		IMSize.addListener(SWT.Selection, new Listener() {
	        public void handleEvent(Event e) {
	        	changeSize();
	          }
	        });
		MenuItem IMLink = new MenuItem(imageOptionMenu, SWT.NONE);
		IMLink.setText("Make Link");
		IMLink.addListener(SWT.Selection, new Listener() {
	        public void handleEvent(Event e) {
	        	makeLink();
	          }
	        });
		MenuItem IMRemove = new MenuItem(imageOptionMenu, SWT.NONE);
		IMRemove.setText("Remove");
		IMRemove.addListener(SWT.Selection, new Listener() {
	        public void handleEvent(Event e) {
	        	removeImage();
	          }
	        });
		
		titleOptionMenu = new Menu(composite);
		MenuItem TMLink = new MenuItem(titleOptionMenu, SWT.NONE);
		TMLink.setText("Make Link");
		TMLink.addListener(SWT.Selection, new Listener() {
	        public void handleEvent(Event e) {
	        	makeLink();
	          }
	        });
		MenuItem TMTextColor = new MenuItem(titleOptionMenu, SWT.NONE);
		TMTextColor.setText("Text Color");
		TMTextColor.addListener(SWT.Selection, new Listener() {
	        public void handleEvent(Event e) {
	        	changeTextColor();
	          }
	        });
		MenuItem TMAlign = new MenuItem(titleOptionMenu, SWT.NONE);
		TMAlign.setText("Edit");
		TMAlign.addListener(SWT.Selection, new Listener() {
	        public void handleEvent(Event e) {
	        	editText();
	          }
	        });
		
		lblTopFrame1.setMenu(imageOptionMenu);
		lblHeaderFrame.setMenu(imageOptionMenu);
		lblPicFrame1.setMenu(imageOptionMenu);
		txtTopFrame2.setMenu(titleOptionMenu);
		txtTitleFrame1.setMenu(titleOptionMenu);
		txtTitleFrame2.setMenu(titleOptionMenu);
		
		scrolledComposite.setBounds(0, 0, 0, 0);
		scrolledComposite.setContent(composite);
		scrolledComposite.setMinSize(composite.computeSize(SWT.DEFAULT, SWT.DEFAULT));
		
		templateParser();
	}
		
	private void setImageFrame(CLabel frame, String imgFile, int x, int y, int width, int height, String url){
		try{
		if(imgFile == null){
			removeImage();
		}else{
			int[] dimension = FileConvertor.getImageDimension(imgFile);
			if(width == -1)
				width = dimension[0];
			if(height == -1)
				height = dimension[1];
			
			frame.setBounds(x, y, width, height);
			frame.setImage(resize(new Image(shell.getDisplay(), imgFile), width, height));
			
			frame.setData("img", imgFile);
			frame.setData("url", url);
		}
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	private Image resize(Image image, int width, int height) {
		Image scaled = new Image(Display.getDefault(), width, height);
		GC gc = new GC(scaled);
		gc.setAntialias(SWT.ON);
		gc.setInterpolation(SWT.HIGH);
		gc.drawImage(image, 0, 0, image.getBounds().width, image.getBounds().height, 0, 0, width, height);
		gc.dispose();
		image.dispose(); 
		return scaled;
	}
	
	private void setTitleFrame(CLabel frame, String text, int[] bgColor, int[] fgColor, String fontName, int size, int style, int align, String url){
		frame.setFont(SWTResourceManager.getFont(fontName, size, style));
		frame.setForeground(SWTResourceManager.getColor(fgColor[0], fgColor[1], fgColor[2]));
		frame.setBackground(SWTResourceManager.getColor(bgColor[0], bgColor[1], bgColor[2]));
		frame.setAlignment(align);
		frame.setText(text);
		frame.setData("url", url);
	}
	
	private void setTextFrame(StyledText frame, String text, String style, int align){
		frame.setText(text);
		frame.setAlignment(align);
		frame.setData("style", style);
		
		if(style != null && style.length() > 0){
			String[] ranges = style.split(";");
			
			StyleRange[] col = new StyleRange[ranges.length];
			for(int i=0; i<ranges.length; i++){
				String[] styles = ranges[i].split(":");
				
				StyleRange range = new StyleRange();
				range.borderStyle = Integer.parseInt(styles[0]);
				range.fontStyle = Integer.parseInt(styles[1]);
				range.length = Integer.parseInt(styles[2]);
				range.start = Integer.parseInt(styles[3]);
				range.strikeout = styles[4].equals("false")?false:true;
				range.underline = styles[5].equals("false")?false:true;
				range.underlineStyle = Integer.parseInt(styles[6]);
				
				if(styles[7].equals("null"))
					styles[7] = "Color {0, 0, 0}";
				String[] color = styles[7].substring(7, styles[7].length()-1).split(",");
				range.foreground = new Color(Display.getCurrent (), Integer.parseInt(color[0].trim()), Integer.parseInt(color[1].trim()), Integer.parseInt(color[2].trim()));
				
				//embeded picture
				if(!styles[8].equals("null")){
				}
				
				if(styles[9].equals("null"))
					styles[9] = "{9,Serif,0}";
				String[] font = styles[9].substring(1, styles[9].length()-1).split(",");
				range.font = new Font(Display.getCurrent (), font[1], Integer.parseInt(font[0]), Integer.parseInt(font[2]));				
				
				col[i] = range;
			}
			frame.setStyleRanges(col);
		}
		frame.redraw();
	}
	
	private void setContent(int index, String img, String text, String style, int align){		
		int y = 541+(142 * index);
		
		Composite frameSection = new Composite(composite_layout, SWT.NONE);
		frameSection.addListener(SWT.Paint, new Listener() {
	        public void handleEvent(Event event) {
	        	GC gc = event.gc;
	            gc.setLineWidth(1);
	            gc.setLineStyle(SWT.LINE_DASH);
	            gc.drawRectangle(rectX, rectY, rectWidth, rectHeight);
	        }});
		frameSection.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		frameSection.setBounds(10, y, 456, 139);
		frameSection.setData("id","section");
		
		final CLabel lblPicFrame2 = new CLabel(frameSection, SWT.NONE);
		lblPicFrame2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				lblPicFrame2.getMenu().setVisible(true);
				selectedFrame = (CLabel)e.widget;
			}
		});
		lblPicFrame2.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				rectX=((CLabel)e.widget).getBounds().x-1;
				rectY=((CLabel)e.widget).getBounds().y-1;
				rectWidth=((CLabel)e.widget).getBounds().width+1;
				rectHeight=((CLabel)e.widget).getBounds().height+1;
				((CLabel)e.widget).getParent().redraw();
			}
			@Override
			public void mouseExit(MouseEvent e) {
				rectX=0;
				rectY=0;
				rectWidth=0;
				rectHeight=0;
				((CLabel)e.widget).getParent().redraw();
			}
		});
		lblPicFrame2.setTopMargin(0);
		lblPicFrame2.setRightMargin(0);
		lblPicFrame2.setLeftMargin(0);
		lblPicFrame2.setBottomMargin(0);
		lblPicFrame2.setData("id","section"+index);
		
		setImageFrame(lblPicFrame2, imageDirectory+"\\"+img, 1, 1, -1, -1, null);
				
		StyledText txtTextFrame2 = new StyledText(frameSection, SWT.WRAP);
		txtTextFrame2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				EditContentDialog dlg = new EditContentDialog(shell, SWT.NONE, ((StyledText)e.widget).getText(), 
						((StyledText)e.widget).getData("style")==null?null:(String)((StyledText)e.widget).getData("style"), ((StyledText)e.widget).getAlignment());
				dlg.open();
				
				if(dlg.getContent() == null)
					return;
				
				((StyledText)e.widget).setText(dlg.getContent());
				((StyledText)e.widget).setAlignment(dlg.getAlignment());
				if(dlg.getStyleRange() != null)
					((StyledText)e.widget).setStyleRanges(dlg.getStyleRange());
				((StyledText)e.widget).setData("style", dlg.getContentStyle());
				((StyledText)e.widget).redraw();
			}
		});
		txtTextFrame2.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				rectX=((StyledText)e.widget).getBounds().x-1;
				rectY=((StyledText)e.widget).getBounds().y-1;
				rectWidth=((StyledText)e.widget).getBounds().width+1;
				rectHeight=((StyledText)e.widget).getBounds().height+1;
				((StyledText)e.widget).getParent().redraw();
			}
			@Override
			public void mouseExit(MouseEvent e) {
				rectX=0;
				rectY=0;
				rectWidth=0;
				rectHeight=0;
				((StyledText)e.widget).getParent().redraw();
			}
		});
		
		txtTextFrame2.setEditable(false);
		txtTextFrame2.setCursor(new Cursor(shell.getDisplay(), SWT.CURSOR_ARROW));
		txtTextFrame2.setBounds(168, 1, 285, 136);		
		setTextFrame(txtTextFrame2, text, style, align);
		
		lblPicFrame2.setMenu(imageOptionMenu);
		
	}	
	
	private void editImage(){
		ImageManager dlg = new ImageManager(shell, SWT.NONE);
		dlg.open();
		
		if(dlg.getSelectedFile()==null)
			return;
		
		int y = 1, x = 1;
		if(selectedFrame.getData("id").equals("lblTopFrame1")){
			x=10;y= 10;
		}
		if(selectedFrame.getData("id").equals("lblHeaderFrame")){
			x=10; y = lblTopFrame1.getBounds().height+lblTopFrame1.getBounds().y+5;
		}
		if(selectedFrame.getData("id").equals("lblPicFrame1")){
			x=10; y = txtTextFrame1.getBounds().height+txtTextFrame1.getBounds().y+5;
		}
				
		setImageFrame(selectedFrame, imageDirectory+"\\"+dlg.getSelectedFile(), x, y, -1, -1, (String)selectedFrame.getData("url"));
	}
	
	private void changeSize(){
		int[] size =new int[]{selectedFrame.getBounds().width, selectedFrame.getBounds().height};
		
		ChangeSizeDialog dlg = new ChangeSizeDialog(shell, SWT.NONE, size);
		dlg.open();
		
		if(dlg.getSize() == null)
			return;
		
		size = dlg.getSize();
		int y = 1, x = 1;
		if(selectedFrame.getData("id").equals("lblTopFrame1")){
			x=10;y= 10;
		}
		if(selectedFrame.getData("id").equals("lblHeaderFrame")){
			x=10; y = lblTopFrame1.getBounds().height+lblTopFrame1.getBounds().y+5;
		}
		if(selectedFrame.getData("id").equals("lblPicFrame1")){
			x=10; y = txtTextFrame1.getBounds().height+txtTextFrame1.getBounds().y+5;
		}
		
		setImageFrame(selectedFrame, (String)selectedFrame.getData("img"), x, y, size[0], size[1], (String)selectedFrame.getData("url"));
		
		rectX=0;
		rectY=0;
		rectWidth=0;
		rectHeight=0;
		composite_layout.redraw();
	}
	
	private void makeLink(){
		MakeLinkDialog dlg = new MakeLinkDialog(shell, SWT.NONE, (String)selectedFrame.getData("url"));
		dlg.open();
		
		if(dlg.getUrl() == null)
			return;
		
		selectedFrame.setData("url", dlg.getUrl());
	}
	
	private void removeImage(){
		selectedFrame.setImage(null);
		selectedFrame.setData("img", null);
		selectedFrame.setData("url", null);
	}
	
	private void changeTextColor(){
		ColorDialog cd = new ColorDialog(shell);
        cd.setText("ColorDialog Demo");
        cd.setRGB(new RGB(255, 255, 255));
        RGB newColor = cd.open();
        if (newColor == null) 
          return;
        
       selectedFrame.setForeground(SWTResourceManager.getColor(newColor.red, newColor.green, newColor.blue));
	}
	
	private void editText(){
		 String text = selectedFrame.getText(); 
		 int align = (int)selectedFrame.getAlignment(); 
		
		EditTitleDialog dlg = new EditTitleDialog(shell, SWT.NONE, text, align);
		dlg.open();
		
		if(dlg.getText() == null)
			return;
		
		selectedFrame.setText(dlg.getText());
		selectedFrame.setAlignment(dlg.getAlignment());
		selectedFrame.setData("align", dlg.getAlignment());
	}
	
	private void resetLocation(int index){
		switch(index){
		case 1 :
			lblHeaderFrame.setLocation(10, lblTopFrame1.getBounds().height+lblTopFrame1.getBounds().y+5);
		case 2 :
			txtTitleFrame1.setLocation(10, lblHeaderFrame.getBounds().height+lblHeaderFrame.getBounds().y+5);
		case 3 :
			txtTextFrame1.setLocation(10, txtTitleFrame1.getBounds().height+txtTitleFrame1.getBounds().y+5);
		case 4 :
			lblPicFrame1.setLocation(10, txtTextFrame1.getBounds().height+txtTextFrame1.getBounds().y+5);
		case 5 :
			txtTitleFrame2.setLocation(10, lblPicFrame1.getBounds().height+lblPicFrame1.getBounds().y+5);
		}
	}
	
	//Template Parser
	private void templateParser(){
		try{
			File file = new File(templateFile);
			
			DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
			Document doc = docBuilder.parse(file);
			
			Node template = doc.getElementsByTagName("template").item(0);
			NamedNodeMap attr = template.getAttributes();
			layoutFile = attr.getNamedItem("path").getTextContent();
			
			Node logo = doc.getElementsByTagName("logo").item(0);
			attr = logo.getAttributes();
			setImageFrame(lblTopFrame1, imageDirectory+"\\"+attr.getNamedItem("path").getTextContent(), 10, 10, 
					parseNumber(attr.getNamedItem("width").getTextContent()), parseNumber(attr.getNamedItem("height").getTextContent()), attr.getNamedItem("url").getTextContent());
			
			Node booknow = doc.getElementsByTagName("booknow").item(0);
			Node child = booknow.getFirstChild();
			attr = booknow.getAttributes();
			setTitleFrame(txtTopFrame2, child.getTextContent(), getRGB(attr.getNamedItem("bgcolor").getTextContent()), getRGB(attr.getNamedItem("fgcolor").getTextContent()), 
					attr.getNamedItem("font").getTextContent(), (int)getSize(attr.getNamedItem("size").getTextContent()), (int)getStyle(attr.getNamedItem("style").getTextContent()),
					(int)getAlignment(attr.getNamedItem("align").getTextContent()), attr.getNamedItem("url").getTextContent());
			
			Node header = doc.getElementsByTagName("header").item(0);
			attr = header.getAttributes();
			setImageFrame(lblHeaderFrame, imageDirectory+"\\"+attr.getNamedItem("path").getTextContent(), 10, lblTopFrame1.getBounds().height+lblTopFrame1.getBounds().y+5, 
					parseNumber(attr.getNamedItem("width").getTextContent()), parseNumber(attr.getNamedItem("height").getTextContent()), attr.getNamedItem("url").getTextContent());
			
			Node openingtitle = doc.getElementsByTagName("openingtitle").item(0);
			child = openingtitle.getFirstChild();
			attr = openingtitle.getAttributes();
			setTitleFrame(txtTitleFrame1, child.getTextContent(), getRGB(attr.getNamedItem("bgcolor").getTextContent()), getRGB(attr.getNamedItem("fgcolor").getTextContent()), 
					attr.getNamedItem("font").getTextContent(), (int)getSize(attr.getNamedItem("size").getTextContent()), (int)getStyle(attr.getNamedItem("style").getTextContent()),
					(int)getAlignment(attr.getNamedItem("align").getTextContent()), attr.getNamedItem("url").getTextContent());
			
			Node openingcontent = doc.getElementsByTagName("openingcontent").item(0);
			attr = openingcontent.getAttributes();
			NodeList list = openingcontent.getChildNodes();
			setTextFrame(txtTextFrame1, list.item(0).getTextContent(), list.item(1).getTextContent(), (int)getAlignment(attr.getNamedItem("align")));
			
			Node seperator = doc.getElementsByTagName("seperator").item(0);
			attr = seperator.getAttributes();
			setImageFrame(lblPicFrame1, imageDirectory+"\\"+attr.getNamedItem("path").getTextContent(), 10, txtTextFrame1.getBounds().height+txtTextFrame1.getBounds().y+5, 
					parseNumber(attr.getNamedItem("width").getTextContent()), parseNumber(attr.getNamedItem("height").getTextContent()), attr.getNamedItem("url").getTextContent());
			
			Node subtitle = doc.getElementsByTagName("subtitle").item(0);
			child = subtitle.getFirstChild(); 
			attr = subtitle.getAttributes();
			setTitleFrame(txtTitleFrame2, child.getTextContent(), getRGB(attr.getNamedItem("bgcolor").getTextContent()), getRGB(attr.getNamedItem("fgcolor").getTextContent()), 
					attr.getNamedItem("font").getTextContent(), (int)getSize(attr.getNamedItem("size").getTextContent()), (int)getStyle(attr.getNamedItem("style").getTextContent()),
					(int)getAlignment(attr.getNamedItem("align").getTextContent()), attr.getNamedItem("url").getTextContent());
			
			Node content = doc.getElementsByTagName("content").item(0);			
			list = content.getChildNodes();
			int index=0;
			for(int i=0; i<list.getLength(); i++){
				if(!list.item(i).getNodeName().equalsIgnoreCase("section"))
					continue;
				
				attr = list.item(i).getAttributes();
				NodeList section = list.item(i).getChildNodes();
				String img="",text="",styled="";
				for(int j=0; j<section.getLength(); j++){					
					if(section.item(j).getNodeName().equalsIgnoreCase("img"))
						img = section.item(j).getAttributes().getNamedItem("path").getTextContent();
					if(section.item(j).getNodeName().equalsIgnoreCase("text"))
						text = section.item(j).getTextContent();
					if(section.item(j).getNodeName().equalsIgnoreCase("style"))
						styled = section.item(j).getTextContent();
				}
				
				setContent(index, img, text, styled, (int)getAlignment(attr.getNamedItem("align").getTextContent()));
				index++;
			}
			
			resetLocation(2);
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	private Object getSize(Object size){
		try{
		if(size instanceof String){
			if(size.equals("2em"))
				return 22;
			else if(size.equals("1.5em"))
				return 18;
			else if(size.equals("1.17em"))
				return 14;
		}else if(size instanceof Integer){
			switch((int)size){
			case 22 : return "2em";
			case 18 : return "1.5em";
			case 14 : return "1.17em";
			default : return "1em";
			}
		}
		}catch(Exception e){
			e.printStackTrace();
		}
		
		return 12;
	}
	
	private Object getStyle(Object style){
		try{
		if(style instanceof String){
			if(style.equals("bold"))
				return SWT.BOLD;
			if(style.equals("italic"))
				return SWT.ITALIC;
			if(((String) style).contains("bold") && ((String) style).contains("italic"))
				return SWT.BOLD | SWT.ITALIC;
		}else if(style instanceof Integer){
			switch((int)style){
			case SWT.BOLD : return "bold";
			case SWT.ITALIC : return "italic";
			case SWT.BOLD | SWT.ITALIC : return"bold italic";
			}
		}
		}catch(Exception e){
			e.printStackTrace();
		}
		
		return SWT.NONE;
	}
	
	private Object getAlignment(Object align){
		try{
		if(align instanceof String){
			if(align.equals("center"))
				return SWT.CENTER;
			else if(align.equals("left"))
				return SWT.LEFT;
			else if(align.equals("right"))
				return SWT.RIGHT;
		}else if(align instanceof Integer){
			switch((int)align){
			case SWT.CENTER : return "center";
			case SWT.LEFT : return "left";
			case SWT.RIGHT: return "right";
			}
		}
		}catch(Exception e){
			e.printStackTrace();
		}
		
		return SWT.NONE;
	}
	
	private int parseNumber(String number){
		if(number==null || number.length()==0)
			return 0;
		
		return Integer.parseInt(number);
	}
	
	private int[] getRGB(String hex){
	    final int[] ret = new int[3];
	    hex = hex.substring(1);
	    for (int i = 0; i < 3; i++)
	        ret[i] = Integer.parseInt(hex.substring(i * 2, i * 2 + 2), 16);
	    
	    return ret;
	}
	
	private String getHex(Color rgb){
		return String.format("#%02x%02x%02x", rgb.getRed(), rgb.getGreen(), rgb.getBlue());
	}
	
	private void saveTemplate(){
		try{
			File file = new File(templateFile);
			
			DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
			Document doc = docBuilder.parse(file);
			
			Node root= doc.getFirstChild();
			NodeList nodes = root.getChildNodes();
			List<Node> col = new ArrayList<Node>();
			for (int i = 0; i < nodes.getLength(); i++) {
				Node node = nodes.item(i);
				col.add(node);
			}
			for (int i = 0; i < col.size(); i++) {
				root.removeChild(col.get(i));
			}
			
			Element logo = createImageElement(doc.createElement("logo"), lblTopFrame1);
			root.appendChild(logo);
			
			Element booknow = createTitleElement(doc.createElement("booknow"), txtTopFrame2);
			root.appendChild(booknow);
			
			Element header = createImageElement(doc.createElement("header"), lblHeaderFrame);
			root.appendChild(header);
			
			Element openingtitle = createTitleElement(doc.createElement("openingtitle"), txtTitleFrame1);
			root.appendChild(openingtitle);
			
			Element openingcontent = createTextElement(doc.createElement("openingcontent"), txtTextFrame1);
			root.appendChild(openingcontent);
			
			Element seperator = createImageElement(doc.createElement("seperator"), lblPicFrame1);
			root.appendChild(seperator);
			
			Element subtitle = createTitleElement(doc.createElement("subtitle"), txtTitleFrame2);
			root.appendChild(subtitle);
			
			Element content = doc.createElement("content");
			Control[] controls = composite_layout.getChildren();
			for(int i=0; i<controls.length; i++){
				if(controls[i] instanceof Composite && controls[i].getData("id") != null && controls[i].getData("id").equals("section")){
					Control[] sub = ((Composite)controls[i]).getChildren();
					CLabel imgframe = (CLabel)sub[0];
					StyledText textframe = (StyledText)sub[1];
					
					Element section = doc.createElement("section");
					section.setAttribute("align", "left");
					
					Element img = doc.createElement("img");
					img.setAttribute("path", ((String)imgframe.getData("img")).replace(imageDirectory+"\\", ""));
					section.appendChild(img);
					Element text = doc.createElement("text");
					text.appendChild(doc.createTextNode(textframe.getText()));
					section.appendChild(text);
					Element styled = doc.createElement("style");
					styled.appendChild(doc.createTextNode((String)textframe.getData("style")));
					section.appendChild(styled);
										
					content.appendChild(section);
				}
			}
			root.appendChild(content);
			
			TransformerFactory transformerFactory = TransformerFactory.newInstance();
			Transformer transformer = transformerFactory.newTransformer();
			DOMSource domsource = new DOMSource(doc);
			StreamResult result = new StreamResult(file);
			transformer.transform(domsource, result);
		}catch (Exception e){
			e.printStackTrace();
		}	
	}
	
	private Element createImageElement(Element element, CLabel frame){
		element.setAttribute("path", ((String)frame.getData("img")).replace(imageDirectory+"\\", ""));
		element.setAttribute("width", frame.getBounds().width+"");
		element.setAttribute("height", frame.getBounds().height+"");
		element.setAttribute("url", (String)frame.getData("url"));
		
		return element;
	}
	
	private Element createTitleElement(Element element, CLabel frame){
		element.setAttribute("font", frame.getFont().getFontData()[0].getName());
		element.setAttribute("size", (String)getSize(frame.getFont().getFontData()[0].getHeight()));
		element.setAttribute("style", (String)getStyle(frame.getFont().getFontData()[0].getStyle()));
		element.setAttribute("bgcolor", getHex(frame.getBackground()));
		element.setAttribute("fgcolor", getHex(frame.getForeground()));
		element.setAttribute("align", (String)getAlignment(frame.getAlignment()));
		element.setAttribute("url", (String)frame.getData("url"));
		Element text = element.getOwnerDocument().createElement("text");
		text.appendChild(element.getOwnerDocument().createTextNode(frame.getText()));
		element.appendChild(text);
		
		return element;
	}
	
	private Element createTextElement(Element element, StyledText frame){
		element.setAttribute("align", (String)getAlignment(frame.getAlignment()));
		Element text = element.getOwnerDocument().createElement("text");
		text.appendChild(element.getOwnerDocument().createTextNode(frame.getText()));
		element.appendChild(text);
		Element styled = element.getOwnerDocument().createElement("styled");
		styled.appendChild(element.getOwnerDocument().createTextNode((String)frame.getData("style")));
		element.appendChild(styled);
		
		return element;
	}
	
	public Object[] generateHtml(boolean send){
		//generate display style
		String booknowstyle = "font:"+getSize(txtTopFrame2.getFont().getFontData()[0].getHeight())+" "+getStyle(txtTopFrame2.getFont().getFontData()[0].getStyle())+" "+txtTopFrame2.getFont().getFontData()[0].getName()+";"
				+ "color:"+getHex(txtTopFrame2.getForeground())+"; text-align:"+getAlignment(txtTopFrame2.getAlignment())+";";
		String openingtitlestyle = "font:"+getSize(txtTitleFrame1.getFont().getFontData()[0].getHeight())+" "+getStyle(txtTitleFrame1.getFont().getFontData()[0].getStyle())+" "+txtTitleFrame1.getFont().getFontData()[0].getName()+";"
				+ "color:"+getHex(txtTitleFrame1.getForeground())+"; text-align:"+getAlignment(txtTitleFrame1.getAlignment())+";";
		String subtitlestyle = "font:"+getSize(txtTitleFrame2.getFont().getFontData()[0].getHeight())+" "+getStyle(txtTitleFrame2.getFont().getFontData()[0].getStyle())+" "+txtTitleFrame2.getFont().getFontData()[0].getName()+";"
				+ "color:"+getHex(txtTitleFrame2.getForeground())+"; text-align:"+getAlignment(txtTitleFrame2.getAlignment())+";";
		
		String htmlhead = "<head>\n"
				+ "<style>"
				+ "div.wrapper, table.wrapper {width:100%; text-align:center; font:12px Open Sans;}"
				+ "table.table_wrapper {line-height:17px; background-color:#ffffff;}"
				+ "table.button_booknow {padding-top:6px; padding-bottom:6px; "+booknowstyle+"}"
				+ "tr.openingtitle {"+openingtitlestyle+"}"
				+ "tr.subtitle {"+subtitlestyle+"}"
				+ "</style>";
		
		//generate content
		List<Object[]> embImages = new ArrayList<Object[]>();
		String logosource = "",logosourcesend = "";
		if(lblTopFrame1.getData("img") != null){
			logosource = "<img src=\""+lblTopFrame1.getData("img")+"\" width=\""+lblTopFrame1.getBounds().width+"\" height=\""+lblTopFrame1.getBounds().height+"\" border=\"0\" >";
			logosourcesend = "<img src=\"cid:logo\" width=\""+lblTopFrame1.getBounds().width+"\" height=\""+lblTopFrame1.getBounds().height+"\" border=\"0\" >";
			if(lblTopFrame1.getData("url") != null && !lblTopFrame1.getData("url").equals("")){
				logosource = "<a href=\""+lblTopFrame1.getData("url")+"\" >"+logosource+"</a>";
				logosourcesend = "<a href=\""+lblTopFrame1.getData("url")+"\" >"+logosourcesend+"</a>";
			}
			
			embImages.add(new Object[]{"logo", new File((String)lblTopFrame1.getData("img"))});
		}		
		
		String headersource="", headersourcesend="";
		if(lblHeaderFrame.getData("img") != null){
			headersource = "<img src=\""+lblHeaderFrame.getData("img")+"\" width=\""+lblHeaderFrame.getBounds().width+"\" height=\""+lblHeaderFrame.getBounds().height+"\" border=\"0\" >";
			headersourcesend = "<img src=\"cid:header\" width=\""+lblHeaderFrame.getBounds().width+"\" height=\""+lblHeaderFrame.getBounds().height+"\" border=\"0\" >";
			if(lblHeaderFrame.getData("url") != null && !lblHeaderFrame.getData("url").equals("")){
				headersource = "<a href=\""+lblHeaderFrame.getData("url")+"\" >"+headersource+"</a>";
				headersourcesend = "<a href=\""+lblHeaderFrame.getData("url")+"\" >"+headersourcesend+"</a>";
			}
			
			embImages.add(new Object[]{"header", new File((String)lblHeaderFrame.getData("img"))});
		}		
		
		String seperatorsource="",seperatorsourcesend="";
		if(lblPicFrame1.getData("img") != null){
			seperatorsource = "<img src=\""+lblPicFrame1.getData("img")+"\" width=\""+lblPicFrame1.getBounds().width+"\" height=\""+lblPicFrame1.getBounds().height+"\" border=\"0\" >";
			seperatorsourcesend = "<img src=\"cid:seperator\" width=\""+lblPicFrame1.getBounds().width+"\" height=\""+lblPicFrame1.getBounds().height+"\" border=\"0\" >";
			if(lblPicFrame1.getData("url") != null && !lblPicFrame1.getData("url").equals("")){
				seperatorsource = "<a href=\""+lblPicFrame1.getData("url")+"\" >"+seperatorsource+"</a>";
				seperatorsourcesend = "<a href=\""+lblPicFrame1.getData("url")+"\" >"+seperatorsourcesend+"</a>";
			}
			
			embImages.add(new Object[]{"seperator", new File((String)lblPicFrame1.getData("img"))});
		}
		
		String booknowsource = "<div id=\"button_booknow\">"+txtTopFrame2.getText()+"</div>";
		String openingtitlesource = "<div id=\"openingtitle\">"+txtTitleFrame1.getText()+"</div>";
		String subtitlesource = "<div id=\"subtitle\">"+txtTitleFrame2.getText()+"</div>";
		String openingcontentsource = textHtmlStyle(txtTextFrame1, "openingcontent");
		
		String content = "<div id=\"content\"><table border=\"0\" cellpadding=\"3\" cellspacing=\"0\" width=\"100%\">\n";
		Control[] controls = composite_layout.getChildren();
		for(int i=0; i<controls.length; i++){
			if(controls[i] instanceof Composite && controls[i].getData("id") != null && controls[i].getData("id").equals("section")){
				Control[] sub = ((Composite)controls[i]).getChildren();
				CLabel imgframe = (CLabel)sub[0];
				StyledText textframe = (StyledText)sub[1];
				
				content += "<tr><td>\n";
				if(imgframe.getData("img") != null){					
					if(send)
						content += "<img src=\"cid:section"+i+"\" width=\""+imgframe.getBounds().width+"\" height=\""+imgframe.getBounds().height+"\" border=\"0\" ></td>";
					else
						content += "<img src=\""+imgframe.getData("img")+"\" width=\""+imgframe.getBounds().width+"\" height=\""+imgframe.getBounds().height+"\" border=\"0\"></td>";
					embImages.add(new Object[]{"section"+i, new File((String)imgframe.getData("img"))});
				}
				content += "<td valign=\"top\" align=\"justify\">"+textHtmlStyle(textframe, "section"+i)+"</td></tr>\n";
			}
		}
		content += "</table></div>\n";
		
		
		StringBuilder contentBuilder = new StringBuilder();		
		try {
			File newhtmlfile = new File("C:\\ProgramData\\BlackCodeCRM\\EmailTemplate\\tmppreview.htm");
			FileWriter fw = new FileWriter(newhtmlfile.getAbsoluteFile());
			BufferedWriter bw = new BufferedWriter(fw);
			
		    BufferedReader in = new BufferedReader(new FileReader(layoutDirectory+"\\ActiveVacation.htm"));
		    String str;
		    while ((str = in.readLine()) != null) {
		    	if(str.contains("<div id=\"logo\"></div>"))
		    		str = str.replace("<div id=\"logo\"></div>", logosource);
		    	if(str.contains("<div id=\"header\"></div>"))
		    		str = str.replace("<div id=\"header\"></div>", headersource);
		    	if(str.contains("<div id=\"seperatorline\"></div>"))
		    		str = str.replace("<div id=\"seperatorline\"></div>", seperatorsource);
		    	if(str.contains("<div id=\"openingtitle\"></div>"))
		    		str = str.replace("<div id=\"openingtitle\"></div>", openingtitlesource);
		    	if(str.contains("<div id=\"subtitle\"></div>"))
		    		str = str.replace("<div id=\"subtitle\"></div>", subtitlesource);
		    	if(str.contains("<div id=\"button_booknow\"></div>"))
		    		str = str.replace("<div id=\"button_booknow\"></div>", booknowsource);
		    	if(str.contains("<div id=\"openingcontent\"></div>"))
		    		str = str.replace("<div id=\"openingcontent\"></div>",  openingcontentsource);
		    	if(str.contains("<div id=\"content\"></div>"))
		    		str = str.replace("<div id=\"content\"></div>",  content);
		    			    	
		        //contentBuilder.append(str);
		        bw.write(str);
		        
		        if(str.equalsIgnoreCase("<html>")){
		        	contentBuilder.append(htmlhead);
		        	bw.write(htmlhead);
		        }
		    }
		    in.close();
		    bw.close();
		    
		    //send version
		    newhtmlfile = new File("C:\\ProgramData\\BlackCodeCRM\\EmailTemplate\\tmpsend.htm");
			fw = new FileWriter(newhtmlfile.getAbsoluteFile());
			bw = new BufferedWriter(fw);
			
		    in = new BufferedReader(new FileReader(layoutDirectory+"\\ActiveVacation.htm"));
		    while ((str = in.readLine()) != null) {
		    	if(str.contains("<div id=\"logo\"></div>"))
		    		str = str.replace("<div id=\"logo\"></div>", logosourcesend);
		    	if(str.contains("<div id=\"header\"></div>"))
		    		str = str.replace("<div id=\"header\"></div>", headersourcesend);
		    	if(str.contains("<div id=\"seperatorline\"></div>"))
		    		str = str.replace("<div id=\"seperatorline\"></div>", seperatorsourcesend);
		    	if(str.contains("<div id=\"openingtitle\"></div>"))
		    		str = str.replace("<div id=\"openingtitle\"></div>", openingtitlesource);
		    	if(str.contains("<div id=\"subtitle\"></div>"))
		    		str = str.replace("<div id=\"subtitle\"></div>", subtitlesource);
		    	if(str.contains("<div id=\"button_booknow\"></div>"))
		    		str = str.replace("<div id=\"button_booknow\"></div>", booknowsource);
		    	if(str.contains("<div id=\"openingcontent\"></div>"))
		    		str = str.replace("<div id=\"openingcontent\"></div>",  openingcontentsource);
		    	if(str.contains("<div id=\"content\"></div>"))
		    		str = str.replace("<div id=\"content\"></div>",  content);
		    			    	
		        contentBuilder.append(str);
		        bw.write(str);
		        
		        if(str.equalsIgnoreCase("<html>")){
		        	contentBuilder.append(htmlhead);
		        	bw.write(htmlhead);
		        }
		    }
		    in.close();
		    bw.close();
		    
		    if(!send)
		    	Runtime.getRuntime().exec("rundll32 url.dll,FileProtocolHandler "+newhtmlfile); 
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		return new Object[]{contentBuilder.toString(), embImages};
	}
	
	private String textHtmlStyle(StyledText frame, String name){
		StringBuilder html = new StringBuilder();
		html.append("<div id=\""+name+"\">");
		StringBuilder text = new StringBuilder();	
		text.append(frame.getText());
		
		int readChar = 0;
		StyleRange[] ranges = frame.getStyleRanges();		
		for(int i=0; i<ranges.length; i++){
			List<String> startTags = new ArrayList<String>();
			List<String> closeTags = new ArrayList<String>();
			StyleRange range = ranges[i];
			boolean bold=true, italic=true;
			
			if(range.foreground != null){
				String hex = String.format("#%02x%02x%02x", range.foreground.getRed(), range.foreground.getGreen(), range.foreground.getBlue());
				
				if(!hex.equals("#000000")){
					startTags.add("<font color='"+hex+"'>");
					closeTags.add("</font>");
				}
			}
			
			if(range.font != null){
				FontData data = range.font.getFontData()[0];
				startTags.add("<font size='"+(data.getHeight()-7)+"' face='"+data.getName()+"'>");
				closeTags.add("</font>");
				
				if(data.getStyle() == 1){
					startTags.add("<b>");
					closeTags.add("</b>");
					bold = false;
				}else if(data.getStyle() == 2){
					startTags.add("<i>");
					closeTags.add("</i>");
					italic = false;
				}else if(data.getStyle() == 1){
					startTags.add("<b><i>");
					closeTags.add("</i></b>");
					bold = false; italic = false;
				}
			}
			
			if(bold && range.fontStyle == SWT.BOLD){
				startTags.add("<b>");
				closeTags.add("</b>");
			}
			if(italic && range.fontStyle == SWT.ITALIC){
				startTags.add("<i>");
				closeTags.add("</i>");
			}
			if(bold && italic && range.fontStyle == (SWT.ITALIC | SWT.BOLD)){
				startTags.add("<b><i>");
				closeTags.add("</i></b>");
			}
			if(range.underline){
				startTags.add("<u>");
				closeTags.add("</u>");
			}
			
			if(readChar < range.start)
				html.append(text.substring(readChar, range.start-1));
			for(int z=0; z<startTags.size(); z++)
				html.append(startTags.get(z));
			html.append(text.substring(range.start, range.start+range.length));
			for(int z=closeTags.size()-1; z>=0; z--)
				html.append(closeTags.get(z));
			readChar = range.start+range.length;
		}
		
		if(ranges.length == 0)
			html.append(frame.getText());
		
		html.append("</div>");
		return html.toString().replaceAll("\n", "</br>").replaceAll("\r", "&nbsp;&nbsp;&nbsp;&nbsp;").replaceAll("\t", "&nbsp;&nbsp;&nbsp;&nbsp;");
	}
	
	private void testSend(){
		Object[] content = generateHtml(true);
		
		TestSendDialog dlg = new TestSendDialog(shell, SWT.NONE, (String)content[0], (List)content[1]);
		dlg.open();
	}
	
	public Object[] getTemplate(){
		createContents();
		return generateHtml(true);
	}
}
	
	