package com.blackcode.emailmarketing;

import java.io.File;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.eclipse.swt.events.MouseAdapter;
import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.events.MouseTrackAdapter;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.TraverseEvent;
import org.eclipse.swt.events.TraverseListener;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.widgets.Dialog;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.Menu;
import org.eclipse.swt.widgets.MenuItem;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.widgets.TableItem;
import org.eclipse.swt.SWT;
import org.eclipse.wb.swt.SWTResourceManager;
import org.eclipse.swt.widgets.TabFolder;
import org.eclipse.swt.custom.CCombo;
import org.eclipse.swt.widgets.TabItem;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.DateTime;
import org.eclipse.swt.custom.CLabel;
import org.w3c.dom.Document;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;

import com.blackcode.core.SQLiteConnector;
import com.blackcode.model.Account;
import com.blackcode.model.EmailCampaign;
import com.blackcode.model.EmailCampaignRecipient;
import com.blackcode.model.History;

public class EmailCampaignDialog extends Dialog {

	protected Object result;
	protected Shell shell;
	private Text txtDisplayName;
	private Text txtEmailAddress;
	private Text txtEmailAddress_1;
	private Text txtEmailSubject;
	private CCombo cmbRecipient;
	private Text txtRecipient;
	private Table tblRecipient;
	private Composite frameTemplate; 
	private Combo cmbAccount;
	private DateTime dateSend1, dateSend2, dateSend3;
	private Combo cmbSendTime1, cmbSendTime2, cmbSendTime3, cmbSendTemplate1, cmbSendTemplate2, cmbSendTemplate3;
	private Button btnSend1, btnSend2, btnSend3;
	private CLabel lblLogTotalEmails, lblLogStatus, lblLogSent, lblLogFail, lblLogWait;
	private Label lblView1, lblView2, lblView3;
	private Text txtCampaignName;
	private Table tblLog;
	
	final String templatepath = "C:\\ProgramData\\BlackCodeCRM\\EmailTemplate\\template";
	private SQLiteConnector dbConnector = new SQLiteConnector();
	private EmailCampaign campaign = null;
	private List<Account> accounts;
	private Account selectedAccount;
	private List<History> logs;
	private String[] times = new String[]{"00:00","01:00","02:00","03:00","04:00","05:00","06:00","07:00","08:00","09:00","10:00","11:00","12:00",
			"13:00","14:00","15:00","16:00","17:00","18:00","19:00","20:00","21:00","22:00","23:00","24:00"};
	
	/**
	 * Create the dialog.
	 * @param parent
	 * @param style
	 */
	public EmailCampaignDialog(Shell parent, int style) {
		super(parent, style);
		setText("SWT Dialog");
	}
	
	public EmailCampaignDialog(Shell parent, int style, EmailCampaign campaign) {
		super(parent, style);
		this.campaign = campaign;
	}
	
	/**
	 * Open the dialog.
	 * @return the result
	 */
	public Object open() {
		createContents();
		shell.open();
		shell.layout();
		Display display = getParent().getDisplay();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
		return result;
	}

	/**
	 * Create contents of the dialog.
	 */
	private void createContents() {
		shell = new Shell(getParent(), SWT.NONE);
		shell.setSize(528, 536);
		shell.setText(getText());
		shell.setLocation((getParent().getBounds().width/2)-(shell.getBounds().width/2), (getParent().getBounds().height/2)-(shell.getBounds().height/2));
		
		Composite composite = new Composite(shell, SWT.NONE);
		composite.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		composite.setBounds(0, 0, 526, 533);

		Composite frameTitle = new Composite(composite, SWT.NONE);
		frameTitle.setBackground(SWTResourceManager.getColor(50, 50, 50));
		frameTitle.setBounds(0, 0, shell.getBounds().width, 26);
		
		Label lblTitle = new Label(frameTitle, SWT.NONE);
		lblTitle.setForeground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblTitle.setFont(SWTResourceManager.getFont("Georgia", 8, SWT.BOLD));
		lblTitle.setBounds(5, 6, 296, 15);
		lblTitle.setBackground(SWTResourceManager.getColor(50, 50, 50));
		lblTitle.setText("Email Campaign");
		
		final Label lblCloseAction = new Label(frameTitle, SWT.CENTER);
		lblCloseAction.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				shell.close();
			}
		});
		lblCloseAction.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				lblCloseAction.setBackground(SWTResourceManager.getColor(100, 100, 100));
			}
			@Override
			public void mouseExit(MouseEvent e) {
				lblCloseAction.setBackground(SWTResourceManager.getColor(50, 50, 50));
			}
		});
		lblCloseAction.setBounds(composite.getBounds().width-25, 3, 20, 20);
		lblCloseAction.setBackground(SWTResourceManager.getColor(50, 50, 50));
		lblCloseAction.setImage(new Image(shell.getDisplay(), this.getClass().getResourceAsStream("/images/close.png")));
		lblCloseAction.setToolTipText("Close Window");
		
		TabFolder tabFolder = new TabFolder(composite, SWT.NONE);
		tabFolder.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		tabFolder.setBounds(10, 36, 506, 450);
		
		TabItem tbtmBasic = new TabItem(tabFolder, SWT.NONE);
		tbtmBasic.setText("  Basic  ");
		
		Composite frameBasic = new Composite(tabFolder, SWT.NONE);
		tbtmBasic.setControl(frameBasic);
		
		Label lblCampaign = new Label(frameBasic, SWT.NONE);
		lblCampaign.setBounds(19, 10, 75, 15);
		lblCampaign.setText("Campaign");
		
		txtCampaignName = new Text(frameBasic, SWT.BORDER);
		txtCampaignName.setEnabled(false);
		txtCampaignName.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));		
		txtCampaignName.setBounds(19, 31, 298, 23);
		
		Label lblSendByAccount = new Label(frameBasic, SWT.NONE);
		lblSendByAccount.setBounds(19, 69, 96, 15);
		lblSendByAccount.setText("Send by Account");
		
		cmbAccount = new Combo(frameBasic, SWT.NONE);
		cmbAccount.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				selectedAccount = accounts.get(cmbAccount.getSelectionIndex());
				txtEmailAddress.setText(selectedAccount.getEmailId());
			}
		});
		cmbAccount.setBounds(19, 90, 158, 23);
		
		Label lblSendWithName = new Label(frameBasic, SWT.NONE);
		lblSendWithName.setBounds(19, 185, 93, 15);
		lblSendWithName.setText("Send With Name");
		
		txtDisplayName = new Text(frameBasic, SWT.BORDER);
		txtDisplayName.setBounds(19, 206, 296, 23);
		
		Label lblSendWithEmail = new Label(frameBasic, SWT.NONE);
		lblSendWithEmail.setBounds(19, 126, 146, 15);
		lblSendWithEmail.setText("Send With Email Address");
		
		txtEmailAddress = new Text(frameBasic, SWT.BORDER);
		txtEmailAddress.setBounds(19, 147, 296, 23);
		
		Label lblEmailSubject = new Label(frameBasic, SWT.NONE);
		lblEmailSubject.setBounds(19, 248, 73, 15);
		lblEmailSubject.setText("Email Subject");
		
		txtEmailSubject = new Text(frameBasic, SWT.BORDER);
		txtEmailSubject.setBounds(19, 269, 296, 23);
				
		TabItem tbtmSending = new TabItem(tabFolder, SWT.NONE);
		tbtmSending.setText("  Recipients  ");
		
		Composite frameRecipient = new Composite(tabFolder, SWT.NONE);
		tbtmSending.setControl(frameRecipient);
		
		cmbRecipient = new CCombo(frameRecipient, SWT.BORDER);
		cmbRecipient.setBounds(10, 13, 111, 21);
		cmbRecipient.setItems(new String[]{"All Contacts","Account", "Group","Email"});
		cmbRecipient.select(0);
		
		txtRecipient = new Text(frameRecipient, SWT.BORDER);
		txtRecipient.addTraverseListener(new TraverseListener() {
			public void keyTraversed(TraverseEvent e) {
				findRecipient();
			}
		});
		txtRecipient.setBounds(127, 13, 312, 21);
		
		final Label lblFindRecipientAction = new Label(frameRecipient, SWT.CENTER);
		lblFindRecipientAction.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				findRecipient();
			}
		});
		lblFindRecipientAction.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				lblFindRecipientAction.setBackground(SWTResourceManager.getColor(222,222,222));
			}
			@Override
			public void mouseExit(MouseEvent e) {
				lblFindRecipientAction.setBackground(SWTResourceManager.getColor(250, 250, 250));
			}
		});
		lblFindRecipientAction.setBounds(445, 10, 24, 24);
		lblFindRecipientAction.setToolTipText("Find");
		lblFindRecipientAction.setImage(new Image(shell.getDisplay(), this.getClass().getResourceAsStream("/images/search.png")));
				
		tblRecipient = new Table(frameRecipient, SWT.BORDER | SWT.FULL_SELECTION);
		tblRecipient.setBounds(10, 40, 459, 341);
		tblRecipient.setHeaderVisible(true);
		tblRecipient.setLinesVisible(true);
		setMenu(tblRecipient);
		
		TableColumn tblclmnEmail = new TableColumn(tblRecipient, SWT.LEFT);
		tblclmnEmail.setResizable(false);
		tblclmnEmail.setWidth(38);
		tblclmnEmail.setText("No");
		
		TableColumn tblclmnName = new TableColumn(tblRecipient, SWT.NONE);
		tblclmnName.setResizable(false);
		tblclmnName.setWidth(200);
		tblclmnName.setText("Email Ids");
		
		TableColumn tblclmnSentOn = new TableColumn(tblRecipient, SWT.NONE);
		tblclmnSentOn.setResizable(false);
		tblclmnSentOn.setWidth(150);
		tblclmnSentOn.setText("Name");
		
		Label lblAddEmailAddress = new Label(frameRecipient, SWT.NONE);
		lblAddEmailAddress.setBounds(10, 390, 101, 15);
		lblAddEmailAddress.setText("Add Email Address");
		
		txtEmailAddress_1 = new Text(frameRecipient, SWT.BORDER);
		txtEmailAddress_1.addTraverseListener(new TraverseListener() {
			public void keyTraversed(TraverseEvent e) {
				addRecipient();
			}
		});
		txtEmailAddress_1.setBounds(117, 387, 350, 21);
				
		TabItem tbtmContent = new TabItem(tabFolder, SWT.NONE);
		tbtmContent.setText("  Email Templates  ");
		
		frameTemplate = new Composite(tabFolder, SWT.NONE);
		tbtmContent.setControl(frameTemplate);
		
		CLabel lblSendDate = new CLabel(frameTemplate, SWT.CENTER);
		lblSendDate.setFont(SWTResourceManager.getFont("Segoe UI", 9, SWT.BOLD));
		lblSendDate.setBounds(61, 25, 73, 15);
		lblSendDate.setText("Send Date");
		
		Label lblStartTime = new Label(frameTemplate, SWT.CENTER);
		lblStartTime.setFont(SWTResourceManager.getFont("Segoe UI", 9, SWT.BOLD));
		lblStartTime.setBounds(169, 25, 73, 15);
		lblStartTime.setText("Start Time");
		
		Label lblTemplate = new Label(frameTemplate, SWT.CENTER);
		lblTemplate.setFont(SWTResourceManager.getFont("Segoe UI", 9, SWT.BOLD));
		lblTemplate.setBounds(311, 25, 61, 15);
		lblTemplate.setText("Template");
		
		btnSend1 = new Button(frameTemplate, SWT.CHECK);
		btnSend1.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				lblView1.setEnabled(btnSend1.getSelection());
			}
		});
		btnSend1.setFont(SWTResourceManager.getFont("Segoe UI", 9, SWT.BOLD));
		btnSend1.setBounds(10, 49, 40, 16);
		btnSend1.setText("  1.");
		
		dateSend1 = new DateTime(frameTemplate, SWT.BORDER | SWT.DROP_DOWN);
		dateSend1.setBounds(52, 46, 95, 23);
		
		cmbSendTime1 = new Combo(frameTemplate, SWT.BORDER);
		cmbSendTime1.setBounds(153, 46, 95, 23);
		cmbSendTime1.setItems(times);
		
		cmbSendTemplate1 = new Combo(frameTemplate, SWT.BORDER);
		cmbSendTemplate1.setBounds(254, 46, 180, 23);
		
		lblView1 = new Label(frameTemplate, SWT.CENTER);		
		lblView1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				if(cmbSendTemplate1.getText().length()==0)
					return;
				
				preview(cmbSendTemplate1.getText());
			}
		});
		lblView1.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				lblView1.setBackground(SWTResourceManager.getColor(222,222,222));
			}
			@Override
			public void mouseExit(MouseEvent e) {
				lblView1.setBackground(SWTResourceManager.getColor(250, 250, 250));
			}
		});
		lblView1.setToolTipText("Preview");
		lblView1.setBounds(440, 46, 20, 20);
		lblView1.setEnabled(false);
		lblView1.setImage(new Image(shell.getDisplay(), this.getClass().getResourceAsStream("/images/detail.gif")));
		
		btnSend2 = new Button(frameTemplate, SWT.CHECK);
		btnSend2.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				lblView2.setEnabled(btnSend2.getSelection());
			}
		});
		btnSend2.setFont(SWTResourceManager.getFont("Segoe UI", 9, SWT.BOLD));
		btnSend2.setBounds(10, 89, 36, 16);
		btnSend2.setText("  2.");
		
		dateSend2 = new DateTime(frameTemplate, SWT.BORDER | SWT.DROP_DOWN);
		dateSend2.setBounds(52, 86, 95, 23);
		
		cmbSendTime2 = new Combo(frameTemplate, SWT.NONE);
		cmbSendTime2.setBounds(153, 87, 95, 23);
		cmbSendTime2.setItems(times);
		
		cmbSendTemplate2 = new Combo(frameTemplate, SWT.NONE);
		cmbSendTemplate2.setBounds(254, 87, 180, 23);
		
		lblView2 = new Label(frameTemplate, SWT.CENTER);
		lblView2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				if(cmbSendTemplate2.getText().length()==0)
					return;
				
				preview(cmbSendTemplate2.getText());
			}
		});
		lblView2.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				lblView2.setBackground(SWTResourceManager.getColor(222,222,222));
			}
			@Override
			public void mouseExit(MouseEvent e) {
				lblView2.setBackground(SWTResourceManager.getColor(250, 250, 250));
			}
		});
		lblView2.setToolTipText("Preview");
		lblView2.setBounds(440, 90, 20, 20);
		lblView2.setEnabled(false);
		lblView2.setImage(new Image(shell.getDisplay(), this.getClass().getResourceAsStream("/images/detail.gif")));
		
		btnSend3 = new Button(frameTemplate, SWT.CHECK);
		btnSend3.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				lblView3.setEnabled(btnSend3.getSelection());
			}
		});
		btnSend3.setFont(SWTResourceManager.getFont("Segoe UI", 9, SWT.BOLD));
		btnSend3.setBounds(10, 129, 36, 16);
		btnSend3.setText("  3.");
		
		dateSend3 = new DateTime(frameTemplate, SWT.BORDER | SWT.DROP_DOWN);
		dateSend3.setBounds(52, 126, 95, 23);
		
		cmbSendTime3 = new Combo(frameTemplate, SWT.NONE);
		cmbSendTime3.setBounds(153, 127, 95, 23);
		cmbSendTime3.setItems(times);
		
		cmbSendTemplate3 = new Combo(frameTemplate, SWT.NONE);
		cmbSendTemplate3.setBounds(254, 127, 180, 23);
				
		lblView3 = new Label(frameTemplate, SWT.CENTER);
		lblView3.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				if(cmbSendTemplate3.getText().length()==0)
					return;
				
				preview(cmbSendTemplate3.getText());
			}
		});
		lblView3.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				lblView3.setBackground(SWTResourceManager.getColor(222,222,222));
			}
			@Override
			public void mouseExit(MouseEvent e) {
				lblView3.setBackground(SWTResourceManager.getColor(250, 250, 250));
			}
		});
		lblView3.setToolTipText("Preview");
		lblView3.setBounds(440, 130, 20, 20);
		lblView3.setEnabled(false);
		lblView3.setImage(new Image(shell.getDisplay(), this.getClass().getResourceAsStream("/images/detail.gif")));
						
		TabItem tbtmLogs = new TabItem(tabFolder, SWT.NONE);
		tbtmLogs.setText("  Logs  ");
		
		Composite frameLog = new Composite(tabFolder, SWT.NONE);
		tbtmLogs.setControl(frameLog);
		
		lblLogTotalEmails = new CLabel(frameLog, SWT.NONE);
		lblLogTotalEmails.setBounds(24, 10, 410, 21);
		lblLogTotalEmails.setText("Total Emails :");
		
		lblLogStatus = new CLabel(frameLog, SWT.NONE);
		lblLogStatus.setBounds(24, 37, 68, 21);
		lblLogStatus.setText("Status :");
		
		lblLogSent = new CLabel(frameLog, SWT.NONE);
		lblLogSent.setToolTipText("Show Sent List");
		lblLogSent.setForeground(SWTResourceManager.getColor(SWT.COLOR_LINK_FOREGROUND));
		lblLogSent.setBounds(98, 37, 73, 21);
		lblLogSent.setText("(Sent)");
		
		lblLogFail = new CLabel(frameLog, SWT.NONE);
		lblLogFail.setToolTipText("Show Fail List");
		lblLogFail.setForeground(SWTResourceManager.getColor(SWT.COLOR_RED));
		lblLogFail.setBounds(177, 37, 73, 21);
		lblLogFail.setText("(Fail)");
		
		lblLogWait = new CLabel(frameLog, SWT.NONE);
		lblLogWait.setToolTipText("Show Waiting List");
		lblLogWait.setForeground(SWTResourceManager.getColor(SWT.COLOR_DARK_GREEN));
		lblLogWait.setBounds(254, 37, 73, 21);
		lblLogWait.setText("(Wait)");
		
		tblLog = new Table(frameLog, SWT.BORDER | SWT.FULL_SELECTION);
		tblLog.setBounds(10, 64, 478, 348);
		tblLog.setHeaderVisible(true);
		tblLog.setLinesVisible(true);
		
		TableColumn tblclmnDateTime = new TableColumn(tblLog, SWT.NONE);
		tblclmnDateTime.setWidth(110);
		tblclmnDateTime.setText("Date Time");
		
		TableColumn tblclmnSentTo = new TableColumn(tblLog, SWT.NONE);
		tblclmnSentTo.setWidth(150);
		tblclmnSentTo.setText("Sent To");
		
		TableColumn tblclmnTemplate = new TableColumn(tblLog, SWT.NONE);
		tblclmnTemplate.setWidth(120);
		tblclmnTemplate.setText("Template");
		
		TableColumn tblclmnStatus = new TableColumn(tblLog, SWT.CENTER);
		tblclmnStatus.setWidth(75);
		tblclmnStatus.setText("Status");
				
		final CLabel lblSave = new CLabel(composite, SWT.CENTER);
		lblSave.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				if(save())
					shell.close();
			}
		});
		lblSave.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				lblSave.setBackground(SWTResourceManager.getColor(86, 86, 86));
			}
			@Override
			public void mouseExit(MouseEvent e) {
				lblSave.setBackground(SWTResourceManager.getColor(45, 45, 45));
			}
		});
		lblSave.setBounds(172, 495, 81, 28);
		lblSave.setBackground(SWTResourceManager.getColor(45, 45, 45));
		lblSave.setForeground(SWTResourceManager.getColor(245, 245, 245));
		lblSave.setFont(SWTResourceManager.getFont("Georgia", 9, SWT.BOLD));		
		lblSave.setText("Save");
		
		final CLabel lblDelete = new CLabel(composite, SWT.CENTER);
		lblDelete.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				if(delete())
					shell.close();
			}
		});
		lblDelete.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				lblDelete.setBackground(SWTResourceManager.getColor(86, 86, 86));
			}
			@Override
			public void mouseExit(MouseEvent e) {
				lblDelete.setBackground(SWTResourceManager.getColor(45, 45, 45));
			}
		});
		lblDelete.setBounds(286, 495, 81, 28);
		lblDelete.setBackground(SWTResourceManager.getColor(45, 45, 45));
		lblDelete.setForeground(SWTResourceManager.getColor(245, 245, 245));
		lblDelete.setFont(SWTResourceManager.getFont("Georgia", 9, SWT.BOLD));
		lblDelete.setText("Delete");
		
		initialize();
	}
	
	private void initialize(){
		accounts = dbConnector.readAccount(null, null);
		for(int i=0; i<accounts.size(); i++){
			Account account = accounts.get(i);
			cmbAccount.add(account.getCode());
		}
		
		File folder = new File(templatepath);
		File[] templates = folder.listFiles(); 		 
		for (int i = 0; i < templates.length; i++){	
			if (templates[i].isFile()) {
		        if (templates[i].getName().endsWith(".xml")){
		        	cmbSendTemplate1.add(templates[i].getName());
		        	cmbSendTemplate2.add(templates[i].getName());
		        	cmbSendTemplate3.add(templates[i].getName());
		        }
		    }
		}
		
		if(campaign == null)
			return;
		
		int cntTemplate = 0;
		SimpleDateFormat sdf = new SimpleDateFormat("HH:mm");
		txtCampaignName.setText(displayText(campaign.getName()));
		cmbAccount.setText(displayText(campaign.getEmailAccount()));
		txtDisplayName.setText(displayText(campaign.getSendByName()));
		txtEmailAddress.setText(displayText(campaign.getSendByEmailId()));
		txtEmailSubject.setText(displayText(campaign.getEmailSubject()));
		cmbSendTemplate1.setText(displayText(campaign.getTemplate1()));
		cmbSendTemplate2.setText(displayText(campaign.getTemplate2()));
		cmbSendTemplate3.setText(displayText(campaign.getTemplate3()));
		if(campaign.getDateTime1() != null){
			btnSend1.setSelection(true);
			dateSend1.setDate(1900+campaign.getDateTime1().getYear(), campaign.getDateTime1().getMonth(), campaign.getDateTime1().getDate());
			cmbSendTime1.select(campaign.getDateTime1().getHours());
			lblView1.setEnabled(true);
			cntTemplate++;
		}
		if(campaign.getDateTime2() != null){
			btnSend2.setSelection(true);
			dateSend2.setDate(1900+campaign.getDateTime2().getYear(), campaign.getDateTime2().getMonth(), campaign.getDateTime2().getDate());
			cmbSendTime2.setText(sdf.format(campaign.getDateTime1()));
			lblView2.setEnabled(true);
			cntTemplate++;
		}
		if(campaign.getDateTime3() != null){
			btnSend3.setSelection(true);
			dateSend3.setDate(1900+campaign.getDateTime3().getYear(), campaign.getDateTime3().getMonth(), campaign.getDateTime3().getDate());
			cmbSendTime3.setText(sdf.format(campaign.getDateTime3()));
			lblView3.setEnabled(true);
			cntTemplate++;
		}
		
		List<EmailCampaignRecipient> col = campaign.getRecipients();
		tblRecipient.removeAll();
		for(int i=0; i<col.size(); i++){
			EmailCampaignRecipient recipient = col.get(i);
			TableItem ti = new TableItem(tblRecipient, SWT.NONE);
			ti.setText(new String[]{(tblRecipient.getItemCount())+". ", recipient.getEmailId(), displayText(recipient.getContactName())});
			ti.setData(recipient);
		}
				
		sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm");
		logs = dbConnector.readHistory(null, "type='Email Campaign' AND notes LIKE '"+campaign.getId()+"%'", null);
		tblLog.removeAll();
		int sent=0, fail=0;
		for(int i=0; i<logs.size(); i++){
			History log = logs.get(i);
			TableItem ti = new TableItem(tblLog, SWT.NONE);
			ti.setText(new String[]{sdf.format(log.getLogDateTime()), log.getContactName(), "", log.getNotes()});
			if(log.getNotes().contains("Sent"))
				sent++;
			else if(log.getNotes().contains("Fail"))
				fail++;
		}
		
		lblLogTotalEmails.setText("Total Emails : "+col.size()+"(Recipients), "+cntTemplate+" (Templates)");
		lblLogSent.setText(sent+"(Sent)");
		lblLogFail.setText(fail+"(Fail)");
		lblLogWait.setText((col.size()*cntTemplate)-sent-fail+"(Wait)");
	}

	private void setMenu(final Table table) {
	    Listener popUpListener = new Listener() {
	        @Override
	        public void handleEvent(Event event) {
	            MenuItem item = (MenuItem)event.widget;
	            if(item.getText().equals("Remove")){
	            	deleteRecipient();
	            }
	        }
	    };
	    Menu menu = new Menu(table); 
	    MenuItem item2 = new MenuItem(menu, SWT.PUSH);
	    item2.setText("Remove");
	    item2.addListener(SWT.Selection, popUpListener);
	    item2.setImage(new Image(shell.getDisplay(), this.getClass().getResourceAsStream("/images/remove.png")));
	    table.setMenu(menu);
	}
	
	private void findRecipient(){
		String sql = "";
		if(cmbRecipient.getSelectionIndex() == 1 && txtRecipient.getText().length() > 0){
			sql = "accountId LIKE '%"+txtRecipient.getText()+"%'";
		}else if(cmbRecipient.getSelectionIndex() == 2 && txtRecipient.getText().length() > 0){
			sql = "groups LIKE '%"+txtRecipient.getText()+"%'";
		}else if(cmbRecipient.getSelectionIndex() == 3 && txtRecipient.getText().length() > 0){
			sql = "personalEmail='"+txtRecipient.getText()+"' OR workEmail='"+txtRecipient.getText()+"' OR otherEmail='"+txtRecipient.getText()+"'";
		}else {
			sql = null;
		}
		List<EmailCampaignRecipient> data = dbConnector.findEmailRecipient(null, sql, null, campaign.getId());
		
		for(int i=0; i<data.size(); i++){
			EmailCampaignRecipient recipient = data.get(i);
			
			TableItem ti = new TableItem(tblRecipient, SWT.NONE);
			ti.setText(new String[]{(tblRecipient.getItemCount())+". ", recipient.getEmailId(), displayText(recipient.getContactName())});
			ti.setData(recipient);
			campaign.getRecipients().add(recipient);
		}
	}
	
	private void addRecipient(){
		if(txtEmailAddress_1.getText().length()==0)
			return;
		
		for(int i=0; i<tblRecipient.getItemCount(); i++){
			if(tblRecipient.getItem(i).getText(1).contains(txtEmailAddress_1.getText()))
				return;
		}
		
		EmailCampaignRecipient recipient = new EmailCampaignRecipient();
		recipient.setCampaignId(campaign.getId());
		recipient.setEmailId(txtEmailAddress_1.getText());
		recipient.setStatus("Pending");
		Object obj = dbConnector.createEmailRecipient(recipient);
		if(obj instanceof String){
			return;
		}
		
		TableItem ti = new TableItem(tblRecipient, SWT.NONE);
		ti.setText(new String[]{(tblRecipient.getItemCount())+". ", recipient.getEmailId(), displayText(recipient.getContactName())});
		ti.setData(recipient);
		campaign.getRecipients().add(recipient);
		txtEmailAddress_1.setText("");
	}
	
	private void deleteRecipient(){
		if(tblRecipient.getSelectionIndex() == -1)
			return;
		
		EmailCampaignRecipient recipient = (EmailCampaignRecipient)tblRecipient.getItem(tblRecipient.getSelectionIndex()).getData();
		dbConnector.deleteEmailRecipient(recipient, null);
		campaign.getRecipients().remove(recipient);
		tblRecipient.remove(tblRecipient.getSelectionIndex());
	}
	
	private boolean delete(){
		Object obj = dbConnector.deleteEmailCampaign(campaign, null);
		
		if(obj instanceof String){
			return false;
		}
		
		return true;
	}
	
	private boolean save(){
		try{
			campaign.setEmailAccount(captureText(cmbAccount.getText()));
			campaign.setSendByName(captureText(txtDisplayName.getText()));
			campaign.setSendByEmailId(captureText(txtEmailAddress.getText()));
			campaign.setEmailSubject(captureText(txtEmailSubject.getText()));
			campaign.clearTemplates();
			if(btnSend1.getSelection() && cmbSendTemplate1.getText().length()>0){
				Calendar c = Calendar.getInstance();
				c.set(dateSend1.getYear(), dateSend1.getMonth(), dateSend1.getDay());
				if(cmbSendTime1.getSelectionIndex() >= 0)
					c.set(Calendar.HOUR_OF_DAY, cmbSendTime1.getSelectionIndex());
				SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				Date date = sdf.parse(sdf.format(c.getTime()));
				
				campaign.setDateTime1(new Timestamp(date.getTime()));
				campaign.setTemplate1(cmbSendTemplate1.getText());
			}
			if(btnSend2.getSelection() && cmbSendTemplate2.getText().length()>0){
				Calendar c = Calendar.getInstance();
				c.set(dateSend2.getYear(), dateSend2.getMonth(), dateSend2.getDay());
				if(cmbSendTime2.getSelectionIndex() >= 0)
					c.set(Calendar.HOUR_OF_DAY, cmbSendTime2.getSelectionIndex());
				SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				Date date = sdf.parse(sdf.format(c.getTime()));
				
				campaign.setDateTime2(new Timestamp(date.getTime()));
				campaign.setTemplate2(cmbSendTemplate2.getText());
			}
			if(btnSend3.getSelection() && cmbSendTemplate3.getText().length()>0){
				Calendar c = Calendar.getInstance();
				c.set(dateSend3.getYear(), dateSend3.getMonth(), dateSend3.getDay());
				if(cmbSendTime3.getSelectionIndex() >= 0)
					c.set(Calendar.HOUR_OF_DAY, cmbSendTime3.getSelectionIndex());
				SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				Date date = sdf.parse(sdf.format(c.getTime()));
				
				campaign.setDateTime3(new Timestamp(date.getTime()));
				campaign.setTemplate3(cmbSendTemplate3.getText());
			}
			
			dbConnector.updateEmailCampaign(campaign, null);
			return true;
		}catch(Exception e){
			return false;
		}		
	}
	
	private void preview(String templatename){
		try{
			File file = new File(templatepath+"\\"+templatename);
			
			DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
			Document doc = docBuilder.parse(file);
			
			Node template = doc.getElementsByTagName("template").item(0);
			NamedNodeMap attr = template.getAttributes();
			String layout = attr.getNamedItem("layout").getTextContent();
			
			if(layout.equalsIgnoreCase("ActiveVacation")){
        		ActiveVacationDialog dlg = new ActiveVacationDialog(shell.getParent().getShell(), SWT.NONE, templatename);
        		dlg.open();
        	}else if(layout.equalsIgnoreCase("ActivePortfolio")){
        		ActivePortfolioDialog dlg = new ActivePortfolioDialog(shell.getParent().getShell(), SWT.NONE, templatename);
        		dlg.open();
        	}
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	private String displayText(Object obj){
		if(obj==null)
			return "";
		else
			return obj.toString();
	}
	
	private String captureText(String text){
		if(text.length() == 0)
			return null;
		else
			return text;
	}
}
