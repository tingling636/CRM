package com.blackcode.emailmarketing;

import java.io.File;
import java.util.List;
import java.util.Properties;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.Part;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

import org.eclipse.swt.events.MouseAdapter;
import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.events.MouseTrackAdapter;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.widgets.Dialog;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.SWT;
import org.eclipse.wb.swt.SWTResourceManager;
import org.eclipse.swt.custom.CLabel;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Text;

import com.blackcode.core.SQLiteConnector;
import com.blackcode.model.Account;

import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;

public class TestSendDialog extends Dialog {

	protected Object result;
	protected Shell shell;
	private Text txtFrom;
	private Text txtTo;
	private Combo cmbAccount;
	
	private List<Account> accounts;
	private Account selectedAccount;
	private String content;
	private List<Object[]> images;

	/**
	 * Create the dialog.
	 * @param parent
	 * @param style
	 */
	public TestSendDialog(Shell parent, int style) {
		super(parent, style);
		setText("SWT Dialog");
	}
	
	public TestSendDialog(Shell parent, int style, String content, List<Object[]> images) {
		super(parent, style);
		this.content = content;
		this.images = images;
	}

	/**
	 * Open the dialog.
	 * @return the result
	 */
	public Object open() {
		createContents();
		shell.open();
		shell.layout();
		Display display = getParent().getDisplay();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
		return result;
	}

	/**
	 * Create contents of the dialog.
	 */
	private void createContents() {
		shell = new Shell(getParent(), SWT.NONE);
		shell.setSize(323, 156);
		shell.setText(getText());
		shell.setLocation(getParent().getBounds().x+(getParent().getBounds().width/2)-(shell.getBounds().width/2), getParent().getBounds().y+(getParent().getBounds().height/2)-(shell.getBounds().height/2));
		
		Composite composite = new Composite(shell, SWT.NONE);
		composite.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		composite.setBounds(0, 0, 321, 154);

		Composite frameTitle = new Composite(composite, SWT.NONE);
		frameTitle.setBackground(SWTResourceManager.getColor(50, 50, 50));
		frameTitle.setBounds(0, 0, shell.getBounds().width, 26);
		
		Label lblTitle = new Label(frameTitle, SWT.NONE);
		lblTitle.setForeground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblTitle.setFont(SWTResourceManager.getFont("Georgia", 8, SWT.BOLD));
		lblTitle.setBounds(5, 6, 296, 15);
		lblTitle.setBackground(SWTResourceManager.getColor(50, 50, 50));
		lblTitle.setText("Test Send Email");
		
		final Label lblCloseAction = new Label(frameTitle, SWT.CENTER);
		lblCloseAction.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				shell.close();
			}
		});
		lblCloseAction.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				lblCloseAction.setBackground(SWTResourceManager.getColor(100, 100, 100));
			}
			@Override
			public void mouseExit(MouseEvent e) {
				lblCloseAction.setBackground(SWTResourceManager.getColor(50, 50, 50));
			}
		});
		lblCloseAction.setBounds(composite.getBounds().width-25, 3, 20, 20);
		lblCloseAction.setBackground(SWTResourceManager.getColor(50, 50, 50));
		lblCloseAction.setImage(new Image(shell.getDisplay(), this.getClass().getResourceAsStream("/images/close.png")));
		lblCloseAction.setToolTipText("Close Window");
		
		CLabel lblAccount = new CLabel(composite, SWT.RIGHT);
		lblAccount.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblAccount.setBounds(14, 34, 61, 21);
		lblAccount.setText("Account");
		
		cmbAccount = new Combo(composite, SWT.NONE);
		cmbAccount.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				selectedAccount = accounts.get(cmbAccount.getSelectionIndex());
				txtFrom.setText(selectedAccount.getEmailId());
			}
		});
		cmbAccount.setBounds(91, 32, 206, 23);
		
		Label lblSendBy = new Label(composite, SWT.RIGHT);
		lblSendBy.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblSendBy.setBounds(20, 64, 55, 15);
		lblSendBy.setText("Send By");
		
		txtFrom = new Text(composite, SWT.BORDER);
		txtFrom.setBounds(91, 61, 207, 21);
		
		Label lblSendTo = new Label(composite, SWT.RIGHT);
		lblSendTo.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblSendTo.setBounds(16, 91, 55, 15);
		lblSendTo.setText("Send To");
		
		txtTo = new Text(composite, SWT.BORDER);
		txtTo.setBounds(91, 88, 206, 21);
		
		final CLabel lblSend = new CLabel(composite, SWT.CENTER);
		lblSend.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				send();
				shell.close();
			}
		});
		lblSend.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				lblSend.setBackground(SWTResourceManager.getColor(86, 86, 86));
			}
			@Override
			public void mouseExit(MouseEvent e) {
				lblSend.setBackground(SWTResourceManager.getColor(45, 45, 45));
			}
		});
		lblSend.setBackground(SWTResourceManager.getColor(45, 45, 45));
		lblSend.setForeground(SWTResourceManager.getColor(245, 245, 245));
		lblSend.setFont(SWTResourceManager.getFont("Georgia", 9, SWT.BOLD));
		lblSend.setBounds(91, 123, 61, 24);
		lblSend.setText("Send");
		
		final CLabel lblCancel = new CLabel(composite, SWT.CENTER);
		lblCancel.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				shell.close();
			}
		});
		lblCancel.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				lblCancel.setBackground(SWTResourceManager.getColor(86, 86, 86));
			}
			@Override
			public void mouseExit(MouseEvent e) {
				lblCancel.setBackground(SWTResourceManager.getColor(45, 45, 45));
			}
		});
		lblCancel.setBackground(SWTResourceManager.getColor(45, 45, 45));
		lblCancel.setForeground(SWTResourceManager.getColor(245, 245, 245));
		lblCancel.setFont(SWTResourceManager.getFont("Georgia", 9, SWT.BOLD));
		lblCancel.setBounds(176, 123, 61, 24);
		lblCancel.setText("Cancel");
		
		initialize();
	}
	
	private void initialize(){
		accounts = new SQLiteConnector().readAccount(null, null);
		for(int i=0; i<accounts.size(); i++){
			Account account = accounts.get(i);
			cmbAccount.add(account.getCode());
		}
	}
	
	private boolean send(){		
		Properties props = new Properties();
	    props.put("mail.smtp.auth", true);
	    props.put("mail.smtp.starttls.enable", true);
	    props.put("mail.smtp.host", selectedAccount.getOutgoingMailServer());
	    
	    Session session = Session.getInstance(props,
	    		new javax.mail.Authenticator() {
	                protected PasswordAuthentication getPasswordAuthentication() {
	                    return new PasswordAuthentication(selectedAccount.getEmailId(), selectedAccount.getEmailPassword());
	                }
	            });

	    try {
	        MimeMessage message = new MimeMessage(session);
	        message.setFrom(new InternetAddress(selectedAccount.getEmailId()));
	        message.addRecipients(Message.RecipientType.TO, InternetAddress.parse(txtTo.getText()));
	        message.setSubject("Email Template Testing");
	                
	        Multipart multipart = new MimeMultipart();	       
	         
	        // Fill the message
	        BodyPart messageBodyPart = new MimeBodyPart();	 
	        messageBodyPart.setContent(content,"text/html");
	        multipart.addBodyPart(messageBodyPart);
	        
	    	// Picture in content
	        for(int i=0; i<images.size(); i++){
	        	MimeBodyPart embImagePart = new MimeBodyPart();
	        	DataSource iconDataSource = new FileDataSource((File)images.get(i)[1]);
	        	embImagePart.setDataHandler(new DataHandler(iconDataSource));
	        	embImagePart.setDisposition(Part.INLINE);
	        	embImagePart.setContentID("<" + images.get(i)[0]+ ">");
	        	embImagePart.addHeader("Content-Type", "image/png");
	        	multipart.addBodyPart(embImagePart);
	        }
	        
	    	message.setContent(multipart);
	    	Transport.send(message);
	        
	    	return true;
	    } catch (MessagingException e) {
	        e.printStackTrace();
	        
	        return false;
	    } catch (Exception e) {
	        e.printStackTrace();
	        
	        return false;
	    }
	}
}
