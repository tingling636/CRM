package com.blackcode.emailmarketing;

import java.io.File;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.eclipse.swt.events.MouseAdapter;
import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.events.MouseTrackAdapter;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.widgets.Dialog;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.SWT;
import org.eclipse.wb.swt.SWTResourceManager;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.custom.CLabel;
import org.w3c.dom.Document;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;

import com.blackcode.core.FileConvertor;

public class EmailDesignerDialog extends Dialog {

	protected Object result;
	protected Shell shell;
	private Text txtName;
	private Button btnOpen, btnCreateNew;
	private Combo cmbTemplate, cmbLayout;
	private CLabel lblConfirm;
	private CLabel lblCancel;

	final String templatepath = "C:\\ProgramData\\BlackCodeCRM\\EmailTemplate\\template";
	final String layoutpath = "C:\\ProgramData\\BlackCodeCRM\\EmailTemplate\\layout";
	private String filename;
	private String layout;
	private Label lblView;
	
	/**
	 * Create the dialog.
	 * @param parent
	 * @param style
	 */
	public EmailDesignerDialog(Shell parent, int style) {
		super(parent, style);
		setText("SWT Dialog");
	}

	/**
	 * Open the dialog.
	 * @return the result
	 */
	public Object open() {
		createContents();
		shell.open();
		shell.layout();
		Display display = getParent().getDisplay();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
		return result;
	}

	/**
	 * Create contents of the dialog.
	 */
	private void createContents() {
		shell = new Shell(getParent(), SWT.NONE);
		shell.setSize(349, 235);
		shell.setText(getText());
		shell.setLocation(getParent().getBounds().x+(getParent().getBounds().width/2)-(shell.getBounds().width/2), getParent().getBounds().y+(getParent().getBounds().height/2)-(shell.getBounds().height/2));
		
		Composite composite = new Composite(shell, SWT.NONE);
		composite.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		composite.setBounds(0, 0, 347, 233);

		Composite frameTitle = new Composite(composite, SWT.NONE);
		frameTitle.setBackground(SWTResourceManager.getColor(50, 50, 50));
		frameTitle.setBounds(0, 0, shell.getBounds().width, 26);
		
		Label lblTitle = new Label(frameTitle, SWT.NONE);
		lblTitle.setForeground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblTitle.setFont(SWTResourceManager.getFont("Georgia", 8, SWT.BOLD));
		lblTitle.setBounds(5, 6, 296, 15);
		lblTitle.setBackground(SWTResourceManager.getColor(50, 50, 50));
		lblTitle.setText("Email Designer");
		
		final Label lblCloseAction = new Label(frameTitle, SWT.CENTER);
		lblCloseAction.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				shell.close();
			}
		});
		lblCloseAction.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				lblCloseAction.setBackground(SWTResourceManager.getColor(100, 100, 100));
			}
			@Override
			public void mouseExit(MouseEvent e) {
				lblCloseAction.setBackground(SWTResourceManager.getColor(50, 50, 50));
			}
		});
		lblCloseAction.setBounds(composite.getBounds().width-25, 3, 20, 20);
		lblCloseAction.setBackground(SWTResourceManager.getColor(50, 50, 50));
		lblCloseAction.setImage(new Image(shell.getDisplay(), this.getClass().getResourceAsStream("/images/close.png")));
		lblCloseAction.setToolTipText("Close Window");
		
		btnOpen = new Button(composite, SWT.RADIO);
		btnOpen.setSelection(true);
		btnOpen.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		btnOpen.setFont(SWTResourceManager.getFont("Segoe UI", 9, SWT.BOLD));
		btnOpen.setBounds(36, 42, 118, 16);
		btnOpen.setText(" Open Template");
		
		cmbTemplate = new Combo(composite, SWT.NONE);
		cmbTemplate.setBounds(62, 64, 239, 23);
		
		btnCreateNew = new Button(composite, SWT.RADIO);
		btnCreateNew.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		btnCreateNew.setFont(SWTResourceManager.getFont("Segoe UI", 9, SWT.BOLD));
		btnCreateNew.setBounds(36, 103, 152, 16);
		btnCreateNew.setText(" Create New Template");
		
		Label lblName = new Label(composite, SWT.RIGHT);
		lblName.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblName.setBounds(46, 128, 43, 15);
		lblName.setText("Name");
		
		txtName = new Text(composite, SWT.BORDER);
		txtName.setBounds(105, 125, 196, 21);
		
		Label lblLayout = new Label(composite, SWT.RIGHT);
		lblLayout.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblLayout.setBounds(46, 155, 43, 15);
		lblLayout.setText("Layout");
		
		cmbLayout = new Combo(composite, SWT.NONE);
		cmbLayout.setBounds(105, 152, 196, 23);
		
		lblView = new Label(composite, SWT.CENTER);
		lblView.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				if(cmbLayout.getText().length()==0)
					return;
				
				preview(cmbLayout.getText());
			}
		});
		lblView.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				lblView.setBackground(SWTResourceManager.getColor(222,222,222));
			}
			@Override
			public void mouseExit(MouseEvent e) {
				lblView.setBackground(SWTResourceManager.getColor(250, 250, 250));
			}
		});
		lblView.setToolTipText("Preview");
		lblView.setBounds(307, 155, 20, 20);
		lblView.setImage(new Image(shell.getDisplay(), this.getClass().getResourceAsStream("/images/detail.gif")));
		
		lblConfirm = new CLabel(composite, SWT.CENTER);
		lblConfirm.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				if(btnOpen.getSelection()){
					filename = cmbTemplate.getText();
					setLayout();
				}else if(btnCreateNew.getSelection()){
					FileConvertor.copyFile(layoutpath+"\\"+cmbLayout.getText(), templatepath, txtName.getText()+".xml");
					filename = txtName.getText()+".xml";
					layout = cmbLayout.getText().replace(".xml", "");
				}
				shell.close();
			}
		});
		lblConfirm.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				lblConfirm.setBackground(SWTResourceManager.getColor(86, 86, 86));
			}
			@Override
			public void mouseExit(MouseEvent e) {
				lblConfirm.setBackground(SWTResourceManager.getColor(45, 45, 45));
			}
		});
		lblConfirm.setBackground(SWTResourceManager.getColor(45, 45, 45));
		lblConfirm.setForeground(SWTResourceManager.getColor(245, 245, 245));
		lblConfirm.setFont(SWTResourceManager.getFont("Georgia", 9, SWT.BOLD));
		lblConfirm.setBounds(95, 191, 71, 26);
		lblConfirm.setText("Confirm");
		
		lblCancel = new CLabel(composite, SWT.CENTER);
		lblCancel.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				shell.close();
			}
		});
		lblCancel.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				lblCancel.setBackground(SWTResourceManager.getColor(86, 86, 86));
			}
			@Override
			public void mouseExit(MouseEvent e) {
				lblCancel.setBackground(SWTResourceManager.getColor(45, 45, 45));
			}
		});
		lblCancel.setBackground(SWTResourceManager.getColor(45, 45, 45));
		lblCancel.setForeground(SWTResourceManager.getColor(245, 245, 245));
		lblCancel.setFont(SWTResourceManager.getFont("Georgia", 9, SWT.BOLD));
		lblCancel.setBounds(185, 191, 71, 26);
		lblCancel.setText("Cancel");
				
		initialize();
	}
	
	private void initialize(){
		//list templates
		File folder = new File(templatepath);
		File[] templates = folder.listFiles(); 		 
		for (int i = 0; i < templates.length; i++){	
			if (templates[i].isFile()) {
		        if (templates[i].getName().endsWith(".xml")){
		        	cmbTemplate.add(templates[i].getName());
		        }
		    }
		}
		
		//list layout
		folder = new File(layoutpath);
		File[] layouts = folder.listFiles(); 		 
		for (int i = 0; i < layouts.length; i++){	
			if (layouts[i].isFile()) {
		        if (layouts[i].getName().endsWith(".xml")){
		        	cmbLayout.add(layouts[i].getName());
		        }
		    }
		}
	}
	
	private void setLayout(){
		try{
			File file = new File(templatepath+"\\"+cmbTemplate.getText());
			
			DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
			Document doc = docBuilder.parse(file);
			
			Node template = doc.getElementsByTagName("template").item(0);
			NamedNodeMap attr = template.getAttributes();
			layout = attr.getNamedItem("layout").getTextContent();
		}catch(Exception e){
			
		}
	}
	
	private void preview(String templatename){
		try{
			File file = new File(layoutpath+"\\"+templatename);
			
			DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
			Document doc = docBuilder.parse(file);
			
			Node template = doc.getElementsByTagName("template").item(0);
			NamedNodeMap attr = template.getAttributes();
			String layout = attr.getNamedItem("layout").getTextContent();
			
			if(layout.equalsIgnoreCase("ActiveVacation")){
        		ActiveVacationDialog dlg = new ActiveVacationDialog(shell.getParent().getShell(), SWT.NONE, templatename, true);
        		dlg.open();
        	}else if(layout.equalsIgnoreCase("ActivePortfolio")){
        		ActivePortfolioDialog dlg = new ActivePortfolioDialog(shell.getParent().getShell(), SWT.NONE, templatename, true);
        		dlg.open();
        	}else if(layout.equalsIgnoreCase("ActiveEvent")){
        		ActiveEventDialog dlg = new ActiveEventDialog(shell.getParent().getShell(), SWT.NONE, templatename, true);
        		dlg.open();
        	}
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public String getFilename(){
		return this.filename;
	}
	
	public String getLayout(){
		return this.layout;
	}
}
