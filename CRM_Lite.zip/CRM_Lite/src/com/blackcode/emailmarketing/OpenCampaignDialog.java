package com.blackcode.emailmarketing;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.eclipse.swt.events.MouseAdapter;
import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.events.MouseTrackAdapter;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.widgets.Dialog;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.wb.swt.SWTResourceManager;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.custom.CLabel;

import com.blackcode.core.SQLiteConnector;
import com.blackcode.model.EmailCampaign;
import com.blackcode.model.EmailCampaignRecipient;

public class OpenCampaignDialog extends Dialog {

	protected Object result;
	protected Shell shell;
	private Text txtName;
	private Button btnOpen, btnCreateNew;
	private Combo cmbCampaign;

	private SQLiteConnector dbConnector = new SQLiteConnector();
	private List<EmailCampaign> campaigns = new ArrayList<EmailCampaign>();
	private EmailCampaign selectedCampaign = null;
	
	/**
	 * Create the dialog.
	 * @param parent
	 * @param style
	 */
	public OpenCampaignDialog(Shell parent, int style) {
		super(parent, style);
		setText("SWT Dialog");
	}

	/**
	 * Open the dialog.
	 * @return the result
	 */
	public Object open() {
		createContents();
		shell.open();
		shell.layout();
		Display display = getParent().getDisplay();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
		return result;
	}

	/**
	 * Create contents of the dialog.
	 */
	private void createContents() {
		shell = new Shell(getParent(), SWT.NONE);
		shell.setSize(317, 192);
		shell.setLocation(getParent().getBounds().x+(getParent().getBounds().width/2)-(shell.getBounds().width/2), getParent().getBounds().y+(getParent().getBounds().height/2)-(shell.getBounds().height/2));
		
		Composite composite = new Composite(shell, SWT.NONE);
		composite.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		composite.setBounds(0, 0, 315, 190);

		Composite frameTitle = new Composite(composite, SWT.NONE);
		frameTitle.setBackground(SWTResourceManager.getColor(50, 50, 50));
		frameTitle.setBounds(0, 0, shell.getBounds().width, 26);
		
		Label lblTitle = new Label(frameTitle, SWT.NONE);
		lblTitle.setForeground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblTitle.setFont(SWTResourceManager.getFont("Georgia", 8, SWT.BOLD));
		lblTitle.setBounds(5, 6, 225, 15);
		lblTitle.setBackground(SWTResourceManager.getColor(50, 50, 50));
		lblTitle.setText("Open Campaign");
		
		final Label lblCloseAction = new Label(frameTitle, SWT.CENTER);
		lblCloseAction.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				shell.close();
			}
		});
		lblCloseAction.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				lblCloseAction.setBackground(SWTResourceManager.getColor(100, 100, 100));
			}
			@Override
			public void mouseExit(MouseEvent e) {
				lblCloseAction.setBackground(SWTResourceManager.getColor(50, 50, 50));
			}
		});
		lblCloseAction.setBounds(composite.getBounds().width-25, 3, 20, 20);
		lblCloseAction.setBackground(SWTResourceManager.getColor(50, 50, 50));
		lblCloseAction.setImage(new Image(shell.getDisplay(), this.getClass().getResourceAsStream("/images/close.png")));
		lblCloseAction.setToolTipText("Close Window");
		
		btnOpen = new Button(composite, SWT.RADIO);
		btnOpen.setSelection(true);
		btnOpen.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		btnOpen.setBounds(27, 38, 90, 16);
		btnOpen.setText("Open");
		
		cmbCampaign = new Combo(composite, SWT.NONE);
		cmbCampaign.setBounds(42, 60, 238, 23);
		
		btnCreateNew = new Button(composite, SWT.RADIO);
		btnCreateNew.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		btnCreateNew.setBounds(27, 93, 90, 16);
		btnCreateNew.setText("Create New");
		
		Label lblName = new Label(composite, SWT.NONE);
		lblName.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblName.setBounds(42, 115, 39, 15);
		lblName.setText("Name");
		
		txtName = new Text(composite, SWT.BORDER);
		txtName.setBounds(87, 115, 193, 21);
		
		final CLabel lblConfirm = new CLabel(composite, SWT.CENTER);
		lblConfirm.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				if(btnOpen.getSelection()){
					if(cmbCampaign.getSelectionIndex() == -1)
						return;
					selectedCampaign = campaigns.get(cmbCampaign.getSelectionIndex());
				}else if(btnCreateNew.getSelection()){
					createCampaign(txtName.getText());
				}
				shell.close();
			}
		});
		lblConfirm.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				lblConfirm.setBackground(SWTResourceManager.getColor(86, 86, 86));
			}
			@Override
			public void mouseExit(MouseEvent e) {
				lblConfirm.setBackground(SWTResourceManager.getColor(45, 45, 45));
			}
		});
		lblConfirm.setBackground(SWTResourceManager.getColor(45, 45, 45));
		lblConfirm.setForeground(SWTResourceManager.getColor(245, 245, 245));
		lblConfirm.setFont(SWTResourceManager.getFont("Georgia", 9, SWT.BOLD));
		lblConfirm.setBounds(74, 154, 69, 26);
		lblConfirm.setText("Confirm");
		
		final CLabel lblCancel = new CLabel(composite, SWT.CENTER);
		lblCancel.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				selectedCampaign = null;				
				shell.close();
			}
		});
		lblCancel.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				lblCancel.setBackground(SWTResourceManager.getColor(86, 86, 86));
			}
			@Override
			public void mouseExit(MouseEvent e) {
				lblCancel.setBackground(SWTResourceManager.getColor(45, 45, 45));
			}
		});
		lblCancel.setBackground(SWTResourceManager.getColor(45, 45, 45));
		lblCancel.setForeground(SWTResourceManager.getColor(245, 245, 245));
		lblCancel.setFont(SWTResourceManager.getFont("Georgia", 9, SWT.BOLD));
		lblCancel.setBounds(172, 154, 69, 26);
		lblCancel.setText("Cancel");
		
		initialize();
	}
	
	private void initialize(){
		campaigns = dbConnector.readEmailCampaign(null, null, "createdOn DESC");
	    for(int i=0; i<campaigns.size(); i++){
	    	EmailCampaign campaign = (EmailCampaign)campaigns.get(i);
	    	cmbCampaign.add(campaign.getName());
	    }
	}
	
	private void createCampaign(String name){
		try{
			Calendar c = Calendar.getInstance();
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-mm-dd hh:mm:ss");
			Date now = sdf.parse(sdf.format(c.getTime()));
			
			EmailCampaign campaign = new EmailCampaign();
			campaign.setName(name);
			campaign.isActive(true);
			campaign.setRecipients(new ArrayList<EmailCampaignRecipient>());
			//campaign.setCreatedBy(user.getUserId());
			campaign.setCreatedOn(new Timestamp(now.getTime()));
			
			Object obj = dbConnector.createEmailCampaign(campaign);
			if(obj instanceof String){
				selectedCampaign = null;
			}
			
			selectedCampaign = (EmailCampaign)obj;
		}catch(Exception e){
			
		}		
	}
	
	public EmailCampaign getCampaign(){
		return this.selectedCampaign;
	}
}
