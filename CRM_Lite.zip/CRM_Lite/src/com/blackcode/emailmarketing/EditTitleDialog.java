package com.blackcode.emailmarketing;

import org.eclipse.swt.events.MouseAdapter;
import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.events.MouseTrackAdapter;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.widgets.Dialog;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.SWT;
import org.eclipse.wb.swt.SWTResourceManager;
import org.eclipse.swt.custom.CLabel;
import org.eclipse.swt.widgets.Text;

public class EditTitleDialog extends Dialog {

	protected Object result;
	protected Shell shell;
	private Text txtText;

	private CLabel lblLeft, lblRight, lblCenter;
	private int alignment = SWT.CENTER;
	private String text;
	/**
	 * Create the dialog.
	 * @param parent
	 * @param style
	 */
	public EditTitleDialog(Shell parent, int style) {
		super(parent, style);
		setText("SWT Dialog");
	}
	
	public EditTitleDialog(Shell parent, int style, String text, int alignment) {
		super(parent, style);
		this.text = text;
		this.alignment = alignment;
	}

	/**
	 * Open the dialog.
	 * @return the result
	 */
	public Object open() {
		createContents();
		shell.open();
		shell.layout();
		Display display = getParent().getDisplay();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
		return result;
	}

	/**
	 * Create contents of the dialog.
	 */
	private void createContents() {
		shell = new Shell(getParent(), SWT.NONE);
		shell.setSize(363, 122);
		shell.setLocation(getParent().getBounds().x+(getParent().getBounds().width/2)-(shell.getBounds().width/2), getParent().getBounds().y+(getParent().getBounds().height/2)-(shell.getBounds().height/2));
		
		Composite composite = new Composite(shell, SWT.NONE);
		composite.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		composite.setBounds(0, 0, 360, 120);

		Composite frameTitle = new Composite(composite, SWT.NONE);
		frameTitle.setBackground(SWTResourceManager.getColor(50, 50, 50));
		frameTitle.setBounds(0, 0, shell.getBounds().width, 26);
		
		Label lblTitle = new Label(frameTitle, SWT.NONE);
		lblTitle.setForeground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblTitle.setFont(SWTResourceManager.getFont("Georgia", 8, SWT.BOLD));
		lblTitle.setBounds(5, 6, 296, 15);
		lblTitle.setBackground(SWTResourceManager.getColor(50, 50, 50));
		lblTitle.setText("Edit Text");
		
		final Label lblCloseAction = new Label(frameTitle, SWT.CENTER);
		lblCloseAction.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				shell.close();
			}
		});
		lblCloseAction.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				lblCloseAction.setBackground(SWTResourceManager.getColor(100, 100, 100));
			}
			@Override
			public void mouseExit(MouseEvent e) {
				lblCloseAction.setBackground(SWTResourceManager.getColor(50, 50, 50));
			}
		});
		lblCloseAction.setBounds(composite.getBounds().width-25, 3, 20, 20);
		lblCloseAction.setBackground(SWTResourceManager.getColor(50, 50, 50));
		lblCloseAction.setImage(new Image(shell.getDisplay(), this.getClass().getResourceAsStream("/images/close.png")));
		lblCloseAction.setToolTipText("Close Window");
		
		lblLeft = new CLabel(composite, SWT.SHADOW_OUT | SWT.CENTER);
		lblLeft.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				alignment = SWT.LEFT;
				selectAlign(alignment);
			}
		});
		lblLeft.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblLeft.setTopMargin(2);
		lblLeft.setRightMargin(2);
		lblLeft.setLeftMargin(2);
		lblLeft.setBottomMargin(2);
		lblLeft.setImage(new Image(shell.getDisplay(), this.getClass().getResourceAsStream("/images/text-align-left.png")));
		lblLeft.setBounds(10, 32, 21, 21);
		
		lblCenter = new CLabel(composite, SWT.SHADOW_OUT | SWT.CENTER);
		lblCenter.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				alignment = SWT.CENTER;
				selectAlign(alignment);
			}
		});
		lblCenter.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblCenter.setTopMargin(2);
		lblCenter.setRightMargin(2);
		lblCenter.setLeftMargin(2);
		lblCenter.setBottomMargin(2);
		lblCenter.setImage(new Image(shell.getDisplay(), this.getClass().getResourceAsStream("/images/text-align-center.png")));
		lblCenter.setBounds(32, 32, 21, 21);
		
		lblRight = new CLabel(composite, SWT.SHADOW_OUT);
		lblRight.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				alignment = SWT.RIGHT;
				selectAlign(alignment);
			}
		});
		lblRight.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblRight.setTopMargin(2);
		lblRight.setRightMargin(2);
		lblRight.setLeftMargin(2);
		lblRight.setBottomMargin(2);
		lblRight.setImage(new Image(shell.getDisplay(), this.getClass().getResourceAsStream("/images/text-align-right.png")));
		lblRight.setBounds(54, 32, 21, 21);
				
		txtText = new Text(composite, SWT.BORDER);
		txtText.setBounds(10, 57, 340, 21);
		if(text != null)
			txtText.setText(text);
		
		final CLabel lblOk = new CLabel(composite, SWT.CENTER);
		lblOk.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				text = txtText.getText();
				shell.close();
			}
		});
		lblOk.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				lblOk.setBackground(SWTResourceManager.getColor(86, 86, 86));
			}
			@Override
			public void mouseExit(MouseEvent e) {
				lblOk.setBackground(SWTResourceManager.getColor(45, 45, 45));
			}
		});
		lblOk.setBackground(SWTResourceManager.getColor(45, 45, 45));
		lblOk.setForeground(SWTResourceManager.getColor(245, 245, 245));
		lblOk.setFont(SWTResourceManager.getFont("Georgia", 9, SWT.BOLD));
		lblOk.setBounds(109, 84, 61, 26);
		lblOk.setText("OK");
		
		final CLabel lblCancel = new CLabel(composite, SWT.CENTER);
		lblCancel.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				text = null;
				shell.close();
			}
		});
		lblCancel.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				lblCancel.setBackground(SWTResourceManager.getColor(86, 86, 86));
			}
			@Override
			public void mouseExit(MouseEvent e) {
				lblCancel.setBackground(SWTResourceManager.getColor(45, 45, 45));
			}
		});
		lblCancel.setBackground(SWTResourceManager.getColor(45, 45, 45));
		lblCancel.setForeground(SWTResourceManager.getColor(245, 245, 245));
		lblCancel.setFont(SWTResourceManager.getFont("Georgia", 9, SWT.BOLD));
		lblCancel.setBounds(188, 84, 61, 26);
		lblCancel.setText("Cancel");
		
		selectAlign(alignment);
	}
	
	private void selectAlign(int align){
		lblLeft.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblCenter.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblRight.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		
		switch(align){
		case SWT.LEFT:
			lblLeft.setBackground(SWTResourceManager.getColor(SWT.COLOR_WIDGET_LIGHT_SHADOW));
			break;
		case SWT.CENTER:
			lblCenter.setBackground(SWTResourceManager.getColor(SWT.COLOR_WIDGET_LIGHT_SHADOW));
			break;
		case SWT.RIGHT:
			lblRight.setBackground(SWTResourceManager.getColor(SWT.COLOR_WIDGET_LIGHT_SHADOW));
			break;
		}
	}
	public int getAlignment(){
		return this.alignment;
	}
	
	public String getText(){
		return this.text;
	}
}
