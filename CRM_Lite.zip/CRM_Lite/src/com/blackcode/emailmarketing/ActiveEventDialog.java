package com.blackcode.emailmarketing;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.CLabel;
import org.eclipse.swt.custom.ScrolledComposite;
import org.eclipse.swt.custom.StyleRange;
import org.eclipse.swt.events.ControlAdapter;
import org.eclipse.swt.events.ControlEvent;
import org.eclipse.swt.events.MouseAdapter;
import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.events.MouseTrackAdapter;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.Cursor;
import org.eclipse.swt.graphics.Font;
import org.eclipse.swt.graphics.FontData;
import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Dialog;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.Menu;
import org.eclipse.swt.widgets.MenuItem;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.wb.swt.SWTResourceManager;
import org.eclipse.swt.custom.StyledText;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.blackcode.core.FileConvertor;

public class ActiveEventDialog extends Dialog {

	protected Object result;
	protected Shell shell;

	private Composite composite_layout, composite;
	private ScrolledComposite scrolledComposite;
	private CLabel lblTopLeftImage, lblTopRightImage, lblImage;
	private StyledText txtContent, txtSideNote;
	private CLabel selectedFrame;
	
	private int rectX, rectY, rectWidth, rectHeight;	
	private String imageDirectory = "C:\\ProgramData\\BlackCodeCRM\\EmailTemplate\\image";
	private String layoutDirectory = "C:\\ProgramData\\BlackCodeCRM\\EmailTemplate\\layout";
	private String layoutFile;
	private String templateFile;
	private Menu imageOptionMenu;
	private boolean freeze;
	/**
	 * Create the dialog.
	 * @param parent
	 * @param style
	 */
	public ActiveEventDialog(Shell parent, int style) {
		super(parent, style);
		setText("SWT Dialog");
	}
	
	public ActiveEventDialog(Shell parent, int style, String templatename) {
		super(parent, style);
		setText("Email Designer");
		templateFile = "C:\\ProgramData\\BlackCodeCRM\\EmailTemplate\\template\\"+templatename;
	}
	
	public ActiveEventDialog(Shell parent, int style, String layoutname, boolean freeze) {
		super(parent, style);
		setText("Email Designer");
		templateFile = "C:\\ProgramData\\BlackCodeCRM\\EmailTemplate\\layout\\"+layoutname;
		this.freeze = freeze;
	}

	/**
	 * Open the dialog.
	 * @return the result
	 */
	public Object open() {
		createContents();
		shell.open();
		shell.layout();
		Display display = getParent().getDisplay();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
		return result;
	}

	/**
	 * Create contents of the dialog.
	 */
	private void createContents() {
		shell = new Shell(getParent(), SWT.DIALOG_TRIM | SWT.RESIZE);
		shell.addControlListener(new ControlAdapter() {
			@Override
			public void controlResized(ControlEvent e) {
				if(scrolledComposite == null)
					return;
				
				Rectangle r = shell.getClientArea();
				scrolledComposite.setBounds(0, 0, r.width, r.height);
	            shell.redraw();
			}
		});
		shell.setSize(560, getParent().getBounds().height-80);
		shell.setLocation(getParent().getBounds().width/2-380, 40);
		shell.setText(getText());

		scrolledComposite = new ScrolledComposite(shell, SWT.BORDER | SWT.H_SCROLL | SWT.V_SCROLL);
		scrolledComposite.setBounds(0, 0, shell.getBounds().width, shell.getBounds().height);
		scrolledComposite.setExpandHorizontal(true);
		scrolledComposite.setExpandVertical(true);
		
		composite = new Composite(scrolledComposite, SWT.NONE);
		
		Composite composite_action = new Composite(composite, SWT.BORDER);
		composite_action.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		composite_action.setBounds(3, 3, 520, 41);
		composite_action.setEnabled(!freeze);
		
		final CLabel lblSave = new CLabel(composite_action, SWT.CENTER);
		lblSave.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				saveTemplate();
			}
		});
		lblSave.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				lblSave.setForeground(SWTResourceManager.getColor(255, 102, 0));
				lblSave.setCursor(new Cursor(shell.getDisplay(), SWT.CURSOR_HAND));
			}
			@Override
			public void mouseExit(MouseEvent e) {
				lblSave.setForeground(SWTResourceManager.getColor(0, 0, 0));
				lblSave.setCursor(new Cursor(shell.getDisplay(), SWT.CURSOR_ARROW));
			}
		});		
		lblSave.setBackground(SWTResourceManager.getColor(255, 215, 0));
		lblSave.setBounds(8, 8, 61, 24);
		lblSave.setText("Save");
		
		final CLabel lblPreview = new CLabel(composite_action, SWT.CENTER);
		lblPreview.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				generateHtml(false);
			}
		});
		lblPreview.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				lblPreview.setForeground(SWTResourceManager.getColor(255, 102, 0));
				lblPreview.setCursor(new Cursor(shell.getDisplay(), SWT.CURSOR_HAND));
			}
			@Override
			public void mouseExit(MouseEvent e) {
				lblPreview.setForeground(SWTResourceManager.getColor(0, 0, 0));
				lblPreview.setCursor(new Cursor(shell.getDisplay(), SWT.CURSOR_ARROW));
			}
		});		
		lblPreview.setBackground(SWTResourceManager.getColor(255, 215, 0));
		lblPreview.setBounds(70, 8, 61, 24);
		lblPreview.setText("Preview");
		
		final CLabel lblTest = new CLabel(composite_action, SWT.CENTER);
		lblTest.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				testSend();
			}
		});
		lblTest.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				lblTest.setForeground(SWTResourceManager.getColor(255, 102, 0));
				lblTest.setCursor(new Cursor(shell.getDisplay(), SWT.CURSOR_HAND));
			}
			@Override
			public void mouseExit(MouseEvent e) {
				lblTest.setForeground(SWTResourceManager.getColor(0, 0, 0));
				lblTest.setCursor(new Cursor(shell.getDisplay(), SWT.CURSOR_ARROW));
			}
		});		
		lblTest.setBackground(SWTResourceManager.getColor(255, 215, 0));
		lblTest.setBounds(132, 8, 61, 24);
		lblTest.setText("Test");
		
		composite_layout = new Composite(composite, SWT.BORDER);
		composite_layout.addListener(SWT.Paint, new Listener() {
	        public void handleEvent(Event event) {
	            GC gc = event.gc;
	            gc.setLineWidth(1);
	            gc.setLineStyle(SWT.LINE_DASH);
	            gc.drawRectangle(rectX, rectY, rectWidth, rectHeight);
	        }});
		composite_layout.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		composite_layout.setBounds(3, 55, 520,838);
		
		lblTopLeftImage = new CLabel(composite_layout, SWT.CENTER);
		lblTopLeftImage.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				lblTopLeftImage.getMenu().setVisible(true);
				selectedFrame = (CLabel)e.widget;
			}
		});
		lblTopLeftImage.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				rectX=lblTopLeftImage.getBounds().x-1;
				rectY=lblTopLeftImage.getBounds().y-1;
				rectWidth=lblTopLeftImage.getBounds().width+1;
				rectHeight=lblTopLeftImage.getBounds().height+1;
				composite_layout.redraw();
			}
			@Override
			public void mouseExit(MouseEvent e) {
				rectX=0;
				rectY=0;
				rectWidth=0;
				rectHeight=0;
				composite_layout.redraw();
			}
		});	
		lblTopLeftImage.setBottomMargin(0);
		lblTopLeftImage.setTopMargin(0);
		lblTopLeftImage.setRightMargin(0);
		lblTopLeftImage.setLeftMargin(0);
		lblTopLeftImage.setBounds(10, 5, 200, 45);
		lblTopLeftImage.setImage(new Image(shell.getDisplay(), this.getClass().getResourceAsStream("/images/pic1.jpg")));
		lblTopLeftImage.setData("topleftimage");
		
		lblTopRightImage = new CLabel(composite_layout, SWT.CENTER);
		lblTopRightImage.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				lblTopRightImage.getMenu().setVisible(true);
				selectedFrame = (CLabel)e.widget;
			}
		});
		lblTopRightImage.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				rectX=lblTopRightImage.getBounds().x-1;
				rectY=lblTopRightImage.getBounds().y-1;
				rectWidth=lblTopRightImage.getBounds().width+1;
				rectHeight=lblTopRightImage.getBounds().height+1;
				composite_layout.redraw();
			}
			@Override
			public void mouseExit(MouseEvent e) {
				rectX=0;
				rectY=0;
				rectWidth=0;
				rectHeight=0;
				composite_layout.redraw();
			}
		});	
		lblTopRightImage.setTopMargin(0);
		lblTopRightImage.setBottomMargin(0);
		lblTopRightImage.setRightMargin(0);
		lblTopRightImage.setLeftMargin(0);
		lblTopRightImage.setBounds(320, 5, 187, 45);
		lblTopRightImage.setImage(new Image(shell.getDisplay(), this.getClass().getResourceAsStream("/images/pic2.png")));
		lblTopRightImage.setData("toprightimage");
		
		lblImage = new CLabel(composite_layout, SWT.CENTER);
		lblImage.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				lblImage.getMenu().setVisible(true);
				selectedFrame = (CLabel)e.widget;
			}
		});
		lblImage.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				rectX=lblImage.getBounds().x-1;
				rectY=lblImage.getBounds().y-1;
				rectWidth=lblImage.getBounds().width+1;
				rectHeight=lblImage.getBounds().height+1;
				composite_layout.redraw();
			}
			@Override
			public void mouseExit(MouseEvent e) {
				rectX=0;
				rectY=0;
				rectWidth=0;
				rectHeight=0;
				composite_layout.redraw();
			}
		});	
		lblImage.setTopMargin(0);
		lblImage.setBottomMargin(0);
		lblImage.setRightMargin(0);
		lblImage.setLeftMargin(0);
		lblImage.setBounds(0, 65, 570, 178);
		lblImage.setImage(new Image(shell.getDisplay(), this.getClass().getResourceAsStream("/images/pic3.jpg")));
		lblImage.setData("image");
		
		txtContent = new StyledText(composite_layout, SWT.WRAP);
		txtContent.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				EditContentDialog dlg = new EditContentDialog(shell, SWT.NONE, txtContent.getText(), 
						txtContent.getData("style")==null?null:(String)txtContent.getData("style"), txtContent.getAlignment());
				dlg.open();
				
				if(dlg.getContent() == null)
					return;
				
				txtContent.setText(dlg.getContent());
				txtContent.setAlignment(dlg.getAlignment());
				if(dlg.getStyleRange() != null)
					txtContent.setStyleRanges(dlg.getStyleRange());
				txtContent.setData("style", dlg.getContentStyle());
				txtContent.redraw();
			}
		});
		txtContent.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				rectX=txtContent.getBounds().x-1;
				rectY=txtContent.getBounds().y-1;
				rectWidth=txtContent.getBounds().width+1;
				rectHeight=txtContent.getBounds().height+1;
				composite_layout.redraw();
			}
			@Override
			public void mouseExit(MouseEvent e) {
				rectX=0;
				rectY=0;
				rectWidth=0;
				rectHeight=0;
				composite_layout.redraw();
			}
		});
		txtContent.setEditable(false);
		txtContent.setBounds(10, 260, 317, 294);
		txtContent.setCursor(new Cursor(shell.getDisplay(), SWT.CURSOR_ARROW));
		
		txtSideNote = new StyledText(composite_layout, SWT.BORDER | SWT.WRAP);
		txtSideNote.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				EditContentDialog dlg = new EditContentDialog(shell, SWT.NONE, txtSideNote.getText(), 
						txtSideNote.getData("style")==null?null:(String)txtSideNote.getData("style"), txtSideNote.getAlignment());
				dlg.open();
				
				if(dlg.getContent() == null)
					return;
				
				txtSideNote.setText(dlg.getContent());
				txtSideNote.setAlignment(dlg.getAlignment());
				if(dlg.getStyleRange() != null)
					txtSideNote.setStyleRanges(dlg.getStyleRange());
				txtSideNote.setData("style", dlg.getContentStyle());
				txtSideNote.redraw();
			}
		});
		txtSideNote.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				rectX=txtSideNote.getBounds().x-1;
				rectY=txtSideNote.getBounds().y-1;
				rectWidth=txtSideNote.getBounds().width+1;
				rectHeight=txtSideNote.getBounds().height+1;
				composite_layout.redraw();
			}
			@Override
			public void mouseExit(MouseEvent e) {
				rectX=0;
				rectY=0;
				rectWidth=0;
				rectHeight=0;
				composite_layout.redraw();
			}
		});
		txtSideNote.setEditable(false);
		txtSideNote.setBounds(333, 310, 180, 188);
		txtSideNote.setCursor(new Cursor(shell.getDisplay(), SWT.CURSOR_ARROW));
		
		scrolledComposite.setBounds(0, 0, 0, 0);
		scrolledComposite.setContent(composite);
		scrolledComposite.setMinSize(composite.computeSize(SWT.DEFAULT, SWT.DEFAULT));
		
		imageOptionMenu = new Menu(composite);
		MenuItem IMNew = new MenuItem(imageOptionMenu, SWT.NONE);
		IMNew.setText("New Image");
		IMNew.addListener(SWT.Selection, new Listener() {
	        public void handleEvent(Event e) {
	        	editImage();
	          }
	        });
		MenuItem IMSize = new MenuItem(imageOptionMenu, SWT.NONE);
		IMSize.setText("Change Size");
		IMSize.addListener(SWT.Selection, new Listener() {
	        public void handleEvent(Event e) {
	        	changeSize();
	          }
	        });
		MenuItem IMLink = new MenuItem(imageOptionMenu, SWT.NONE);
		IMLink.setText("Make Link");
		IMLink.addListener(SWT.Selection, new Listener() {
	        public void handleEvent(Event e) {
	        	makeLink();
	          }
	        });
		MenuItem IMRemove = new MenuItem(imageOptionMenu, SWT.NONE);
		IMRemove.setText("Remove");
		IMRemove.addListener(SWT.Selection, new Listener() {
	        public void handleEvent(Event e) {
	        	removeImage();
	          }
	        });
			
		lblImage.setMenu(imageOptionMenu);
		lblTopLeftImage.setMenu(imageOptionMenu);
		lblTopRightImage.setMenu(imageOptionMenu);
		
		templateParser();
	}
	
	private void setImageFrame(CLabel frame, String imgFile, int x, int y, int width, int height, String url){
		try{
		if(imgFile == null){
			removeImage();
		}else{
			int[] dimension = FileConvertor.getImageDimension(imgFile);
			if(width == -1)
				width = dimension[0];
			if(height == -1)
				height = dimension[1];
			
			frame.setBounds(x, y, width, height);
			frame.setImage(resize(new Image(shell.getDisplay(), imgFile), width, height));
			
			frame.setData("img", imgFile);
			frame.setData("url", url);
		}
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	private Image resize(Image image, int width, int height) {
		Image scaled = new Image(Display.getDefault(), width, height);
		GC gc = new GC(scaled);
		gc.setAntialias(SWT.ON);
		gc.setInterpolation(SWT.HIGH);
		gc.drawImage(image, 0, 0, image.getBounds().width, image.getBounds().height, 0, 0, width, height);
		gc.dispose();
		image.dispose(); 
		return scaled;
	}
	
	private void setTextFrame(StyledText frame, String text, String style, int align){
		frame.setText(text);
		frame.setAlignment(align);
		frame.setData("style", style);
		
		if(style != null && style.length() > 0){
			String[] ranges = style.split(";");
			
			StyleRange[] col = new StyleRange[ranges.length];
			for(int i=0; i<ranges.length; i++){
				String[] styles = ranges[i].split(":");
				
				StyleRange range = new StyleRange();
				range.borderStyle = Integer.parseInt(styles[0]);
				range.fontStyle = Integer.parseInt(styles[1]);
				range.length = Integer.parseInt(styles[2]);
				range.start = Integer.parseInt(styles[3]);
				range.strikeout = styles[4].equals("false")?false:true;
				range.underline = styles[5].equals("false")?false:true;
				range.underlineStyle = Integer.parseInt(styles[6]);
				
				if(styles[7].equals("null"))
					styles[7] = "Color {0, 0, 0}";
				String[] color = styles[7].substring(7, styles[7].length()-1).split(",");
				range.foreground = new Color(Display.getCurrent (), Integer.parseInt(color[0].trim()), Integer.parseInt(color[1].trim()), Integer.parseInt(color[2].trim()));
				
				//embeded picture
				if(!styles[8].equals("null")){
				}
				
				if(styles[9].equals("null"))
					styles[9] = "{9,Serif,0}";
				String[] font = styles[9].substring(1, styles[9].length()-1).split(",");
				range.font = new Font(Display.getCurrent (), font[1], Integer.parseInt(font[0]), Integer.parseInt(font[2]));				
				
				col[i] = range;
			}
			frame.setStyleRanges(col);
		}
		frame.redraw();
	}
	
	private void editImage(){
		ImageManager dlg = new ImageManager(shell, SWT.NONE);
		dlg.open();
		
		if(dlg.getSelectedFile()==null)
			return;
				
		int y=10, x=10;
		if(selectedFrame.getData().equals("topleftimage")){
			y = 5; x=10;
		}else if(selectedFrame.getData().equals("toprightimage")){
			y = 5; x=320;
		}if(selectedFrame.getData().equals("image")){
			y = lblTopRightImage.getBounds().height;
			if(lblTopLeftImage.getBounds().height > y)
				y = lblTopLeftImage.getBounds().height;
			y += 15;x=0;
		}
				
		setImageFrame(selectedFrame, imageDirectory+"\\"+dlg.getSelectedFile(), x, y, -1, -1, (String)selectedFrame.getData("url"));
	}
	
	private void changeSize(){
		int[] size =new int[]{selectedFrame.getBounds().width, selectedFrame.getBounds().height};
		
		ChangeSizeDialog dlg = new ChangeSizeDialog(shell, SWT.NONE, size);
		dlg.open();
		
		if(dlg.getSize() == null)
			return;
		
		size = dlg.getSize();
		int y=10, x=10;
		if(selectedFrame.getData().equals("topleftimage")){
			y = 5; x=10;
		}else if(selectedFrame.getData().equals("toprightimage")){
			y = 5; x=320;
		}if(selectedFrame.getData().equals("image")){
			y = lblTopRightImage.getBounds().height+lblTopRightImage.getBounds().y;
			if((lblTopLeftImage.getBounds().height+lblTopLeftImage.getBounds().y) > y)
				y = lblTopLeftImage.getBounds().height+lblTopLeftImage.getBounds().y;
			y += 15;x=0;
		}
		
		setImageFrame(selectedFrame, (String)selectedFrame.getData("img"), x, y, size[0], size[1], (String)selectedFrame.getData("url"));
		
		rectX=0;
		rectY=0;
		rectWidth=0;
		rectHeight=0;
		composite_layout.redraw();
	}
	
	private void makeLink(){
		MakeLinkDialog dlg = new MakeLinkDialog(shell, SWT.NONE, (String)selectedFrame.getData("url"));
		dlg.open();
		
		if(dlg.getUrl() == null)
			return;
		
		selectedFrame.setData("url", dlg.getUrl());
	}
	
	private void removeImage(){
		selectedFrame.setImage(null);
		selectedFrame.setData("img", null);
		selectedFrame.setData("url", null);
	}
	
	private void resetLocation(int index){
		switch(index){
		case 1 :
			int y = lblTopLeftImage.getBounds().height+lblTopLeftImage.getBounds().y;
			if((lblTopRightImage.getBounds().height+lblTopRightImage.getBounds().y) > y)
				y = lblTopRightImage.getBounds().height+lblTopRightImage.getBounds().y;
			lblImage.setLocation(0, y+15);
		case 2 :
			txtContent.setLocation(10, lblImage.getBounds().height+lblImage.getBounds().y+15);
		case 3 :
			txtSideNote.setLocation(333, txtContent.getBounds().y+50);
		}
	}
	
	private void templateParser(){
		try{
			File file = new File(templateFile);
			
			DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
			Document doc = docBuilder.parse(file);
			
			Node template = doc.getElementsByTagName("template").item(0);
			NamedNodeMap attr = template.getAttributes();
			layoutFile = attr.getNamedItem("path").getTextContent();
			
			Node TopLeftImage = doc.getElementsByTagName("TopLeftImage").item(0);
			attr = TopLeftImage.getAttributes();
			setImageFrame(lblTopLeftImage, imageDirectory+"\\"+attr.getNamedItem("path").getTextContent(), 10, lblTopLeftImage.getBounds().height+lblTopLeftImage.getBounds().y+5, 
					parseNumber(attr.getNamedItem("width").getTextContent()), parseNumber(attr.getNamedItem("height").getTextContent()), attr.getNamedItem("url").getTextContent());
			
			Node TopRightImage = doc.getElementsByTagName("TopRightImage").item(0);
			attr = TopRightImage.getAttributes();
			setImageFrame(lblTopRightImage, imageDirectory+"\\"+attr.getNamedItem("path").getTextContent(), 320, lblTopRightImage.getBounds().height+lblTopRightImage.getBounds().y+5, 
					parseNumber(attr.getNamedItem("width").getTextContent()), parseNumber(attr.getNamedItem("height").getTextContent()), attr.getNamedItem("url").getTextContent());
			
			Node Image = doc.getElementsByTagName("Image").item(0);
			attr = Image.getAttributes();
			setImageFrame(lblImage, imageDirectory+"\\"+attr.getNamedItem("path").getTextContent(), 10, lblImage.getBounds().height+lblImage.getBounds().y+5, 
					parseNumber(attr.getNamedItem("width").getTextContent()), parseNumber(attr.getNamedItem("height").getTextContent()), attr.getNamedItem("url").getTextContent());
					
			Node content = doc.getElementsByTagName("Content").item(0);
			attr = content.getAttributes();
			NodeList list = content.getChildNodes();
			setTextFrame(txtContent, list.item(0).getTextContent(), list.item(1).getTextContent(), (int)getAlignment(attr.getNamedItem("align")));
			
			Node openingcontent = doc.getElementsByTagName("SideNote").item(0);
			attr = openingcontent.getAttributes();
			list = openingcontent.getChildNodes();
			setTextFrame(txtSideNote, list.item(0).getTextContent(), list.item(1).getTextContent(), (int)getAlignment(attr.getNamedItem("align")));
			
			resetLocation(1);
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	private Object getSize(Object size){
		try{
		if(size instanceof String){
			if(size.equals("2em"))
				return 22;
			else if(size.equals("1.5em"))
				return 18;
			else if(size.equals("1.17em"))
				return 14;
		}else if(size instanceof Integer){
			switch((int)size){
			case 22 : return "2em";
			case 18 : return "1.5em";
			case 14 : return "1.17em";
			default : return "1em";
			}
		}
		}catch(Exception e){
			e.printStackTrace();
		}
		
		return 12;
	}
	
	private Object getStyle(Object style){
		try{
		if(style instanceof String){
			if(style.equals("bold"))
				return SWT.BOLD;
			if(style.equals("italic"))
				return SWT.ITALIC;
			if(((String) style).contains("bold") && ((String) style).contains("italic"))
				return SWT.BOLD | SWT.ITALIC;
		}else if(style instanceof Integer){
			switch((int)style){
			case SWT.BOLD : return "bold";
			case SWT.ITALIC : return "italic";
			case SWT.BOLD | SWT.ITALIC : return"bold italic";
			}
		}
		}catch(Exception e){
			e.printStackTrace();
		}
		
		return SWT.NONE;
	}
	
	private Object getAlignment(Object align){
		try{
		if(align instanceof String){
			if(align.equals("center"))
				return SWT.CENTER;
			else if(align.equals("left"))
				return SWT.LEFT;
			else if(align.equals("right"))
				return SWT.RIGHT;
		}else if(align instanceof Integer){
			switch((int)align){
			case SWT.CENTER : return "center";
			case SWT.LEFT : return "left";
			case SWT.RIGHT: return "right";
			}
		}
		}catch(Exception e){
			e.printStackTrace();
		}
		
		return SWT.NONE;
	}
	
	private int parseNumber(String number){
		if(number==null || number.length()==0)
			return 0;
		
		return Integer.parseInt(number);
	}
	
	private int[] getRGB(String hex){
	    final int[] ret = new int[3];
	    hex = hex.substring(1);
	    for (int i = 0; i < 3; i++)
	        ret[i] = Integer.parseInt(hex.substring(i * 2, i * 2 + 2), 16);
	    
	    return ret;
	}
	
	private String getHex(Color rgb){
		return String.format("#%02x%02x%02x", rgb.getRed(), rgb.getGreen(), rgb.getBlue());
	}
	
	private void saveTemplate(){
		try{
			File file = new File(templateFile);
			
			DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
			Document doc = docBuilder.parse(file);
			
			Node root= doc.getFirstChild();
			NodeList nodes = root.getChildNodes();
			List<Node> col = new ArrayList<Node>();
			for (int i = 0; i < nodes.getLength(); i++) {
				Node node = nodes.item(i);
				col.add(node);
			}
			for (int i = 0; i < col.size(); i++) {
				root.removeChild(col.get(i));
			}
						
			Element TopLeftImage = createImageElement(doc.createElement("TopLeftImage"), lblTopLeftImage);
			root.appendChild(TopLeftImage);
			
			Element TopRightImage = createImageElement(doc.createElement("TopRightImage"), lblTopRightImage);
			root.appendChild(TopRightImage);
			
			Element image = createImageElement(doc.createElement("Image"), lblImage);
			root.appendChild(image);
			
			Element sidenote = createTextElement(doc.createElement("SideNote"), txtSideNote);
			root.appendChild(sidenote);
			
			Element content = createTextElement(doc.createElement("Content"), txtContent);
			root.appendChild(content);
						
			TransformerFactory transformerFactory = TransformerFactory.newInstance();
			Transformer transformer = transformerFactory.newTransformer();
			DOMSource domsource = new DOMSource(doc);
			StreamResult result = new StreamResult(file);
			transformer.transform(domsource, result);
		}catch (Exception e){
			e.printStackTrace();
		}	
	}
	
	private Element createImageElement(Element element, CLabel frame){
		element.setAttribute("path", ((String)frame.getData("img")).replace(imageDirectory+"\\", ""));
		element.setAttribute("width", frame.getBounds().width+"");
		element.setAttribute("height", frame.getBounds().height+"");
		element.setAttribute("url", (String)frame.getData("url"));
		
		return element;
	}
	/*
	private Element createTitleElement(Element element, CLabel frame){
		element.setAttribute("font", frame.getFont().getFontData()[0].getName());
		element.setAttribute("size", (String)getSize(frame.getFont().getFontData()[0].getHeight()));
		element.setAttribute("style", (String)getStyle(frame.getFont().getFontData()[0].getStyle()));
		element.setAttribute("bgcolor", getHex(frame.getBackground()));
		element.setAttribute("fgcolor", getHex(frame.getForeground()));
		element.setAttribute("align", (String)getAlignment(frame.getAlignment()));
		element.setAttribute("url", (String)frame.getData("url"));
		Element text = element.getOwnerDocument().createElement("text");
		text.appendChild(element.getOwnerDocument().createTextNode(frame.getText()));
		element.appendChild(text);
		
		return element;
	}*/
	
	private Element createTextElement(Element element, StyledText frame){
		element.setAttribute("align", (String)getAlignment(frame.getAlignment()));
		Element text = element.getOwnerDocument().createElement("text");
		text.appendChild(element.getOwnerDocument().createTextNode(frame.getText()));
		element.appendChild(text);
		Element styled = element.getOwnerDocument().createElement("styled");
		styled.appendChild(element.getOwnerDocument().createTextNode((String)frame.getData("style")));
		element.appendChild(styled);
		
		return element;
	}
	
	private Object[] generateHtml(boolean send){
				
		//generate content
		List<Object[]> embImages = new ArrayList<Object[]>();		
		String rightimagesource="",rightimagesourcesend="";
		if(lblTopRightImage.getData("img") != null){
			rightimagesource = "<img src=\""+lblTopRightImage.getData("img")+"\" width=\""+lblTopRightImage.getBounds().width+"\" height=\""+lblTopRightImage.getBounds().height+"\" border=\"0\" >";
			rightimagesourcesend = "<img src=\"cid:rightimage\" width=\""+lblTopRightImage.getBounds().width+"\" height=\""+lblTopRightImage.getBounds().height+"\" border=\"0\" >";
			if(lblTopRightImage.getData("url") != null && !lblTopRightImage.getData("url").equals("")){
				rightimagesource = "<a href=\""+lblImage.getData("url")+"\" >"+rightimagesource+"</a>";
				rightimagesourcesend = "<a href=\""+lblImage.getData("url")+"\" >"+rightimagesourcesend+"</a>";
			}
			
			embImages.add(new Object[]{"rightimage", new File((String)lblTopRightImage.getData("img"))});
		}
		String leftimagesource="",leftimagesourcesend="";
		if(lblTopLeftImage.getData("img") != null){
			leftimagesource = "<img src=\""+lblTopLeftImage.getData("img")+"\" width=\""+lblTopLeftImage.getBounds().width+"\" height=\""+lblTopLeftImage.getBounds().height+"\" border=\"0\" >";
			leftimagesourcesend = "<img src=\"cid:leftimage\" width=\""+lblTopLeftImage.getBounds().width+"\" height=\""+lblTopLeftImage.getBounds().height+"\" border=\"0\" >";
			if(lblTopLeftImage.getData("url") != null && !lblTopLeftImage.getData("url").equals("")){
				leftimagesource = "<a href=\""+lblTopLeftImage.getData("url")+"\" >"+leftimagesource+"</a>";
				leftimagesourcesend = "<a href=\""+lblTopLeftImage.getData("url")+"\" >"+leftimagesourcesend+"</a>";
			}
			
			embImages.add(new Object[]{"leftimage", new File((String)lblTopLeftImage.getData("img"))});
		}
		String imagesource="",imagesourcesend="";
		if(lblImage.getData("img") != null){
			imagesource = "<img src=\""+lblImage.getData("img")+"\" width=\""+lblImage.getBounds().width+"\" height=\""+lblImage.getBounds().height+"\" border=\"0\" >";
			imagesourcesend = "<img src=\"cid:image\" width=\""+lblImage.getBounds().width+"\" height=\""+lblImage.getBounds().height+"\" border=\"0\" >";
			if(lblImage.getData("url") != null && !lblImage.getData("url").equals("")){
				imagesource = "<a href=\""+lblImage.getData("url")+"\" >"+imagesource+"</a>";
				imagesourcesend = "<a href=\""+lblImage.getData("url")+"\" >"+imagesourcesend+"</a>";
			}
			
			embImages.add(new Object[]{"image", new File((String)lblImage.getData("img"))});
		}		
				
		String sidesource = textHtmlStyle(txtSideNote, "SideNote");
		String contentsource = textHtmlStyle(txtContent, "Content");
		
		StringBuilder contentBuilder = new StringBuilder();		
		try {
			File newhtmlfile = new File("C:\\ProgramData\\BlackCodeCRM\\EmailTemplate\\tmppreview.htm");
			FileWriter fw = new FileWriter(newhtmlfile.getAbsoluteFile());
			BufferedWriter bw = new BufferedWriter(fw);
			
		    BufferedReader in = new BufferedReader(new FileReader(layoutDirectory+"\\ActiveEvent.htm"));
		    String str;
		    while ((str = in.readLine()) != null) {
		    	if(str.contains("<div id=\"TopLeftImage\"></div>"))
		    		str = str.replace("<div id=\"TopLeftImage\"></div>", leftimagesource);
		    	if(str.contains("<div id=\"TopRightImage\"></div>"))
		    		str = str.replace("<div id=\"TopRightImage\"></div>", rightimagesource);
		    	if(str.contains("<div id=\"Image\"></div>"))
		    		str = str.replace("<div id=\"Image\"></div>", imagesource);
		    	if(str.contains("<div id=\"Content\"></div>"))
		    		str = str.replace("<div id=\"Content\"></div>", contentsource);
		    	if(str.contains("<div id=\"SideNote\"></div>"))
		    		str = str.replace("<div id=\"SideNote\"></div>", sidesource);
		    			    	
		       // contentBuilder.append(str);
		        bw.write(str);
		       
		    }
		    in.close();
		    bw.close();
		    
		    //send version
		    newhtmlfile = new File("C:\\ProgramData\\BlackCodeCRM\\EmailTemplate\\tmpsend.htm");
			fw = new FileWriter(newhtmlfile.getAbsoluteFile());
			bw = new BufferedWriter(fw);
			
		    in = new BufferedReader(new FileReader(layoutDirectory+"\\ActiveEvent.htm"));
		    while ((str = in.readLine()) != null) {
		    	if(str.contains("<div id=\"TopLeftImage\"></div>"))
		    		str = str.replace("<div id=\"TopLeftImage\"></div>", leftimagesourcesend);
		    	if(str.contains("<div id=\"TopRightImage\"></div>"))
		    		str = str.replace("<div id=\"TopRightImage\"></div>", rightimagesourcesend);
		    	if(str.contains("<div id=\"Image\"></div>"))
		    		str = str.replace("<div id=\"Image\"></div>", imagesourcesend);
		    	if(str.contains("<div id=\"Content\"></div>"))
		    		str = str.replace("<div id=\"Content\"></div>", contentsource);
		    	if(str.contains("<div id=\"SideNote\"></div>"))
		    		str = str.replace("<div id=\"SideNote\"></div>", sidesource);
		    			    	
		        contentBuilder.append(str);
		        bw.write(str);
		       
		    }
		    in.close();
		    bw.close();
		    
		    if(!send)
		    	Runtime.getRuntime().exec("rundll32 url.dll,FileProtocolHandler "+newhtmlfile); 
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		return new Object[]{contentBuilder.toString(), embImages};
	}
	
	private String textHtmlStyle(StyledText frame, String name){
		StringBuilder html = new StringBuilder();
		html.append("<div id=\""+name+"\">");
		StringBuilder text = new StringBuilder();	
		text.append(frame.getText());
				
		int readChar = 0;
		StyleRange[] ranges = frame.getStyleRanges();		
		for(int i=0; i<ranges.length; i++){
			List<String> startTags = new ArrayList<String>();
			List<String> closeTags = new ArrayList<String>();
			StyleRange range = ranges[i];
			boolean bold=true, italic=true;
			
			if(range.foreground != null){
				String hex = String.format("#%02x%02x%02x", range.foreground.getRed(), range.foreground.getGreen(), range.foreground.getBlue());
				
				if(!hex.equals("#000000")){
					startTags.add("<font color='"+hex+"'>");
					closeTags.add("</font>");
				}
			}
			
			if(range.font != null){
				FontData data = range.font.getFontData()[0];
				startTags.add("<font size='"+(data.getHeight()-7)+"' face='"+data.getName()+"'>");
				closeTags.add("</font>");
				
				if(data.getStyle() == 1){
					startTags.add("<b>");
					closeTags.add("</b>");
					bold = false;
				}else if(data.getStyle() == 2){
					startTags.add("<i>");
					closeTags.add("</i>");
					italic = false;
				}else if(data.getStyle() == 1){
					startTags.add("<b><i>");
					closeTags.add("</i></b>");
					bold = false; italic = false;
				}
			}
			
			if(bold && range.fontStyle == SWT.BOLD){
				startTags.add("<b>");
				closeTags.add("</b>");
			}
			if(italic && range.fontStyle == SWT.ITALIC){
				startTags.add("<i>");
				closeTags.add("</i>");
			}
			if(bold && italic && range.fontStyle == (SWT.ITALIC | SWT.BOLD)){
				startTags.add("<b><i>");
				closeTags.add("</i></b>");
			}
			if(range.underline){
				startTags.add("<u>");
				closeTags.add("</u>");
			}
			
			if(readChar < range.start)
				html.append(text.substring(readChar, range.start-1));
			for(int z=0; z<startTags.size(); z++)
				html.append(startTags.get(z));
			html.append(text.substring(range.start, range.start+range.length));
			for(int z=closeTags.size()-1; z>=0; z--)
				html.append(closeTags.get(z));
			readChar = range.start+range.length;
		}
		
		if(ranges.length == 0)
			html.append(frame.getText());
		
		html.append("</div>");
		return html.toString().replaceAll("\n", "</br>").replaceAll("\r", "&nbsp;&nbsp;&nbsp;&nbsp;").replaceAll("\t", "&nbsp;&nbsp;&nbsp;&nbsp;");
	}
	
	private void testSend(){
		Object[] content = generateHtml(true);
		
		TestSendDialog dlg = new TestSendDialog(shell, SWT.NONE, (String)content[0], (List)content[1]);
		dlg.open();
	}
	
	public Object[] getTemplate(){
		createContents();
		return generateHtml(true);
	}
}
