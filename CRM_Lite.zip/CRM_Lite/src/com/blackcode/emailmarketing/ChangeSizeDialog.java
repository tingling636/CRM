package com.blackcode.emailmarketing;

import org.eclipse.swt.events.MouseAdapter;
import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.events.MouseTrackAdapter;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.widgets.Dialog;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.SWT;
import org.eclipse.wb.swt.SWTResourceManager;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.custom.CLabel;

public class ChangeSizeDialog extends Dialog {

	protected Object result;
	protected Shell shell;
	private Text txtWidth;
	private Text txtHeight;

	private int[] size;
	/**
	 * Create the dialog.
	 * @param parent
	 * @param style
	 */
	public ChangeSizeDialog(Shell parent, int style) {
		super(parent, style);
		setText("SWT Dialog");
	}
	
	public ChangeSizeDialog(Shell parent, int style, int[] size) {
		super(parent, style);
		this.size = size;
	}

	/**
	 * Open the dialog.
	 * @return the result
	 */
	public Object open() {
		createContents();
		shell.open();
		shell.layout();
		Display display = getParent().getDisplay();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
		return result;
	}

	/**
	 * Create contents of the dialog.
	 */
	private void createContents() {
		shell = new Shell(getParent(), SWT.NONE);
		shell.setSize(364, 108);
		shell.setText(getText());
		shell.setLocation(getParent().getBounds().x+(getParent().getBounds().width/2)-(shell.getBounds().width/2), getParent().getBounds().y+(getParent().getBounds().height/2)-(shell.getBounds().height/2));
		
		Composite composite = new Composite(shell, SWT.NONE);
		composite.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		composite.setBounds(0, 0, 361, 107);

		Composite frameTitle = new Composite(composite, SWT.NONE);
		frameTitle.setBackground(SWTResourceManager.getColor(50, 50, 50));
		frameTitle.setBounds(0, 0, shell.getBounds().width, 26);
		
		Label lblTitle = new Label(frameTitle, SWT.NONE);
		lblTitle.setForeground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblTitle.setFont(SWTResourceManager.getFont("Georgia", 8, SWT.BOLD));
		lblTitle.setBounds(5, 6, 296, 15);
		lblTitle.setBackground(SWTResourceManager.getColor(50, 50, 50));
		lblTitle.setText("Change Size");
		
		final Label lblCloseAction = new Label(frameTitle, SWT.CENTER);
		lblCloseAction.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				shell.close();
			}
		});
		lblCloseAction.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				lblCloseAction.setBackground(SWTResourceManager.getColor(100, 100, 100));
			}
			@Override
			public void mouseExit(MouseEvent e) {
				lblCloseAction.setBackground(SWTResourceManager.getColor(50, 50, 50));
			}
		});
		lblCloseAction.setBounds(composite.getBounds().width-25, 3, 20, 20);
		lblCloseAction.setBackground(SWTResourceManager.getColor(50, 50, 50));
		lblCloseAction.setImage(new Image(shell.getDisplay(), this.getClass().getResourceAsStream("/images/close.png")));
		lblCloseAction.setToolTipText("Close Window");
		
		Label lblWidthpixe = new Label(composite, SWT.NONE);
		lblWidthpixe.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblWidthpixe.setBounds(10, 43, 77, 15);
		lblWidthpixe.setText("Width (Pixels)");
		
		txtWidth = new Text(composite, SWT.BORDER);
		txtWidth.addListener(SWT.Verify, new Listener() {
			public void handleEvent(Event e) {				
			    verifyNumberInput(e);
			}});
		txtWidth.setBounds(93, 40, 76, 21);
		if(size != null)
			txtWidth.setText(size[0]+"");
		
		Label lblHeightpixels = new Label(composite, SWT.NONE);
		lblHeightpixels.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblHeightpixels.setBounds(192, 43, 77, 15);
		lblHeightpixels.setText("Height (Pixels)");
		
		txtHeight = new Text(composite, SWT.BORDER);
		txtHeight.addListener(SWT.Verify, new Listener() {
			public void handleEvent(Event e) {				
			    verifyNumberInput(e);
			}});
		txtHeight.setBounds(275, 40, 76, 21);
		if(size != null)
			txtHeight.setText(size[1]+"");
		
		final CLabel lblOk = new CLabel(composite, SWT.CENTER);
		lblOk.setBackground(SWTResourceManager.getColor(45, 45, 45));
		lblOk.setForeground(SWTResourceManager.getColor(245, 245, 245));
		lblOk.setFont(SWTResourceManager.getFont("Georgia", 9, SWT.BOLD));
		lblOk.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				if(txtWidth.getText().length() > 0 && txtHeight.getText().length() > 0)
					size = new int[]{Integer.parseInt(txtWidth.getText()), Integer.parseInt(txtHeight.getText())};
				else
					size = null;
				shell.close();
			}
		});
		lblOk.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				lblOk.setBackground(SWTResourceManager.getColor(86, 86, 86));
			}
			@Override
			public void mouseExit(MouseEvent e) {
				lblOk.setBackground(SWTResourceManager.getColor(45, 45, 45));
			}
		});
		lblOk.setBounds(103, 76, 61, 24);
		lblOk.setText("OK");
		
		final CLabel lblCancel = new CLabel(composite, SWT.CENTER);
		lblCancel.setBackground(SWTResourceManager.getColor(45, 45, 45));
		lblCancel.setForeground(SWTResourceManager.getColor(245, 245, 245));
		lblCancel.setFont(SWTResourceManager.getFont("Georgia", 9, SWT.BOLD));
		lblCancel.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				size = null;
				shell.close();
			}
		});
		lblCancel.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				lblCancel.setBackground(SWTResourceManager.getColor(86, 86, 86));
			}
			@Override
			public void mouseExit(MouseEvent e) {
				lblCancel.setBackground(SWTResourceManager.getColor(45, 45, 45));
			}
		});
		lblCancel.setBounds(192, 76, 61, 24);
		lblCancel.setText("Cancel");
	}
	
	private void verifyNumberInput(Event e){
		String string = e.text;
		char[] chars = new char[string.length()];
	    string.getChars(0, chars.length, chars, 0);
	    for (int i = 0; i < chars.length; i++) {
	    	if (!('0' <= chars[i] && chars[i] <= '9')) {
	    		return;
	        }
	   }
	}
	
	public int[] getSize(){
		return this.size;
	}
}
