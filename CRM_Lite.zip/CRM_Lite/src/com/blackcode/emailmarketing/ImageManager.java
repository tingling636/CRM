package com.blackcode.emailmarketing;

import java.io.File;
import java.io.FilenameFilter;

import org.eclipse.swt.events.MouseAdapter;
import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.events.MouseTrackAdapter;
import org.eclipse.swt.graphics.Cursor;
import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.widgets.Dialog;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.FileDialog;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.SWT;
import org.eclipse.wb.swt.SWTResourceManager;
import org.eclipse.swt.custom.CLabel;
import org.eclipse.swt.custom.ScrolledComposite;
import org.eclipse.swt.widgets.Tree;
import org.eclipse.swt.widgets.TreeItem;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;

import com.blackcode.core.FileConvertor;

public class ImageManager extends Dialog {

	protected Object result;
	protected Shell shell;
	
	private Tree treeFolder;
	private Composite frameImage;
	private ScrolledComposite scrolledComposite;
	
	private String selectedFile;
	private String selectedFolder = "";
	static final String imageDirectory = "C:\\ProgramData\\BlackCodeCRM\\EmailTemplate\\image";
	static final File directory = new File(imageDirectory);
    static final String[] EXTENSIONS = new String[]{ "gif", "png", "bmp", "jpg" };
    static final FilenameFilter IMAGE_FILTER = new FilenameFilter() {
        @Override
        public boolean accept(final File dir, final String name) {
            for (final String ext : EXTENSIONS) {
                if (name.endsWith("." + ext)) {
                    return (true);
                }
            }
            return (false);
        }
    };
    
	/**
	 * Create the dialog.
	 * @param parent
	 * @param style
	 */
	public ImageManager(Shell parent, int style) {
		super(parent, style);
		setText("SWT Dialog");
	}

	/**
	 * Open the dialog.
	 * @return the result
	 */
	public Object open() {
		createContents();
		shell.open();
		shell.layout();
		Display display = getParent().getDisplay();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
		return result;
	}

	/**
	 * Create contents of the dialog.
	 */
	private void createContents() {
		shell = new Shell(getParent(), SWT.NONE);
		shell.setSize(623, 470);
		shell.setText(getText());
		shell.setLocation(getParent().getBounds().x+(getParent().getBounds().width/2)-(shell.getBounds().width/2), getParent().getBounds().y+(getParent().getBounds().height/2)-(shell.getBounds().height/2));
		
		Composite composite = new Composite(shell, SWT.NONE);
		composite.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		composite.setBounds(0, 0, 619, 468);

		Composite frameTitle = new Composite(composite, SWT.NONE);
		frameTitle.setBackground(SWTResourceManager.getColor(50, 50, 50));
		frameTitle.setBounds(0, 0, shell.getBounds().width, 26);
		
		Label lblTitle = new Label(frameTitle, SWT.NONE);
		lblTitle.setForeground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblTitle.setFont(SWTResourceManager.getFont("Georgia", 8, SWT.BOLD));
		lblTitle.setBounds(5, 6, 296, 15);
		lblTitle.setBackground(SWTResourceManager.getColor(50, 50, 50));
		lblTitle.setText("Image Manager");
		
		final Label lblCloseAction = new Label(frameTitle, SWT.CENTER);
		lblCloseAction.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				selectedFile = null;
				shell.close();
			}
		});
		lblCloseAction.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				lblCloseAction.setBackground(SWTResourceManager.getColor(100, 100, 100));
			}
			@Override
			public void mouseExit(MouseEvent e) {
				lblCloseAction.setBackground(SWTResourceManager.getColor(50, 50, 50));
			}
		});
		lblCloseAction.setBounds(composite.getBounds().width-25, 3, 20, 20);
		lblCloseAction.setBackground(SWTResourceManager.getColor(50, 50, 50));
		lblCloseAction.setImage(new Image(shell.getDisplay(), this.getClass().getResourceAsStream("/images/close.png")));
		lblCloseAction.setToolTipText("Close Window");
		
		scrolledComposite = new ScrolledComposite(composite, SWT.BORDER | SWT.H_SCROLL | SWT.V_SCROLL);
		scrolledComposite.setBounds(10, 32, 430, 430);
		scrolledComposite.setExpandHorizontal(true);
		scrolledComposite.setExpandVertical(true);
		
		frameImage = new Composite(scrolledComposite, SWT.NONE);
		frameImage.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
				
		CLabel lblAddNewImage = new CLabel(composite, SWT.CENTER);
		lblAddNewImage.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				FileDialog dlg = new FileDialog(new Shell(Display.getDefault()));
		        dlg.setText("Open File");
		        String dir = dlg.open();
		        if (dir != null) {
		        	FileConvertor.copyFile(dir, selectedFolder.length()>0?imageDirectory+"//"+selectedFolder:imageDirectory, null);
		        }
			}
		});
		lblAddNewImage.setBounds(480, 35, 100, 26);
		lblAddNewImage.setText("Add New Image");
		
		treeFolder = new Tree(composite, SWT.BORDER);
		treeFolder.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				selectedFolder = (String) ((TreeItem)e.item).getData("path");
				showImages(((TreeItem)e.item).getData("path"));
			}
		});
		treeFolder.setBounds(446, 80, 165, 382);
		
		showFolders();
		
		scrolledComposite.setContent(frameImage);
		scrolledComposite.setMinSize(frameImage.computeSize(SWT.DEFAULT, SWT.DEFAULT));
	}
    
	private void showFolders(){
		TreeItem trtmRoot = new TreeItem(treeFolder, SWT.NONE);
		trtmRoot.setText("Main Folder");
		trtmRoot.setData("path", "");
		
	    // get all the files from a directory
	    File[] fList = directory.listFiles();
	    for (File file : fList) {
	    	if (file.isDirectory()) {
	    		TreeItem trtm = new TreeItem(trtmRoot, SWT.NONE);
	   			trtm.setText(file.getName());
	   			trtm.setData("path", file.getName());
	        }
	    }
	    
	    trtmRoot.setExpanded(true);
	}
	
	private void showImages(Object path){
		if(path == null)
			return;
		
		frameImage.dispose();
		frameImage = new Composite(scrolledComposite, SWT.NONE);
		frameImage.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		
		int x=3,y=3;
		final File dir = new File(imageDirectory+"\\"+path.toString());
		if (dir.isDirectory()) { // make sure it's a directory
            for (final File f : dir.listFiles(IMAGE_FILTER)) {
            	String pathname = (path==""?"":(path.toString()+"\\"))+f.getName();
            	Image img = new Image(shell.getDisplay(), imageDirectory+"\\"+pathname);
            	int width = 80, height=80;
            	if(img.getImageData().width < width)
            		width = img.getImageData().width;
            	if(img.getImageData().height < height)
            		height = img.getImageData().height;
            	
            	final CLabel lblImage = new CLabel(frameImage, SWT.CENTER);
            	lblImage.addMouseListener(new MouseAdapter() {
        			@Override
        			public void mouseDown(MouseEvent e) {
        				selectedFile = (String)((CLabel)e.widget).getData();
        				shell.close();
        			}
        		});
            	lblImage.addMouseTrackListener(new MouseTrackAdapter() {
        			@Override
        			public void mouseEnter(MouseEvent e) {
        				lblImage.setCursor(new Cursor(shell.getDisplay(), SWT.CURSOR_HAND));
        			}
        			@Override
        			public void mouseExit(MouseEvent e) {
        				lblImage.setCursor(new Cursor(shell.getDisplay(), SWT.CURSOR_ARROW));
        			}
        		});		
            	lblImage.setTopMargin(0);
            	lblImage.setRightMargin(0);
            	lblImage.setLeftMargin(0);
        		lblImage.setBounds(x, y, 80, 80);
        		lblImage.setImage(resize(img, width, height));
        		lblImage.setData(pathname);
        		
        		x += 85;
        		if(x >= 345){
        			x = 3;
        			y += 85;
        		}
            }
        }
		
		frameImage.redraw();
		scrolledComposite.setContent(frameImage);
		scrolledComposite.setMinSize(frameImage.computeSize(SWT.DEFAULT, SWT.DEFAULT));
	}
	
	private Image resize(Image image, int width, int height) {
		Image scaled = new Image(Display.getDefault(), width, height);
		GC gc = new GC(scaled);
		gc.setAntialias(SWT.ON);
		gc.setInterpolation(SWT.HIGH);
		gc.drawImage(image, 0, 0, image.getBounds().width, image.getBounds().height, 0, 0, width, height);
		gc.dispose();
		image.dispose(); // don't forget about me!
		return scaled;
	}
	
	public String getSelectedFile(){
		return this.selectedFile;
	}
}
