package com.blackcode.emailmarketing;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.ColorDialog;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Dialog;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.Menu;
import org.eclipse.swt.widgets.MenuItem;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.wb.swt.SWTResourceManager;
import org.eclipse.swt.custom.CLabel;
import org.eclipse.swt.custom.ScrolledComposite;
import org.eclipse.swt.custom.StyleRange;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.custom.StyledText;
import org.eclipse.swt.events.ControlAdapter;
import org.eclipse.swt.events.ControlEvent;
import org.eclipse.swt.events.MouseAdapter;
import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.events.MouseTrackAdapter;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.Cursor;
import org.eclipse.swt.graphics.Font;
import org.eclipse.swt.graphics.FontData;
import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.graphics.RGB;
import org.eclipse.swt.graphics.Rectangle;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.blackcode.core.FileConvertor;

public class ActivePortfolioDialog extends Dialog {

	protected Object result;
	protected Shell shell;
	
	private CLabel lblTopTitle, lblImage;
	private StyledText txtDescription;
	private Label lblSeperator;
	private Composite composite_layout, composite;
	private ScrolledComposite scrolledComposite;
	private int rectX, rectY, rectWidth, rectHeight;

	private String imageDirectory = "C:\\ProgramData\\BlackCodeCRM\\EmailTemplate\\image";
	private String layoutDirectory = "C:\\ProgramData\\BlackCodeCRM\\EmailTemplate\\layout";
	private String layoutFile;
	private String templateFile;
	private Menu imageOptionMenu, titleOptionMenu;
	private CLabel selectedFrame;
	private boolean freeze;

	/**
	 * Create the dialog.
	 * @param parent
	 * @param style
	 */
	public ActivePortfolioDialog(Shell parent, int style) {
		super(parent, style);
		setText("SWT Dialog");
	}
	
	public ActivePortfolioDialog(Shell parent, int style, String templatename) {
		super(parent, style);
		setText("Email Designer");
		templateFile = "C:\\ProgramData\\BlackCodeCRM\\EmailTemplate\\template\\"+templatename;
	}
	
	public ActivePortfolioDialog(Shell parent, int style, String layoutname, boolean freeze) {
		super(parent, style);
		setText("Email Designer");
		templateFile = "C:\\ProgramData\\BlackCodeCRM\\EmailTemplate\\layout\\"+layoutname;
		this.freeze = freeze;
	}

	/**
	 * Open the dialog.
	 * @return the result
	 */
	public Object open() {
		createContents();
		shell.open();
		shell.layout();
		Display display = getParent().getDisplay();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
		return result;
	}

	/**
	 * Create contents of the dialog.
	 */
	private void createContents() {
		shell = new Shell(getParent(), SWT.DIALOG_TRIM | SWT.RESIZE);
		shell.addControlListener(new ControlAdapter() {
			@Override
			public void controlResized(ControlEvent e) {
				if(scrolledComposite == null)
					return;
				
				Rectangle r = shell.getClientArea();
				scrolledComposite.setBounds(0, 0, r.width, r.height);
	            shell.redraw();
			}
		});
		shell.setSize(560, getParent().getBounds().height-80);
		shell.setLocation(getParent().getBounds().width/2-380, 40);
		shell.setText(getText());
		
		scrolledComposite = new ScrolledComposite(shell, SWT.BORDER | SWT.H_SCROLL | SWT.V_SCROLL);
		scrolledComposite.setBounds(0, 0, shell.getBounds().width, shell.getBounds().height);
		scrolledComposite.setExpandHorizontal(true);
		scrolledComposite.setExpandVertical(true);
		
		composite = new Composite(scrolledComposite, SWT.NONE);
		
		Composite composite_action = new Composite(composite, SWT.BORDER);
		composite_action.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		composite_action.setBounds(3, 3, 520, 41);
		composite_action.setEnabled(!freeze);
		
		final CLabel lblSave = new CLabel(composite_action, SWT.CENTER);
		lblSave.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				saveTemplate();
			}
		});
		lblSave.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				lblSave.setForeground(SWTResourceManager.getColor(255, 102, 0));
				lblSave.setCursor(new Cursor(shell.getDisplay(), SWT.CURSOR_HAND));
			}
			@Override
			public void mouseExit(MouseEvent e) {
				lblSave.setForeground(SWTResourceManager.getColor(0, 0, 0));
				lblSave.setCursor(new Cursor(shell.getDisplay(), SWT.CURSOR_ARROW));
			}
		});		
		lblSave.setBackground(SWTResourceManager.getColor(255, 215, 0));
		lblSave.setBounds(8, 8, 61, 24);
		lblSave.setText("Save");
		
		final CLabel lblPreview = new CLabel(composite_action, SWT.CENTER);
		lblPreview.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				generateHtml(false);
			}
		});
		lblPreview.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				lblPreview.setForeground(SWTResourceManager.getColor(255, 102, 0));
				lblPreview.setCursor(new Cursor(shell.getDisplay(), SWT.CURSOR_HAND));
			}
			@Override
			public void mouseExit(MouseEvent e) {
				lblPreview.setForeground(SWTResourceManager.getColor(0, 0, 0));
				lblPreview.setCursor(new Cursor(shell.getDisplay(), SWT.CURSOR_ARROW));
			}
		});		
		lblPreview.setBackground(SWTResourceManager.getColor(255, 215, 0));
		lblPreview.setBounds(70, 8, 61, 24);
		lblPreview.setText("Preview");
		
		final CLabel lblTest = new CLabel(composite_action, SWT.CENTER);
		lblTest.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				testSend();
			}
		});
		lblTest.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				lblTest.setForeground(SWTResourceManager.getColor(255, 102, 0));
				lblTest.setCursor(new Cursor(shell.getDisplay(), SWT.CURSOR_HAND));
			}
			@Override
			public void mouseExit(MouseEvent e) {
				lblTest.setForeground(SWTResourceManager.getColor(0, 0, 0));
				lblTest.setCursor(new Cursor(shell.getDisplay(), SWT.CURSOR_ARROW));
			}
		});		
		lblTest.setBackground(SWTResourceManager.getColor(255, 215, 0));
		lblTest.setBounds(132, 8, 61, 24);
		lblTest.setText("Test");
		
		Label label = new Label(composite, SWT.SEPARATOR | SWT.HORIZONTAL);
		label.setBounds(3, 50, 520, 2);
		
		composite_layout = new Composite(composite, SWT.BORDER);
		composite_layout.addListener(SWT.Paint, new Listener() {
	        public void handleEvent(Event event) {
	            GC gc = event.gc;
	            gc.setLineWidth(1);
	            gc.setLineStyle(SWT.LINE_DASH);
	            gc.drawRectangle(rectX, rectY, rectWidth, rectHeight);
	        }});
		composite_layout.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		composite_layout.setBounds(3, 55, 520,838);
		
		lblTopTitle = new CLabel(composite_layout, SWT.NONE);
		lblTopTitle.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				lblTopTitle.getMenu().setVisible(true);
				selectedFrame = (CLabel)e.widget;
			}
		});
		lblTopTitle.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				rectX=lblTopTitle.getBounds().x-1;
				rectY=lblTopTitle.getBounds().y-1;
				rectWidth=lblTopTitle.getBounds().width+1;
				rectHeight=lblTopTitle.getBounds().height+1;
				composite_layout.redraw();
			}
			@Override
			public void mouseExit(MouseEvent e) {
				rectX=0;
				rectY=0;
				rectWidth=0;
				rectHeight=0;
				composite_layout.redraw();
			}
		});	
		lblTopTitle.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblTopTitle.setBounds(10, 10, 496, 38);
		
		lblSeperator = new Label(composite_layout, SWT.SEPARATOR | SWT.HORIZONTAL);
		lblSeperator.setBounds(10, 52, 496, 2);
		
		lblImage = new CLabel(composite_layout, SWT.NONE);
		lblImage.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				lblImage.getMenu().setVisible(true);
				selectedFrame = (CLabel)e.widget;
			}
		});
		lblImage.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				rectX=lblImage.getBounds().x-1;
				rectY=lblImage.getBounds().y-1;
				rectWidth=lblImage.getBounds().width+1;
				rectHeight=lblImage.getBounds().height+1;
				composite_layout.redraw();
			}
			@Override
			public void mouseExit(MouseEvent e) {
				rectX=0;
				rectY=0;
				rectWidth=0;
				rectHeight=0;
				composite_layout.redraw();
			}
		});	
		lblImage.setLeftMargin(0);
		lblImage.setRightMargin(0);
		lblImage.setTopMargin(0);
		lblImage.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblImage.setBounds(10, 65, 496, 151);
		
		txtDescription = new StyledText(composite_layout, SWT.WRAP);
		txtDescription.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				EditContentDialog dlg = new EditContentDialog(shell, SWT.NONE, txtDescription.getText(), 
						txtDescription.getData("style")==null?null:(String)txtDescription.getData("style"), txtDescription.getAlignment());
				dlg.open();
				
				if(dlg.getContent() == null)
					return;
				
				txtDescription.setText(dlg.getContent());
				txtDescription.setAlignment(dlg.getAlignment());
				if(dlg.getStyleRange() != null)
					txtDescription.setStyleRanges(dlg.getStyleRange());
				txtDescription.setData("style", dlg.getContentStyle());
				txtDescription.redraw();
			}
		});
		txtDescription.addMouseTrackListener(new MouseTrackAdapter() {
			@Override
			public void mouseEnter(MouseEvent e) {
				rectX=txtDescription.getBounds().x-1;
				rectY=txtDescription.getBounds().y-1;
				rectWidth=txtDescription.getBounds().width+1;
				rectHeight=txtDescription.getBounds().height+1;
				composite_layout.redraw();
			}
			@Override
			public void mouseExit(MouseEvent e) {
				rectX=0;
				rectY=0;
				rectWidth=0;
				rectHeight=0;
				composite_layout.redraw();
			}
		});
		txtDescription.setEditable(false);
		txtDescription.setSize(496, 195);
		txtDescription.setCursor(new Cursor(shell.getDisplay(), SWT.CURSOR_ARROW));

		scrolledComposite.setBounds(0, 0, 0, 0);
		scrolledComposite.setContent(composite);
		scrolledComposite.setMinSize(composite.computeSize(SWT.DEFAULT, SWT.DEFAULT));
		
		//Menu
		imageOptionMenu = new Menu(composite);
		MenuItem IMNew = new MenuItem(imageOptionMenu, SWT.NONE);
		IMNew.setText("New Image");
		IMNew.addListener(SWT.Selection, new Listener() {
	        public void handleEvent(Event e) {
	        	editImage();
	          }
	        });
		MenuItem IMSize = new MenuItem(imageOptionMenu, SWT.NONE);
		IMSize.setText("Change Size");
		IMSize.addListener(SWT.Selection, new Listener() {
	        public void handleEvent(Event e) {
	        	changeSize();
	          }
	        });
		MenuItem IMLink = new MenuItem(imageOptionMenu, SWT.NONE);
		IMLink.setText("Make Link");
		IMLink.addListener(SWT.Selection, new Listener() {
	        public void handleEvent(Event e) {
	        	makeLink();
	          }
	        });
		MenuItem IMRemove = new MenuItem(imageOptionMenu, SWT.NONE);
		IMRemove.setText("Remove");
		IMRemove.addListener(SWT.Selection, new Listener() {
	        public void handleEvent(Event e) {
	        	removeImage();
	          }
	        });
		
		titleOptionMenu = new Menu(composite);
		MenuItem TMLink = new MenuItem(titleOptionMenu, SWT.NONE);
		TMLink.setText("Make Link");
		TMLink.addListener(SWT.Selection, new Listener() {
	        public void handleEvent(Event e) {
	        	makeLink();
	          }
	        });
		MenuItem TMTextColor = new MenuItem(titleOptionMenu, SWT.NONE);
		TMTextColor.setText("Text Color");
		TMTextColor.addListener(SWT.Selection, new Listener() {
	        public void handleEvent(Event e) {
	        	changeTextColor();
	          }
	        });
		MenuItem TMAlign = new MenuItem(titleOptionMenu, SWT.NONE);
		TMAlign.setText("Edit");
		TMAlign.addListener(SWT.Selection, new Listener() {
	        public void handleEvent(Event e) {
	        	editText();
	          }
	        });		
		
		lblTopTitle.setMenu(titleOptionMenu);
		lblImage.setMenu(imageOptionMenu);
		
		templateParser();
	}
	
	private void setImageFrame(CLabel frame, String imgFile, int x, int y, int width, int height, String url){
		try{
		if(imgFile == null){
			removeImage();
		}else{
			int[] dimension = FileConvertor.getImageDimension(imgFile);
			if(width == -1)
				width = dimension[0];
			if(height == -1)
				height = dimension[1];
			
			frame.setBounds(x, y, width, height);
			frame.setImage(resize(new Image(shell.getDisplay(), imgFile), width, height));
			
			frame.setData("img", imgFile);
			frame.setData("url", url);
		}
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	private Image resize(Image image, int width, int height) {
		Image scaled = new Image(Display.getDefault(), width, height);
		GC gc = new GC(scaled);
		gc.setAntialias(SWT.ON);
		gc.setInterpolation(SWT.HIGH);
		gc.drawImage(image, 0, 0, image.getBounds().width, image.getBounds().height, 0, 0, width, height);
		gc.dispose();
		image.dispose(); 
		return scaled;
	}
	
	private void setTitleFrame(CLabel frame, String text, int[] bgColor, int[] fgColor, String fontName, int size, int style, int align, String url){
		frame.setFont(SWTResourceManager.getFont(fontName, size, style));
		frame.setForeground(SWTResourceManager.getColor(fgColor[0], fgColor[1], fgColor[2]));
		frame.setBackground(SWTResourceManager.getColor(bgColor[0], bgColor[1], bgColor[2]));
		frame.setAlignment(align);
		frame.setText(text);
		frame.setData("url", url);
	}
	
	private void setTextFrame(StyledText frame, String text, String style, int align){
		frame.setText(text);
		frame.setAlignment(align);
		frame.setData("style", style);
		
		if(style != null && style.length() > 0){
			String[] ranges = style.split(";");
			
			StyleRange[] col = new StyleRange[ranges.length];
			for(int i=0; i<ranges.length; i++){
				String[] styles = ranges[i].split(":");
				
				StyleRange range = new StyleRange();
				range.borderStyle = Integer.parseInt(styles[0]);
				range.fontStyle = Integer.parseInt(styles[1]);
				range.length = Integer.parseInt(styles[2]);
				range.start = Integer.parseInt(styles[3]);
				range.strikeout = styles[4].equals("false")?false:true;
				range.underline = styles[5].equals("false")?false:true;
				range.underlineStyle = Integer.parseInt(styles[6]);
				
				if(styles[7].equals("null"))
					styles[7] = "Color {0, 0, 0}";
				String[] color = styles[7].substring(7, styles[7].length()-1).split(",");
				range.foreground = new Color(Display.getCurrent (), Integer.parseInt(color[0].trim()), Integer.parseInt(color[1].trim()), Integer.parseInt(color[2].trim()));
				
				//embeded picture
				if(!styles[8].equals("null")){
				}
				
				if(styles[9].equals("null"))
					styles[9] = "{9,Serif,0}";
				String[] font = styles[9].substring(1, styles[9].length()-1).split(",");
				range.font = new Font(Display.getCurrent (), font[1], Integer.parseInt(font[0]), Integer.parseInt(font[2]));				
				
				col[i] = range;
			}
			frame.setStyleRanges(col);
		}
		frame.redraw();
	}
	
	private void editImage(){
		ImageManager dlg = new ImageManager(shell, SWT.NONE);
		dlg.open();
		
		if(dlg.getSelectedFile()==null)
			return;
		
		int y = lblSeperator.getBounds().height+lblSeperator.getBounds().y+5, x = 1;
				
		setImageFrame(selectedFrame, imageDirectory+"\\"+dlg.getSelectedFile(), x, y, -1, -1, (String)selectedFrame.getData("url"));
	}
	
	private void changeSize(){
		int[] size =new int[]{selectedFrame.getBounds().width, selectedFrame.getBounds().height};
		
		ChangeSizeDialog dlg = new ChangeSizeDialog(shell, SWT.NONE, size);
		dlg.open();
		
		if(dlg.getSize() == null)
			return;
		
		size = dlg.getSize();
		int y = lblSeperator.getBounds().height+lblSeperator.getBounds().y+5, x = 10;
		
		setImageFrame(selectedFrame, (String)selectedFrame.getData("img"), x, y, size[0], size[1], (String)selectedFrame.getData("url"));
		
		rectX=0;
		rectY=0;
		rectWidth=0;
		rectHeight=0;
		composite_layout.redraw();
	}
	
	private void makeLink(){
		MakeLinkDialog dlg = new MakeLinkDialog(shell, SWT.NONE, (String)selectedFrame.getData("url"));
		dlg.open();
		
		if(dlg.getUrl() == null)
			return;
		
		selectedFrame.setData("url", dlg.getUrl());
	}
	
	private void removeImage(){
		selectedFrame.setImage(null);
		selectedFrame.setData("img", null);
		selectedFrame.setData("url", null);
	}
	
	private void changeTextColor(){
		ColorDialog cd = new ColorDialog(shell);
        cd.setText("ColorDialog Demo");
        cd.setRGB(new RGB(255, 255, 255));
        RGB newColor = cd.open();
        if (newColor == null) 
          return;
        
       selectedFrame.setForeground(SWTResourceManager.getColor(newColor.red, newColor.green, newColor.blue));
	}
	
	private void editText(){
		 String text = selectedFrame.getText(); 
		 int align = (int)selectedFrame.getAlignment(); 
		
		EditTitleDialog dlg = new EditTitleDialog(shell, SWT.NONE, text, align);
		dlg.open();
		
		if(dlg.getText() == null)
			return;
		
		selectedFrame.setText(dlg.getText());
		selectedFrame.setAlignment(dlg.getAlignment());
		selectedFrame.setData("align", dlg.getAlignment());
	}
	
	private void resetLocation(int index){
		switch(index){
		case 1 :
			lblSeperator.setLocation(10, lblTopTitle.getBounds().height+lblTopTitle.getBounds().y+5);
		case 2 :
			lblImage.setLocation(10, lblSeperator.getBounds().height+lblSeperator.getBounds().y+5);
		case 3 :
			txtDescription.setLocation(10, lblImage.getBounds().height+lblImage.getBounds().y+10);
		}
	}
	
	//Template Parser
	private void templateParser(){
		try{
			File file = new File(templateFile);
			
			DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
			Document doc = docBuilder.parse(file);
			
			Node template = doc.getElementsByTagName("template").item(0);
			NamedNodeMap attr = template.getAttributes();
			layoutFile = attr.getNamedItem("path").getTextContent();
			
			Node title = doc.getElementsByTagName("title").item(0);
			Node child = title.getFirstChild();
			attr = title.getAttributes();
			setTitleFrame(lblTopTitle, child.getTextContent(), getRGB(attr.getNamedItem("bgcolor").getTextContent()), getRGB(attr.getNamedItem("fgcolor").getTextContent()), 
					attr.getNamedItem("font").getTextContent(), (int)getSize(attr.getNamedItem("size").getTextContent()), (int)getStyle(attr.getNamedItem("style").getTextContent()),
					(int)getAlignment(attr.getNamedItem("align").getTextContent()), attr.getNamedItem("url").getTextContent());
			
			Node header = doc.getElementsByTagName("header").item(0);
			attr = header.getAttributes();
			setImageFrame(lblImage, imageDirectory+"\\"+attr.getNamedItem("path").getTextContent(), 10, lblImage.getBounds().height+lblImage.getBounds().y+5, 
					parseNumber(attr.getNamedItem("width").getTextContent()), parseNumber(attr.getNamedItem("height").getTextContent()), attr.getNamedItem("url").getTextContent());
			
			Node openingcontent = doc.getElementsByTagName("description").item(0);
			attr = openingcontent.getAttributes();
			NodeList list = openingcontent.getChildNodes();
			setTextFrame(txtDescription, list.item(0).getTextContent(), list.item(1).getTextContent(), (int)getAlignment(attr.getNamedItem("align")));
			
			resetLocation(1);
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	private Object getSize(Object size){
		try{
		if(size instanceof String){
			if(size.equals("2em"))
				return 22;
			else if(size.equals("1.5em"))
				return 18;
			else if(size.equals("1.17em"))
				return 14;
		}else if(size instanceof Integer){
			switch((int)size){
			case 22 : return "2em";
			case 18 : return "1.5em";
			case 14 : return "1.17em";
			default : return "1em";
			}
		}
		}catch(Exception e){
			e.printStackTrace();
		}
		
		return 12;
	}
	
	private Object getStyle(Object style){
		try{
		if(style instanceof String){
			if(style.equals("bold"))
				return SWT.BOLD;
			if(style.equals("italic"))
				return SWT.ITALIC;
			if(((String) style).contains("bold") && ((String) style).contains("italic"))
				return SWT.BOLD | SWT.ITALIC;
		}else if(style instanceof Integer){
			switch((int)style){
			case SWT.BOLD : return "bold";
			case SWT.ITALIC : return "italic";
			case SWT.BOLD | SWT.ITALIC : return"bold italic";
			}
		}
		}catch(Exception e){
			e.printStackTrace();
		}
		
		return SWT.NONE;
	}
	
	private Object getAlignment(Object align){
		try{
		if(align instanceof String){
			if(align.equals("center"))
				return SWT.CENTER;
			else if(align.equals("left"))
				return SWT.LEFT;
			else if(align.equals("right"))
				return SWT.RIGHT;
		}else if(align instanceof Integer){
			switch((int)align){
			case SWT.CENTER : return "center";
			case SWT.LEFT : return "left";
			case SWT.RIGHT: return "right";
			}
		}
		}catch(Exception e){
			e.printStackTrace();
		}
		
		return SWT.NONE;
	}
	
	private int parseNumber(String number){
		if(number==null || number.length()==0)
			return 0;
		
		return Integer.parseInt(number);
	}
	
	private int[] getRGB(String hex){
	    final int[] ret = new int[3];
	    hex = hex.substring(1);
	    for (int i = 0; i < 3; i++)
	        ret[i] = Integer.parseInt(hex.substring(i * 2, i * 2 + 2), 16);
	    
	    return ret;
	}
	
	private String getHex(Color rgb){
		return String.format("#%02x%02x%02x", rgb.getRed(), rgb.getGreen(), rgb.getBlue());
	}
	
	private void saveTemplate(){
		try{
			File file = new File(templateFile);
			
			DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
			Document doc = docBuilder.parse(file);
			
			Node root= doc.getFirstChild();
			NodeList nodes = root.getChildNodes();
			List<Node> col = new ArrayList<Node>();
			for (int i = 0; i < nodes.getLength(); i++) {
				Node node = nodes.item(i);
				col.add(node);
			}
			for (int i = 0; i < col.size(); i++) {
				root.removeChild(col.get(i));
			}
						
			Element title = createTitleElement(doc.createElement("title"), lblTopTitle);
			root.appendChild(title);
			
			Element header = createImageElement(doc.createElement("header"), lblImage);
			root.appendChild(header);
			
			Element description = createTextElement(doc.createElement("description"), txtDescription);
			root.appendChild(description);
						
			TransformerFactory transformerFactory = TransformerFactory.newInstance();
			Transformer transformer = transformerFactory.newTransformer();
			DOMSource domsource = new DOMSource(doc);
			StreamResult result = new StreamResult(file);
			transformer.transform(domsource, result);
		}catch (Exception e){
			e.printStackTrace();
		}	
	}
	
	private Element createImageElement(Element element, CLabel frame){
		element.setAttribute("path", ((String)frame.getData("img")).replace(imageDirectory+"\\", ""));
		element.setAttribute("width", frame.getBounds().width+"");
		element.setAttribute("height", frame.getBounds().height+"");
		element.setAttribute("url", (String)frame.getData("url"));
		
		return element;
	}
	
	private Element createTitleElement(Element element, CLabel frame){
		element.setAttribute("font", frame.getFont().getFontData()[0].getName());
		element.setAttribute("size", (String)getSize(frame.getFont().getFontData()[0].getHeight()));
		element.setAttribute("style", (String)getStyle(frame.getFont().getFontData()[0].getStyle()));
		element.setAttribute("bgcolor", getHex(frame.getBackground()));
		element.setAttribute("fgcolor", getHex(frame.getForeground()));
		element.setAttribute("align", (String)getAlignment(frame.getAlignment()));
		element.setAttribute("url", (String)frame.getData("url"));
		Element text = element.getOwnerDocument().createElement("text");
		text.appendChild(element.getOwnerDocument().createTextNode(frame.getText()));
		element.appendChild(text);
		
		return element;
	}
	
	private Element createTextElement(Element element, StyledText frame){
		element.setAttribute("align", (String)getAlignment(frame.getAlignment()));
		Element text = element.getOwnerDocument().createElement("text");
		text.appendChild(element.getOwnerDocument().createTextNode(frame.getText()));
		element.appendChild(text);
		Element styled = element.getOwnerDocument().createElement("styled");
		styled.appendChild(element.getOwnerDocument().createTextNode((String)frame.getData("style")));
		element.appendChild(styled);
		
		return element;
	}
	
	private Object[] generateHtml(boolean send){
		//generate display style
		String titlestyle = "font:"+getSize(lblTopTitle.getFont().getFontData()[0].getHeight())+" "+getStyle(lblTopTitle.getFont().getFontData()[0].getStyle())+" "+lblTopTitle.getFont().getFontData()[0].getName()+";"
				+ "color:"+getHex(lblTopTitle.getForeground())+"; text-align:"+getAlignment(lblTopTitle.getAlignment())+";";
		
		String htmlhead = "<head>\n"
				+ "<style>"
				+ "div.wrapper, table.wrapper {width:100%;}"
				+ "table.table_wrapper {line-height:17px; background-color:##f6f9fc;}"
				+ "table.title { "+titlestyle+"}"
				+ "</style>\n";
		
		//generate content
		List<Object[]> embImages = new ArrayList<Object[]>();		
		String headersource="",headersourcesend="";
		if(lblImage.getData("img") != null){
			headersource = "<img src=\""+lblImage.getData("img")+"\" width=\""+lblImage.getBounds().width+"\" height=\""+lblImage.getBounds().height+"\" border=\"0\" >";
			headersourcesend = "<img src=\"cid:header\" width=\""+lblImage.getBounds().width+"\" height=\""+lblImage.getBounds().height+"\" border=\"0\" >";
			if(lblImage.getData("url") != null && !lblImage.getData("url").equals("")){
				headersource = "<a href=\""+lblImage.getData("url")+"\" >"+headersource+"</a>";
				headersourcesend = "<a href=\""+lblImage.getData("url")+"\" >"+headersourcesend+"</a>";
			}
			
			embImages.add(new Object[]{"header", new File((String)lblImage.getData("img"))});
		}		
				
		String titlesource = "<div id=\"title\">"+lblTopTitle.getText()+"</div>";
		String descriptionsource = textHtmlStyle(txtDescription, "description");
		
		StringBuilder contentBuilder = new StringBuilder();		
		try {
			File newhtmlfile = new File("C:\\ProgramData\\BlackCodeCRM\\EmailTemplate\\tmppreview.htm");
			FileWriter fw = new FileWriter(newhtmlfile.getAbsoluteFile());
			BufferedWriter bw = new BufferedWriter(fw);
			
		    BufferedReader in = new BufferedReader(new FileReader(layoutDirectory+"\\ActivePortfolio.htm"));
		    String str;
		    while ((str = in.readLine()) != null) {
		    	if(str.contains("<div id=\"title\"></div>"))
		    		str = str.replace("<div id=\"title\"></div>", titlesource);
		    	if(str.contains("<div id=\"header\"></div>"))
		    		str = str.replace("<div id=\"header\"></div>", headersource);
		    	if(str.contains("<div id=\"description\"></div>"))
		    		str = str.replace("<div id=\"description\"></div>", descriptionsource);
		    			    	
		        bw.write(str);
		        
		        if(str.equalsIgnoreCase("<html>")){
		        	contentBuilder.append(htmlhead);
		        	bw.write(htmlhead);
		        }
		    }
		    in.close();
		    bw.close();
		    
		    //send version
		    newhtmlfile = new File("C:\\ProgramData\\BlackCodeCRM\\EmailTemplate\\tmpsend.htm");
			fw = new FileWriter(newhtmlfile.getAbsoluteFile());
			bw = new BufferedWriter(fw);
			
		    in = new BufferedReader(new FileReader(layoutDirectory+"\\ActivePortfolio.htm"));
		    while ((str = in.readLine()) != null) {
		    	if(str.contains("<div id=\"title\"></div>"))
		    		str = str.replace("<div id=\"title\"></div>", titlesource);
		    	if(str.contains("<div id=\"header\"></div>"))
		    		str = str.replace("<div id=\"header\"></div>", headersource);
		    	if(str.contains("<div id=\"description\"></div>"))
		    		str = str.replace("<div id=\"description\"></div>", descriptionsource);
		    			    	
		        contentBuilder.append(str);
		        bw.write(str);
		        
		        if(str.equalsIgnoreCase("<html>")){
		        	contentBuilder.append(htmlhead);
		        	bw.write(htmlhead);
		        }
		    }
		    in.close();
		    bw.close();
		    
		    if(!send)
		    	Runtime.getRuntime().exec("rundll32 url.dll,FileProtocolHandler "+newhtmlfile); 
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		return new Object[]{contentBuilder.toString(), embImages};
	}
	
	private String textHtmlStyle(StyledText frame, String name){
		StringBuilder html = new StringBuilder();
		html.append("<div id=\""+name+"\">");
		StringBuilder text = new StringBuilder();	
		text.append(frame.getText());
				
		int readChar = 0;
		StyleRange[] ranges = frame.getStyleRanges();		
		for(int i=0; i<ranges.length; i++){
			List<String> startTags = new ArrayList<String>();
			List<String> closeTags = new ArrayList<String>();
			StyleRange range = ranges[i];
			boolean bold=true, italic=true;
			
			if(range.foreground != null){
				String hex = String.format("#%02x%02x%02x", range.foreground.getRed(), range.foreground.getGreen(), range.foreground.getBlue());
				
				if(!hex.equals("#000000")){
					startTags.add("<font color='"+hex+"'>");
					closeTags.add("</font>");
				}
			}
			
			if(range.font != null){
				FontData data = range.font.getFontData()[0];
				startTags.add("<font size='"+(data.getHeight()-7)+"' face='"+data.getName()+"'>");
				closeTags.add("</font>");
				
				if(data.getStyle() == 1){
					startTags.add("<b>");
					closeTags.add("</b>");
					bold = false;
				}else if(data.getStyle() == 2){
					startTags.add("<i>");
					closeTags.add("</i>");
					italic = false;
				}else if(data.getStyle() == 1){
					startTags.add("<b><i>");
					closeTags.add("</i></b>");
					bold = false; italic = false;
				}
			}
			
			if(bold && range.fontStyle == SWT.BOLD){
				startTags.add("<b>");
				closeTags.add("</b>");
			}
			if(italic && range.fontStyle == SWT.ITALIC){
				startTags.add("<i>");
				closeTags.add("</i>");
			}
			if(bold && italic && range.fontStyle == (SWT.ITALIC | SWT.BOLD)){
				startTags.add("<b><i>");
				closeTags.add("</i></b>");
			}
			if(range.underline){
				startTags.add("<u>");
				closeTags.add("</u>");
			}
			
			if(readChar < range.start)
				html.append(text.substring(readChar, range.start-1));
			for(int z=0; z<startTags.size(); z++)
				html.append(startTags.get(z));
			html.append(text.substring(range.start, range.start+range.length));
			for(int z=closeTags.size()-1; z>=0; z--)
				html.append(closeTags.get(z));
			readChar = range.start+range.length;
		}
		
		if(ranges.length == 0)
			html.append(frame.getText());
		
		html.append("</div>");
		return html.toString().replaceAll("\n", "</br>").replaceAll("\r", "&nbsp;&nbsp;&nbsp;&nbsp;").replaceAll("\t", "&nbsp;&nbsp;&nbsp;&nbsp;");
	}
	
	private void testSend(){
		Object[] content = generateHtml(true);
		
		TestSendDialog dlg = new TestSendDialog(shell, SWT.NONE, (String)content[0], (List)content[1]);
		dlg.open();
	}

	public Object[] getTemplate(){
		createContents();
		return generateHtml(true);
	}
}
